# Filipino P0 + P1 linguistic review

## Result

The entire **341 typed-key batch** was reviewed: **92 P0 + 249 P1**. Every entry includes the complete English and Filipino values, exact hashes, an individual linguistic rationale, source-consumer evidence, a disposition and explicit limits. This is model-based linguistic and static-source review, not a structural check presented as linguistic certification.

Current priority dispositions:

- **301** current values retained within inspected static-consumer context.
- **29** current values retained for wording only because no direct production consumer was found.
- **2** exact prior priority pairs carried with their original bounded receipts.
- **5** priority wording corrections proposed.
- **3** priority edge labels are correct alone but their composed crop hints need the two shared-template corrections below.
- **1** composed-idiom context hold remains unknown, not a confirmed failure.

Thus **332/341 current priority pairs are retained with bounded scope**, and all **341/341 have review dispositions**. The core candidate changes **7 XML values: 5 priority values + 2 P2 dependency templates**. If applied exactly, it would resolve eight priority dispositions, leaving **340 bounded priority dispositions and one unknown-context hold**. This does not mean Filipino, native fluency, UI or accessibility is certified.

Five separate optional editorial suggestions are not classified as current translation failures and are not in the core candidate patch.

## Exact source binding

- Reviewed tree: `b9b148d5d8ef7c7b088500a9c177f9f59304b800`.
- Observed local HEAD: `ddffe57016c689b2a7868c31e415dcb625f5c6b5`.
- The local HEAD's tree exactly matches the assigned tree; the source worktree was clean before and after this review.
- English: `Paintroid/src/main/res/values/strings.xml`.
- Filipino: `Paintroid/src/main/res/values-b+fil/strings.xml`.
- Priority manifest: `translations/string-importance.json`.

The parent reports later develop references `ef46e8aa/c96f9708` with Fit/status-only changes and no resource changes. This worker did not fetch or independently verify those later trees. The review is bound to the exact tree and per-value/source-file hashes above, not silently rebound to later consumers. The earlier package's develop SHA `4355869e2e198b5616419291cba225b018444fab` is not an available local Git object and is not represented as independently verified here.

The source has 717 translatable typed entries. Three English-only resource constants are explicitly non-translatable and are not falsely counted as missing Filipino entries.

## Core proposed corrections

1. `gallery_credit_too_large`: replace the ambiguous “make too large in order to restore” relation with an explicit condition that adding these credits would make the drawing too large to restore. Keep the previous drawing/credits preservation assurance.
2. `ui_keeps_pixels_at_the_top_left_smaller_canvas`: clarify right/bottom edge loss, use an inanimate reference for pixels, and retain top-left anchoring and the exact `Ibalik` undo action.
3. `colour_truncated_metadata`: describe truncation of the image file, instead of the literal “image ends inside metadata.” The inspected source encounters premature EOF; no cause or recovery promise is invented.
4. `ui_crop_preview_drag_an_edge_or_corner_drag`: use `i-drag sa loob nito` to express where to drag, rather than making the inside itself the object.
5. `ui_edit_transform33`: use `Paikutin`, matching the adjacent actual Rotate command, instead of the less precise `Ikutin`.

These are targeted semantic-clarity, idiom and command-precision proposals, not claims that every current string is incomprehensible or a runtime failure.

## Required shared dependencies

The current crop hints combine bare directional labels into phrases such as `Kaliwa na bawas sa pixels`. The candidate uses:

- `ui_trim_in_pixels`: `Bawas sa %1$s (pixels)`
- `ui_trim_in_percent`: `Bawas sa %1$s (porsiyento)`

Apply these two templates together. They resolve composed hints for the priority labels Left, Right and Bottom, while also supporting the unchanged non-priority Top label. The two P2 dependencies are separate from the 341-key tally; this is not a full P2 review claim. The labels themselves are not rewritten.

## Remaining unknown-context hold

`ui_foreground_background_colour_palette` retains its three numbered arguments, but `%3$s paleta ng kulay` may need a Filipino linker depending on the exact state phrase supplied. No direct production consumer or actual third-argument domain was found in the reviewed tree. The review therefore does not invent a replacement or assert a confirmed malformed runtime string. Its composed idiom remains unknown.

“No direct consumer found” is only a bounded static-search result, not proof that a resource can never be used dynamically or indirectly.

## Optional editorial proposals

`optional-refinements.json` and `filipino-optional-refinements.patch` are separate from the core candidate:

- Restore the ellipsis in the `ui_save_a5d0d9` Save alias.
- Harmonize `lona` to the catalogue's existing `canvas` term in the SVG warning and Canvas category.
- Restore the explicit pixel-count label and avoid a fixed English plural after the number.
- Avoid the mildly awkward inanimate `sila` in the full-image memory warning.

The optional-refinements patch targets the original source. If the core patch has already been applied, use `filipino-optional-after-core.patch` instead because nearby patch context overlaps. Do not apply both optional patches. Exact before hashes remain mandatory.

These five current values already preserve their source meanings. Optional polish does not increase the number of confirmed errors, does not lift any context hold and is not required to apply the core patch.

## Prior receipts and catalogue accounting

All **22** mapped prior Filipino receipts still match both English and Filipino exact hashes. Two overlap the priority batch: `save20_unsupported_image_colour` and `ui_sampled_resize_memory_explanation`. The other twenty remain separate. The package embeds all union receipts, available original receipts, later-cohort receipts and their caveats without promoting them to broader acceptance. In particular, earlier code-switching, credit-term, native-review and layout caveats remain in force.

Including the two explicit P2 dependency findings, the current 717-entry catalogue partition is:

- **352** current bounded dispositions: 332 priority + 20 non-overlapping prior pairs.
- **11** known pending/context-hold entries: 5 priority proposals + 3 dependent priority labels + 1 unknown priority composition + 2 P2 dependency templates.
- **354** present but outside current mapped review coverage.
- **0** missing.

This is a reconciliation of the exact supplied evidence, not a claim that no other historical review can exist.

## Verification and limitations

Completed:

- Exact 341-key manifest reconciliation and per-key complete-value review.
- Independent production scan of exact `R.string` / `@string` references in `Paintroid/src/main`, excluding translated value catalogues: 311 direct-consumer keys and 30 without direct consumers.
- Context inspection of animation lower-bound counts, dimensions/units, crop edges, tool/category announcements, colour hex values, memory-message concatenation, and menu navigation labels.
- Rebinding all 22 historical pairs without changing their scopes.
- XML parse, original/candidate placeholder-signature comparison, identity/attribute preservation and exactly seven core changes.
- Core and optional patch dry runs and application in disposable artifact copies only, including combined applicability; exact comparison to expected content.
- Original source catalogue hashes and clean source worktree verified after review.

Not run: builds, Gradle, compilation, APK generation, CI, device/emulator, installed UI, TalkBack, native-human review, version changes, publication, release, PR creation or merging. The illustrative compositions are not Android/JVM formatter tests. Structural checks establish artifact integrity, not linguistic correctness, font support, usable layout or speech quality.

The source catalogue was not edited. The parent owns durable repository integration. PR #56 remains an intentional draft tracker and must never be merged.

## Files

- `filipino-p0-p1-review.json`: authoritative full ledger and dependencies.
- `filipino-p0-p1-review.csv`: flat complete-value ledger.
- `source-bindings.json`: exact source, manifest and per-pair hashes.
- `prior-22-exact-pairs.json`: all prior pairs and original scope/caveats.
- `proposed-corrections.json`: seven exact core proposals, reasons and consumers.
- `filipino-priority-candidate.patch`: core proposal, unapplied to source.
- `candidate/Paintroid/src/main/res/values-b+fil/strings.xml`: complete core-candidate catalogue, separate from source.
- `optional-refinements.json` and `filipino-optional-refinements.patch`: five optional improvements, separate from the core patch.
- `filipino-optional-after-core.patch`: the same five optional edits, explicitly based on the core candidate rather than the original source.
- `static-composition-examples.json`: source-composed string illustrations.
- `validation.json`: bounded mechanical outcomes and explicit non-executed stages.
- `review-notes.txt`: the 341 individually authored review rationales.
