import collections,csv,difflib,hashlib,json,pathlib,re,shutil,subprocess,xml.etree.ElementTree as ET
O=pathlib.Path(__file__).resolve().parent
R=O.parent/'translation-current-integration-20261021/source'
SRC='Paintroid/src/main/res/values/strings.xml';LOC='Paintroid/src/main/res/values-b+fil/strings.xml'
TREE='b9b148d5d8ef7c7b088500a9c177f9f59304b800'
HEAD=subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip()
assert subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD^{tree}'],text=True).strip()==TREE
assert subprocess.check_output(['git','-C',str(R),'status','--porcelain'],text=True)==''
def h(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def fh(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):(O/p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def vals(p):
 d={}
 for e in ET.parse(p).getroot():
  if e.attrib.get('translatable')=='false':continue
  if e.tag=='string':d['string/'+e.attrib['name']]=''.join(e.itertext())
  elif e.tag=='plurals':d['plurals/'+e.attrib['name']]={c.attrib['quantity']:''.join(c.itertext()) for c in e}
 return d
en=vals(R/SRC);fil=vals(R/LOC);source_hashes={SRC:fh(R/SRC),LOC:fh(R/LOC)}
manifest=json.loads((R/'translations/string-importance.json').read_text());tiers={k:t['id'] for t in manifest['tiers'] for k in t['keys']}
rows=json.loads((O/'pairs-consumers.json').read_text());priority={x['key'] for x in rows}
assert priority=={k for k,t in tiers.items() if t in ('P0','P1')} and len(priority)==341
notes={int(i):v for i,v in (line.split('|',1) for line in (O/'review-notes.txt').read_text().splitlines())};assert set(notes)==set(range(1,342))
notes[320]=notes[320].replace('All thirteen supported format alternatives and Base64 image text','All named format alternatives and Base64 image text')
changes={
 'string/gallery_credit_too_large':'Magiging masyadong malaki ang guhit para maibalik kung idaragdag ang mga credit na ito. Pinanatili ang dati mong guhit at mga credit.',
 'string/ui_keeps_pixels_at_the_top_left_smaller_canvas':'Pinananatili ang mga pixel sa kaliwang itaas. Kapag pinaliit ang mga sukat ng canvas, inaalis ang mga pixel na lampas sa kanan o ibabang gilid; maibabalik ang mga ito gamit ang Ibalik.',
 'string/colour_truncated_metadata':'Naputol ang file ng larawan sa loob ng color metadata nito.',
 'string/ui_crop_preview_drag_an_edge_or_corner_drag':'Preview ng crop. I-drag ang gilid o sulok; i-drag sa loob nito para ilipat ang crop.',
 'string/ui_edit_transform33':'Baligtarin / Paikutin',
 'string/ui_trim_in_pixels':'Bawas sa %1$s (pixels)',
 'string/ui_trim_in_percent':'Bawas sa %1$s (porsiyento)',
}
assert len(changes)==7 and len(changes.keys()&priority)==5
optional={
 'string/ui_save_a5d0d9':('I-save…','Restore the source ellipsis without changing the already-acceptable Save action. The current alias deliberately resolves to the non-ellipsis Save label; this is a disclosure/consistency suggestion, not a demonstrated wrong operation.'),
 'string/commons_svg_original_size_unavailable':('Walang nakasaad na magagamit na orihinal na laki sa SVG. Walang ipinalit na laki na batay sa canvas.','Harmonize lona with canvas in this catalogue. The current complete statement preserves the source meaning; this is a terminology consistency improvement only.'),
 'string/ui_d_d_px_d_pixels_2f_mp':('%1$d × %2$d px · Bilang ng pixel: %3$,d (%4$.2f MP)','Restore the explicit Pixel count label and use an invariant counted-noun construction. The current translation still conveys the same number, so this is clarity/editorial improvement rather than a confirmed omitted fact.'),
 'string/ui_edit_canvas33':('Canvas','Use the same canvas term as the canvas commands and messages. Lona is not declared intrinsically wrong.'),
 'string/ui_the_full_image_and_working_buffers_exceed_the':('Lumampas ang buong larawan at working buffers sa kasalukuyang ligtas na limitasyon, o hindi makapaglaan ng memory ang Android para sa mga ito. Baguhin ang laki ng isang kopya para ma-edit ito. Hindi magbabago ang orihinal mong file.','Avoid inanimate sila and clarify allocation of memory. All source claims are already understood in the current text; optional polish remains separate from the required-candidate patch.'),
}
deps={'string/ui_bottom','string/ui_left','string/ui_right'};depkeys=['string/ui_trim_in_pixels','string/ui_trim_in_percent']
holds={'string/ui_foreground_background_colour_palette'}
union=json.loads(pathlib.Path('/tmp/an-all-language-reviews/all-language-review-union.json').read_text())
prior={x['key']:x for x in union['receipts'] if x['tag']=='fil'};assert len(prior)==22
audit=json.loads(pathlib.Path('/tmp/an-current-ledger-audit/audit.json').read_text());orig={x['key']:x for x in audit['receipts'] if x['tag']=='fil'}
later={};carried=[]
for k,v in prior.items():
 assert h(en[k])==v['current_english_sha256'] and h(fil[k])==v['current_localized_sha256'],k
 lr=[]
 for ref in v.get('later_evidence',[]):
  if ref['file'] not in later:later[ref['file']]=json.loads((pathlib.Path('/tmp/an-all-language-reviews')/ref['file']).read_text())['receipts']
  receipt=later[ref['file']][ref['index']];assert receipt['tag']=='fil' and receipt['key']==k;lr.append(receipt)
 carried.append({'tag':'fil','key':k,'in_priority_batch':k in priority,'english':en[k],'filipino':fil[k],'english_sha256':h(en[k]),'filipino_sha256':h(fil[k]),'exact_current_pair':True,'scope_policy':'Carry the original exact-pair evidence and every caveat. Do not promote to native, runtime, whole-language, layout or new-consumer acceptance.','union_receipt':v,'original_receipt':orig.get(k),'later_receipts':lr})
write('prior-22-exact-pairs.json',carried)
limits=[
 'Model-based linguistic review and static source-context inspection only. Not native-human, installed UI, layout, font, speech or TalkBack certification.',
 'Exact reviewed tree is b9b148d5d8ef7c7b088500a9c177f9f59304b800. Local commit identity differs from develop. Parent-reported later develop ef46e8aa/c96f9708 has Fit/status-only changes with no resource changes; that report is not an independent verification here, and later consumers are not silently rebound.',
 'Thirty keys have no direct production consumer found in the reviewed tree. Twenty-nine receive wording-only judgments; one is a composed-idiom context hold. No-direct-reference is not proof that dynamic or indirect use is impossible.',
 'Proposed corrections and optional refinements are not production edits or independently accepted translations. Source and prior accepted pairs remain untouched.',
 'PR #56 is an intentional draft tracker and must never be merged. No publication or release is included.'
]
token=re.compile(r'%(?:\d+\$)?[-#+ 0,(<]*\d*(?:\.\d+)?[a-zA-Z%]')
def tok(v):return sorted(token.findall(v)) if isinstance(v,str) else {k:tok(x) for k,x in v.items()}
entries=[]
for row in rows:
 k=row['key'];assert en[k]==row['en'] and fil[k]==row['fil']
 if k in holds:state='unresolved_composed_context_hold';cs=state
 elif k in changes:state='proposed_wording_correction';cs='candidate_linguistically_reviewed_static_unapplied'
 elif k in deps:state='requires_shared_template_correction';cs='candidate_context_reviewed_if_both_dependencies_applied'
 elif k in prior:state='carried_prior_exact_bounded';cs=state
 elif not row['consumers']:state='reviewed_current_wording_only';cs=state
 else:state='reviewed_current_static';cs=state
 consumers=row['consumers']
 for c in consumers:c['source_tree']=TREE;c['source_file_sha256']=fh(R/c['path'])
 val=changes.get(k,fil[k])
 entry={'index':row['index'],'tag':'fil','tier':row['tier'],'key':k,'english':en[k],'filipino':fil[k],'candidate':val,'english_sha256':h(en[k]),'filipino_sha256':h(fil[k]),'candidate_sha256':h(val),'disposition':state,'candidate_disposition':cs,'confidence':'medium' if k in changes or k in deps or k in holds or len(en[k])>90 else 'medium-high','review_note':notes[row['index']],'context_scope':'static_direct_consumer' if consumers else 'wording_only_no_direct_consumer_found','consumers':consumers,'atomic_dependencies':depkeys if k in deps else [],'placeholder_tokens_english':tok(en[k]),'placeholder_tokens_current':tok(fil[k]),'placeholder_tokens_candidate':tok(val),'prior_receipt_key':k if k in prior else None,'optional_refinement_available':k in optional,'native_human_reviewed':False,'runtime_verified':False}
 if fil[k].startswith('@string/'):
  target='string/'+fil[k][8:];entry['alias_resolution']={'target':target,'value':fil[target],'scope':'Exact local resource alias only; Android resource resolution not executed.'}
 entries.append(entry)

def consumers_for(k):
 name=k.split('/')[1];found=[];pat=re.compile(r'\bR\.string\.'+re.escape(name)+r'\b')
 for p in sorted((R/'Paintroid/src/main').rglob('*')):
  if not p.is_file() or p.suffix not in ('.kt','.java','.xml') or '/res/values' in str(p):continue
  for n,line in enumerate(p.read_text().splitlines(),1):
   if pat.search(line):found.append({'path':str(p.relative_to(R)),'line':n,'text':line.strip(),'source_tree':TREE,'source_file_sha256':fh(p)})
 return found
outside=[]
for k in depkeys:
 outside.append({'tag':'fil','key':k,'tier':tiers[k],'not_in_341_key_count':True,'english':en[k],'filipino':fil[k],'candidate':changes[k],'english_sha256':h(en[k]),'filipino_sha256':h(fil[k]),'candidate_sha256':h(changes[k]),'disposition':'proposed_atomic_dependency_correction','review_note':'The current edge + na bawas sequence is awkward with bare directional labels. Bawas sa + edge expresses the amount removed from that edge, and parenthesized units make the input dimension explicit. Apply pixel and percent templates together; priority labels and the unchanged top label then compose consistently.','consumers':consumers_for(k),'atomic_dependencies':depkeys,'native_human_reviewed':False,'runtime_verified':False})
corrections=[]
bykey={x['key']:x for x in entries+outside}
for k,v in changes.items():
 x=bykey[k];corrections.append({'tag':'fil','key':k,'tier':tiers[k],'outside_priority_dependency':k not in priority,'before':fil[k],'after':v,'before_sha256':h(fil[k]),'after_sha256':h(v),'english':en[k],'english_sha256':h(en[k]),'reason':x['review_note'],'classification':{'string/gallery_credit_too_large':'ambiguous_causal_relationship','string/ui_keeps_pixels_at_the_top_left_smaller_canvas':'idiom_and_boundary_precision','string/colour_truncated_metadata':'diagnostic_clarity','string/ui_crop_preview_drag_an_edge_or_corner_drag':'gesture_location_grammar','string/ui_edit_transform33':'rotation_verb_precision'}.get(k,'composed_direction_grammar'),'consumers':x['consumers'],'atomic_group':depkeys if k in depkeys else [k],'status':'proposed_unapplied_not_independently_approved'})
write('proposed-corrections.json',corrections)
opt=[]
for k,(v,reason) in optional.items():
 opt.append({'tag':'fil','key':k,'tier':tiers[k],'english':en[k],'before':fil[k],'after':v,'before_sha256':h(fil[k]),'after_sha256':h(v),'reason':reason,'classification':'optional_editorial_not_confirmed_error','status':'not_in_core_candidate_patch','current_disposition_unchanged':True})
write('optional-refinements.json',opt)
raw=(R/LOC).read_text()
def replace(raw,edits):
 out=raw
 for k,v in edits.items():
  name=k.split('/')[1];pattern=re.compile(r'(<string\s+name="'+re.escape(name)+r'"[^>]*>)(.*?)(</string>)',re.S)
  assert len(pattern.findall(out))==1
  escaped=v.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
  out,n=pattern.subn(lambda m:m[1]+escaped+m[3],out);assert n==1
 return out
candidate=replace(raw,changes);cp=O/'candidate'/LOC;cp.parent.mkdir(parents=True,exist_ok=True);cp.write_text(candidate)
patch=''.join(difflib.unified_diff(raw.splitlines(keepends=True),candidate.splitlines(keepends=True),fromfile='a/'+LOC,tofile='b/'+LOC));(O/'filipino-priority-candidate.patch').write_text(patch)
optional_candidate=replace(raw,{k:v for k,(v,_) in optional.items()});(O/'filipino-optional-refinements.patch').write_text(''.join(difflib.unified_diff(raw.splitlines(keepends=True),optional_candidate.splitlines(keepends=True),fromfile='a/'+LOC,tofile='b/'+LOC)))
combined_candidate=replace(candidate,{k:v for k,(v,_) in optional.items()})
(O/'filipino-optional-after-core.patch').write_text(''.join(difflib.unified_diff(candidate.splitlines(keepends=True),combined_candidate.splitlines(keepends=True),fromfile='a/'+LOC,tofile='b/'+LOC)))
cv=vals(cp);assert set(en)==set(fil)==set(cv) and len(fil)==717
assert {k for k in fil if fil[k]!=cv[k]}==set(changes)
for k in priority|set(changes):assert tok(en[k])==tok(fil[k])==tok(cv[k]),k
for k,(v,_) in optional.items():assert tok(en[k])==tok(v),k
attributes=lambda p:{e.tag+'/'+e.attrib['name']:e.attrib for e in ET.parse(p).getroot() if e.tag in ['string','plurals']}
assert attributes(R/LOC)==attributes(cp)
assert all(fh(R/k)==v for k,v in source_hashes.items())
statecounts=dict(collections.Counter(x['disposition'] for x in entries));tiercounts=dict(collections.Counter(x['tier'] for x in entries))
accepted={x['key'] for x in entries if x['disposition'] in ('reviewed_current_static','reviewed_current_wording_only','carried_prior_exact_bounded')}|set(prior)
held=(priority-set(accepted))|set(depkeys)
unknown=set(fil)-accepted-held
summary={'priority_entries':len(entries),'priority_tiers':tiercounts,'direct_consumer_keys':sum(bool(x['consumers']) for x in entries),'no_direct_consumer_keys':sum(not x['consumers'] for x in entries),'current_dispositions':statecounts,'current_priority_bounded_retained':len(accepted&priority),'priority_proposed_corrections':len(priority&changes.keys()),'priority_shared_dependency_holds':len(deps),'priority_unknown_composition_holds':len(holds),'outside_priority_dependency_corrections':len(outside),'core_candidate_xml_changes':len(changes),'optional_refinements_separate_not_counted_as_failures':len(optional),'prior_exact_receipts_carried':len(prior),'prior_receipts_overlapping_priority':len(set(prior)&priority),'prior_receipts_outside_priority':len(set(prior)-priority),'catalogue_current_partition_including_two_dependency_holds':{'bounded_current':len(accepted),'known_pending_or_context_hold':len(held),'present_review_unknown':len(unknown),'missing':len(set(en)-set(fil)),'total':len(fil)},'if_core_candidate_applied_priority':{'bounded_dispositions':340,'unknown_composition_hold':1,'wording_only_within_bounded':29,'not_native_or_runtime_certification':True},'priority_keys_unreviewed':0}
assert sum(statecounts.values())==341 and len(accepted)+len(held)+len(unknown)==717
identity={'exact_reviewed_tree':TREE,'observed_local_head':HEAD,'binding':'Local HEAD has the exact assigned reviewed tree. The previously recorded develop commit 4355869e2e198b5616419291cba225b018444fab is not available as a local Git object and is not represented as locally verified. Source paths, tree ID and content hashes are the primary evidence.','parent_reported_later_develop':'ef46e8aa/c96f9708; Fit/status-only changes and no resource changes, not independently fetched by this worker.','later_consumer_limitation':'No automatic rebind of static consumer judgments to a later tree. Source-only Fit entries remain source-only here.','source_catalogue':SRC,'source_catalogue_sha256':source_hashes[SRC],'localized_catalogue':LOC,'localized_catalogue_sha256':source_hashes[LOC],'priority_manifest':'translations/string-importance.json','priority_manifest_sha256':fh(R/'translations/string-importance.json'),'source_worktree_clean_before_and_after':True}
write('filipino-p0-p1-review.json',{'schema_version':1,'language':'Filipino','tag':'fil','review_date_utc':'2026-10-21','review_kind':'full_341_key_model_linguistic_and_static_source_context_review','source_identity':identity,'summary':summary,'limitations':limits,'entries':entries,'outside_priority_dependencies':outside,'unresolved_holds':[x for x in entries if x['key'] in holds],'prior_receipts_file':'prior-22-exact-pairs.json','optional_editorial_file':'optional-refinements.json'})
write('source-bindings.json',{'source_identity':identity,'entries':[{'key':x['key'],'tier':x['tier'],'english_sha256':x['english_sha256'],'filipino_sha256':x['filipino_sha256'],'candidate_sha256':x['candidate_sha256']} for x in entries]})
with (O/'filipino-p0-p1-review.csv').open('w') as f:
 keys=['index','tier','key','disposition','candidate_disposition','context_scope','english','filipino','candidate','review_note'];w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows({k:x[k] for k in keys} for x in entries)
# Illustrative static substitutions. These are not Java/Android formatting or runtime tests.
examples=[]
def s(template,args):
 for i,v in enumerate(args,1):template=template.replace('%'+str(i)+'$s',str(v))
 return template.replace('\\n','\n')
for edge in ['ui_left','ui_top','ui_right','ui_bottom']:
 for k in depkeys:examples.append({'case':'crop_edge_'+edge+'_'+k,'args':[fil['string/'+edge]],'current':s(fil[k],[fil['string/'+edge]]),'candidate':s(changes[k],[fil['string/'+edge]]),'scope':'source-composed string illustration only'})
for n in [2,10,21]:
 for frame in [str(n),fil['string/formats22_at_least_frames'].replace('%1$d',str(n))]:examples.append({'case':'animation_count','args':['GIF',frame],'current':s(fil['string/formats22_animation_message'],['GIF',frame]),'candidate_same_as_current':True})
for dimension in ['ui_height_in','ui_width_in']:
 for unit in ['ui_percent_fd8671','ui_pixels_6ec9c2']:examples.append({'case':dimension+'_'+unit,'current':s(fil['string/'+dimension],[fil['string/'+unit]]),'candidate_same_as_current':True})
for category,tool in [('ui_drawing23','ui_pencil'),('ui_category_selection','ui_rectangle_select'),('ui_category_insert','ui_ellipse')]:
 for k in ['ui_collapse_tool_category','ui_expand_tool_category']:examples.append({'case':k,'current':s(fil['string/'+k],[fil['string/'+category],fil['string/'+tool]]),'candidate_same_as_current':True})
examples.extend([{'case':'colour_label_hash_already_supplied','current':s(fil['string/ui_colour'],['#12ABCD'])},{'case':'palette_cell_hash_added_by_template','current':s(fil['string/ui_colour_tap_foreground_hold_background'],['12ABCD'])},{'case':'memory_estimate_boundary','current':s(fil['string/ui_estimated_memory_current_working_budget'],['80 MiB','64 MiB'])+fil['string/ui_choose_a_smaller_size']},{'case':'recovery_route','current':fil['string/ui_menu_file']+' > '+fil['string/ui_load_image']},{'case':'paste_route','current':' → '.join(fil['string/'+k] for k in ['ui_draw26','ui_category_insert','ui_other_images34'])}])
write('static-composition-examples.json',{'limitation':'Illustrative substitutions from exact values and inspected consumers; not Android/JVM formatting, UI or TalkBack execution.','examples':examples})
# Apply solely in a disposable artifact copy, never the production source tree.
tmp=O/'patch-application-check';target=tmp/LOC;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(raw)
dry=subprocess.run(['patch','--dry-run','-p1','-i',str(O/'filipino-priority-candidate.patch')],cwd=tmp,text=True,capture_output=True)
assert dry.returncode==0,dry.stdout+dry.stderr
applied=subprocess.run(['patch','-p1','-i',str(O/'filipino-priority-candidate.patch')],cwd=tmp,text=True,capture_output=True)
assert applied.returncode==0 and target.read_bytes()==cp.read_bytes()
assert all(fh(R/k)==v for k,v in source_hashes.items()) and subprocess.check_output(['git','-C',str(R),'status','--porcelain'],text=True)==''
validation={'manifest_entries_exact':True,'priority_count':341,'tier_counts':tiercounts,'catalogue_entries':717,'all_prior_22_exact_pairs_preserved':True,'prior_overlap_priority':2,'all_priority_values_have_individual_notes':len(notes)==341,'independent_production_consumer_scan':{'direct':311,'no_direct':30,'search_scope':'Paintroid/src/main .kt/.java/.xml excluding translated value catalogues; exact R.string and @string references; no dynamic-use proof'},'current_source_candidate_placeholder_signatures_equal':True,'candidate_xml_parses':True,'resource_identities_and_attributes_preserved':True,'exact_changed_keys':list(changes),'changed_key_count':7,'patch_dry_run':{'exit_code':dry.returncode,'output':dry.stdout+dry.stderr},'patch_applied_only_to_artifact_copy':{'exit_code':applied.returncode,'output':applied.stdout+applied.stderr,'matches_candidate_exactly':True},'source_catalogues_unchanged':source_hashes,'source_git_worktree_clean_after':True,'composition_examples':len(examples),'optional_patch_not_in_core_patch':True,'not_run':['builds','Gradle','compilation','APK generation','CI','device/emulator','installed UI','TalkBack','native-human review','publication','PR creation','merge','version changes','release'],'interpretation':'Structural checks support integrity only. Linguistic judgments are the separate individually authored notes. Unresolved context is not a failed test.'}
for mode in ['optional','combined']:
 base=O/('patch-'+mode+'-check');p=base/LOC;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(raw)
 patches=['filipino-optional-refinements.patch'] if mode=='optional' else ['filipino-priority-candidate.patch','filipino-optional-after-core.patch']
 for name in patches:
  result=subprocess.run(['patch','--dry-run','-p1','-i',str(O/name)],cwd=base,text=True,capture_output=True);assert result.returncode==0,(name,result.stdout,result.stderr)
  result=subprocess.run(['patch','-p1','-i',str(O/name)],cwd=base,text=True,capture_output=True);assert result.returncode==0,(name,result.stdout,result.stderr)
 assert p.read_text()==(optional_candidate if mode=='optional' else combined_candidate)
validation['optional_patch_dry_run_and_application_in_artifact_copy']=True
validation['combined_core_then_optional_after_core_patch_application_in_artifact_copy']=True
validation['optional_changed_keys']=5
validation['combined_changed_keys']=12
validation['optional_patch_base_warning']='The optional-refinements patch targets the original source. After core, use optional-after-core instead; baseline context overlaps with core edits. Exact before hashes remain mandatory.'
write('validation.json',validation)
print(json.dumps(summary,ensure_ascii=False,indent=2))
