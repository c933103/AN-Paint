from pathlib import Path
import json,hashlib,tarfile,zipfile
R=Path(__file__).resolve().parent
B=R/'bounded-originals';B.mkdir(exist_ok=True)
with zipfile.ZipFile(R/'originals/regression.zip') as z:
 for n in z.namelist():
  if ('/test-results/' in n and n.endswith('.xml')) or n in ['build/reports/ci-phases/python.log','build/reports/ci-phases/python.time','app/build/reports/lint-results-debug.xml']:
   p=B/'regression'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(n))
for stem in ['probes','core','position','union']:
 with zipfile.ZipFile(R/'originals'/f'{stem}.zip') as z:
  for n in z.namelist():
   if n.endswith(('summary.json','instrumentation.log','device-identity.json','artifact-selection.json','collection-status.log','dialog-export.log','dialog-pull.log','vertical-locale-export.log','vertical-locale-inventory.log','vertical-control-reachability.log')) or stem=='probes':
    p=B/stem/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(n))
with zipfile.ZipFile(R/'originals/apk-source.zip') as z:
 (B/'build-info.json').write_bytes(z.read('build/delivery/build-info.json'))
files=[p for p in R.iterdir() if p.is_file() and p.suffix in ['.json','.py','.log','.exit','.md']]
files += [p for p in B.rglob('*') if p.is_file()]
files += [p for p in (R/'mandatory-exports').iterdir() if p.is_file()]
files=[p for p in files if p.name!='package-index.json']
archive=R/'independent-terminal-evidence.tar.xz'
with tarfile.open(archive,'w:xz') as t:
 for p in sorted(files):t.add(p,arcname=str(p.relative_to(R)),recursive=False)
index={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':[{'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(files)],'original_large_archives_not_duplicated':True}
(R/'package-index.json').write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(archive) as t:
 assert len(t.getmembers())==len(files)
 for m in t:
  assert t.extractfile(m).read()==(R/m.name).read_bytes()
print(json.dumps({'bytes':index['bytes'],'sha256':index['sha256'],'members':len(files)}))
