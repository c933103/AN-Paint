from pathlib import Path
import json,hashlib,zipfile
F=Path(__file__).resolve().parent
exclude={'pr117-regression-failure.zip','ci-ordering-repair-evidence.zip','artifact-manifest.json','packet-receipt.json','upload-payload.json','source-upload-payload.json'}
files=[p for p in F.rglob('*')if p.is_file() and p.name not in exclude and not p.relative_to(F).parts[0]in {'artifact','__pycache__'}]
# Exact original position ZIP contains every original artifact member; avoid
# duplicating its unpacked copy. Keep all relevant JVM XML suites separately.
manifest=[{'path':str(p.relative_to(F)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(files)]
(F/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
zpath=F/'ci-ordering-repair-evidence.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(files)+[F/'artifact-manifest.json']:z.write(p,str(p.relative_to(F)))
with zipfile.ZipFile(zpath)as z:
 assert z.testzip()is None
 for item in manifest:
  raw=z.read(item['path']);assert len(raw)==item['bytes']and hashlib.sha256(raw).hexdigest()==item['sha256']
raw=zpath.read_bytes();receipt={'file':zpath.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'git_blob_sha':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),'members':len(manifest)+1,'all_members_verified':True}
(F/'packet-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
