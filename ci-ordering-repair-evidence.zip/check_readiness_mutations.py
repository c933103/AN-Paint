from pathlib import Path
import sys, tempfile, unittest, io, json
O=Path(__file__).resolve().parent; W=O.parent/'worktree'
sys.path.insert(0,str(W/'tools'))
import test_position_composition as contract
s=(W/'app/src/androidTest/java/paint/anpaint/android/AssemblyPositionDeviceTest.kt').read_text()
start=s.index('            await("IME shown for native field input:')
end=s.index('\n        } catch(error: AssertionError)',start)
barrier=s[start:end]
mutations={
 'original_pending_show_race':(O/'AssemblyPositionDeviceTest-before.kt').read_text(),
 'remove_visible_barrier':s[:start]+s[end:],
 'move_barrier_after_typing':s.replace(barrier,'').replace('        await("native field input:',barrier+'\n        await("native field input:'),
 'remove_hidden_tap_guard':s.replace('view.rootWindowInsets?.isVisible(WindowInsets.Type.ime())==false','true'),
 'bypass_native_hide':s.replace('device.pressKeyCode(KeyEvent.KEYCODE_BACK)','true'),
}
results=[]
with tempfile.TemporaryDirectory() as directory:
 root=Path(directory); path=root/'java/paint/anpaint/android/AssemblyPositionDeviceTest.kt';path.parent.mkdir(parents=True)
 old=contract.SOURCE;contract.SOURCE=root
 try:
  for name,value in [('current',s),*mutations.items()]:
   path.write_text(value)
   output=io.StringIO();result=unittest.TextTestRunner(stream=output).run(contract.PositionCompositionTest('test_native_edit_dismisses_keyboard_before_revealing_and_keeps_real_input'))
   results.append(dict(case=name,successful=result.wasSuccessful(),failures=len(result.failures),errors=len(result.errors),output=output.getvalue()))
 finally:contract.SOURCE=old
assert results[0]['successful'] and all(not x['successful'] and x['failures']+x['errors']==1 for x in results[1:]),results
(O/'readiness-mutations.json').write_text(json.dumps({'scope':'Host source-order/guard regression contract; does not execute Android IME or demonstrate installed repair success.','cases':results},indent=2)+'\n')
print('Current contract passes; all five synchronization/input regressions rejected.')
