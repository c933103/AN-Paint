from pathlib import Path
import hashlib,json,subprocess,sys,xml.etree.ElementTree as E
O=Path(__file__).resolve().parent; W=O/'source';sys.path.insert(0,str(W/'tools'))
import translation_catalogues as C
from test_assembly_help_modes import PATHS,KEY
from test_translations import SCOPED_TAGS
base=json.loads((O/'base-tree.json').read_text());byleaf={e['path']:e for e in base['tree'] if e['type']=='blob'}
changed=subprocess.check_output(['git','diff','--name-only'],cwd=W,text=True).splitlines();new=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=W,text=True).splitlines()
rows=[]
for path,e in byleaf.items():
 p=W/path;b=p.read_bytes();sha=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();mode='100755' if p.stat().st_mode&0o111 else '100644'
 assert mode==e['mode']
 if path not in changed: assert sha==e['sha'],path
 rows.append({'path':path,'mode':mode,'sha':sha})
for path in new:
 p=W/path;b=p.read_bytes();rows.append({'path':path,'mode':'100755' if p.stat().st_mode&0o111 else '100644','sha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
for path in changed:
 if '/res/' not in path:continue
 old=E.fromstring(subprocess.check_output(['git','show','HEAD:'+path],cwd=W,text=True));current=E.parse(W/path).getroot();values=lambda r:{(n.tag,n.get('name')):E.tostring(n,encoding='unicode') for n in r}
 a,b=values(old),values(current);assert set(a)==set(b);assert {k for k in a if a[k]!=b[k]}=={('string',KEY)}
summary={'base_commit':'44ad5ce2156fef79baae3ef5650b9ac5eac06202','base_tree':base['sha'],'base_leaf_count':len(byleaf),'candidate_leaf_count':len(rows),'changed':changed,'added':new,'removed':[], 'all_unmodified_contents_and_modes_match':True,'resource_keys_changed':['string/'+KEY],'priority':'P3 unchanged','placement_model_crop_code':'Unchanged from exact verified base','other_language_values':'Unchanged. Full Help/source binding re-review is explicitly required; historical acceptance does not carry forward to the changed English contract.','held_PR56':'No changes'}
(O/'source-comparison.json').write_text(json.dumps(summary,indent=2)+'\n');(O/'candidate-manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
source=(W/'Paintroid/src/main/res/values/strings.xml');old=E.fromstring(subprocess.check_output(['git','show','HEAD:Paintroid/src/main/res/values/strings.xml'],cwd=W,text=True)).find(f"string[@name='{KEY}']").text;new=E.parse(source).find(f"string[@name='{KEY}']").text
bindings=[]
for tag in C.offered_tags():
 if tag in PATHS:continue
 path=C.catalogue_paths()[tag];node=E.parse(path).find(f"string[@name='{KEY}']")
 bindings.append({'tag':tag,'path':str(path.relative_to(W)),'in_original_59_catalogue_scope':tag in SCOPED_TAGS,'has_help_override':node is not None,'help_sha256':hashlib.sha256(node.text.encode()).hexdigest() if node is not None else None,'status':'requires-full-Help-and-source-binding-re-review' if node is not None else 'changed-English-fallback-requires-routing-recheck; no-native-language-acceptance','prior_full_value_acceptance_carried_forward':False})
receipt={'scope':'Other-language complete assembly Help/source bindings only. Does not withdraw separately bounded unchanged crop plural or unrelated key evidence.','source_key':'string/'+KEY,'source_base_commit':summary['base_commit'],'old_English_value_sha256':hashlib.sha256(old.encode()).hexdigest(),'candidate_English_value_sha256':hashlib.sha256(new.encode()).hexdigest(),'new_obligations':['Separate snapping origin/overlap rules from Exact position.','Exact position: select image, current localized toolbar label, top-left zero-based whole-pixel X/Y, other positions preserved, overlaps allowed.','Other images stay placed; attached images may move to fill a removed image gap.','Re-read complete Help including controls, crop, dimensions, normalization, memory floor and persistence against actual consumers.'],'all_other_language_bindings':bindings,'counts':{'other_public_locales':len(bindings),'overrides_needing_re_review':sum(x['has_help_override'] for x in bindings),'English_fallback_routing_rechecks':sum(not x['has_help_override'] for x in bindings)},'holds':'PR56 and existing language/rendering holds are unchanged. This receipt is separate; no whole-language or device acceptance.'}
(O/'other-language-source-bindings.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps(receipt['counts']));print('Verified',len(rows),'candidate paths')
