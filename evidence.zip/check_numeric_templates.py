from pathlib import Path
import json,re,subprocess,xml.etree.ElementTree as ET
O=Path(__file__).resolve().parent;W=O/'source';D=Path('/workspace/shared/anpaint-commons-errors-20261017/compile-check/deps');K=[str(p) for p in D.glob('*.jar')];src=O/'template-probe';src.mkdir(exist_ok=True)
keys={'ui_recent_colour_empty':(['s'],'arrayOf(String.format(locale,"%d",4))'), 'ui_current_safe_editing_budget_s_up_to_2f':(['s','f'],'arrayOf("memory",2.25)'), 'ui_d_d_pixels_2f_mp_exceeds_the_current':(['d','d','f','f'],'arrayOf(1500,2000,3.0,2.25)'), 'ui_current_safe_budget_2f_mp':(['f'],'arrayOf(2.25)'), 'ui_0f_0f_px_1f':(['f','f','f'],'arrayOf(150f,80f,12.5f)'), 'ui_recent_colour_d_06x_tap_foreground_hold_background':(['d','X'],'arrayOf(3,0xabcdef)')}
records=[]
for f in sorted((W/'Paintroid/src/main/res').glob('values*/strings.xml')):
 for e in ET.parse(f).getroot().findall('string'):
  key=e.get('name')
  if key in keys:
   text=''.join(e.itertext()).replace('\\n','\n').replace("\\'", "'")
   found=re.findall(r'%(\d+)\$[-#+ 0,(]*\d*(?:\.\d+)?([dfXsx])',text)
   expected=keys[key][0]
   assert sorted(found,key=lambda t:int(t[0]))==[(str(i+1),v)for i,v in enumerate(expected)],(str(f),key,found)
   records.append({'path':str(f.relative_to(W)),'key':key,'template':text})
(O/'format-contract-check.json').write_text(json.dumps({'templates_checked':len(records),'resource_files':len(set(r['path']for r in records)),'format_signatures':{k:v[0]for k,v in keys.items()},'records':records},ensure_ascii=False,indent=2)+'\n')
def quote(s):return json.dumps(s,ensure_ascii=False).replace('$','\\$')
lines=['import java.util.Locale','fun main() {','var checks=0','val locales=listOf("pt-BR","de","en-001","ar","ro")','for (tag in locales) {','val locale=Locale.forLanguageTag(tag)','Locale.setDefault(if(tag=="en-001") Locale.GERMANY else Locale.US)']
for r in records:
 args=keys[r['key']][1];lines+=['run {',f'val template={quote(r["template"])}',f'val args={args}','val selected=String.format(locale,template,*args)','check(!selected.contains("%1$"))','checks++']
 if r['key']=='ui_recent_colour_d_06x_tap_foreground_hold_background':lines+=['check(selected.contains("#ABCDEF"))','if(tag=="ar") check(selected.contains("٣"))','checks++']
 lines+=['}']
lines+=['}'];lines += ['for((tag,low,whole) in listOf(Triple("pt-BR","2,50%","123%"),Triple("de","2,50%","123%"),Triple("en-001","2.50%","123%"),Triple("ar","٢٫٥٠%","١٢٣%"),Triple("ro","2,50%","123%"))) {','val selected=Locale.forLanguageTag(tag)','check(String.format(selected,"%1\\$.2f%%",2.5)==low)','check(String.format(selected,"%1\\$d%%",123)==whole)','checks+=2','check(String.format(selected,"%d",4)==if(tag=="ar") "٤" else "4")','checks++','if(tag!="en-001") {check(String.format(Locale.ROOT,"%.2f%%",2.5)!=low);checks++}','Locale.setDefault(if(tag=="en-001") Locale.GERMANY else Locale.US)','check(String.format(Locale.getDefault(),"%.2f%%",2.5)!=low);checks++','}', 'println("PASS: $checks exact XML-template value/contract checks; locale selection stand-in only, not Android execution")','}']
(src/'TemplateProbe.kt').write_text('\n'.join(lines)+'\n')
cmd=['java','-cp',':'.join(K),'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-jvm-target','17','-classpath',str(D/'kotlin-stdlib-1.9.24.jar'),'-d',str(src/'classes'),str(src/'TemplateProbe.kt')];r=subprocess.run(cmd,text=True,capture_output=True);(O/'template-compile.log').write_text(r.stdout+r.stderr);print('compile',r.returncode,r.stderr[:2500]);
if r.returncode:raise SystemExit(r.returncode)
r=subprocess.run(['java','-cp',str(src/'classes')+':'+str(D/'kotlin-stdlib-1.9.24.jar'),'TemplateProbeKt'],text=True,capture_output=True);(O/'template-check.log').write_text(r.stdout+r.stderr);print(r.stdout+r.stderr);raise SystemExit(r.returncode)
