from pathlib import Path
import json,sys,xml.etree.ElementTree as E
O=Path(__file__).resolve().parent;W=O/'source';sys.path.insert(0,str(W/'tools'))
from test_assembly_help_modes import PATHS,KEY,require_complete
expected=json.loads((W/'Paintroid/src/test/resources/assembly-help-modes/expected.json').read_text())['locales'];rows=[]
for row in json.loads((O/'complete-value-comparison.json').read_text()):
 root=E.parse(W/row['path']).getroot();root.find(f"string[@name='{KEY}']").text=row['old']
 try:require_complete(root,expected[row['tag']]['help'])
 except ValueError as e:rows.append({'tag':row['tag'],'old_complete_value_rejected':True,'reason':str(e)})
 else:raise RuntimeError('Old value accepted: '+row['tag'])
(O/'old-value-controls.json').write_text(json.dumps(rows,indent=2)+'\n');print('All',len(rows),'old complete values rejected')
