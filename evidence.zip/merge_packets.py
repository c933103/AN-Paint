import json,pathlib,collections
w=pathlib.Path('/workspace/shared/anpaint-p2-continuation-evidence')
i=json.load(open(w/'inputs.json'));c={**i,'translations':{},'notes':{}};r={'accepted':{},'decisions':[],'summary':collections.Counter(),'contexts':{},'limits':'Independent changed-only AI review, not native-human, complete-layout/speech, release or installed-APK diagnosis certification.'}
for pair in ['az-be','hy-ka','sq-gd']:
 a=json.load(open(w/f'candidate-{pair}.json'));b=json.load(open(w/f'review-{pair}.json'))
 assert len(b['decisions'])==40 and sum(len(x) for x in a['translations'].values())==40
 assert all(d['candidate']==a['translations'][d['locale']][d['key']] for d in b['decisions'])
 assert len({(d['locale'],d['key']) for d in b['decisions']})==40
 assert all(d['final']==b['accepted'][d['locale']][d['key']] for d in b['decisions'] if d['status']!='hold')
 c['translations'].update(a['translations']);c['notes'][pair]=a['notes']
 r['accepted'].update(b['accepted']);r['decisions']+=b['decisions'];r['summary'].update(b['summary']);r['contexts'][pair]={'context':b['context'],'limits':b['limits']}
assert set(c['translations'])==set(i['paths']) and r['summary']['final_accepted']==120 and r['summary']['held']==0
(w/'candidate.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');(w/'review.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
print(r['summary'])
