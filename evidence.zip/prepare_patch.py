from pathlib import Path
import json,hashlib,xml.etree.ElementTree as ET
B=Path(__file__).resolve().parent;R=B/'source'
review=json.loads(Path('/workspace/shared/anpaint-memory-full-review-20261017/complete-review.json').read_text())
key=review['key']; sha=lambda x:hashlib.sha256(x.encode()).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
base={e['path']:e for e in json.loads((B/'base-tree.json').read_text())['tree'] if e['type']=='blob'}
proof=[]
for row in review['results']:
 path=f"Paintroid/src/main/res/values-{row['qualifier']}/strings.xml";p=R/path;b=p.read_bytes()
 assert blob(b)==base[path]['sha']==row['catalogue_blob'],path
 nodes=ET.fromstring(b).findall(f"string[@name='{key}']");assert len(nodes)==1
 value=''.join(nodes[0].itertext());assert value==row['reviewed_value'];assert sha(value)==row['reviewed_value_sha256']
 proof.append({'locale':row['locale'],'qualifier':row['qualifier'],'path':path,'catalogue_blob':blob(b),'value_sha256':sha(value),'prior_disposition':row['disposition'],'prior_confidence':row['confidence']})
default=ET.parse(R/'Paintroid/src/main/res/values/strings.xml').getroot().find(f"string[@name='{key}']")
fixture={'schema_version':1,'key':key,'scope':'Two bounded detail-loss modality corrections. Complete-value matching is a regression contract, not full-message linguistic acceptance; bo and jje remain on hold.','values':{'default':''.join(default.itertext())},'constraints':{'default':{'attributes':default.attrib,'formatted':default.get('formatted')!='false','placeholders':{}}},'catalogues':{'default':'values'},'whole_value_accepted':{'bo':False,'jje':False}}
changes=[]
for row in review['candidate_corrections']:
 p=R/f"Paintroid/src/main/res/values-{row['qualifier']}/strings.xml";old=p.read_text();node=ET.fromstring(old).find(f"string[@name='{key}']");before=''.join(node.itertext())
 assert sha(before)==row['before_value_sha256'];assert before.count(row['replace_from'])==1
 after=before.replace(row['replace_from'],row['replace_to']);assert after==row['complete_candidate_value'];assert sha(after)==row['candidate_value_sha256']
 assert old.count(before)==1;new=old.replace(before,after);p.write_text(new)
 assert ''.join(ET.fromstring(new).find(f"string[@name='{key}']").itertext())==after
 fixture['values'][row['locale']]=after;fixture['constraints'][row['locale']]={'attributes':node.attrib,'formatted':node.get('formatted')!='false','placeholders':{}};fixture['catalogues'][row['locale']]='values-'+row['qualifier']
 changes.append({'locale':row['locale'],'path':p.relative_to(R).as_posix(),'old_complete_value':before,'new_complete_value':after,'old_value_sha256':sha(before),'new_value_sha256':sha(after),'one_span_only':True,'old_span':row['replace_from'],'new_span':row['replace_to']})
p=R/'Paintroid/src/test/resources/memory-modality/expected.json';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(fixture,ensure_ascii=False,indent=2)+'\n')
(B/'baseline-and-change-proof.json').write_text(json.dumps({'review_source_commit':review['source_commit'],'integration_base_commit':'44ad5ce2156fef79baae3ef5650b9ac5eac06202','nine_values_unchanged_from_review_baseline':proof,'changes':changes,'quantities':'Not applicable: this is one scalar string, with no quantity resources or placeholders.','whole_value_holds':8,'whole_value_acceptances':1,'unchanged_accepted_locale':'vi-Hani'},ensure_ascii=False,indent=2)+'\n')
print('Verified all nine complete values against reviewed catalogue/value hashes; applied only two exact spans.')
