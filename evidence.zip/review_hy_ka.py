import json,re,pathlib,xml.etree.ElementTree as ET
p=pathlib.Path('/workspace/shared/anpaint-p2-continuation-evidence'); repo=pathlib.Path('/workspace/shared/anpaint-p2-continuation-20261110')
c=json.loads((p/'candidate-hy-ka.json').read_text())['translations']; inp=json.loads((p/'inputs.json').read_text())
reasons={
'hy':[
'Ընտրեք is the polite imperative and էջ is the correct indefinite object for choosing one page; appropriate for PDF and TIFF.',
'Complete description preserves kind, filename, total count and the single-page image-editing purpose; Armenian clause order and punctuation are coherent.',
'Definite Էջի համարը clearly labels the page-number input rather than a count.',
'Նախորդ էջ correctly names the previous page without restricting shared credit pagination to PDF.',
'Հաջորդ էջ correctly names the next page in both document selection and credit pagination.',
'Բացել էջը is a suitable infinitive action label with the selected page as definite object.',
'Ընտրված էջի նախադիտում is a clear nominal accessibility description of the selected-page preview.',
'Polite input instruction and 1-ից մինչև range preserve the one-based lower bound and inclusive upper limit.',
'Էջ %1$d՝ %2$d-ից reads current page out of total; the second clause says the preview is loading, not that opening has completed.',
'Current/total order and width × height are preserved; փիքսել agrees with numeral-led measurement and no preview-size qualification is introduced.',
'Unavailable preview statement preserves the appended error explanation without claiming that the document itself cannot be opened.',
'Both complete sentences distinguish preview memory shortage and the conditional հնարավորության դեպքում offer of smaller dimensions on opening.',
'Failed reading remains definite, while կարող է scopes the possible damaged-file or unsupported-feature explanations; Android-version qualification remains intact.',
'Replace անպաշտպան, which commonly describes something defenseless, with technical չպաշտպանված for a copy without protection. Password OR unsupported encryption and saving before import remain explicit.',
'ոչ դատարկ excludes empty files and 512 MiB-ից ոչ մեծ includes exactly 512 MiB; this is a file-size constraint, not rendering memory.',
'պարունակի with numeral-led էջ is grammatical and preserves the range from one through the supplied maximum.',
'ընտրությունն այլևս վավեր չէ correctly marks stale page selection; the second sentence directs selection from this document rather than another file.',
'չափերն անվավեր են կամ չափազանց մեծ են preserves invalid OR overly large page dimensions and the import limitation.',
'Complete sentence explicitly requires a rectangle entirely within selected-page bounds with both width and height greater than zero; no empty or outside region is admitted.',
'պատկերման համար պահանջվող հիշողությունը identifies rendering demand and compares it with available image-memory allowance, not storage or file-size limits.'
],
'ka':[
'აირჩიეთ გვერდი is a natural polite selection imperative, usable for either PDF or TIFF.',
'Replace გამოსახულებად რედაქტირებისთვის with გამოსახულების სახით რედაქტირებისთვის to state editing in image form explicitly rather than suggest editing into an image. Kind, filename, count, one-page choice and source newline remain unchanged.',
'გვერდის ნომერი correctly labels the selected page number, not total pages.',
'წინა გვერდი naturally labels previous page and remains valid for plain-text credit pagination.',
'შემდეგი გვერდი naturally labels next page without a PDF-only restriction.',
'გვერდის გახსნა is a grammatical action noun phrase suitable for the opening button.',
'არჩეული გვერდის წინასწარი ხედი correctly identifies the selected-page preview and avoids confusing it with a generic thumbnail.',
'შეიყვანეთ is a polite input imperative; 1-დან %1$d-მდე preserves the one-based inclusive range.',
'გვერდი %1$d, სულ %2$d explicitly distinguishes current page from total; იტვირთება is an ongoing loading state.',
'Page number, explicit total, width × height and numeral-led პიქსელი are correct; dimensions are not described as preview dimensions.',
'წინასწარი ხედი მიუწვდომელია states unavailable preview and leaves the supplied diagnostic intact.',
'The two sentences identify insufficient preview memory and explicitly condition the smaller-dimensions offer with თუ შესაძლებელია; no success guarantee is added.',
'შეიძლება governs both დაზიანებული იყოს and იყენებდეს, retaining uncertainty for damage OR unsupported features; Android-version support is explicit.',
'The sentence retains password OR unsupported encryption, then instructs saving an unprotected copy before import. დაუცველი ასლი is understandable in this file-protection context.',
'არ უნდა იყოს ცარიელი excludes empty files; არ უნდა აღემატებოდეს 512 MiB-ს makes 512 MiB inclusive, with the Georgian case ending correctly attached to the unit.',
'უნდა შეიცავდეს governs გვერდს correctly and 1-დან %1$d-მდე retains both page-count bounds.',
'აღარ არის მართებული conveys that the page choice is no longer valid; ამ დოკუმენტიდან restricts the corrective selection to this document.',
'ზომები არასწორია ან ... ზედმეტად დიდია retains both invalid-dimension and excessive-dimension alternatives, with an explicit import context.',
'The complete coordinated sentence requires a rectangle with positive width and height entirely within the selected-page boundaries; მოსაჭრელი არე matches the crop-region context.',
'გამოსახვისთვის საჭირო მეხსიერება describes rendering memory; the comparison to the memory limit available for images does not imply a storage or file-size problem.'
]}
accepted={}; decisions=[]
for loc,values in c.items():
    accepted[loc]={}
    assert len(values)==20 and set(values)==set(inp['source'])
    assert (repo/inp['paths'][loc]).is_file()
    for (key,value),reason in zip(values.items(),reasons[loc]):
        final=value
        if (loc,key)==('hy','formats22_pdf_encrypted'): final=value.replace('անպաշտպան','չպաշտպանված')
        if (loc,key)==('ka','formats22_page_description'): final=value.replace('გამოსახულებად რედაქტირებისთვის','გამოსახულების სახით რედაქტირებისთვის')
        assert re.findall(r'%\d+\$[sd]',final)==re.findall(r'%\d+\$[sd]',inp['source'][key]['text'])
        assert final.count('\\n')==inp['source'][key]['text'].count('\\n')
        assert '\n' not in final and '"' not in final and "'" not in final
        ET.fromstring('<string>'+final+'</string>')
        accepted[loc][key]=final
        decisions.append(dict(locale=loc,key=key,status='accept' if value==final else 'revise',candidate=value,final=final,reason=reason))
result=dict(accepted=accepted,decisions=decisions,summary=dict(accepted_unchanged=38,revised=2,held=0,final_accepted=40),context={
'base_sha':inp['base_sha'],'canonical_paths':{x:inp['paths'][x] for x in c},
'read_consumers':['ImportSelection.kt (complete)','PdfCodec.kt (complete)','ImageImport.kt: ImportedImage class','ImageResizeDialog.kt (complete)','ClassicPaintActivity.kt: import selection / askToResize / decodeImage','LegacyImageCreditsActivity.kt (complete)'],
'read_test_context':['PdfCodecTest.kt: multipage/source dimensions, editable raster, invalid crops/pages, memory, malformed PDF and specific errors','OrdinaryPriorityFollowthroughTest.kt: page chooser and native-memory minimum-size behavior','LegacyImageCreditsActivityTest.kt: oversized credit pagination and restoration'],
'semantic_findings':['Page input is 1-based and converted to zero-based internally. Status arguments are current page then total; displayed dimensions come from source, not the 384-pixel preview.','Previous/next labels also paginate credit text.','PDF dimensions are 144-dpi source pixels; crop coordinates must be positive-area and within those source bounds.','Nonempty PDF length permits exactly 512 MiB. Page count is 1 through supplied maximum.','SecurityException becomes password-or-unsupported-encryption text; generic errors retain possible damage or unsupported features.','Preview-memory copy must remain conditional because even 1×1 can exceed native/resident memory allowance.'],
'format_checks': 'All 40 values checked for exact positional slot sequence/types, XML text parseability, no ASCII quote/apostrophe needing Android escaping, and raw backslash-n parity with source. Both canonical paths exist. No application files changed.',
'terminology_basis':'Pinned canonical resources inspected for local vocabulary only; author notes and existing strings are not independent linguistic acceptance.'},limits=['Independent AI contextual full-value review of the 40 changed candidates only. Not native-human linguistic acceptance.','No Android compilation, runtime execution, glyph/layout, screen-reader or release certification. Tests were read, not executed.','No claims about remaining locale keys or overall catalogue completeness. No external review requested or publication performed.'])
assert len(decisions)==40
(p/'review-hy-ka.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result['summary']))
