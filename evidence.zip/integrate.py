import collections,copy,hashlib,json,pathlib,re,subprocess,unicodedata,xml.etree.ElementTree as E,sys
sys.path.insert(0,'tools')
import translation_catalogues as catalogues
from current_localization_contracts import decode_display
w=pathlib.Path('/workspace/shared/anpaint-p2-continuation-evidence')
p=json.load(open(w/'candidate.json'))
review=json.load(open(w/'review.json'))
assert review['summary']['held']==0 and review['summary']['final_accepted']==120
values=review['accepted']
assert set(p['paths'])=={'az','be','hy','ka','sq','gd'}
assert set(p['paths'])<=set(catalogues.offered_tags())
assert set(values)==set(p['paths'])
assert all(catalogues.catalogue_paths()[locale].relative_to(catalogues.ROOT).as_posix()==path for locale,path in p['paths'].items())
assert subprocess.check_output(['git','status','--porcelain'],text=True)==''
source={n.get('name'):n for n in E.parse('Paintroid/src/main/res/values/strings.xml').getroot()}
tiers={k:t['id'] for t in json.load(open('translations/string-importance.json'))['tiers'] for k in t['keys']}
held={(x['path'],x['key']) for xs in json.load(open(w/'fresh-held-changes.json')).values() for x in xs}
def node_value(n):
 c=copy.deepcopy(n);c.tail=None
 return E.tostring(c,encoding='unicode')
summary={}
for locale,path in p['paths'].items():
 target=pathlib.Path(path);old=target.read_text();before=E.fromstring(old)
 old_nodes={n.get('name'):node_value(n) for n in before}
 stack={n.get('name') for n in E.fromstring(subprocess.check_output(['git','show','localization/global-p1-controls-fifth-20261109:'+path]))}
 assert set(values[locale])==set(p['translations'][locale]) and len(values[locale])==20
 additions=[]
 for key,value in values[locale].items():
  assert key not in old_nodes and key not in stack and (path,key) not in held
  assert tiers['string/'+key]=='P2'
  assert p['source'][key]=={'text':source[key].text,'attributes':source[key].attrib}
  assert value and value==unicodedata.normalize('NFC',value)
  assert collections.Counter(re.findall(r'%[0-9]+[$][a-zA-Z]',value))==collections.Counter(re.findall(r'%[0-9]+[$][a-zA-Z]',source[key].text))
  assert value.count(r'\n')==source[key].text.count(r'\n') and '\n' not in value
  assert not any(ord(c)<32 for c in value)
  assert not catalogues.android_string_errors(value)
  assert not catalogues.format_string_errors(value,source[key].get('formatted')!='false')
  assert decode_display(value)
  assert any(key in f.read_text() for f in pathlib.Path('Paintroid/src/main/java').rglob('*.kt'))
  node=E.Element('string',source[key].attrib);node.text=value
  additions.append('    '+E.tostring(node,encoding='unicode')+'\n')
 assert old.count('</resources>')==1
 final=old.replace('</resources>',''.join(additions)+'</resources>')
 nodes={n.get('name'):n for n in E.fromstring(final)}
 assert len(nodes)==len(before)+20
 assert all(node_value(nodes[k])==v for k,v in old_nodes.items())
 assert all(nodes[k].text==v and nodes[k].attrib==source[k].attrib for k,v in values[locale].items())
 target.write_text(final)
 summary[locale]={'old_nodes_preserved':len(before),'new_values':20,'path':path,'blob':subprocess.check_output(['git','hash-object',path],text=True).strip()}
summary['accepted_map_sha256']=hashlib.sha256(json.dumps(values,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
(w/'integration.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
