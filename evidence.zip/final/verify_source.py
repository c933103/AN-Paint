from pathlib import Path
import json,hashlib,subprocess,sys,xml.etree.ElementTree as ET
O=Path(__file__).resolve().parent;S=O/'source';base=json.loads((O/'base-tree.json').read_text())
expected_base={e['path']:e for e in base['tree'] if e['type']=='blob'}
changes=subprocess.check_output(['git','diff','--name-only'],cwd=S,text=True).splitlines()
new=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=S,text=True).splitlines()
assert set(changes)=={f'Paintroid/src/main/res/{x}/strings.xml' for x in ['values-de','values-b+es+ES','values-it','values-b+pt+PT']}
assert set(new)=={'Paintroid/src/test/java/org/catrobat/paintroid/local/CropCounterpartGuidanceTest.kt','Paintroid/src/test/resources/crop-counterparts/expected.json','tools/test_crop_counterpart_guidance.py'}
def describe(p):
 b=p.read_bytes();return {'path':str(p.relative_to(S)),'mode':oct(p.stat().st_mode&0o777)[2:],'sha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
rows=[]
for path,e in expected_base.items():
 r=describe(S/path);rows.append(r)
 assert ('100755' if r['mode']=='755' else '100644')==e['mode'],path
 if path not in changes:assert r['sha']==e['sha'],path
for path in new:rows.append(describe(S/path))
for path in changes:
 old=ET.fromstring(subprocess.check_output(['git','show','HEAD:'+path],cwd=S,text=True));current=ET.parse(S/path).getroot()
 keys=lambda root:{(x.tag,x.attrib['name']):ET.tostring(x,encoding='unicode') for x in root}
 a,b=keys(old),keys(current);assert set(a)==set(b)
 assert {k for k in a if a[k]!=b[k]}=={('string','ui_add_up_to_20_images_with_android_s'),('plurals','ui_crop_preview_images')}
summary={'base_commit':'f988a94d8e4fa300bfe181ba67bba7b546651ca1','base_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=S,text=True).strip(),'base_leaf_count':len(expected_base),'candidate_leaf_count':len(rows),'changed':changes,'added':new,'removed':[],'all_unchanged_blob_contents_and_modes_match':True,'resource_scope':'Exactly two keys per locale, one complete Help and both existing one/other crop items. All other resource values are unchanged.','existing_accepted_scope':'All EN/FR/JA/HK/LT/AR/RU/KO resource files and corresponding existing tests/fixtures are unchanged from the verified base; prior bounded receipts are preserved, never expanded into new acceptance.','separate_work':'All merged PR117/119 source/tests/resources are preserved exactly from develop f988a94d; this patch adds no duplicate implementation.','priority':'Help remains P3; crop plurals remain P2. translations/string-importance.json is byte-identical.','scope_and_unreviewed_receipts_unchanged':True}
(O/'source-comparison.json').write_text(json.dumps(summary,indent=2)+'\n');(O/'candidate-manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
# Show that restoring any one of the twelve original complete values fails the current oracle.
sys.path.insert(0,str(S/'tools'));from test_crop_counterpart_guidance import require_complete,PATHS
fixture=json.loads((S/'Paintroid/src/test/resources/crop-counterparts/expected.json').read_text())['locales'];rejections=[]
for pair in json.loads((O/'complete-value-comparison.json').read_text()):
 tag=pair['tag'];root=ET.parse(S/'Paintroid/src/main/res'/PATHS[tag]/'strings.xml').getroot();q=pair['quantity'];key=pair['key']
 node=root.find(f"./plurals[@name='{key}']/item[@quantity='{q}']" if q else f"./string[@name='{key}']");node.text=pair['old_full_value']
 try:require_complete(root,fixture[tag])
 except ValueError as e:rejections.append({'tag':tag,'key':key,'quantity':q,'old_value_rejected':True,'reason':str(e)})
 else:raise AssertionError((tag,key,q))
assert len(rejections)==12;(O/'old-value-controls.json').write_text(json.dumps(rejections,indent=2)+'\n')
print(json.dumps(summary,indent=2));print('All 12 old-value controls rejected')
