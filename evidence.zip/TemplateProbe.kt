import java.util.Locale
fun main() {
var checks=0
val locales=listOf("pt-BR","de","en-001","ar","ro")
for (tag in locales) {
val locale=Locale.forLanguageTag(tag)
Locale.setDefault(if(tag=="en-001") Locale.GERMANY else Locale.US)
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Current safe budget: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Current safe editing budget: %1\$s · up to %2\$.2f MP before decoder overhead"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d pixels (%3\$.2f MP) exceeds the current safe editing budget of %4\$.2f MP. AN Paint keeps the complete image in memory and reserves space for transforms and selections. Available memory determines this budget. The operation was stopped before allocating the oversized bitmap. No automatic resizing was applied."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Recent colour %1\$d: #%2\$06X. Tap foreground, hold background."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Recent colour %1\$s: empty"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="الحد الآمن الحالي: %1\$.2f ميغابكسل."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="حد التحرير الآمن الحالي: %1\$s · حتى %2\$.2f ميغابكسل قبل الحمل الإضافي لفك الترميز"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="يتجاوز %1\$d × %2\$d بكسل (%3\$.2f ميغابكسل) حد التحرير الآمن الحالي البالغ %4\$.2f ميغابكسل. يحتفظ AN Paint بالصورة كاملة في الذاكرة ويحجز مساحة للتحويلات والتحديدات. تحدد الذاكرة المتاحة هذا الحد. أُوقفت العملية قبل تخصيص الصورة النقطية الكبيرة جدًا. لم يُطبق تغيير حجم تلقائي."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="اللون الأخير %1\$d: #%2\$06X. اضغط للمقدمة، واضغط مطولًا للخلفية."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="اللون الأخير %1\$s: فارغ"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Huidige veilige limiet: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Huidige veilige redigeerlimiet: %1\$s · tot %2\$.2f MP voor dekodeerderoorhoofse koste"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d piksels (%3\$.2f MP) oorskry die huidige veilige redigeerlimiet van %4\$.2f MP. AN Paint hou die volledige beeld in geheue en reserveer ruimte vir transformasies en keuses. Beskikbare geheue bepaal hierdie limiet. Die bewerking is gestop voordat die te groot bitmap toegewys is. Geen outomatiese grootteverandering is toegepas nie."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Onlangse kleur %1\$d: #%2\$06X. Tik vir voorgrond, hou in vir agtergrond."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Onlangse kleur %1\$s: leeg"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="タネ アエイワンケ エアㇱカイ パㇰノ: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="タネ ノカ ヌイェ クス RAM コㇿ イシナ: %1\$s · チヌイェㇷ゚ オㇿ ワ ノカ アカㇻ クス ウㇱケ ソモ オマレ ノ %2\$.2f MP パㇰノ"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d pixel (%3\$.2f MP) アナㇰ タネ ノカ ヌイェ クス アエイワンケ エアㇱカイ %4\$.2f MP カス. AN Paint アナㇰ ノカ オピッタ RAM オㇿ タ アマ. ノカ コㇿ カトゥフ アシンナレ クス ネワ ノカ アヌㇺケ クス カ RAM コㇿ ウㇱケ アアマ. タネ アエイワンケ エアㇱカイ RAM アニ タン パㇰノ パテㇰ ノカ ヌイェ エアㇱカイ. ポロ ノカ コㇿ pixel オピッタ RAM オㇿ タ アアマ エトコ タン イカㇻ アホントモトゥイェ. ノカ コㇿ ポロル ヤイカタ アシンナレ カ ソモ キ."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="タネ エイワンケ イロ %1\$d: #%2\$06X. アキㇰ ヤクン コッチャ, アキㇱマ ヤクン オカ イロ."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="タネ アエイワンケ イロ %1\$s: イサㇺ"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Tane a=eywanke easkay pakno: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Tane noka nuye kusu RAM kor isina: %1\$s · cinuyep or wa noka a=kar kusu uske somo omare no %2\$.2f MP pakno"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d pixel (%3\$.2f MP) anak tane noka nuye kusu a=eywanke easkay %4\$.2f MP kasu. AN Paint anak noka opitta RAM or ta ama. Noka kor katuhu a=sinnare kusu newa noka a=numke kusu ka RAM kor uske a=ama. Tane a=eywanke easkay RAM ani tan pakno patek noka nuye easkay. Poro noka kor pixel opitta RAM or ta a=ama etoko tan ikar a=hontomotuye. Noka kor pororu yaykata a=sinnare ka somo ki."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Tane eywanke iro %1\$d: #%2\$06X. A=kik yakun kotca, a=kisma yakun oka iro."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Tane a=eywanke iro %1\$s: isam"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="ད་ལྟའི་བདེ་འཇགས་ཚད: %1\$.2f MP།"
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="ད་ལྟའི་བདེ་འཇགས་རྩོམ་སྒྲིག་ཚད: %1\$s · གསང་བཤད་ཆས་ཀྱི་ཁ་སྣོན་མ་རྩིས་གོང་ %2\$.2f MP བར།"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d པིག་སེལ (%3\$.2f MP) ནི་ད་ལྟའི་བདེ་འཇགས་རྩོམ་སྒྲིག་ཚད་ %4\$.2f MP ལས་བརྒལ། AN Paint ཡིས་པར་རིས་ཆ་ཚང་དྲན་ཤེས་ནང་ཉར་ཞིང་བསྒྱུར་བ་དང་འདེམས་ཁུལ་ལ་སྟོང་ཆ་སྔོན་ཉར་བྱེད། ཚད་འདི་སྤྱོད་རུང་དྲན་ཤེས་ལས་ཐག་གཅོད། bitmap ཧ་ཅང་ཆེ་བ་བཟོ་གོང་བྱ་སྤྱོད་མཚམས་བཞག་ཡོད། རང་འགུལ་གྱིས་ཆེ་ཆུང་མ་བསྒྱུར།"
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="ཉེ་ཆར་སྤྱད་པའི་ཁ་དོག %1\$d: #%2\$06X། རེག་ན་མདུན། རྒྱུན་གནོན་ན་རྒྱབ།"
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="ཉེ་ཆར་གྱི་ཁ་དོག %1\$s: སྟོང་།"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Kasamtangang luwas nga limit: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Kasamtangang luwas nga gahin sa memorya alang sa pag-edit: %1\$s · hangtod %2\$.2f MP, wala pa labot ang dugang nga memorya sa decoder"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Ang %1\$d × %2\$d pixels (%3\$.2f MP) milapas sa kasamtangang luwas nga gahin sa pag-edit nga %4\$.2f MP. Gitipigan sa AN Paint ang tibuok hulagway sa memorya ug gigahinan usab og luna ang pag-usab sa porma ug mga pagpili. Ang magamit nga memorya maoy magbuot niining gahin. Gihunong ang operasyon sa wala pa paggahin og memorya alang sa sobrang dakong bitmap. Wala awtomatikong usba ang gidak-on."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Bag-ong gigamit nga kolor %1\$d: #%2\$06X. I-tap para sa atubangan, pislita ug dugay para sa likod."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Bag-ong gigamit nga kolor %1\$s: walay sulod"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="ད་ལྟོའི་ཉེན་མེད་ཚད: %1\$.2f MP།"
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="ད་ལྟོའི་ཉེན་མེད་བསྒྱུར་བཅོས་ཚད: %1\$s · ཨང་བཤད་ཆས་ཀྱི་ཁ་སྐོང་མ་རྩིས་པར་ %2\$.2f MP ཚུན།"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d པིག་སེལསི (%3\$.2f MP) འདི་ད་ལྟོའི་ཉེན་མེད་བསྒྱུར་བཅོས་ཚད་ %4\$.2f MP ལས་བརྒལ་ཡོད། AN Paint གིས་གཟུགས་བརྙན་ཆ་ཚང་དྲན་ཚད་ནང་བཞག་སྟེ་བསྒྱུར་བཅོས་དང་སེལ་འཐུ་གི་དོན་ལུ་ས་སྟོང་བཞགཔ་ཨིན། ཚད་འདི་དྲན་ཚད་ཐོབ་ཚུགས་མི་དང་འཁྲིལ་གཏན་འཁེལ་འབདཝ་ཨིན། bitmap ཚད་ལས་བརྒལ་མི་བཟོ་བའི་ཧེ་མ་བྱ་བ་མཚམས་འཇོག་འབད་ཡོད། རང་འགུལ་ཚད་བསྒྱུར་མ་འབད།"
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="ཉེ་ཆར་ཚོས་གཞི %1\$d: #%2\$06X། ཨེབ་ན་གདོང་གཞི། ཨེབ་བཞག་ན་རྒྱབ་གཞི།"
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="ཉེ་ཆར་ཚོས་གཞི %1\$s: སྟོངམ།"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Current safe budget: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Current safe editing budget: %1\$s · up to %2\$.2f MP before decoder overhead"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d pixels (%3\$.2f MP) exceeds the current safe editing budget of %4\$.2f MP. AN Paint keeps the complete image in memory and reserves space for transforms and selections. Available memory determines this budget. The operation was stopped before allocating the oversized bitmap. No automatic resizing was applied."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Recent colour %1\$d: #%2\$06X. Tap foreground, hold background."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Recent colour %1\$s: empty"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Current safe budget: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Current safe editing budget: %1\$s · up to %2\$.2f MP before decoder overhead"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d pixels (%3\$.2f MP) exceeds the current safe editing budget of %4\$.2f MP. AN Paint keeps the complete image in memory and reserves space for transforms and selections. Available memory determines this budget. The operation was stopped before allocating the oversized bitmap. No automatic resizing was applied."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Recent colour %1\$d: #%2\$06X. Tap foreground, hold background."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Recent colour %1\$s: empty"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Nuna sekura limo: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Nuna sekura redakta limo: %1\$s · ĝis %2\$.2f MP antaŭ malkodila kromkosto"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d bilderoj (%3\$.2f MP) superas la nunan sekuran redaktan limon de %4\$.2f MP. AN Paint tenas la tutan bildon en memoro kaj rezervas spacon por transformoj kaj elektoj. La disponebla memoro determinas ĉi tiun limon. La operacio haltis antaŭ asigno de tro granda rastrumbildo. Neniu aŭtomata regrandigo estis aplikita."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Lasta koloro %1\$d: #%2\$06X. Tuŝu por malfono, tenu por fono."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Lasta koloro %1\$s: malplena"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Límite seguro actual: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Límite seguro de edición actual: %1\$s · hasta %2\$.2f MP antes de la sobrecarga del decodificador"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d píxeles (%3\$.2f MP) supera el límite seguro de edición actual de %4\$.2f MP. AN Paint mantiene la imagen completa en memoria y reserva espacio para transformaciones y selecciones. La memoria disponible determina este límite. La operación se detuvo antes de asignar el mapa de bits sobredimensionado. No se aplicó ningún cambio de tamaño automático."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Color reciente %1\$d: #%2\$06X. Toca para primer plano; mantén presionado para fondo."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Color reciente %1\$s: vacío"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Límite seguro actual: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Límite seguro de edición actual: %1\$s · hasta %2\$.2f MP antes de la sobrecarga del decodificador"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Una imagen de %1\$d × %2\$d píxeles (%3\$.2f MP) supera el límite seguro de edición actual de %4\$.2f MP. AN Paint mantiene la imagen completa en memoria y reserva espacio para transformaciones y selecciones. La memoria disponible determina este límite. La operación se detuvo antes de asignar el mapa de bits sobredimensionado. No se aplicó ningún cambio de tamaño automático."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Color reciente %1\$d: #%2\$06X. Pulsa para primer plano; mantén pulsado para fondo."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Color reciente %1\$s: vacío"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Praegune ohutu piir: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Praegune ohutu muutmispiir: %1\$s · kuni %2\$.2f MP enne dekoodri lisakulu"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d pikslit (%3\$.2f MP) ületab praeguse ohutu muutmispiiri %4\$.2f MP. AN Paint hoiab kogu pilti mälus ning jätab ruumi teisendustele ja valikutele. Selle piiri määrab saadaolev mälu. Toiming peatati enne liiga suure rasterpildi eraldamist. Automaatset suuruse muutmist ei tehtud."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Hiljutine värv %1\$d: #%2\$06X. Puuduta esiplaani jaoks, hoia tausta jaoks all."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Hiljutine värv %1\$s: tühi"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Kasalukuyang ligtas na limitasyon: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Kasalukuyang ligtas na limitasyon sa pag-edit: %1\$s · hanggang %2\$.2f MP bago ang dagdag na gamit ng decoder"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Ang %1\$d × %2\$d pixels (%3\$.2f MP) ay lumalampas sa kasalukuyang ligtas na limitasyon sa pag-edit na %4\$.2f MP. Pinananatili ng AN Paint ang buong larawan sa memory at naglalaan ng espasyo para sa mga transform at selection. Ang available na memory ang nagtatakda ng limitasyong ito. Itinigil ang operasyon bago maglaan ng sobrang laking bitmap. Walang awtomatikong pagbabago ng laki na inilapat."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Kamakailang kulay %1\$d: #%2\$06X. I-tap para sa harap, pindutin nang matagal para sa likod."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Kamakailang kulay %1\$s: walang laman"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="這下安全上限：%1\$.2f MP。"
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="這下安全編輯上限：%1\$s · 扣除解碼器額外開銷前最多 %2\$.2f MP"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d 像素（%3\$.2f MP）超出這下 %4\$.2f MP 个安全編輯上限。AN Paint 會將完整圖像留等在記憶體，並預留空間作變形及揀取範圍處理。此上限由可用記憶體決定。系統已在配置過大个點陣圖前停止操作，並未自動調大細。"
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="最近使用个色水 %1\$d：#%2\$06X。點設為前景色，長撳設為背景色。"
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="最近使用个色水 %1\$s：空白"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Yá-ha ôn-chhiòn sông han: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Yá-ha ôn-chhiòn piên-si̍p sông han: %1\$s · khieu-chhù kié mâ hi ngiak ngo khôi-sêu chhièn chui-tô %2\$.2f MP"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d siong su(%3\$.2f MP)chhêu chhut yá-ha %4\$.2f MP ke ôn-chhiòn piên-si̍p sông han. AN Paint voi chiông vàn-chṳ́n thù siong liù tén chhai ki-yit thí, pin yi liù khûng kiên chok pien hìn khi̍p kién chhí fam-vì chhú lî. chhṳ́ sông han yù khó yung ki-yit thí kiet-thin. ne-thúng yî chhai phi chṳ ko thai ke tiam chhṳn thù chhièn thìn chṳ́ chhâu chok, pin vi chhṳ-thung tiau thai-se."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Chui khiûn sâi yung ke set súi %1\$d: #%2\$06X. tiam sat vì chhièn kín-set, chhòng khim sat vì poi-kín set."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Chui khiûn sâi yung ke set súi %1\$s: khûng pha̍k"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="현재 안전 한도: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="현재 안전 편집 한도: %1\$s · 디코더 여유분 제외 최대 %2\$.2f MP"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d 픽셀(%3\$.2f MP)은 지금 안전허게 편집헐 수 있는 한도 %4\$.2f MP를 넘엇수다. AN Paint는 이미지 몬딱 메모리에 놔두곡 변형이영 영역 고르기에 쓸 자리도 따로 남겨둡네다. 이 한도는 지금 쓸 수 있는 메모리에 따라 정해집네다. 너무 큰 비트맵 자리를 잡기 전에 작업을 멈추엇수다. 크기를 저절로 줄이지는 않앗수다."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="최근 쓴 색 %1\$d: #%2\$06X. 짧게 누르민 전경색, 오래 누르민 배경색으로 골라집네다."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="최근 색 %1\$s: 비어 이심"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="현재 안전 한도: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="현재 안전 편집 한도: %1\$s · 해독기 추가 기억기 전 최대 %2\$.2f MP"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d 화소(%3\$.2f MP)는 현재 안전 편집 한도 %4\$.2f MP를 초과합니다. AN Paint는 전체 화상을 기억기에 유지하고 변형과 선택령역 처리 공간도 확보합니다. 이 한도는 리용 가능한 기억기에 따라 결정됩니다. 너무 큰 비트맵을 할당하기 전에 작업을 중지했습니다. 자동 크기 조절은 적용하지 않았습니다."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="최근 색 %1\$d: #%2\$06X. 누르면 전경색, 오래 누르면 배경색으로 설정합니다."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="최근 색 %1\$s: 비어 있음"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="현재 안전 한도: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="현재 안전 편집 한도: %1\$s · 디코더 추가 메모리 전 최대 %2\$.2f MP"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d 픽셀(%3\$.2f MP)은 현재 안전 편집 한도 %4\$.2f MP를 초과합니다. AN Paint는 전체 이미지를 메모리에 유지하고 변형과 선택 영역 처리 공간도 확보합니다. 이 한도는 사용 가능한 메모리에 따라 결정됩니다. 너무 큰 비트맵을 할당하기 전에 작업을 중지했습니다. 자동 크기 조절은 적용하지 않았습니다."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="최근 색 %1\$d: #%2\$06X. 탭하면 전경색, 길게 누르면 배경색으로 설정합니다."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="최근 색 %1\$s: 비어 있음"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="現在 安全 限度: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="現在 安全 編輯 限度: %1\$s · 디코더 追加 메모리 전 최대 %2\$.2f MP"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d 픽셀(%3\$.2f MP)은 現在 安全 編輯 限度 %4\$.2f MP를 초과합니다. AN Paint는 全體 이미지를 메모리에 유지하고 변형과 選擇 領域 처리 空間도 확보합니다. 이 限度는 使用 가능한 메모리에 따라 결정됩니다. 너무 큰 비트맵을 할당하기 전에 作業을 중지했습니다. 自動 크기 조절은 適用하지 않았습니다."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="최근 색 %1\$d: #%2\$06X. 탭하면 前景色, 길게 누르면 背景色으로 設定합니다."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="최근 색 %1\$s: 비어 있음"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Pašreizējais drošais limits: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Pašreizējais drošais rediģēšanas limits: %1\$s · līdz %2\$.2f MP pirms dekodētāja papildu izmaksām"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d pikseļi (%3\$.2f MP) pārsniedz pašreizējo drošo rediģēšanas limitu %4\$.2f MP. AN Paint glabā visu attēlu atmiņā un rezervē vietu pārveidojumiem un atlasēm. Pieejamā atmiņa nosaka šo limitu. Darbība tika apturēta pirms pārāk liela bitkartes attēla piešķiršanas. Automātiska izmēra maiņa netika veikta."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Nesenā krāsa %1\$d: #%2\$06X. Pieskarieties priekšplānam, turiet nospiestu fonam."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Nesenā krāsa %1\$s: tukša"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="今安全限：%1\$.2f MP。"
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="今安全編修限：%1\$s · 未計解碼額外耗用，至多 %2\$.2f MP"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d 像素（%3\$.2f MP）逾今安全編修限 %4\$.2f MP。AN Paint 須存全圖於記憶體，且留空間供變形與選區。此限隨可用記憶體而定。於配置過大位圖前已止此舉，未自動縮圖。"
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="最近用之色 %1\$d：#%2\$06X。點設為前景色，久按設為背景色。"
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="最近用之色 %1\$s：空白"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Одоогийн аюулгүй хязгаар: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Одоогийн аюулгүй засварлах хязгаар: %1\$s · декодерын нэмэлт хэрэглээнээс өмнө %2\$.2f MP хүртэл"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d пиксел (%3\$.2f MP) нь одоогийн %4\$.2f MP аюулгүй засварлах хязгаараас давсан. AN Paint бүх зургийг санах ойд хадгалж, хувиргалт болон сонголтод нэмэлт зай нөөцөлдөг. Энэ хязгаар нь боломжит санах ойгоор тогтоно. Хэт том bitmap үүсгэхээс өмнө үйлдлийг зогсоосон. Автоматаар хэмжээ өөрчлөөгүй."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Сүүлийн өнгө %1\$d: #%2\$06X. Товшвол үндсэн, удаан дарвал дэвсгэр өнгө."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Сүүлийн өнгө %1\$s: хоосон"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="ᠣᠳᠣ ᠶᠢᠨ ᠠᠶᠤᠯ ᠦᠭᠡᠢ ᠬᠢᠵᠠᠭᠠᠷ: %1\$.2f MP᠃"
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="ᠣᠳᠣ ᠶᠢᠨ ᠠᠶᠤᠯ ᠦᠭᠡᠢ ᠵᠠᠰᠠᠬᠤ ᠬᠢᠵᠠᠭᠠᠷ: %1\$s · ᠲᠠᠶᠢᠯᠤᠭᠤᠷ ᠤᠨ ᠨᠡᠮᠡᠯᠲᠡ ᠡᠴᠡ ᠡᠮᠦᠨ᠎ᠡ %2\$.2f MP ᠬᠦᠷᠲᠡᠯ᠎ᠡ"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d ᠫᠢᠺᠰᠧᠯ (%3\$.2f MP) ᠨᠢ ᠣᠳᠣ ᠶᠢᠨ %4\$.2f MP ᠠᠶᠤᠯ ᠦᠭᠡᠢ ᠵᠠᠰᠠᠬᠤ ᠬᠢᠵᠠᠭᠠᠷ ᠠᠴᠠ ᠶᠡᠬᠡ᠃ AN Paint ᠪᠦᠬᠦ ᠵᠢᠷᠤᠭ ᠢ ᠣᠢ ᠳᠤ ᠪᠠᠶᠢᠯᠭᠠᠵᠤ᠂ ᠬᠤᠪᠢᠷᠭᠠᠯᠲᠠ ᠪᠠ ᠰᠣᠩᠭᠣᠯᠲᠠ ᠳᠤ ᠵᠠᠢ ᠨᠥᠭᠡᠴᠡᠯᠡᠨ᠎ᠡ᠃ ᠬᠡᠲᠦ ᠶᠡᠬᠡ bitmap ᠬᠤᠪᠢᠶᠠᠷᠢᠯᠠᠬᠤ ᠡᠴᠡ ᠡᠮᠦᠨ᠎ᠡ ᠦᠢᠯᠡᠳᠦᠯ ᠢ ᠵᠣᠭᠰᠣᠭᠠᠪᠠ᠃ ᠠᠦ᠋ᠲ᠋ᠣ ᠬᠡᠮᠵᠢᠶ᠎ᠡ ᠰᠣᠯᠢᠭ᠎ᠠ ᠦᠭᠡᠢ᠃"
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="ᠰᠡᠭᠦᠯ ᠦᠨ ᠥᠩᠭᠡ %1\$d: #%2\$06X᠃ ᠳᠠᠷᠤᠪᠠᠯ ᠡᠮᠦᠨ᠎ᠡ᠂ ᠤᠳᠠᠭᠠᠨ ᠳᠠᠷᠤᠪᠠᠯ ᠠᠷᠤ ᠥᠩᠭᠡ᠃"
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="ᠰᠡᠭᠦᠯ ᠦᠨ ᠥᠩᠭᠡ %1\$s: ᠬᠣᠭᠣᠰᠣᠨ"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="ᡨᡝ ᠵᠣᠪᠣᠯᠣᠨ ᠠᡴᡡ ᠪᠠᡳᡨᠠᠯᠠᠮᡝ ᠮᡠᡨᡝᡵᡝ ᡴᡝᠮᡠᠨ: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="ᡨᡝ ᠵᠣᠪᠣᠯᠣᠨ ᠠᡴᡡ ᡩᠠᠰᠠᠮᡝ ᠮᡠᡨᡝᡵᡝ RAM ᡳ ᡴᡝᠮᡠᠨ: %1\$s · ᠨᡳᡵᡠᡤᠠᠨ ᠣᠪᡠᠮᡝ ᡥᡡᠯᠠᡵᠠ ᡩᡝ ᠪᠠᡳᡨᠠ ᠠᡵᠠᡵᠠ ᡤᡡᠸᠠ ᠪᠠ ᠪᡝ ᡤᡝᠮᡠᠨᡳ ᡩᠣᠰᡳᠮᠪᡠᡥᠠᡴᡡ ᠪᠣᡩᠣᠴᡳ %2\$.2f MP ᡩᡝ ᡳᠰᡳᡨᠠᠯᠠ"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d px (%3\$.2f MP) ᡨᡝ ᠵᠣᠪᠣᠯᠣᠨ ᠠᡴᡡ ᡩᠠᠰᠠᠮᡝ ᠮᡠᡨᡝᡵᡝ %4\$.2f MP ᡳ ᡴᡝᠮᡠᠨ ᠪᡝ ᡩᠠᠪᠠᠯᡳᡥᠠ. AN Paint ᠶᠣᠣᠨᡳ ᠨᡳᡵᡠᡤᠠᠨ ᠪᡝ RAM ᡩᡝ ᠪᡳᠪᡠᠮᠪᡳ. ᠨᡳᡵᡠᡤᠠᠨ ᡳ ᠠᡵᠪᡠᠨ ᠪᡝ ᡥᠠᠯᠠᡵᠠ ᠵᠠᡳ ᠪᠠ ᠪᡝ ᠰᠣᠨᠵᠣᡵᡝ ᡩᡝ ᠪᠠᡳᡨᠠ ᠠᡵᠠᡵᠠ ᠪᠠ ᠪᡝ ᡳᠨᡠ ᠪᡝᠯᡥᡝᠮᠪᡳ. ᠪᠠᡳᡨᠠᠯᠠᠮᡝ ᠮᡠᡨᡝᡵᡝ RAM ᡝᡵᡝ ᡴᡝᠮᡠᠨ ᠪᡝ ᡨᠣᡴᡨᠣᠪᡠᠮᠪᡳ. ᡠᠮᡝᠰᡳ ᠠᠮᠪᠠ ᠨᡳᡵᡠᡤᠠᠨ ᡳ ᠪᠠ ᠪᡝ ᠠᡵᠠᡵᠠ ᠣᠩᡤᠣᠯᠣ ᠪᠠᡳᡨᠠ ᠪᡝ ᠨᠠᡴᠠᡥᠠ. ᠠᠮᠪᠠ ᠠᠵᡳᡤᡝ ᠪᡝ ᠪᡝᠶᡝ ᡳ ᡥᠠᠯᠠᡥᠠᡴᡡ."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="ᡥᠠᠨ᠋ᠴᡳᡴᡳ ᠪᠠᡳ᠌ᠲᠠᠯᠠᡥᠠ ᠪᠣᠴᠣ %1\$d: #%2\$06X. ᡩᠠᡵᠠᡥᠠ ᠣᠴᡳ ᠵᡠᠯᡝᡵᡤᡳ, ᠵᠠᡶᠠᡥᠠ ᠣᠴᡳ ᠠᠮᠠᡵᡤᡳ ᠪᠣᠴᠣ."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="ᡥᠠᠨ᠋ᠴᡳᡴᡳ ᠪᠠᡳ᠌ᠲᠠᠯᠠᡥᠠ ᠪᠣᠴᠣ %1\$s: ᡠᠨ᠋ᡨᡠ᠋ᡥᡠᠨ"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="這馬安全上限：%1\$.2f MP。"
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="這馬安全編輯上限：%1\$s · 扣除解碼器額外開銷前最多 %2\$.2f MP"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d 像素（%3\$.2f MP），超過這馬 %4\$.2f MP 的安全編輯上限矣。AN Paint 愛共完整圖片留佇記憶體，閣留空間做變形佮處理選取範圍。上限是照會當用的記憶體來定的。程式佇配置傷大的點陣圖進前已經停止，無家己調細圖片。"
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="最近使用的色彩 %1\$d：#%2\$06X。點設為前景色，長按設為背景色。"
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="最近使用的色彩 %1\$s：空白"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px \n %3\$.1f °"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Chit-má an-choân siōng-hān: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Chit-má an-choân pian chi̍p siōng-hān: %1\$s · khàu-tî kái-bé-khì gia̍h-gōa khai-siau chiân chòe to %2\$.2f MP"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d siōng-sò͘ (%3\$.2f MP), chhiau-kòe chit-má %4\$.2f MP ê an-choân pian-chi̍p siōng-hān--ah. AN Paint ài kā oân-chéng tô͘-phìⁿ lâu tī kì-ek-thé, koh lâu khong-kan chò piàn-hêng kah chhú-lí soán-chhú hoān-ûi. Siōng-hān sī chiàu ē-tàng ēng ê kì-ek-thé lâi tēng ê. Thêng-sek tī phòe-tì siuⁿ tōa ê tiám-tīn-tô͘ chìn-chêng í-keng thêng-chí, bô ka-kī tiâu sè tô͘-phìⁿ."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Chòe-kīn sú-iōng ê sek-chhái %1\$d: #%2\$06X. Tiám siat ûi chiân kéng-sek, tn̂g àn siat ûi pōe kéng-sek."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Chòe-kīn sú-iōng ê sek-chhái %1\$s: khang-pe̍h"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Limite seguro atual: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Limite seguro de edição atual: %1\$s · até %2\$.2f MP antes da sobrecarga do descodificador"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d píxeis (%3\$.2f MP) excedem o limite seguro de edição atual de %4\$.2f MP. O AN Paint mantém a imagem completa na memória e reserva espaço para transformações e seleções. A memória disponível determina este limite. A operação foi interrompida antes de alocar o bitmap demasiado grande. Não foi aplicado qualquer redimensionamento automático."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Cor recente %1\$d: #%2\$06X. Toque para primeiro plano, mantenha premido para fundo."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Cor recente %1\$s: vazia"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="🧪 %1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="🧪 Current safe budget: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="🧪 Current safe editing budget: %1\$s · up to %2\$.2f MP before decoder overhead"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="🎨 %1\$d × %2\$d pixels (%3\$.2f MP) exceeds the current safe editing budget of %4\$.2f MP. AN Paint keeps the complete image in memory and reserves space for transforms and selections. Available memory determines this budget. The operation was stopped before allocating the oversized bitmap. No automatic resizing was applied."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="🎨 Recent colour %1\$d: #%2\$06X. Tap foreground, hold background."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="🎨 Recent colour %1\$s: empty"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="なま安全んかい ちかゆる上限: %1\$.2f MP。"
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="なま安全んかい編集する上限: %1\$s · 最大%2\$.2f MP（デコーダーぬ追加メモリや くぬ量んかい入っちょーいびらん）"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$dピクセル（%3\$.2f MP）や、なま安全んかい編集する上限%4\$.2f MPやか まぎさいびーん。AN Paintや 画像むる メモリんかい置ち、変形とぅ範囲選択ぬ処理んかい ちかゆるとぅくまん 残さびーん。くぬ上限や、なま ちかゆるメモリぬ量っし 決まやびーん。まぎさるビットマップぬとぅくま取ゆるめーに、作業 とぅみやびたん。自動っし サイズけーゆしや さびらんたん。"
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="さっき ちかたる色 %1\$d: #%2\$06X。タップすれー前景、長押しすれー背景ぬ色んかいなやびーん。"
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="さっき ちかたる色 %1\$s: 空"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="界限 安全 現在: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="界限 整 𢯢 安全 現在: %1\$s · 最多 %2\$.2f MP 𠓀 分 部𢖵 埠 𧵑 部 解 碼"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d 點影 (%3\$.2f MP) 越 過 界限 整 𢯢 安全 現在 纙 %4\$.2f MP. AN Paint 𡨺 全部 影 𥪝 部𢖵 吧 棦 添 𡊲 朱 變 𢷮 吧 漨 譔. 量 部𢖵 可 用 決定 界限 尼. 操作 㐌 仃 𠓀 欺 給發 bitmap 過 𡘯. 空 自動 𢷮 戟 𡱩."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="𦭷 近 低 %1\$d: #%2\$06X. 𪮻 抵 撻 前景, 扨 𡨺 抵 撻 𡋂."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="𦭷 近 低 %1\$s: 𤿰"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="现在安全上限：%1\$.2f MP。"
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="现在安全编辑上限：%1\$s · 扣除解码器额外开销前最多 %2\$.2f MP"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d 像素（%3\$.2f MP），超出现在 %4\$.2f MP 个安全编辑上限哉。AN Paint 要拿整张图片留辣内存里向，还要腾出空间做变形搭处理选区。上限是照可用内存来定个。程序辣分配过大个位图前头已经停下来，呒没自家拿图片缩小。"
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="最近使用个颜色 %1\$d：#%2\$06X。点设为前景色，长揿设为背景色。"
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="最近使用个颜色 %1\$s：空白"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="而家安全上限：%1\$.2f MP。"
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="而家安全編輯上限：%1\$s · 扣除解碼器額外開銷前最多 %2\$.2f MP"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d 像素（%3\$.2f MP）超出而家 %4\$.2f MP 嘅安全編輯上限。AN Paint 會將完整圖片保留喺記憶體，並預留空間作變形及揀選範圍處理。呢個上限由可用記憶體決定。系統已在配置過大嘅點陣圖前停止操作，並未自動調整大小。"
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="最近用嘅顏色 %1\$d：#%2\$06X。撳設為前景色，撳住設為背景色。"
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="最近用嘅顏色 %1\$s：空白"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f ×%2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Ji4 gaa1 on1 cyun4 soeng6 haan6:%1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Ji4 gaa1 on1 cyun4 pin1 cap1 soeng6 haan6:%1\$s · kau3 ceoi4 gaai2 maa5 hei3 ngaak6 ngoi6 hoi1 siu1 cin4 zeoi3 do1%2\$.2f MP"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d ×%2\$d zoeng6 sou3 (%3\$.2f MP)ciu1 ceot1 ji4 gaa1%4\$.2f MP ge3 on1 cyun4 pin1 cap1 soeng6 haan6. AN Paint wui5 zoeng1 jyun4 zing2 tou4 pin2 bou2 lau4 hai2 gei3 jik1 tai2, bing6 jyu6 lau4 hung1 gaan1 zok3 bin3 jing4 kap6 gaan2 syun2 faan6 wai4 cyu2 lei5. Ni1 go3 soeng6 haan6 jau4 ho2 jung6 gei3 jik1 tai2 kyut3 ding6. hai6 tung2 ji5 zoi6 pui3 zi3 gwo3 daai6 ge3 dim2 zan6 tou4 cin4 ting4 zi2 cou1 zok3, bing6 mei6 zi6 dung6 tiu4 zing2 daai6 siu2."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Zeoi3 gan6 jung6 ge3 ngaan4 sik1%1\$d: #%2\$06X. gam6 cit3 wai4 cin4 ging2 sik1, gam6 zyu6 cit3 wai4 bui3 ging2 sik1."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Zeoi3 gan6 jung6 ge3 ngaan4 sik1%1\$s: hung1 baak6"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d pixelů (%3\$.2f MP) překračuje aktuální bezpečný limit pro úpravy %4\$.2f MP. AN Paint uchovává v paměti celý obrázek a vyhrazuje místo pro transformace a výběry. Tento limit závisí na dostupné paměti. Operace byla zastavena před vyhrazením paměti pro příliš velkou bitmapu. K automatické změně velikosti nedošlo."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Aktuelles sicheres Limit: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Aktuelles sicheres Bearbeitungslimit: %1\$s · bis zu %2\$.2f MP vor Decoder-Overhead"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Eine Auflösung von %1\$d × %2\$d Pixeln (%3\$.2f MP) überschreitet das aktuelle sichere Bearbeitungslimit von %4\$.2f MP. AN Paint hält das vollständige Bild im Speicher und reserviert Platz für Transformationen und Auswahlen. Der verfügbare Speicher bestimmt dieses Limit. Der Vorgang wurde gestoppt, bevor die übergroße Bitmap angelegt wurde. Es wurde keine automatische Größenänderung vorgenommen."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Zuletzt verwendete Farbe %1\$d: #%2\$06X. Tippen für Vordergrund, gedrückt halten für Hintergrund."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Zuletzt verwendete Farbe %1\$s: leer"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Τρέχον ασφαλές όριο: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Τρέχον ασφαλές όριο επεξεργασίας: %1\$s · έως %2\$.2f MP πριν την επιβάρυνση του αποκωδικοποιητή"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d pixel (%3\$.2f MP) υπερβαίνουν το τρέχον ασφαλές όριο επεξεργασίας των %4\$.2f MP. Το AN Paint διατηρεί ολόκληρη την εικόνα στη μνήμη και δεσμεύει χώρο για μετασχηματισμούς και επιλογές. Η διαθέσιμη μνήμη καθορίζει αυτό το όριο. Η ενέργεια σταμάτησε πριν δεσμευτεί η υπερμεγέθης bitmap. Δεν εφαρμόστηκε αυτόματη αλλαγή μεγέθους."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Πρόσφατο χρώμα %1\$d: #%2\$06X. Πατήστε για προσκήνιο, κρατήστε πατημένο για φόντο."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Πρόσφατο χρώμα %1\$s: κενό"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Current safe budget: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Current safe editing budget: %1\$s · up to %2\$.2f MP before decoder overhead"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d pixels (%3\$.2f MP) exceeds the current safe editing budget of %4\$.2f MP. AN Paint keeps the complete image in memory and reserves space for transforms and selections. Available memory determines this budget. The operation was stopped before allocating the oversized bitmap. No automatic resizing was applied."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Recent colour %1\$d: #%2\$06X. Tap foreground, hold background."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Recent colour %1\$s: empty"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Current safe budget: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Current safe editing budget: %1\$s · up to %2\$.2f MP before decoder overhead"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d pixels (%3\$.2f MP) exceeds the current safe editing budget of %4\$.2f MP. AN Paint keeps the complete image in memory and reserves space for transforms and selections. Available memory determines this budget. The operation was stopped before allocating the oversized bitmap. No automatic resizing was applied."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Recent colour %1\$d: #%2\$06X. Tap foreground, hold background."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Recent colour %1\$s: empty"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Current safe budget: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Current safe editing budget: %1\$s · up to %2\$.2f MP before decoder overhead"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d pixels (%3\$.2f MP) exceeds the current safe editing budget of %4\$.2f MP. AN Paint keeps the complete image in memory and reserves space for transforms and selections. Available memory determines this budget. The operation was stopped before allocating the oversized bitmap. No automatic resizing was applied."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Recent colour %1\$d: #%2\$06X. Tap foreground, hold background."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Recent colour %1\$s: empty"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Current safe budget: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Current safe editing budget: %1\$s · up to %2\$.2f MP before decoder overhead"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d pixels (%3\$.2f MP) exceeds the current safe editing budget of %4\$.2f MP. AN Paint keeps the complete image in memory and reserves space for transforms and selections. Available memory determines this budget. The operation was stopped before allocating the oversized bitmap. No automatic resizing was applied."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Recent colour %1\$d: #%2\$06X. Tap foreground, hold background."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Recent colour %1\$s: empty"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Current safe budget: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Current safe editing budget: %1\$s · up to %2\$.2f MP before decoder overhead"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d pixels (%3\$.2f MP) exceeds the current safe editing budget of %4\$.2f MP. AN Paint keeps the complete image in memory and reserves space for transforms and selections. Available memory determines this budget. The operation was stopped before allocating the oversized bitmap. No automatic resizing was applied."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Recent colour %1\$d: #%2\$06X. Tap foreground, hold background."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Recent colour %1\$s: empty"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Current safe budget: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Current safe editing budget: %1\$s · up to %2\$.2f MP before decoder overhead"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d pixels (%3\$.2f MP) exceeds the current safe editing budget of %4\$.2f MP. AN Paint keeps the complete image in memory and reserves space for transforms and selections. Available memory determines this budget. The operation was stopped before allocating the oversized bitmap. No automatic resizing was applied."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Recent color %1\$d: #%2\$06X. Tap foreground, hold background."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Recent color %1\$s: empty"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Nykyinen turvallinen raja: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Nykyinen turvallinen muokkausraja: %1\$s · enintään %2\$.2f MP ennen purkimen lisämuistia"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d pikseliä (%3\$.2f MP) ylittää nykyisen turvallisen muokkausrajan %4\$.2f MP. AN Paint pitää koko kuvan muistissa ja varaa tilaa muunnoksille ja valinnoille. Käytettävissä oleva muisti määrittää rajan. Toiminto pysäytettiin ennen liian suuren bittikartan varaamista. Automaattista koonmuutosta ei tehty."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Viimeisin väri %1\$d: #%2\$06X. Napauta etualalle, pidä painettuna taustalle."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Viimeisin väri %1\$s: tyhjä"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Limite sûre actuelle : %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Limite sûre d’édition actuelle : %1\$s · jusqu’à %2\$.2f MP avant le surcoût du décodeur"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d pixels (%3\$.2f MP) dépasse la limite sûre d’édition actuelle de %4\$.2f MP. AN Paint conserve l’image complète en mémoire et réserve de l’espace pour les transformations et les sélections. La mémoire disponible détermine cette limite. L’opération a été arrêtée avant l’allocation du bitmap surdimensionné. Aucun redimensionnement automatique n’a été appliqué."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Couleur récente %1\$d : #%2\$06X. Appuyez pour le premier plan, maintenez pour l’arrière-plan."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Couleur récente %1\$s : vide"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Jelenlegi biztonságos keret: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Jelenlegi biztonságos szerkesztési keret: %1\$s · legfeljebb %2\$.2f MP a dekóder többlete előtt"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="A(z) %1\$d × %2\$d képpont (%3\$.2f MP) meghaladja a jelenlegi %4\$.2f MP biztonságos szerkesztési keretet. Az AN Paint a teljes képet a memóriában tartja, és helyet foglal az átalakításokhoz és kijelölésekhez. A rendelkezésre álló memória határozza meg ezt a keretet. A művelet leállt a túlméretes bittérkép lefoglalása előtt. Automatikus átméretezés nem történt."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Legutóbbi szín %1\$d: #%2\$06X. Koppintás előtérhez, hosszan nyomás háttérhez."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Legutóbbi szín %1\$s: üres"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Batas aman saat ini: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Batas aman pengeditan saat ini: %1\$s · hingga %2\$.2f MP sebelum tambahan memori dekoder"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d piksel (%3\$.2f MP) melebihi batas aman pengeditan saat ini, yaitu %4\$.2f MP. AN Paint menyimpan seluruh gambar di memori serta menyediakan ruang untuk transformasi dan seleksi. Batas ini ditentukan oleh memori yang tersedia. Operasi dihentikan sebelum alokasi bitmap yang terlalu besar. Ukuran gambar tidak diubah secara otomatis."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Warna terbaru %1\$d: #%2\$06X. Ketuk untuk latar depan; tekan lama untuk latar belakang."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Warna terbaru %1\$s: kosong"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Limite sicuro attuale: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Limite sicuro di modifica attuale: %1\$s · fino a %2\$.2f MP prima dell’overhead del decoder"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d pixel (%3\$.2f MP) supera il limite sicuro di modifica attuale di %4\$.2f MP. AN Paint mantiene l’immagine completa in memoria e riserva spazio per trasformazioni e selezioni. La memoria disponibile determina questo limite. L’operazione è stata interrotta prima di allocare la bitmap troppo grande. Non è stato applicato alcun ridimensionamento automatico."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Colore recente %1\$d: #%2\$06X. Tocca per primo piano, tieni premuto per sfondo."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Colore recente %1\$s: vuoto"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="現在の安全上限: %1\$.2f MP。"
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="現在の安全な編集上限: %1\$s · デコーダーの追加メモリを除き最大 %2\$.2f MP"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d ピクセル（%3\$.2f MP）は、現在の安全な編集上限 %4\$.2f MP を超えています。AN Paint は画像全体をメモリ上に保持し、変形や選択範囲の処理用にも領域を確保します。この上限は利用可能なメモリ量によって決まります。大きすぎるビットマップを確保する前に処理を中止しました。自動的な縮小は行っていません。"
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="最近使った色 %1\$d: #%2\$06X。タップで前景色、長押しで背景色に設定します。"
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="最近使った色 %1\$s: 空"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Dabartinė saugi riba: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Dabartinė saugi redagavimo riba: %1\$s · iki %2\$.2f MP prieš dekoderio papildomas sąnaudas"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d pikseliai (%3\$.2f MP) viršija dabartinę saugią redagavimo ribą %4\$.2f MP. AN Paint laiko visą vaizdą atmintyje ir rezervuoja vietą transformacijoms bei žymėjimams. Šią ribą lemia turima atmintis. Veiksmas sustabdytas prieš paskiriant per didelį rastrinį vaizdą. Automatinis dydžio keitimas netaikytas."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Naujausia spalva %1\$d: #%2\$06X. Palieskite priekiniam planui, laikykite nuspaudę fonui."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Naujausia spalva %1\$s: tuščia"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Had selamat semasa: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Had suntingan selamat semasa: %1\$s · sehingga %2\$.2f MP sebelum mengambil kira memori tambahan penyahkod"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d piksel (%3\$.2f MP) melebihi had suntingan selamat semasa %4\$.2f MP. AN Paint menyimpan keseluruhan imej dalam memori dan menyediakan ruang untuk transformasi serta pilihan. Memori tersedia menentukan had ini. Operasi dihentikan sebelum peta bit yang terlalu besar diperuntukkan. Tiada ubah saiz automatik digunakan."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Warna terkini %1\$d: #%2\$06X. Ketik untuk hadapan, tahan untuk latar."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Warna terkini %1\$s: kosong"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Huidige veilige limiet: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Huidige veilige bewerkingslimiet: %1\$s · tot %2\$.2f MP vóór decoder-overhead"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d pixels (%3\$.2f MP) overschrijdt de huidige veilige bewerkingslimiet van %4\$.2f MP. AN Paint houdt de volledige afbeelding in het geheugen en reserveert ruimte voor transformaties en selecties. Het beschikbare geheugen bepaalt deze limiet. De bewerking is gestopt voordat er geheugen voor de te grote bitmap werd toegewezen. Er is niet automatisch verkleind."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Recente kleur %1\$d: #%2\$06X. Tik voor voorgrond, houd ingedrukt voor achtergrond."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Recente kleur %1\$s: leeg"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Obraz o wymiarach %1\$d × %2\$d px (%3\$.2f MP) przekracza obecny bezpieczny limit edycji wynoszący %4\$.2f MP. AN Paint przechowuje cały obraz w pamięci i rezerwuje miejsce na przekształcenia oraz zaznaczenia. Ten limit zależy od dostępnej pamięci. Operacja została zatrzymana przed przydzieleniem pamięci na zbyt dużą bitmapę. Nie zastosowano automatycznej zmiany rozmiaru."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Limite seguro atual: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Limite seguro de edição atual: %1\$s · até %2\$.2f MP antes da sobrecarga do decodificador"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d pixels (%3\$.2f MP) excedem o limite seguro de edição atual de %4\$.2f MP. O AN Paint mantém a imagem completa na memória e reserva espaço para transformações e seleções. A memória disponível determina esse limite. A operação foi interrompida antes de alocar o bitmap grande demais. Nenhum redimensionamento automático foi aplicado."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Cor recente %1\$d: #%2\$06X. Toque para primeiro plano, mantenha pressionado para fundo."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Cor recente %1\$s: vazia"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Текущий безопасный лимит: %1\$.2f Мп."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Текущий безопасный лимит редактирования: %1\$s · до %2\$.2f Мп без учёта дополнительных затрат декодера"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d пикселей (%3\$.2f Мп) превышает текущий безопасный лимит редактирования %4\$.2f Мп. AN Paint хранит полное изображение в памяти и резервирует место для преобразований и выделений. Этот лимит определяется доступной памятью. Операция остановлена до выделения памяти для слишком большого растрового изображения. Автоматическое изменение размера не применялось."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Недавний цвет %1\$d: #%2\$06X. Нажмите для переднего плана, удерживайте для фона."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Недавний цвет %1\$s: пусто"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Kikomo salama cha sasa: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Kikomo salama cha sasa cha uhariri: %1\$s · hadi %2\$.2f MP kabla ya matumizi ya ziada ya kisimbuzi"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d pikseli (%3\$.2f MP) inazidi kikomo salama cha sasa cha uhariri cha %4\$.2f MP. AN Paint huweka picha nzima kwenye kumbukumbu na huhifadhi nafasi kwa mabadiliko na uteuzi. Kumbukumbu inayopatikana huamua kikomo hiki. Operesheni ilisimamishwa kabla ya kutenga bitmap kubwa kupita kiasi. Hakuna kubadilisha ukubwa kiotomatiki kulikotumika."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Rangi ya hivi karibuni %1\$d: #%2\$06X. Gusa kwa mbele, shikilia kwa mandharinyuma."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Rangi ya hivi karibuni %1\$s: tupu"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Geçerli güvenli sınır: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Geçerli güvenli düzenleme sınırı: %1\$s · kod çözücü ek yükünden önce %2\$.2f MP'ye kadar"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d piksel (%3\$.2f MP), geçerli %4\$.2f MP güvenli düzenleme sınırını aşıyor. AN Paint görüntünün tamamını bellekte tutar ve dönüşümler ile seçimler için alan ayırır. Bu sınırı kullanılabilir bellek belirler. İşlem, aşırı büyük bitmap ayrılmadan önce durduruldu. Otomatik yeniden boyutlandırma uygulanmadı."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Son renk %1\$d: #%2\$06X. Ön plan için dokunun, arka plan için basılı tutun."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Son renk %1\$s: boş"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Giới hạn an toàn hiện tại: %1\$.2f MP."
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Giới hạn chỉnh sửa an toàn hiện tại: %1\$s · tối đa %2\$.2f MP trước phần bộ nhớ phụ của bộ giải mã"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d điểm ảnh (%3\$.2f MP) vượt quá giới hạn chỉnh sửa an toàn hiện tại là %4\$.2f MP. AN Paint giữ toàn bộ ảnh trong bộ nhớ và dành thêm chỗ cho biến đổi và vùng chọn. Lượng bộ nhớ khả dụng quyết định giới hạn này. Thao tác đã dừng trước khi cấp phát bitmap quá lớn. Không tự động đổi kích thước."
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="Màu gần đây %1\$d: #%2\$06X. Chạm để đặt tiền cảnh, nhấn giữ để đặt nền."
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="Màu gần đây %1\$s: trống"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="目前安全上限：%1\$.2f MP。"
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="目前安全编辑上限：%1\$s · 扣除解码器额外开销前最多 %2\$.2f MP"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d 像素（%3\$.2f MP）超出目前 %4\$.2f MP 的安全编辑上限。AN Paint 会将完整图片保留在内存，并预留空间作变形及选择范围处理。此上限由可用内存决定。系统已在配置过大的点阵图前停止操作，并未自动调整大小。"
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="最近使用的颜色 %1\$d：#%2\$06X。点按设为前景色，长按设为背景色。"
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="最近使用的颜色 %1\$s：空白"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="目前安全上限：%1\$.2f MP。"
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="目前安全編輯上限：%1\$s · 扣除解碼器額外開銷前最多 %2\$.2f MP"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d 像素（%3\$.2f MP）超出目前 %4\$.2f MP 的安全編輯上限。AN Paint 會將完整圖片保留在記憶體，並預留空間作變形及選取範圍處理。此上限由可用記憶體決定。系統已在配置過大的點陣圖前停止操作，並未自動調整大小。"
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="最近使用的顏色 %1\$d：#%2\$06X。點按設為前景色，長按設為背景色。"
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="最近使用的顏色 %1\$s：空白"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$.0f × %2\$.0f px\n%3\$.1f°"
val args=arrayOf(150f,80f,12.5f)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="目前安全上限：%1\$.2f MP。"
val args=arrayOf(2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="目前安全編輯上限：%1\$s · 扣除解碼器額外開銷前最多 %2\$.2f MP"
val args=arrayOf("memory",2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="%1\$d × %2\$d 像素（%3\$.2f MP）超出目前 %4\$.2f MP 的安全編輯上限。AN Paint 會將完整圖片保留在記憶體，並預留空間作變形及選取範圍處理。此上限由可用記憶體決定。系統已在配置過大的點陣圖前停止操作，並未自動調整大小。"
val args=arrayOf(1500,2000,3.0,2.25)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
run {
val template="最近使用的顏色 %1\$d：#%2\$06X。輕觸設為前景色，長按設為背景色。"
val args=arrayOf(3,0xabcdef)
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
check(selected.contains("#ABCDEF"))
if(tag=="ar") check(selected.contains("٣"))
checks++
}
run {
val template="最近使用的顏色 %1\$s：空白"
val args=arrayOf(String.format(locale,"%d",4))
val selected=String.format(locale,template,*args)
check(!selected.contains("%1$"))
checks++
}
}
for((tag,low,whole) in listOf(Triple("pt-BR","2,50%","123%"),Triple("de","2,50%","123%"),Triple("en-001","2.50%","123%"),Triple("ar","٢٫٥٠%","١٢٣%"),Triple("ro","2,50%","123%"))) {
val selected=Locale.forLanguageTag(tag)
check(String.format(selected,"%1\$.2f%%",2.5)==low)
check(String.format(selected,"%1\$d%%",123)==whole)
checks+=2
check(String.format(selected,"%d",4)==if(tag=="ar") "٤" else "4")
checks++
if(tag!="en-001") {check(String.format(Locale.ROOT,"%.2f%%",2.5)!=low);checks++}
Locale.setDefault(if(tag=="en-001") Locale.GERMANY else Locale.US)
check(String.format(Locale.getDefault(),"%.2f%%",2.5)!=low);checks++
}
println("PASS: $checks exact XML-template value/contract checks; locale selection stand-in only, not Android execution")
}
