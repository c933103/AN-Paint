import json,re
from pathlib import Path
p=Path('/workspace/shared/anpaint-p2-continuation-evidence')
source=json.loads((p/'inputs.json').read_text())
hy=[
'Ընտրեք էջ',
r'%1$s · %2$s\nԷջերի քանակը՝ %3$d։ Ընտրեք մեկ էջ՝ որպես պատկեր խմբագրելու համար։',
'Էջի համարը',
'Նախորդ էջ',
'Հաջորդ էջ',
'Բացել էջը',
'Ընտրված էջի նախադիտում',
'Մուտքագրեք էջի համար՝ 1-ից մինչև %1$d։',
'Էջ %1$d՝ %2$d-ից · Նախադիտումը բեռնվում է…',
'Էջ %1$d՝ %2$d-ից · %3$d × %4$d փիքսել',
'Նախադիտումը հասանելի չէ՝ %1$s',
'Այս նախադիտման համար հիշողությունը չի բավարարում։ Էջը բացելիս հնարավորության դեպքում կառաջարկվեն ավելի փոքր չափեր։',
'Չհաջողվեց կարդալ PDF-ը։ Ֆայլը կարող է վնասված լինել կամ օգտագործել հնարավորություններ, որոնք չեն աջակցվում Android-ի այս տարբերակում։',
'PDF-ը պահանջում է գաղտնաբառ կամ օգտագործում է չաջակցվող գաղտնագրում։ Ներմուծելուց առաջ պահպանեք անպաշտպան պատճեն։',
'PDF ֆայլը պետք է լինի ոչ դատարկ և 512 MiB-ից ոչ մեծ։',
'PDF-ը պետք է պարունակի 1-ից մինչև %1$d էջ։',
'PDF-ի էջի ընտրությունն այլևս վավեր չէ։ Ընտրեք էջ այս փաստաթղթից։',
'PDF-ի էջի չափերն անվավեր են կամ չափազանց մեծ են ներմուծման համար։',
'PDF-ի կտրվող տարածքը պետք է լինի ընտրված էջի սահմաններում ամբողջությամբ տեղավորվող ուղղանկյուն՝ զրոյից մեծ լայնությամբ և բարձրությամբ։',
'PDF-ի պատկերման համար պահանջվող հիշողությունը գերազանցում է պատկերների համար հասանելի հիշողության սահմանը։'
]
ka=[
'აირჩიეთ გვერდი',
r'%1$s · %2$s\nგვერდების რაოდენობა: %3$d. აირჩიეთ ერთი გვერდი გამოსახულებად რედაქტირებისთვის.',
'გვერდის ნომერი',
'წინა გვერდი',
'შემდეგი გვერდი',
'გვერდის გახსნა',
'არჩეული გვერდის წინასწარი ხედი',
'შეიყვანეთ გვერდის ნომერი 1-დან %1$d-მდე.',
'გვერდი %1$d, სულ %2$d · წინასწარი ხედი იტვირთება…',
'გვერდი %1$d, სულ %2$d · %3$d × %4$d პიქსელი',
'წინასწარი ხედი მიუწვდომელია: %1$s',
'ამ წინასწარი ხედისთვის მეხსიერება არასაკმარისია. გვერდის გახსნისას, თუ შესაძლებელია, შემოთავაზებული იქნება უფრო მცირე ზომები.',
'PDF-ის წაკითხვა ვერ მოხერხდა. ფაილი შეიძლება დაზიანებული იყოს ან იყენებდეს ფუნქციებს, რომლებსაც Android-ის ეს ვერსია არ უჭერს მხარს.',
'PDF მოითხოვს პაროლს ან იყენებს დაშიფვრას, რომელიც მხარდაჭერილი არ არის. შემოტანამდე შეინახეთ დაუცველი ასლი.',
'PDF ფაილი არ უნდა იყოს ცარიელი და მისი ზომა არ უნდა აღემატებოდეს 512 MiB-ს.',
'PDF უნდა შეიცავდეს 1-დან %1$d-მდე გვერდს.',
'PDF-ის გვერდის არჩევანი აღარ არის მართებული. აირჩიეთ გვერდი ამ დოკუმენტიდან.',
'PDF-ის გვერდის ზომები არასწორია ან შემოტანისთვის ზედმეტად დიდია.',
'PDF-ის მოსაჭრელი არე უნდა იყოს მართკუთხედი ნულზე მეტი სიგანითა და სიმაღლით და მთლიანად არჩეული გვერდის საზღვრებში უნდა იყოს.',
'PDF-ის გამოსახვისთვის საჭირო მეხსიერება გამოსახულებებისთვის ხელმისაწვდომი მეხსიერების ლიმიტს აჭარბებს.'
]
keys=list(source['source'])
assert len(keys)==len(hy)==len(ka)==20
translations={lang:dict(zip(keys,values)) for lang,values in [('hy',hy),('ka',ka)]}
for lang,entries in translations.items():
 for key,val in entries.items():
  en=source['source'][key]['text']
  assert re.findall(r'%\d+\$[sd]',en)==re.findall(r'%\d+\$[sd]',val),(lang,key)
  assert en.count('\\n')==val.count('\\n'),(lang,key)
base=source['base_sha']
root=f'https://github.com/c933103/AN-Paint/blob/{base}/'
paths=['Paintroid/src/main/java/org/catrobat/paintroid/classic/'+s+'.kt' for s in ['ImportSelection','PdfCodec','ImageResizeDialog','LegacyImageCreditsActivity']]
notes={
 'context':{'base_sha':base,'consumer_sources':[root+x for x in paths], 'observations':['ImportSelection uses 1-based user input and converts it to a zero-based page index; description is format, filename, then page count. Dimensions are source width and height, not preview size.','Previous and next page labels also serve plain-text image-credit pagination and must not say PDF.','PdfCodec requires 1 through 512 MiB inclusive byte length, 1 through MAX_PAGES pages, positive page dimensions, and crop edges inside the selected page with positive width and height.','ImageResizeDialog enables load only when the chosen dimensions fit; even 1×1 may fail native-work memory limits. Smaller-dimension offer remains conditional.','PDF failure messages preserve possible damage OR unsupported Android-version features, password OR unsupported encryption, and image-rendering memory limits rather than file-storage capacity.']},
 'terminology_sources':[{'url':root+source['paths']['hy'],'commit':base,'scope':'Existing Armenian canonical resources: նախադիտում (preview), պատկեր (image), չափեր (dimensions), հիշողություն (memory), ներմուծում (import), կտրվող տարածք (crop region), փիքսել in recent size and memory strings. Older պիքսել spelling also occurs; no changes outside assigned keys.'},{'url':root+source['paths']['ka'],'commit':base,'scope':'Existing Georgian canonical resources: გამოსახულება (image), ზომები (dimensions), მეხსიერება (memory), შემოტანა (import), მოსაჭრელი არე (crop region), პიქსელი (pixel). Use წინასწარი ხედი from the current crop-preview description rather than older ui_preview მინიატურა (thumbnail).'}],
 'limits':['Static AI-authored candidate composition only; not native-human acceptance.','No external GNOME terminology source fetched or claimed. Existing pinned canonical locale terminology used as context, not proof of linguistic correctness.','No Android compilation, runtime, glyph/layout, screen-reader or release certification performed by this author.','Exactly 20 candidate messages per locale; Android raw \\n retained and positional format slots statically checked. Independent changed-only review remains required.']}
(p/'candidate-hy-ka.json').write_text(json.dumps({'translations':translations,'notes':notes},ensure_ascii=False,indent=2)+'\n')
print('Wrote candidate-hy-ka.json; 20 messages per language; slots/newlines checked.')
