import hashlib, json, pathlib, subprocess, zipfile

root = pathlib.Path(__file__).resolve().parent
head = '0d56dd970c22398f7fa032d1baee4a1b74c83f2b'
previous = 'fcdb417dddd5cba516eea661e917f0183ed61d46'
base = '5dba779c904a25bde2ec6d6f8f48eb3cad901a1e'
source = root / 'source'
for name in ['host-normal', 'host-optimized', 'focused-normal', 'focused-optimized', 'compile-check', 'catalogues', 'diff-check']:
    assert (root / (name + '.exit')).read_text().strip() == '0', name
for name in ['host-normal', 'host-optimized']:
    text = (root / (name + '.log')).read_text()
    assert 'Ran 902 tests' in text and '\nOK\n' in text

readme = '''# PR122: preserve distinct English and default Help oracles

Application head: `0d56dd970c22398f7fa032d1baee4a1b74c83f2b`  
Application tree: `b8655bf9b69f89afd3499b9efce1414746de326c`  
First parent: prior PR122 head `fcdb417dddd5cba516eea661e917f0183ed61d46`  
Second parent / integrated develop: `5dba779c904a25bde2ec6d6f8f48eb3cad901a1e`  
PR: https://github.com/c933103/AN-Paint/pull/122  
Scope tracker: https://github.com/c933103/AN-Paint/pull/75

## Exact hosted failure

[Run 39057824063](https://github.com/c933103/AN-Paint/actions/runs/39057824063), job `117469343203`, artifact `12110274600`, executed the prior head. The downloaded artifact has 114 JVM reports: 1,104 tests, one failure, no errors or skipped tests. The failing method was `AssemblyActivityTest.englishHelpModesReachActualHelpAndExactPositionToolbarWithCurrentLabels`, line 460. Exact JUnit comparison:

`expected:<...«File > About, licen[c]es & credits» panel.> but was:<...«File > About, licen[s]es & credits» panel.>`

The test incorrectly assumed a language-only `en` configuration selected unqualified default resources. In this hosted API33 configuration it resolved to the en-US value, whose full Help ends in `licenses`, while the unqualified default ends in `licences`. This is a test oracle/routing error, not an assembly placement/model failure.

The failing pre-loop assertion prevented the subsequent actual Help/toolbar locale loop from running. No pass is attributed to that loop on the failed head. The separate `exactFirstPlacementAndUnplaceMatchHelpWhileSnapRemovalCanFillTheGap` method passed (0.424s); `AssemblyActivityTest` overall had 22 tests and one failure. Lint subsequently passed on the failed head. The exact XML, job excerpt, aggregate report counts and downloaded artifact hash are preserved here.

## Repair and coverage

The only new PR122 repair changes `AssemblyActivityTest.kt`:

- Compare the complete language-only `en` result to the complete en-US fixture.
- Separately request unmatched `zxx` and compare its complete result to the unqualified default fixture.
- Assert the two complete fixtures differ, and assert each requested resource configuration is retained.
- Leave the nine app-language actual Help/toolbar consumers and the placement/model controls intact.

No text normalization, spelling substitution, containment-only replacement, or assertion removal is used. Both original complete fixtures remain byte-identical. Android's [default-resource matching guidance](https://developer.android.com/guide/topics/resources/providing-resources.html) supports using a locale without a matching catalogue; `zxx` is absent from the application catalogues. Its actual runtime route and the full repaired method remain pending the new hosted run. Compilation alone does not execute this route.

The current develop merge integrates PR121's five disjoint files. Every one of the 1,196 application leaf paths, blob hashes and modes was verified against the composed source before publication. Relative to current develop, the application diff is the same 17 scoped PR122 paths. All initial Help text, fixtures, source-boundary host tests and production placement/model code are unchanged by this repair. The separate Japanese follow-on is not included. P3 priority and held PR56 remain unchanged.

## Verification of the composed repair

- Full host suite: **902 passed**, normal (208.956s) and optimized (208.548s).
- Focused assembly Help/source-binding plus integrated memory-modality controls: **69 passed** in each mode.
- Canonical catalogue validation and `git diff --check`: passed.
- AAPT2 compile of all canonical resources plus the existing two exact-script mirror layouts, and resource link: passed.
- Supplementary Kotlin 1.9.24/API35 compilation of changed test source and its support classes against existing compiled dependencies with fresh resource symbols: passed. This is not a clean Gradle build or Robolectric runtime execution.
- The previously recorded local Gradle attempt was blocked while downloading Gradle8.13 (`Network is unreachable`); the original immutable evidence retains that failure. No local JVM/device pass is claimed.
- New exact-head [hosted run 39059990522](https://github.com/c933103/AN-Paint/actions/runs/39059990522) was queued when this receipt was prepared. No full hosted JVM pass is claimed by this receipt.

## Other-language source bindings

The separate [initial full-source change receipt](https://github.com/c933103/AN-Paint/blob/878c912c017e7b145d51d366e064727b34602e38/README.md) and its [binding inventory](https://github.com/c933103/AN-Paint/blob/878c912c017e7b145d51d366e064727b34602e38/other-language-source-bindings.json) remain applicable: 50 other-language full Help overrides need complete-entry/source-binding re-review and 112 English-fallback locale routes need recheck. Historical full-value acceptance is not carried forward across the changed English source. This repair makes no whole-language claim and grants no acceptance to those bindings.

`evidence.zip` contains raw failed-run evidence, exact repair patch, source/remote-tree manifests, both full host logs, focused logs, catalogue/diff results, supplementary compilation recipe/logs, and snapshots of the repaired test and unchanged complete fixtures. `receipt.json` binds the archive and application head. Review and merge remain with the parent reviewer.
'''
(root / 'README.md').write_text(readme)
names = [
    'README.md', 'failed-run-receipt.json', 'failed-job-excerpt.log',
    'TEST-org.catrobat.paintroid.local.AssemblyActivityTest.xml', 'repair.patch',
    'source-comparison.json', 'candidate-manifest.json', 'integration-entries.json',
    'verify_compile.py', 'kotlin-compile.json', 'kotlin-compile.log', 'prepare_repair_evidence.py',
]
for name in ['host-normal', 'host-optimized', 'focused-normal', 'focused-optimized', 'compile-check', 'catalogues', 'diff-check']:
    names += [name + '.log', name + '.exit']
snapshots = [
    'Paintroid/src/test/java/org/catrobat/paintroid/local/AssemblyActivityTest.kt',
    'Paintroid/src/test/resources/assembly-help-modes/expected.json',
]
archive = root / 'evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for name in names:
        z.write(root / name, name)
    for name in snapshots:
        z.write(source / name, 'source/' + name)
files = []
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for n in z.namelist():
        b = z.read(n)
        files.append({'path': n, 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()})
b = archive.read_bytes()
receipt = {
    'application_head': head, 'application_tree': 'b8655bf9b69f89afd3499b9efce1414746de326c',
    'parents': [previous, base], 'current_develop_base': base,
    'previous_PR122_head': previous,
    'all_application_leaf_paths_hashes_modes_verified': 1196,
    'changed_paths_relative_to_current_develop': 17,
    'only_new_repair_path': snapshots[0],
    'failed_run': 39057824063, 'failed_job': 117469343203, 'failed_artifact': 12110274600,
    'failed_run_JVM': {'tests': 1104, 'failures': 1},
    'host_suite_normal': {'passed': 902, 'seconds': 208.956},
    'host_suite_optimized': {'passed': 902, 'seconds': 208.548},
    'focused_each_mode': 69,
    'AAPT2_compile_and_link': 'passed', 'supplementary_Kotlin_compile': 'passed; no runtime execution',
    'new_hosted_run': 39059990522, 'hosted_status_at_receipt': 'queued',
    'zxx_default_runtime_route': 'pending new hosted execution; not established by local compilation',
    'other_language_source_binding_receipt': '878c912c017e7b145d51d366e064727b34602e38',
    'other_language_full_Help_re_review': 50, 'English_fallback_routing_recheck': 112,
    'placement_model_code': 'unchanged', 'Japanese_follow_on': 'not included', 'PR56': 'unchanged',
    'archive': {'path': 'evidence.zip', 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(), 'files': files},
}
(root / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'archive_bytes': len(b), 'files': len(files), 'sha256': receipt['archive']['sha256']}))
