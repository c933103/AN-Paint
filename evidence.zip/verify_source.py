from pathlib import Path
import json,hashlib,xml.etree.ElementTree as ET
B=Path(__file__).resolve().parent;R=B/'source'
tree=json.loads((B/'base-tree.json').read_text());base={e['path']:e for e in tree['tree'] if e['type']=='blob'}
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
new_paths={'tools/test_sampled_memory_modality.py','Paintroid/src/test/resources/memory-modality/expected.json','Paintroid/src/test/java/org/catrobat/paintroid/local/SampledMemoryModalityTest.kt'}
changed_paths={f'Paintroid/src/main/res/values-b+{tag}/strings.xml' for tag in ('bo','jje')}
final={}
for path in set(base)|new_paths:
 p=R/path;b=p.read_bytes();mode='100755' if p.stat().st_mode&0o111 else '100644'
 final[path]={'path':path,'mode':mode,'type':'blob','sha':blob(b),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
changes={p for p,e in final.items() if p not in base or (e['sha'],e['mode'])!=(base[p]['sha'],base[p]['mode'])}
assert changes==new_paths|changed_paths,changes
proof=json.loads((B/'baseline-and-change-proof.json').read_text());rows=[]
for c in proof['changes']:
 path=c['path'];after=(R/path).read_text();assert after.count(c['new_complete_value'])==1
 before=after.replace(c['new_complete_value'],c['old_complete_value']);assert blob(before.encode())==base[path]['sha']
 b=ET.fromstring(before);a=ET.fromstring(after)
 assert len(a)==len(b)
 diffs=[]
 for old,new in zip(b,a):
  assert old.tag==new.tag and old.attrib==new.attrib
  if ET.tostring(old)!=ET.tostring(new):
   diffs.append({'tag':old.tag,'name':old.get('name'),'attributes':old.attrib,'children':len(old),'placeholders':[]})
 assert len(diffs)==1 and diffs[0]['name']=='ui_sampled_resize_memory_explanation'
 assert diffs[0]['tag']=='string' and diffs[0]['children']==0
 rows.append({'path':path,'only_changed_node':diffs[0],'other_nodes_attributes_quantities_and_text_unchanged':True,'single_span_reversal_reconstructs_exact_base_blob':True})
manifest={'base_commit':'44ad5ce2156fef79baae3ef5650b9ac5eac06202','base_tree':tree['sha'],'base_leaves':len(base),'final_leaves':len(final),'changes':[final[p]for p in sorted(changes)],'all_leaves':[final[p]for p in sorted(final)]}
(B/'candidate-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
summary={'base_commit':manifest['base_commit'],'base_leaves':len(base),'final_leaves':len(final),'changed_paths':sorted(changes),'removed_paths':[],'complete_xml_comparisons':rows,'all_unchanged_content_and_modes_verified':True,'consumer_and_routing_unchanged':True,'whole_value_holds_remain':8,'vi_Hani_unchanged':True}
(B/'source-comparison.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False,indent=2))
