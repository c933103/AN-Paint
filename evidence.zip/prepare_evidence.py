from pathlib import Path
import json,hashlib,zipfile,re,shutil
O=Path(__file__).resolve().parent;W=O/'source';P=O/'evidence';P.mkdir(exist_ok=True)
changed=json.loads((O/'upload-source.json').read_text());summary={'application_head':'5401d2bd3a8287ac4ce517c0c8e216bdbe8241fe','application_tree':'47d3226454d474bd8d2b62d859fca2b27afba1e5','base':'8c08554995f4d07be1b47736746ab2d0771e810e','pr':'https://github.com/c933103/AN-Paint/pull/119','hosted_run':'https://github.com/c933103/AN-Paint/actions/runs/39050219892','hosted_status_at_receipt':'in_progress','remote_tree_verified_leaves':1184,'changed_files':[],'tests':{},'limits':['Full local Gradle/Robolectric/lint/device stages not run: wrapper download failed with Network is unreachable.','Kotlin compilation uses fresh resource symbols and previously compiled dependency classes, not a complete Gradle build.','JVM formatting probe uses exact XML templates and Java Formatter with a selected-locale stand-in; it does not execute Android Views.','Six added actual-consumer Robolectric methods await exact-head hosted execution. No wording fluency/completeness or installed-screen acceptance claim.','The memoryLabel/ImageDimensions repair remains separately owned by PR117.']}
for f in changed:
 p=W/f['path'];content=p.read_bytes();sha=hashlib.sha1(b'blob '+str(len(content)).encode()+b'\0'+content).hexdigest();assert sha==f['sha'];summary['changed_files'].append({'path':f['path'],'git_blob':sha,'sha256':hashlib.sha256(content).hexdigest(),'mode':f['mode']});target=P/'source'/f['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
for name in ['normal','optimized']:
 log=(O/f'host-{name}.log').read_text();assert (O/f'host-{name}.exit').read_text().strip()=='0';match=re.search(r'Ran (\d+) tests in ([.\d]+)s\n\nOK',log);assert match;summary['tests']['host_'+name]={'tests':int(match[1]),'seconds':float(match[2]),'result':'pass'}
summary['tests']['kotlin_changed_compile']={'result':'pass','details':'kotlin-compile.json'};assert json.loads((O/'kotlin-compile.json').read_text())['exit_code']==0
summary['tests']['aapt2_resource_compile_link']={'result':'pass'};summary['tests']['catalogue_validation']={'result':'pass'};summary['tests']['template_probe']={'result':'pass','checks':2144,'scope':'exact XML-template/locale formatting checks, including ROOT/default-locale negative comparisons'}
summary['tests']['new_robolectric_methods']={'count':6,'status':'pending hosted execution'}
(P/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
for n in ['source.patch','focused-normal.log','host-normal.log','host-optimized.log','host-initial-stale-source-assertion.log','catalogue-validation.log','kotlin-compile.log','kotlin-compile.json','gradle-check.log','format-contract-check.json','template-compile.log','template-check.log','verified-remote-tree.json','verify_compile.py','check_numeric_templates.py','prepare_evidence.py']:
 shutil.copyfile(O/n,P/n)
for n in ['commands.json','compile.log','link.log']:
 (P/'resource-check').mkdir(exist_ok=True);shutil.copyfile(O/'resource-check'/n,P/'resource-check'/n)
shutil.copyfile(O/'template-probe/TemplateProbe.kt',P/'TemplateProbe.kt')
readme='''# Selected-locale numeric display evidence — PR119

Application head: `5401d2bd3a8287ac4ce517c0c8e216bdbe8241fe`\nBase: `8c08554995f4d07be1b47736746ab2d0771e810e` (includes Greek #118)\nTree: `47d3226454d474bd8d2b62d859fca2b27afba1e5`

[Bounded source PR](https://github.com/c933103/AN-Paint/pull/119) · [exact-head hosted run](https://github.com/c933103/AN-Paint/actions/runs/39050219892)

## Result

All 876 local host tests passed normally (200.780 s) and optimized (200.446 s). AAPT2 compiled and linked the current resources. Catalogue validation passed. Kotlin 1.9.24 compiled the changed production code and six new actual-consumer JVM tests against API35, fresh resource symbols and existing dependency classes. The exact-template JVM probe passed 2,144 checks, including Arabic hex/index distinctions and ROOT/process-default negative comparisons. All 1,184 remote leaves/modes matched the reviewed base plus exactly seven changed files.

The initial host failure is preserved: one source-string assertion still expected the old unformatted memory-warning call. Its memory-warning assertion now requires the typed locale-aware call and arguments. No ImageImport test was changed.

## Scope

Budget captions and memory rejection warning, selection dimensions/rotation, fractional/integer zoom, and populated/empty recent-colour indices use the selected resource locale. Empty recent captions preserve their `%s` contract by receiving an already localized integer. The three new resource templates contain only numeric format syntax and are non-translatable. Hexadecimal syntax, arithmetic, editable numeric serialization, parsing, memory admission, colour values and wording remain unchanged.

The new Robolectric tests exercise actual consumers for pt-BR, German, English, Arabic and Romanian English fallback while the process default intentionally disagrees. They cover all three dimension-dialog routes, resize budget refresh/cancel, admission boundaries, geometry preservation, empty/populated transitions, zoom label/status and slider accessibility descriptions.

## Limits

Hosted run 39050219892 was **in progress** at receipt creation. Local Gradle wrapper download failed with `Network is unreachable`; full local Gradle, Robolectric, lint and device execution are **not claimed**. Direct Kotlin compilation and the JVM template stand-in are supplementary, not Android execution. Exact-head hosted test/review gates remain required. No installed UI, native-language fluency or complete-localization acceptance is claimed. PR117’s ImageImport/memoryLabel repair is separate.

The ZIP contains raw logs, scripts, exact changed source and templates, the patch, summary and source-bound remote inventory. `packet-manifest.json` gives each member’s SHA-256; the separate archive record identifies the ZIP itself. This evidence is intentionally outside the application diff.
'''
(O/'evidence-README.md').write_text(readme);(P/'README.md').write_text(readme)
manifest=[{'path':str(p.relative_to(P)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(P.rglob('*'))if p.is_file()];(O/'packet-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(O/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(P.rglob('*')):
  if p.is_file():z.write(p,str(p.relative_to(P)))
record={'archive_bytes':(O/'evidence.zip').stat().st_size,'archive_sha256':hashlib.sha256((O/'evidence.zip').read_bytes()).hexdigest(),'members':len(manifest),'source_head':summary['application_head']};(O/'archive-record.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
