Historical reviewer summary, recorded before publication. The separately mentioned nine-key Commons batch is excluded from this application change.

# Applied-v3 independent verification

The full independent review is complete. Exact frozen v3 XML SHA-256: `a9c4656817f2d57d96322bd394a18c510caca02a9053acaebc8e4d518844eb1e`.

The v3 XML is byte-for-byte identical to the reviewer's two-correction proposal. Only `ui_rectangle_select` and `ui_reset_crop` changed from v2; the other 339 target values and all resource attributes remain unchanged. All five v3 files match their manifest and working source. Every previously cited source context retains its hash.

Final 341-target disposition:
- 310 accepted for complete wording and inspected static consumer context
- 25 wording passes with no located direct consumer; contextual acceptance remains held
- 5 wording/context uncertainties with no located direct consumer
- 1 unchanged-baseline `ui_fit` layout hold

All 241 new entries: 220 wording + static-context accepts, 21 wording-only passes awaiting concrete consumer verification, and no unapplied wording correction. The 100 existing entries comprise 90 accepts and 10 holds. The two accepted P2 companions and nine accepted Commons candidates remain separately counted.

The exact two applied corrections are `Obdélníkový výběr` and `Zrušit ořez`. Both correction-specific negative controls and all focused checks pass: independently rerun v3 suite 13/13 normal and 13/13 optimized. Applied-hash verification also passes normally and optimized. Broader v3 host tests are owned by the producer and are not represented here as completed.

The original 341-entry review and its earlier 308/2/31 verdict remain preserved in `independent-receipt.json`. The complete successor with 341 final per-entry decisions, unchanged holds and exact source/text hashes is `applied-v3-independent-receipt.json`.

No native-speaker, Android runtime, layout, glyph, TalkBack, whole-language or release certification is claimed. English fallback earns no translation credit. No remote publication or PR56 mutation was performed by this reviewer.
