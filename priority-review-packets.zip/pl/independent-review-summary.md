Historical reviewer summary, recorded before publication. The separately mentioned nine-key Commons batch is excluded from this application change.

# Independent Polish P0/P1 candidate review

## Result

All 341 complete English/Polish pairs were read independently, including all 221 new drafts and all 120 existing targets. Recorded consumer references were checked directly. Existing producer classifications were not reused as verdicts or prior-review credit.

- 304 accept: 203 new translations and 101 unchanged existing translations.
- 6 correct: the six proposed replacements are accepted exactly as drafted.
- 31 hold: 30 keys have no identified current consumer (18 new, 12 existing); one existing Fit caption has a concrete fixed-control-width concern.
- Therefore 310 candidate pairs have bounded static-context acceptance, including the six accepted replacements. This is not Android/runtime acceptance or a claim of a fully translated Polish locale.
- Two P2 composition companions and nine new Commons reasons were reviewed and accepted separately. Neither group is included in 341.
- No extra wording change is required beyond the producer's six corrections. No source files were edited by the independent reviewer, and no remote PR56 writes were made.

## The six accepted corrections

- save20_file_format: Format pliku. The selector also includes derived text exports.
- ui_keep_editing23: Kontynuuj edycję. Makes the safe keep-editing choice explicit.
- ui_background_colour: Kolor tła. Restores the color object in dialog/accessibility contexts.
- ui_foreground_colour: Kolor pierwszego planu. Restores the color object in dialog/accessibility contexts.
- ui_pixels_6ec9c2: pikselach. Composes after w on both axes; the standalone unit remains piksele.
- ui_solid_fill: Jednolite wypełnienie. Names the solid-fill style rather than an imperative to paint over something.

## One additional layout hold

ui_fit remains “Cały obraz w oknie”. Its wording is understandable, but the horizontal zoom_fit_view is a 44 × 44 dp FlowButton with 8 dp padding on each side and 13 sp text. This leaves 28 dp of text width. FlowButton delegates horizontal measurement/drawing to the native Button and does not autosize it. The long Polish caption cannot be accepted as fully readable from source evidence alone.

Evidence:

- ClassicPaintActivity.kt lines 545–549: native button style, text size and padding.
- ClassicPaintActivity.kt lines 665–667: fixed 44 × 44 dp zoom Fit control.
- RibbonWidgets.kt lines 36–37: horizontal measurement delegated to native Button.

Hold the visible ui_fit consumer until a native measurement proves full visibility or the control receives a compact caption/icon treatment. ui_fit_entire_canvas_in_view remains valid as the full accessibility label. No native clipping measurement is claimed here.

The foreground swatch is different: ColourStatusButton measures/scales its caption into a 132 dp region. I did not infer a defect there merely from the longer Polish name.

## Safety and composition

The review retained complete warnings and remedies for animation loss, original-file preservation, partial restoration, undo-history failure, recovery-copy retention/export, paused autosave, memory limits, source-decoding memory floors, and export-versus-save behavior. Typed placeholders, literal format names, exact canvas.png references, range endpoints and menu routes are preserved.

The animation phrase uses a noun-label construction that works with exact and “co najmniej” counts. Dimension descriptions compose as “Szerokość/Wysokość w pikselach/procentach”. Tool expansion/collapse descriptions use “Wybrane narzędzie” so the dynamically selected tool name does not require gender agreement.

Some surrounding P2 estimates and explanations still use English fallback. Their existence does not invalidate the reviewed Polish sentence, but this packet does not claim fully Polish dialogs or whole-locale completion.

## Verification

Independently rerun on the frozen producer candidate:

- Polish focused regression suite: 11 passed in ordinary Python.
- Same focused suite: 11 passed under Python -O.
- Current message-family contracts: 12 passed.
- Independent candidate checks: all 341 resource values match the reviewed candidate; typed placeholders and Android string syntax pass; no duplicate keys; all 341 have individual semantic review notes.
- All six frozen artifact hashes match. All 130 recorded input blobs match the supplied complete tree for develop 2da486c6a1969e14d73a64666921d6a1c35e2e99. Local unchanged baseline files also match recorded SHA-256.
- The producer's final full ordinary host run reports 789 passing tests. It was not rerun here; focused checks are not presented as an independent aggregate pass.

Android compilation, installed rendering, large-font interaction, TalkBack and physical-device checks were not run. Android SDK/adb were unavailable. The candidate has not been credited as already integrated.

## Remaining targeted tests

1. Native Polish zoom_fit_view measurement at ordinary and 2× font size: every character must be represented by visible layout lines; every rendered line bottom must fit within the button's content height. If not, use a compact visual treatment with the complete accessibility label retained.
2. Polish ordinary/cursor status readouts at narrow widths and ordinary/large fonts: verify the save-failed/paused instruction and complete draft state are available. Source bounds are known; clipping is not claimed as a measured defect.
3. Installed Polish Save/Discard/Keep editing, animation first/default-frame and recovery dialogs: check full warnings and reachable affirmative/negative actions.
4. TalkBack dimension units and expand/collapse tool descriptions using tools with differing Polish gender.
5. For any of the 30 no-consumer holds, identify the actual current consumer and dynamic arguments before awarding contextual acceptance; do not infer unreachability solely from the absent reference.

## Deliverables

- polish-341-independent-verdicts.json: complete per-entry accept/correct/hold, semantic reason, hashes and verified consumer references.
- polish-P2-companion-verdicts.json: two separately counted composition reviews.
- polish-Commons-nine-independent-verdicts.json: nine independently accepted new Commons reason strings, bound to the exact producer contract/packet hashes.
- entry-review-notes.tsv: all 341 individual semantic notes.
- independent-validation.json: hash, source, resource, syntax, denominator and test checks.
- focused-normal.log, focused-optimized.log, family-normal.log: actual independent test output.
