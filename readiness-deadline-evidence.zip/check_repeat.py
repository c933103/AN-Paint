from pathlib import Path
import sys, unittest
ROOT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'source/tools'))
import test_ci_emulator as m
suite=unittest.TestSuite(m.EmulatorReadinessTest(name) for _ in range(20) for name in (
    'test_hung_service_is_killed_within_remaining_budget',
    'test_deadline_reached_during_initial_progress_never_launches_probe'))
with (ROOT/'repeat.log').open('w') as out:
 result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
raise SystemExit(not result.wasSuccessful())
