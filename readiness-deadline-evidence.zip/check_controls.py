"""Temporary negative controls; never shipped as application source."""
from pathlib import Path
import json, os, signal, subprocess, sys, tempfile, time

ROOT=Path(__file__).parent
SOURCE=ROOT/'source'
script=(SOURCE/'tools/ci_emulator.sh').read_text()
controls={
 'without-deadline-guard': (script.replace('if (( remaining <= 0 )); then', 'if false; then', 1),
                          'test_deadline_reached_during_initial_progress_never_launches_probe'),
 'without-timeout': (script.replace('timeout --kill-after=1s "${probe}s" "$adb"', '"$adb"', 1),
                     'test_hung_service_is_killed_within_remaining_budget'),
 'wrong-probe-cap': (script.replace('then probe="$remaining";', 'then probe=2;', 1),
                     'test_hung_service_is_killed_within_remaining_budget'),
}
receipts=[]
for name,(mutated,test) in controls.items():
 assert mutated!=script
 target=ROOT/(name+'.sh'); target.write_text(mutated)
 code=f'''import sys, unittest
from pathlib import Path
sys.path.insert(0, {str(SOURCE/'tools')!r})
import test_ci_emulator as m
m.SCRIPT=Path({str(target)!r})
suite=unittest.TestSuite([m.EmulatorReadinessTest({test!r})])
r=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(not r.wasSuccessful())
'''
 with (ROOT/(name+'.log')).open('w') as log:
  p=subprocess.Popen([sys.executable,'-c',code],cwd=SOURCE,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  started=time.monotonic(); killed=[]
  try:status=p.wait(timeout=20)
  finally:
   candidates={int(e.name) for e in Path('/proc').iterdir() if e.name.isdigit()}|{p.pid}
   for pid in sorted(candidates,reverse=True):
    try:
     if os.getsid(pid)==p.pid:os.kill(pid,signal.SIGKILL);killed.append(pid)
    except ProcessLookupError:pass
   p.wait(timeout=5)
 receipts.append(dict(control=name,test=test,exit=status,elapsed_seconds=time.monotonic()-started,killed_session_pids=killed,rejected=status!=0))
 print(receipts[-1],flush=True)
(ROOT/'negative-controls.json').write_text(json.dumps(receipts,indent=2)+'\n')
assert all(r['rejected'] for r in receipts)
