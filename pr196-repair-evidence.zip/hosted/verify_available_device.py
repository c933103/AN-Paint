"""Recompute PR196 repaired exact-head pull-request source, compiled-test and original device-artifact evidence."""
from pathlib import Path
import collections,hashlib,json,re,shutil,sys,tempfile,unittest,xml.etree.ElementTree as E,zipfile
root=Path(__file__).resolve().parent
lane=root.parents[1]
art=root/'original-artifacts'
head='6ec83afb6b00037bab0e7f65637f6abcdf41f57c'
run=40568484000
sha=lambda b:hashlib.sha256(b).hexdigest()
def sha_file(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def sha_entry(z,name):
 with z.open(name) as f:return hashlib.file_digest(f,'sha256').hexdigest()
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
final=json.loads((root.parent/'verified-repair-tree.json').read_text())
merge=json.loads((root/'tested-merge-commit.json').read_text())
assert merge['tree']['sha']==final['sha'] and [x['sha'] for x in merge['parents']]==['e596389890e72262bf75fa10dafd8b29b5e21bd8',head] and merge['sha']=='47783875d03a28949916f405e4cd422cceb23c08'
expected={x['path']:x for x in final['tree'] if x['type']=='blob'}
metadata=json.loads((root/'artifacts-metadata.json').read_text())['artifacts']
prefixes={'apk-source':'apk-and-source','instrumentation':'instrumentation-apks','regression':'regression-and-lint','probes':'exact-script-generation','core':'emulator-core','position':'emulator-position','union':'emulator-api-35'}
verified=[]
for stem,prefix in prefixes.items():
 if stem=='regression':continue
 m=next(x for x in metadata if x['name'].startswith(prefix));artifact=art/(stem+'.zip')
 assert artifact.stat().st_size==m['size_in_bytes'] and sha_file(artifact)==m['digest'].removeprefix('sha256:')
 assert m['workflow_run']['id']==run and m['workflow_run']['head_sha']==head
 with zipfile.ZipFile(art/(stem+'.zip')) as z:assert z.testzip() is None
 verified.append({'id':m['id'],'name':m['name'],'sha256':sha_file(artifact),'size_bytes':artifact.stat().st_size})
with zipfile.ZipFile(art/'apk-source.zip') as z:
 info=json.loads(z.read('build/delivery/build-info.json'))
 with z.open('build/delivery/AN-Paint-source.zip') as src,(root/'AN-Paint-source.zip').open('wb') as dst:shutil.copyfileobj(src,dst,1024*1024)
 assert sha_file(root/'AN-Paint-source.zip')==info['source_sha256']
 assert sha_entry(z,'app/build/outputs/apk/debug/app-debug.apk')==info['apk_sha256']
assert info['commit']==merge['sha'] and info['run_id']==str(run)
sourcezip=zipfile.ZipFile(root/'AN-Paint-source.zip');missing=[];bad=[]
for path,x in expected.items():
 try:b=sourcezip.read('AN-Paint/'+path)
 except KeyError:missing.append(path);continue
 if blob(b)!=x['sha']:bad.append(path)
assert missing==['.gitignore','.idea/codeStyles/Project.xml','colorpicker/.gitignore'] and not bad,(missing,bad)
work=root/'inventory-source';work.mkdir(exist_ok=True)
for path in expected:
 if path not in missing:
  p=work/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(sourcezip.read('AN-Paint/'+path))
sys.path.insert(0,str(work/'tools'))
from run_android_instrumentation import declared_tests,source_tests_sha256,parse_protocol
from app_instrumentation_matrix import verify_reports
from compose_device_reports import compose
extracted={}
extraction=root/'verification-extraction';extraction.mkdir(exist_ok=True)
for stem in ['core','position','union']:
 p=extraction/stem;p.mkdir(exist_ok=True)
 with zipfile.ZipFile(art/(stem+'.zip')) as z:z.extractall(p)
 extracted[stem]=p
appdir=work/'app/src/androidTest';paintdir=work/'Paintroid/src/androidTest'
coverage=verify_reports(appdir,extracted['union'],35)
assert coverage['success']
selection=json.loads((extracted['union']/'artifact-selection.json').read_text())
assert selection['run_id']==run and selection['workflow_head']==head and selection['checkout']==merge['sha']
for group in ['core','position']:
 m=next(x for x in metadata if x['name'].startswith(prefixes[group]))
 assert selection['selected'][group]['artifact_id']==m['id'] and selection['selected'][group]['digest']==m['digest']
# Recompose independent original group archives; never use the CI union as its own oracle.
composed=compose(appdir,extracted['core'],extracted['position'],35,{'GITHUB_SHA':merge['sha'],'GITHUB_RUN_ID':str(run),'GITHUB_RUN_ATTEMPT':'1','BUILD_VARIANT':'debug'})
assert composed['success'] and composed['completed_tests']==coverage['completed_tests']
assert json.loads((extracted['core']/'composed-device-identity.json').read_text())==json.loads((extracted['union']/'composed-device-identity.json').read_text())
raw_reports=[]
for s in sorted(extracted['union'].rglob('summary.json')):
 d=json.loads(s.read_text())
 if 'cases' not in d:continue
 log=s.parent/'instrumentation.log';assert log.exists()
 identities={(x['classname'],x['name']) for x in d['cases']}
 parsed=parse_protocol(log.read_text(),identities,returncode=d['returncode'],timed_out=d['timed_out'])
 assert parsed['success'] and parsed['completed_tests']==d['completed_tests'],str(s)
 rel=s.relative_to(extracted['union']);assert s.read_bytes()==(extracted['core']/rel).read_bytes()
 assert log.read_bytes()==(extracted['core']/rel.parent/'instrumentation.log').read_bytes()
 raw_reports.append({'path':str(rel),'tests':len(identities),'log_sha256':sha(log.read_bytes())})
paint=json.loads((extracted['union']/'Paintroid/androidTest-results/summary.json').read_text())
assert {(x['classname'],x['name']) for x in paint['cases']}==declared_tests(paintdir,sdk_level=35)
assert paint['source_tests_sha256']==source_tests_sha256(paintdir)
ident=json.loads((extracted['union']/'composed-device-identity.json').read_text())
assert ident['commit']==info['commit'] and ident['source_sha256']==info['source_sha256'] and ident['apk_sha256']==info['apk_sha256']
with zipfile.ZipFile(art/'instrumentation.zip') as z:assert sha_entry(z,'app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk')==ident['test_apk_sha256']
assert source_tests_sha256(appdir)==ident['source_tests_sha256']
result={'scope':'Original API35 group and union artifacts only; regression/lint not yet included','head':head,'checkout':merge['sha'],'run':run,'verified_artifacts':verified,'paintroid':paint['completed_tests'],'app':coverage['completed_tests'],'raw_reports':raw_reports,'independent_group_recomposition':True,'source_inventory_binding':True,'artifact_selection_matches_original_job_groups':True,'missing':[],'unexpected':[],'suppressed':[],'deferred':[]}
(root/'available-device-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['verified_artifacts','raw_reports']},indent=2))
