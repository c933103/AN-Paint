from pathlib import Path
import json,hashlib,zipfile,base64
O=Path(__file__).resolve().parent
skip={'pr119-regression-failure.zip','upload-source.json','upload-payload.json','integration-evidence.zip','packet-receipt.json','artifact-manifest.json'}
files=[]
for p in O.rglob('*'):
 if not p.is_file()or p.name in skip or p.suffix in {'.class','.apk'}:continue
 parts=p.relative_to(O).parts
 if parts[0]in {'compiled-check','__pycache__'}or'classes'in parts:continue
 if parts[0]=='resource-check'and p.name not in {'compile.log','link.log','commands.json','AndroidManifest.xml'}:continue
 files.append(p)
manifest=[{'path':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(files)]
(O/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
zpath=O/'integration-evidence.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(files)+[O/'artifact-manifest.json']:z.write(p,str(p.relative_to(O)))
with zipfile.ZipFile(zpath)as z:
 assert z.testzip()is None
 for e in manifest:
  raw=z.read(e['path']);assert len(raw)==e['bytes']and hashlib.sha256(raw).hexdigest()==e['sha256']
raw=zpath.read_bytes();receipt={'file':zpath.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'git_blob_sha':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),'members':len(manifest)+1,'all_members_verified':True}
(O/'packet-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
rows=[]
for name in ['README.md','source-publication.json','test-summary.json','environment-failure-receipt.json','final-tree-proof.json','independent-review.json','packet-receipt.json','artifact-manifest.json','integration-evidence.zip']:
 raw=(O/name).read_bytes();rows.append({'path':name,'sha':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),'encoding':'base64'if name.endswith('.zip')else'utf-8','content':base64.b64encode(raw).decode()if name.endswith('.zip')else raw.decode()})
(O/'upload-payload.json').write_text(json.dumps(rows));print(json.dumps(receipt))
