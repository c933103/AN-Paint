import java.util.Locale
object R { object string {const val ui_1f_s=0;const val ui_current_safe_editing_budget_s_up_to_2f=1} }
var selected=Locale.US
var current="en-001"
val templates=mapOf("pt-BR" to listOf("%1\$.1f %2\$s","Limite seguro de edição atual: %1\$s · até %2\$.2f MP antes da sobrecarga do decodificador"),"de" to listOf("%1\$.1f %2\$s","Aktuelles sicheres Bearbeitungslimit: %1\$s · bis zu %2\$.2f MP vor Decoder-Overhead"),"en-001" to listOf("%1\$.1f %2\$s","Current safe editing budget: %1\$s · up to %2\$.2f MP before decoder overhead"),"ar" to listOf("%1\$.1f %2\$s","حد التحرير الآمن الحالي: %1\$s · حتى %2\$.2f ميغابكسل قبل الحمل الإضافي لفك الترميز"),"ro" to listOf("%1\$.1f %2\$s","Current safe editing budget: %1\$s · up to %2\$.2f MP before decoder overhead"))
fun ui(id:Int,vararg args:Any?):String {val text=templates.getValue(current)[id];return if(args.isEmpty())text else String.format(selected,text,*args)}
fun memoryLabel(bytes: Double): String {
    val units = arrayOf("B", "KiB", "MiB", "GiB", "TiB", "PiB", "EiB")
    var amount = bytes.coerceAtLeast(0.0); var unit = 0
    while (amount >= 1024 && unit < units.lastIndex) { amount /= 1024; unit++ }
    return String.format(Locale.ROOT, ui(R.string.ui_1f_s), amount, units[unit])
}


fun budget(bytes:Double,mp:Double)=ui(R.string.ui_current_safe_editing_budget_s_up_to_2f, memoryLabel(bytes), mp)
fun main() {
val cases=listOf(Triple("pt-BR","Limite seguro de edição atual: 25,7 MiB · até 2,25 MP antes da sobrecarga do decodificador","Limite seguro de edição atual: 17,2 MiB · até 1,50 MP antes da sobrecarga do decodificador"),Triple("de","Aktuelles sicheres Bearbeitungslimit: 25,7 MiB · bis zu 2,25 MP vor Decoder-Overhead","Aktuelles sicheres Bearbeitungslimit: 17,2 MiB · bis zu 1,50 MP vor Decoder-Overhead"),Triple("en-001","Current safe editing budget: 25.7 MiB · up to 2.25 MP before decoder overhead","Current safe editing budget: 17.2 MiB · up to 1.50 MP before decoder overhead"),Triple("ar","حد التحرير الآمن الحالي: ٢٥٫٧ MiB · حتى ٢٫٢٥ ميغابكسل قبل الحمل الإضافي لفك الترميز","حد التحرير الآمن الحالي: ١٧٫٢ MiB · حتى ١٫٥٠ ميغابكسل قبل الحمل الإضافي لفك الترميز"),Triple("ro","Current safe editing budget: 25,7 MiB · up to 2,25 MP before decoder overhead","Current safe editing budget: 17,2 MiB · up to 1,50 MP before decoder overhead"))
var count=0
for((tag,first,second)in cases){current=tag;selected=Locale.forLanguageTag(tag);Locale.setDefault(if(tag=="en-001")Locale.GERMANY else Locale.US)
 for((bytes,mp,wanted)in listOf(Triple(27000000.0,2.25,first),Triple(18000000.0,1.5,second))){val actual=budget(bytes,mp);check(wanted==actual){"$tag expected [$wanted] actual [$actual]"};count++}}
println("PASS: $count complete two-layer budget captions using actual XML; resource-formatting stand-in only")}
