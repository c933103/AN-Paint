"""Exact source-format expressions with XML and an explicit resource-locale stand-in; not Android."""
from pathlib import Path
import re,json,subprocess,xml.etree.ElementTree as ET,hashlib
O=Path(__file__).resolve().parent;W=O.parent/'worktree';D=Path('/workspace/shared/anpaint-commons-errors-20261017/compile-check/deps');deps=':'.join(str(p)for p in D.glob('*.jar'))
main=W/'Paintroid/src/main/java/org/catrobat/paintroid/classic';source=(main/'ImageImport.kt').read_text();body=source[source.index('fun memoryLabel('):source.index('data class ImportPlan')];outer=next(l.strip().removeprefix('budget.text = ')for l in(main/'ImageResizeDialog.kt').read_text().splitlines()if 'budget.text = 'in l)
expr=outer.replace('current.workingBytes.toDouble()','bytes').replace('current.maxPixels(residentPixels) / 1_000_000.0','mp')
test=(W/'Paintroid/src/test/java/org/catrobat/paintroid/local/NumericDisplayLocaleTest.kt').read_text();segment=test.split('val captions=mapOf(',1)[1].split('\n        for(tag in tags)',1)[0]
cases=re.findall(r'"([\w-]+)" to \("([^"]+)" to\s*"([^"]+)"\)',segment);assert len(cases)==5
res=W/'Paintroid/src/main/res'
def values(folder):return {e.get('name'):''.join(e.itertext())for e in ET.parse(res/folder/'strings.xml').getroot()if e.tag=='string'}
en=values('values');folders={'pt-BR':'values-pt-rBR','de':'values-de','en-001':'values','ar':'values-ar','ro':'values-ro'}
def kt(s):return json.dumps(s,ensure_ascii=False).replace('$','\\$')
head='''import java.util.Locale
object R { object string {const val ui_1f_s=0;const val ui_current_safe_editing_budget_s_up_to_2f=1} }
var selected=Locale.US
var current="en-001"
'''
head+='val templates=mapOf('+','.join(kt(t)+' to listOf('+','.join(kt(values(f).get(k,en[k]))for k in ['ui_1f_s','ui_current_safe_editing_budget_s_up_to_2f'])+')'for t,f in folders.items())+')\n'
head+='fun ui(id:Int,vararg args:Any?):String {val text=templates.getValue(current)[id];return if(args.isEmpty())text else String.format(selected,text,*args)}\n'
expected='val cases=listOf('+','.join('Triple('+','.join(kt(x)for x in row)+')'for row in cases)+')\n'
tail='''fun main() {
'''+expected+'''var count=0
for((tag,first,second)in cases){current=tag;selected=Locale.forLanguageTag(tag);Locale.setDefault(if(tag=="en-001")Locale.GERMANY else Locale.US)
 for((bytes,mp,wanted)in listOf(Triple(27000000.0,2.25,first),Triple(18000000.0,1.5,second))){val actual=budget(bytes,mp);check(wanted==actual){"$tag expected [$wanted] actual [$actual]"};count++}}
println("PASS: $count complete two-layer budget captions using actual XML; resource-formatting stand-in only")}
'''
fixed='return ui(R.string.ui_1f_s, amount, units[unit])';old='return String.format(Locale.ROOT, ui(R.string.ui_1f_s), amount, units[unit])';assert fixed in body
outer_root=expr.replace('ui(R.string.ui_current_safe_editing_budget_s_up_to_2f,','String.format(Locale.ROOT, ui(R.string.ui_current_safe_editing_budget_s_up_to_2f),')
variants={'integrated':(body,expr),'missing_pr117_inner':(body.replace(fixed,old),expr),'missing_pr119_outer':(body,outer_root),'process_default_outer':(body,outer_root.replace('Locale.ROOT','Locale.getDefault()'))}
rows=[]
for name,(b,e)in variants.items():
 d=O/'composed-budget-probe'/name;d.mkdir(parents=True,exist_ok=True);p=d/'Probe.kt';p.write_text(head+b+'\nfun budget(bytes:Double,mp:Double)='+e+'\n'+tail)
 c=subprocess.run(['java','-cp',deps,'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-jvm-target','17','-classpath',str(D/'kotlin-stdlib-1.9.24.jar'),'-d',str(d/'classes'),str(p)],text=True,capture_output=True);(d/'compile.log').write_text(c.stdout+c.stderr);assert c.returncode==0,c.stderr
 r=subprocess.run(['java','-cp',str(d/'classes')+':'+str(D/'kotlin-stdlib-1.9.24.jar'),'ProbeKt'],text=True,capture_output=True);(d/'run.log').write_text(r.stdout+r.stderr);assert (r.returncode==0)==(name=='integrated'),r.stdout+r.stderr
 rows.append({'variant':name,'compile_exit':c.returncode,'run_exit':r.returncode,'result':'pass'if name=='integrated'else'rejected_expected','source_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(O/'composed-budget-probe.json').write_text(json.dumps({'scope':'Exact memoryLabel body and outer budget expression with XML resources; Android Resources formatter stand-in, not UI/Android execution. Outer expression substitutes fixture byte/MP parameters only.','literal_cases':cases,'results':rows},ensure_ascii=False,indent=2)+'\n');print('10 literal full captions pass; missing inner, missing outer and process-default outer mutations rejected.')
