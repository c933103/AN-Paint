from pathlib import Path
import json,hashlib,shutil,difflib
O=Path(__file__).resolve().parent;W=O.parent/'worktree';R=Path('/workspace/shared/anpaint-display-locale-followup-20261017/source')
def blobs(p):return {e['path']:e for e in json.loads(p.read_text())['tree']if e['type']=='blob'}
b=blobs(O.parent/'position-ci-failure/greek-develop-tree.json');l=blobs(O.parent/'position-ci-failure/candidate-full-tree.json');r=blobs(O/'pr119-tree.json')
def verify(p,e):
 raw=p.read_bytes();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==e['sha'],p;assert ('100755'if p.stat().st_mode&0o111 else'100644')==e['mode'],p
for p,e in l.items():verify(W/p,e)
right=[p for p,e in r.items()if p not in b or(e['sha'],e['mode'])!=(b[p]['sha'],b[p]['mode'])];assert len(right)==7
for p in right:
 verify(R/p,r[p]);before=O/'pr119-original'/p;before.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/p,before)
 if p in l:
  before=O/'pr117-original'/p;before.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(W/p,before)
 dest=W/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/p,dest)
# The only overlap consists of independent assertions for two now resource-aware consumers.
p=W/'tools/test_russian_portuguese_priority_wording.py';s=p.read_text();old='ui(R.string.ui_d_d_px_d_pixels_2f_mp), width, height, pixels, pixels / 1_000_000.0)';new='ui(R.string.ui_d_d_px_d_pixels_2f_mp, width, height, pixels, pixels / 1_000_000.0)';assert s.count(old)==1;s=s.replace(old,new);p.write_text(s)
p=W/'Paintroid/src/test/java/org/catrobat/paintroid/local/NumericDisplayLocaleTest.kt';s=p.read_text();old='''        for(tag in tags) {
            select(tag)
            var limit=policy(2_250_000)
''';new='''        // Literal full captions exercise both formatting layers independently:
        // 27,000,000 bytes = 25.7 MiB; 18,000,000 bytes = 17.2 MiB.
        // Do not compute expectations using the production memoryLabel helper.
        val captions=mapOf(
            "pt-BR" to ("Limite seguro de edição atual: 25,7 MiB · até 2,25 MP antes da sobrecarga do decodificador" to
                "Limite seguro de edição atual: 17,2 MiB · até 1,50 MP antes da sobrecarga do decodificador"),
            "de" to ("Aktuelles sicheres Bearbeitungslimit: 25,7 MiB · bis zu 2,25 MP vor Decoder-Overhead" to
                "Aktuelles sicheres Bearbeitungslimit: 17,2 MiB · bis zu 1,50 MP vor Decoder-Overhead"),
            "en-001" to ("Current safe editing budget: 25.7 MiB · up to 2.25 MP before decoder overhead" to
                "Current safe editing budget: 17.2 MiB · up to 1.50 MP before decoder overhead"),
            "ar" to ("حد التحرير الآمن الحالي: ٢٥٫٧ MiB · حتى ٢٫٢٥ ميغابكسل قبل الحمل الإضافي لفك الترميز" to
                "حد التحرير الآمن الحالي: ١٧٫٢ MiB · حتى ١٫٥٠ ميغابكسل قبل الحمل الإضافي لفك الترميز"),
            "ro" to ("Current safe editing budget: 25,7 MiB · up to 2,25 MP before decoder overhead" to
                "Current safe editing budget: 17,2 MiB · up to 1,50 MP before decoder overhead")
        )
        for(tag in tags) {
            select(tag)
            val (initialCaption,updatedCaption)=captions.getValue(tag)
            var limit=policy(2_250_000)
''';assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('''                resize={applied=true},cancel={cancelled=true}).show()
            val root=dialog.window!!.decorView
''','''                resize={applied=true},cancel={cancelled=true}).show()
            // The production refresh and validating listener are installed by
            // queued OnShow; observe the dialog after that lifecycle callback.
            shadowOf(Looper.getMainLooper()).idle()
            val root=dialog.window!!.decorView
''')
s=s.replace('expected(R.string.ui_current_safe_editing_budget_s_up_to_2f,memoryLabel(limit.workingBytes.toDouble()),2.25)','initialCaption').replace('expected(R.string.ui_current_safe_editing_budget_s_up_to_2f,memoryLabel(limit.workingBytes.toDouble()),1.5)','updatedCaption')
s=s.replace('''            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).performClick()
            assertTrue(cancelled);assertFalse(applied)
''','''            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).performClick()
            shadowOf(Looper.getMainLooper()).idle()
            assertFalse(dialog.isShowing)
            assertTrue(cancelled);assertFalse(applied)
''');p.write_text(s)
(O/'composition-plan.json').write_text(json.dumps({'parents':['a5e3ed03c58f2bf6fde5d5562e873a18df47b55a','5401d2bd3a8287ac4ce517c0c8e216bdbe8241fe'],'common_base':'8c08554995f4d07be1b47736746ab2d0771e810e','pr119_delta':right,'shared_file':'tools/test_russian_portuguese_priority_wording.py','additional_test_strengthening':'Literal complete resize budget initial/refresh captions for five locales; queued show/cancel dispatch and dismissal assertion.','production_changes_beyond_parent_union':[]},indent=2)+'\n')
print('Composed exact119delta and preserved117changes; sharedassertions reconciled; independentfullconsumerexpectations added.')
