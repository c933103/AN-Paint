# Lithuanian P0/P1 linguistic review

## Result

All **341 typed priority keys** were reviewed as one batch: **92 P0 + 249 P1**. This is a complete per-key linguistic and static-source-consumer review, not native-speaker, installed-UI, accessibility-runtime or whole-language certification.

- **320 current pairs retained with bounded scope:** 289 new direct-consumer static judgments, 30 wording-only judgments, and 1 exact prior bounded receipt.
- **14 priority corrections proposed.**
- **3 further priority labels have acceptable text but depend on corrections to shared crop-hint templates.** Their current composed context is not accepted.
- **4 terminology holds remain:** the three credits warnings using bare plural `priskyrimai`, and `Diteringas` in the GIF description. These are unresolved idiom/terminology questions, not asserted confirmed mistranslations.
- **3 P2 dependency corrections** are separate from the 341-key tally. The complete candidate changes 17 XML values.
- If the complete source-bound candidate is integrated, **337/341** priority pairs have bounded model-review dispositions, while **4/341 remain held**. Of the 337, **30 remain wording-only**. This does not mean “Lithuanian finished.”

All **22** mapped old Lithuanian receipts still exactly match both current English and Lithuanian values. Only `string/ui_sampled_resize_memory_explanation` overlaps this priority batch; the other 21 are carried separately. The original scopes, confidence and caveats are preserved, not upgraded. The historical 22/695 tracker snapshot must not be mistaken for current completion or an absence of all other review history.

## Source binding

Requested develop: `4355869e2e198b5616419291cba225b018444fab`.

Exact reviewed tree: `b9b148d5d8ef7c7b088500a9c177f9f59304b800`.

Observed local checkout HEAD: `ddffe57016c689b2a7868c31e415dcb625f5c6b5`. Its tree equals the requested tree exactly; the differing local commit is not represented as the develop commit. Full English/Lithuanian per-key hashes, catalogue hashes, manifest hash and source-consumer paths/lines are in the ledger.

The input source catalogue was read-only and was not edited. The parent owns durable repository integration. **PR #56 is an intentional draft tracker and must never be merged.**

## Important findings

1. `language20_translation_note` currently claims the locale contains all translatable UI text, instead of explaining maintenance and English fallback. The proposal restores the complete current-source meaning and paragraph break.
2. The animation warning appends fixed accusative plural `kadrus` to exact and `bent`-prefixed counts. The proposal uses a count label, avoiding wrong agreement for values such as 10, 11 and 21 while preserving animation-loss warnings. The related unknown-animation message gets a grammatical uncertainty clause, not a claim that animation is confirmed.
3. Pixel totals use fixed `pikseliai` regardless of count. The proposal uses `Pikselių skaičius:`. The large-image memory warning uses an explicit image subject and px notation while retaining all safe-budget, allocation-stop and no-auto-resize claims.
4. Tool-category announcements currently concatenate `pasirinkta` with differently gendered tool names. The proposals introduce `Pasirinktas įrankis:` and keep each label independent.
5. Dimension accessibility strings currently produce constructions such as `Aukštis pikseliai vienetais`. The atomic fix yields `Aukštis pikseliais`, `Aukštis procentais`, and their width counterparts. Standalone Pixels/Percent radio labels remain unchanged.
6. Shared crop-edge hints currently produce `Kairė apkirpimas pikseliais`. Colon-delimited templates preserve each existing edge label as a heading. Pixel and percent modes must be changed together.
7. Palette tap/hold guidance is made explicit about selecting foreground versus background colour; scrolling and hexadecimal placeholders remain intact.
8. The select-none crop button becomes an actual select-none instruction rather than the status-like `Nėra`. The dimensions error replaces expiry-like `galiojančius` with `tinkamus`.

## Required atomic dependencies

These three P2 keys are deliberately separate from priority coverage, not a new broad review batch:

- `string/ui_width_in`, with priority `ui_height_in`, `ui_percent_fd8671`, and `ui_pixels_6ec9c2`.
- `string/ui_trim_in_pixels` and `string/ui_trim_in_percent`, together. These resolve current context defects for priority `ui_left`, `ui_right`, and `ui_bottom`, and also support the existing non-priority top label without changing it.

Do not cherry-pick only the unit values or only the height template. The two unit forms are composition-specific keys, distinct from the standalone labels.

## Remaining holds

- `gallery_credit_could_not_save`
- `gallery_credit_too_large`
- `legacy_credits_unreadable`

The preservation/failure clauses in these three messages are understood and source-consistent. The hold concerns natural use of bare plural `priskyrimai` for stored credit information. Creative Commons itself uses `priskyrimas` for attribution, so this report does **not** declare that term wrong. Resolve the full credit-label terminology coherently rather than substituting three isolated warnings. Existing accepted receipts such as the empty-credit message are preserved with their original limits.

- `save20_gif_description`

Still-image output, 256 colours and first-frame opening are preserved. Independent Lithuanian graphics-term review is still needed for `Diteringas` alongside the non-priority `save20_dither` label. No unverified replacement is included.

## Deliverables

- `lithuanian-p0-p1-review.json`: authoritative 341-key ledger, current/candidate dispositions, complete exact values, individual review notes, consumers, hashes, limits and separate dependencies.
- `lithuanian-p0-p1-review.csv`: flat human-readable/exportable ledger.
- `prior-22-exact-pairs.json`: all 22 existing exact pairs, original receipts and preserved caveats.
- `proposed-corrections.json`: all 17 proposed edits with reasons, sources and atomic grouping.
- `lithuanian-priority-candidate.patch`: source-bound patch; not applied to production.
- `candidate/Paintroid/src/main/res/values-lt/strings.xml`: complete candidate catalogue.
- `static-composition-examples.json`: 28 illustrative string compositions for count, gender and unit boundaries. Not Android/JVM formatting tests.
- `validation.json`: exact mechanical check outcomes and explicit non-executed runtime/build stages.

## Verification and limits

Completed: exact 341-key manifest reconciliation; unique per-key notes; exact current/source and candidate placeholder signatures; XML parsing; resource-identity preservation; exactly 17 intended value changes; all 22 prior pair hashes; static consumer/alias inspection; isolated-copy patch dry run and application with exact candidate equality; unchanged production catalogue checks.

Not run: Gradle, builds, compilation, APKs, CI dispatch, emulators, installed UI, TalkBack, native-speaker review, version changes, releases, production edits, PR creation or merges. Structural checks establish integrity, **not linguistic correctness**.

The 30 no-direct-consumer keys retain wording-only limits. Absence of a direct source reference is not proof of impossibility of indirect/dynamic use. No review conclusion claims safe layout, good speech output, font coverage or physical control reachability.

## External linguistic reference

[Unicode CLDR Lithuanian plural rules](https://unicode.org/cldr/charts/48/supplemental/language_plural_rules.html#lt) distinguish integer endings such as 1/21, 2–9 and 0/10–19. They support avoiding a single fixed counted-noun form here; they do not certify the proposed vocabulary or Android runtime behavior.

[Creative Commons Lithuanian attribution terminology](https://creativecommons.org/licenses/by/2.0/pl/deed.lt) was visible in the primary-source search result. A full-page fetch failed; this is limited terminology context, not a review of the license or a basis to lift the credit-UI idiom hold.
