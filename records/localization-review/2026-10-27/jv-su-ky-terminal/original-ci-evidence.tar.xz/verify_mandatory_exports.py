from pathlib import Path
import subprocess,sys,json,hashlib
R=Path(__file__).resolve().parent;L=R.parent;S=R/'inventory-source';core=sorted(R.glob('verification-extraction-*'),key=lambda p:p.stat().st_mtime)[-1]/'core';out=R/'mandatory-exports';out.mkdir(exist_ok=True)
assert (core/'collection-status.log').read_text()=='dialog_pull_exit=0\nvertical_pull_exit=0\nlogcat_exit=0\nresult=0\n'
commands=[['dialog_evidence_transport.py',str(core/'dialog-export'),'--dialog-summary',str(core/'app-dialog/androidTest-results/summary.json'),'--output',str(out/'dialog'),'--receipt',str(out/'dialog.json')],['vertical_evidence_transport.py',str(core/'vertical-locale-export'),'--sdk','35','--output',str(out/'vertical'),'--receipt',str(out/'vertical-export.json')],['vertical_locale_matrix.py','verify-screenshots',str(out/'vertical'),'--output',str(out/'vertical-screenshots.json')],['vertical_control_reachability.py',str(out/'vertical/reachability'),'--sdk','35','--output',str(out/'vertical-reachability.json')]]
results=[]
for args in commands:
 logfile=out/(args[0]+'.log')
 with logfile.open('w') as f:code=subprocess.run([sys.executable,str(S/'tools'/args[0]),*args[1:]],cwd=S,stdout=f,stderr=subprocess.STDOUT).returncode
 assert code==0,(args[0],code)
 results.append({'validator':args[0],'exit':code,'log_sha256':hashlib.sha256(logfile.read_bytes()).hexdigest()})
receipt=json.loads((R/'terminal-verification.json').read_text());apk=R/'app.apk';assert hashlib.sha256(apk.read_bytes()).hexdigest()==receipt['apk_sha256']
with (out/'apksigner.log').open('w') as f:code=subprocess.run(['java','-Xmx128m','-jar',str(R/'apksigner.jar'),'verify','--verbose','--print-certs',str(apk)],stdout=f,stderr=subprocess.STDOUT).returncode
assert code==0
summary={'head':receipt['head'],'tree':receipt['tree'],'run_id':receipt['run_id'],'mandatory_collection_exit':0,'independent_validators':results,'original_app_apk_signature_exit':code,'scope':'Original same-run exports independently revalidated using exact source scripts; no universal layout or native linguistic claim.'}
(R/'mandatory-exports-verification.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
