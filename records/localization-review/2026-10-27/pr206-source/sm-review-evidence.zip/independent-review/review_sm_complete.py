from pathlib import Path
import copy,collections,hashlib,json,re,sys,xml.etree.ElementTree as E
B=Path(__file__).resolve().parents[1];O=B/'independent-review';S=B.parent/'yo-zu-xh-p0-p1-20261027/source';sys.path.insert(0,str(S/'tools'))
import translation_catalogues as tc
from test_slovak_slovenian_catalan_priority_wording import token_contract
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected={r['path']:r['sha256'] for r in json.loads((B/'sm-frozen-packet-bindings.json').read_text())}
packets=[]
for path,h in expected.items():assert sha(B/path)==h;packets.append(json.loads((B/path).read_text()))
rows=packets[0]['rows']+packets[1]['rows'];by={r['identity']:r for r in rows};deps=[];overlaps=[]
for r in packets[2]['rows']:
 if r['identity']in by:
  x=by[r['identity']]
  for k in('english','current','candidate_display_value','candidate_resource_value','candidate_resource_attributes','direct_consumers'):assert x[k]==r[k],(r['identity'],k)
  overlaps.append(r['identity'])
 else:deps.append(r)
assert len(rows)==341 and len(deps)==15 and len(overlaps)==4
rows+=deps;assert len({r['identity']for r in rows})==356
inventory=json.loads((B/'sm-inventory.json').read_text());catalogue=inventory['catalogue_path'];en={e.tag+'/'+e.get('name'):e for e in E.parse(S/'Paintroid/src/main/res/values/strings.xml').getroot()};old={e.tag+'/'+e.get('name'):e for e in E.parse(S/catalogue).getroot()}
def obj(n):
 if n is None:return None
 x={'value':n.text if n.tag=='string'else{c.get('quantity'):c.text for c in n},'attributes':n.attrib}
 if n.tag=='plurals':x['children_attributes']={c.get('quantity'):c.attrib for c in n}
 return x
refs=collections.defaultdict(list)
for root in('Paintroid/src/main','app/src/main'):
 for f in(S/root).rglob('*'):
  if f.suffix not in('.kt','.java','.xml')or'/res/values'in str(f):continue
  for i,line in enumerate(f.read_text().splitlines()):
   for kind,key in re.findall(r'R\.(string|plurals)\.([A-Za-z0-9_]+)\b',line):refs[kind+'/'+key].append((str(f.relative_to(S)),i+1))
def decode(v):
 if isinstance(v,dict):return{q:decode(t)for q,t in v.items()}
 assert v[0]==v[-1]=='"';v=v[1:-1]
 return re.sub(r'\\(u[0-9a-fA-F]{4}|.)',lambda m:chr(int(m[1][1:],16))if m[1].startswith('u')else{'n':'\n','r':'\r','t':'\t'}.get(m[1],m[1]),v)
holds={'string/'+k for k in('formats22_derived_exported','ui_save_as','ui_save_as_jpeg','ui_save_as_jpeg_xl','ui_save_as_png','ui_foreground_background_colour_palette','ui_pinch_and_pan_mode','ui_fit_image','ui_main23','ui_fg','ui_bg')};review=[];edits={};raw={};shown={};limited=[];windows=set()
for orig in rows:
 r=copy.deepcopy(orig);ident=r['identity'];key=ident.split('/')[1]
 for field,n in [('english',en[ident]),('current',old.get(ident))]:
  expected_node=obj(n)
  if expected_node is not None and 'children_attributes'in expected_node:
   assert r[field]=={k:v for k,v in expected_node.items()if k!='children_attributes'},(ident,field);r[field]=expected_node
  else:assert r[field]==expected_node,(ident,field)
 assert sorted((c['path'],c['line'])for c in r['direct_consumers'])==sorted(refs[ident]),ident
 for c in r['direct_consumers']:
  ls=(S/c['path']).read_text().splitlines();assert '\n'.join(ls[c['start_line']-1:c['end_line']])==c['context'];windows.add((c['path'],c['line'],c['start_line'],c['end_line']))
 if ident in holds:
  assert r['current']is None and (not r['direct_consumers']or key in('ui_fg','ui_bg'))
  r.update(decision='hold_absent',new_acceptance_credit=0,rationale='Preserve exact existing absence. Dormant route/state-sensitive wording has no current direct consumer; new compact FG/BG wording has no measured button-layout evidence. Candidate text not integrated or credited.');review.append(r);continue
 v=r['candidate_resource_value'];display=r['candidate_display_value'];assert decode(v)==display,(ident,'display')
 values=v if isinstance(v,dict)else{'string':v};e=r['english']['value']
 if isinstance(v,dict):assert set(v)=={'other'}
 for q,t in values.items():
  english=e[q]if isinstance(e,dict)else e
  assert token_contract(english)==token_contract(t),(ident,'tokens')
  assert re.findall(r'\\+n',english)==re.findall(r'\\+n',t),(ident,'newline')
  assert not tc.android_string_errors(t),(ident,tc.android_string_errors(t))
  assert not tc.format_string_errors(t,r['candidate_resource_attributes'].get('formatted')!='false'),ident
 r.update(decision='accept_candidate',reviewed_value=v,reviewed_display_value=display,reviewed_attributes=r['candidate_resource_attributes'],new_acceptance_credit=1,rationale='Independent complete-value comparison preserves action/object, polarity, conditions, preservation/loss, quantities and route-label consistency; exact source/current/caller binding and one-pass raw Android-to-display decoding verified. Bounded model/static review only.')
 if not r['direct_consumers']:limited.append(ident);r['rationale']+=' Wording only: no active direct caller, no runtime-route/layout certification.'
 if isinstance(v,dict):r['reviewed_children_attributes']={'other':{'quantity':'other'}};r['rationale']+=' Full preview/apply/count/conditional movement of attached images restored; other-only candidate avoids assuming an unverified inherited English plural rule. Actual compiled Android dispatch not tested here.'
 raw[key]=v;shown[key]=display;z={k:r[k]for k in('identity','tier','reviewed_value','reviewed_attributes','decision','rationale','direct_consumers')};z.update(type=ident.split('/')[0],source=r['english'],previous_target=r['current'])
 if isinstance(v,dict):z['reviewed_children_attributes']=r['reviewed_children_attributes']
 assert r['current']is None;edits[key]=z;review.append(r)
# Atomic menu routes and direct warnings share accepted label text.
assert shown['ui_menu_file']=='Faila' and shown['ui_load_image']=='Uta le ata…' and shown['save20_title']=='Sefe o se…' and shown['ui_save']=='Sefe'
assert shown['ui_save_a5d0d9']=='Sefe…'
assert shown['ui_export_recovery_copy']=='Auina atu le kopi toe faafoʻi…'
assert shown['formats22_at_least_frames']=='%1$d pe sili atu'
assert 'Faila > Uta le ata' in shown['ui_recovery_copy_exported_extract_canvas_png_from_the']
assert 'Tusi ata → Faaofi → Isi ata' in shown['ui_paste_hint34']
assert 'le faitauina o le ata i se fua ua faaitiitia' in shown['ui_sampled_resize_memory_explanation']
assert 'e toe faafoʻi na pika' in shown['ui_keeps_pixels_at_the_top_left_smaller_canvas']
assert 'ona tulaga e faaitiitia ai le telē o le faila' in shown['ui_save_explanation23']
assert '\n' in shown['ui_crop_preview_images']['other']
examples=[shown['formats22_animation_message'].replace('%1$s','GIF').replace('%2$s',str(n))for n in(2,3,21)]
examples.append(shown['formats22_animation_message'].replace('%1$s','GIF').replace('%2$s',shown['formats22_at_least_frames'].replace('%1$d','21')))
assert len(raw)==345
out={'source_commit':inventory['source_commit'],'source_tree':inventory['source_tree'],'locale':'sm','catalogue_path':catalogue,'rows':review[:341],'dependencies':review[341:],'accepted_resource_text_values':raw,'accepted_display_values':shown,'integration_values':edits,'held_priority_identities':sorted(holds),'wording_only_or_route_limited_identities':limited,'packet_sha256':expected,'duplicate_companion_priority_identities':overlaps,'animation_composition_examples':examples,'verification':{'priority':341,'P0':92,'P1':249,'unique_companions':15,'full_values_read':356,'source_current_pairs_verified':356,'unique_direct_caller_windows':len(windows),'accepted_resources':345,'exact_additions':345,'held_absent':11,'new_acceptance_credit':345},'references':['https://education.nsw.gov.au/content/dam/main-education/teaching-and-learning/curriculum/multicultural-education/eald/eald-bilingual-dictionary-samoan.pdf','https://www.unicode.org/cldr/charts/48/supplemental/language_plural_rules.html'],'limits':['No native-human linguistic acceptance, installed layout, TalkBack or Android/JVM/device execution.','SM not found in CLDR48 plural chart; other-only resource candidate does not establish installed Android dispatch, which still needs testing.','Eleven exact absent holds remain absent; four duplicate priority companions do not add review credit.']}
p=O/'sm-complete-review.json';p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');summary={'locale':'sm','priority':341,'companions':15,'edits':345,'accepted_retained':0,'holds_absent':11,'wording_route_limited':len(limited),'direct_caller_windows':len(windows),'ledger':p.name,'ledger_sha256':sha(p)};(O/'sm-complete-review-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
