from pathlib import Path
import copy,collections,hashlib,json,re,sys,xml.etree.ElementTree as E
B=Path(__file__).resolve().parents[1];O=B/'independent-review';S=B.parent/'yo-zu-xh-p0-p1-20261027/source';sys.path.insert(0,str(S/'tools'))
import translation_catalogues as tc
from test_slovak_slovenian_catalan_priority_wording import token_contract
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected={'rw-P0-author-packet.json': '2c60914e7c155cadb39ca16d827f127fe47977b74c8377311a1d207bb9d00174', 'rw-P1-author-packet.json': 'cc51172d41d9ac208e963d465d82fabef3fc81483711b819c4001e311ad97eff', 'rw-dependency-author-packet.json': '202507b5706944a2524e89432e793d2f9a42c6c61aa8b6755eb348a2cbba42f4'}
packets=[]
for path,h in expected.items():assert sha(B/path)==h;packets.append(json.loads((B/path).read_text()))
rows=packets[0]['rows']+packets[1]['rows'];by={r['identity']:r for r in rows};deps=[];overlaps=[]
for r in packets[2]['rows']:
 if r['identity']in by:
  x=by[r['identity']]
  for k in('english','current','candidate_display_value','candidate_resource_value','candidate_resource_attributes','direct_consumers'):assert x[k]==r[k],(r['identity'],k)
  overlaps.append(r['identity'])
 else:deps.append(r)
assert len(rows)==341 and len(deps)==15 and len(overlaps)==4
rows+=deps;assert len({r['identity']for r in rows})==356
inventory=json.loads((B/'rw-inventory.json').read_text());catalogue=inventory['catalogue_path'];en={e.tag+'/'+e.get('name'):e for e in E.parse(S/'Paintroid/src/main/res/values/strings.xml').getroot()};old={e.tag+'/'+e.get('name'):e for e in E.parse(S/catalogue).getroot()}
def obj(n):
 if n is None:return None
 x={'value':n.text if n.tag=='string'else{c.get('quantity'):c.text for c in n},'attributes':n.attrib}
 if n.tag=='plurals':x['children_attributes']={c.get('quantity'):c.attrib for c in n}
 return x
refs=collections.defaultdict(list)
for root in('Paintroid/src/main','app/src/main'):
 for f in(S/root).rglob('*'):
  if f.suffix not in('.kt','.java','.xml')or'/res/values'in str(f):continue
  for i,line in enumerate(f.read_text().splitlines()):
   for kind,key in re.findall(r'R\.(string|plurals)\.([A-Za-z0-9_]+)\b',line):refs[kind+'/'+key].append((str(f.relative_to(S)),i+1))
def decode(v):
 if isinstance(v,dict):return{q:decode(t)for q,t in v.items()}
 assert v[0]==v[-1]=='"';v=v[1:-1]
 return re.sub(r'\\(u[0-9a-fA-F]{4}|.)',lambda m:chr(int(m[1][1:],16))if m[1].startswith('u')else{'n':'\n','r':'\r','t':'\t'}.get(m[1],m[1]),v)
holds={'string/'+k for k in('formats22_derived_exported','ui_save_as','ui_save_as_jpeg','ui_save_as_jpeg_xl','ui_save_as_png','ui_foreground_background_colour_palette','ui_pinch_and_pan_mode','ui_fit_image','ui_main23','ui_fg','ui_bg')};review=[];edits={};raw={};shown={};limited=[];windows=set()
for orig in rows:
 r=copy.deepcopy(orig);ident=r['identity'];key=ident.split('/')[1]
 for field,n in [('english',en[ident]),('current',old.get(ident))]:
  expected_node=obj(n)
  if expected_node is not None and 'children_attributes'in expected_node:
   assert r[field]=={k:v for k,v in expected_node.items()if k!='children_attributes'},(ident,field);r[field]=expected_node
  else:assert r[field]==expected_node,(ident,field)
 assert sorted((c['path'],c['line'])for c in r['direct_consumers'])==sorted(refs[ident]),ident
 for c in r['direct_consumers']:
  ls=(S/c['path']).read_text().splitlines();assert '\n'.join(ls[c['start_line']-1:c['end_line']])==c['context'];windows.add((c['path'],c['line'],c['start_line'],c['end_line']))
 if ident in holds:
  assert r['current']is None and (not r['direct_consumers']or key in('ui_fg','ui_bg'))
  r.update(decision='hold_absent',new_acceptance_credit=0,rationale='Preserve exact existing absence. Dormant route/state-sensitive wording has no current direct consumer; new compact FG/BG wording has no measured button-layout evidence. Candidate text not integrated or credited.');review.append(r);continue
 v=r['candidate_resource_value'];display=r['candidate_display_value'];assert decode(v)==display,(ident,'display')
 values=v if isinstance(v,dict)else{'string':v};e=r['english']['value']
 if isinstance(v,dict):assert set(v)=={'other'}
 if key=='ui_crop_preview_images':assert display['other'].count(chr(10))==1 and (chr(92)+'n') not in display['other']
 for q,t in values.items():
  english=e[q]if isinstance(e,dict)else e
  assert token_contract(english)==token_contract(t),(ident,'tokens')
  assert re.findall(r'\\+n',english)==re.findall(r'\\+n',t),(ident,'newline')
  assert not tc.android_string_errors(t),(ident,tc.android_string_errors(t))
  assert not tc.format_string_errors(t,r['candidate_resource_attributes'].get('formatted')!='false'),ident
 r.update(decision='accept_candidate',reviewed_value=v,reviewed_display_value=display,reviewed_attributes=r['candidate_resource_attributes'],new_acceptance_credit=1,rationale='Independent complete-value comparison preserves action/object, polarity, conditions, preservation/loss, quantities and route-label consistency; exact source/current/caller binding and one-pass raw Android-to-display decoding verified. Bounded model/static review only.')
 if not r['direct_consumers']:limited.append(ident);r['rationale']+=' Wording only: no active direct caller, no runtime-route/layout certification.'
 if isinstance(v,dict):r['reviewed_children_attributes']={'other':{'quantity':'other'}};r['rationale']+=' Full preview/apply/count/conditional movement of attached images restored; other-only candidate avoids assuming an unverified inherited English plural rule. Actual compiled Android dispatch not tested here.'
 if key=='ui_draw_again':assert display=='Komeza gushushanya'
 if key in ('ui_copy','ui_copy_all','ui_paste_hint34'):assert display.startswith('Koporora');r['rationale']+=' Copy action uses primary-supported imperative rather than noun kopi.'
 if key=='ui_crop_preview_images':assert 'Umubare w’amashusho: %3$d' in display['other'] and 'bishobora kwimura' in display['other'] and 'afatanye na yo' in display['other'];r['rationale']+=' Count-neutral construction avoids plural noun being selected at one by unverified rw Android dispatch.'
 if r['current'] is not None and v==r['current']['value'] and r['reviewed_attributes']==r['current']['attributes']:r['decision']='retain_current';r['rationale']+=' Existing term individually checked against action and object; exact bytes retained, not auto-approved from inventory presence.'
 raw[key]=v;shown[key]=display;z={k:r[k]for k in('identity','tier','reviewed_value','reviewed_attributes','decision','rationale','direct_consumers')};z.update(type=ident.split('/')[0],source=r['english'],previous_target=r['current'])
 if isinstance(v,dict):z['reviewed_children_attributes']=r['reviewed_children_attributes']
 if r['decision']!='retain_current':edits[key]=z
 review.append(r)
# Atomic route labels and composed animation count are reviewed as full sentences.
assert shown['ui_menu_file']=='Dosiye' and shown['ui_load_image']=='Injiza ishusho…' and shown['ui_save']=='Bika'
assert shown['ui_export_recovery_copy']=='Sohora kopi yo kugarura…' and shown['save20_title']=='Bika nka…'
assert shown['formats22_at_least_frames']=='nibura %1$d'
examples=[shown['formats22_animation_message'].replace('%1$s','GIF').replace('%2$s',str(n))for n in(2,3,21)]
examples.append(shown['formats22_animation_message'].replace('%1$s','GIF').replace('%2$s',shown['formats22_at_least_frames'].replace('%1$d','21')))
assert len(raw)==345
out={'source_commit':inventory['source_commit'],'source_tree':inventory['source_tree'],'locale':'rw','catalogue_path':catalogue,'rows':review[:341],'dependencies':review[341:],'accepted_resource_text_values':raw,'accepted_display_values':shown,'integration_values':edits,'held_priority_identities':sorted(holds),'wording_only_or_route_limited_identities':limited,'packet_sha256':expected,'duplicate_companion_priority_identities':overlaps,'animation_composition_examples':examples,'verification':{'priority':341,'P0':92,'P1':249,'unique_companions':15,'full_values_read':356,'source_current_pairs_verified':356,'unique_direct_caller_windows':len(windows),'accepted_resources':345,'exact_additions':sum(r['current'] is None and r['decision']!='hold_absent' for r in review),'retained':sum(r['decision']=='retain_current' for r in review),'held_absent':11,'new_acceptance_credit':345},'references':['https://www.rwandaheritage.gov.rw/fileadmin/user_upload/RCHA/Publications/Published_Books/Inkoranyamuga_y_ikoranabuhanga.pdf','https://dr.ur.ac.rw/bitstream/handle/123456789/2308/Sibomana%20Francois%20Xavier.pdf?isAllowed=y&sequence=1','https://www.unicode.org/cldr/charts/48/supplemental/language_plural_rules.html'],'limits':['No native-human linguistic acceptance, installed layout, TalkBack or Android/JVM/device execution.','RW not found in CLDR48 plural chart; other-only resource candidate does not establish installed Android dispatch, which still needs testing.','Eleven exact absent holds remain absent; four duplicate priority companions do not add review credit.']}
p=O/'rw-complete-review.json';p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');summary={'locale':'rw','priority':341,'companions':15,'edits':len(edits),'accepted_retained':345-len(edits),'holds_absent':11,'wording_route_limited':len(limited),'direct_caller_windows':len(windows),'ledger':p.name,'ledger_sha256':sha(p)};(O/'rw-complete-review-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
