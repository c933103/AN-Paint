from pathlib import Path
import json,hashlib,re,xml.etree.ElementTree as E,sys
B=Path(__file__).resolve().parent;S=B.parent/'yo-zu-xh-p0-p1-20261027/source';sys.path.insert(0,str(B));from freeze_display_packets import serialized
candidates={'mi':{'ui_strength':'Kaha (%)','ui_fill_line':'Whakakī + rārangi','ui_image_assembly':'Huinga atahanga…'},'sm':{'ui_strength':'Malosi (%)','ui_fill_line':'Faatumu + laina','ui_image_assembly':'Tuufaatasiga o ata…'},'rw':{'ui_strength':'Ubukana (%)','ui_fill_line':'Kuzuza + umurongo','ui_image_assembly':'Uruvange rw’amashusho…'}}
en={n.get('name'):n for n in E.parse(S/'Paintroid/src/main/res/values/strings.xml').getroot()};rows=[]
for tag,values in candidates.items():
 inv=json.loads((B/f'{tag}-inventory.json').read_text());cur={n.get('name'):n for n in E.parse(S/inv['catalogue_path']).getroot()}
 for key,value in values.items():
  n=cur.get(key);row={'locale':tag,'identity':'string/'+key,'tier':'bounded-runtime-companion','english':{'value':en[key].text,'attributes':dict(en[key].attrib)},'current':None if n is None else {'value':n.text,'attributes':dict(n.attrib)},'candidate_display_value':value,'candidate_resource_value':serialized(value),'candidate_resource_attributes':dict(en[key].attrib),'direct_consumers':[]}
  for p in (S/'Paintroid/src/main/java').rglob('*.kt'):
   lines=p.read_text().splitlines()
   for i,line in enumerate(lines):
    if re.search(r'R\.string\.'+key+r'\b',line):row['direct_consumers'].append({'path':p.relative_to(S).as_posix(),'line':i+1,'start_line':max(0,i-4)+1,'end_line':min(len(lines),i+5),'context':'\n'.join(lines[max(0,i-4):min(len(lines),i+5)])})
  rows.append(row)
(B/'runtime-extra-author-packet.json').write_text(json.dumps({'source_commit':'b225631aa4609d9d0c64513982f56cb39d864125','source_tree':'28ada9cbc9cf3c7509dbed764ebb7e245e064b8f','scope':'Nine bounded actual-dialog/tool-name companions needed to exercise existing runtime consumers without untranslated dependency labels; no full-locale or native claim','rows':rows},ensure_ascii=False,indent=2)+'\n')
