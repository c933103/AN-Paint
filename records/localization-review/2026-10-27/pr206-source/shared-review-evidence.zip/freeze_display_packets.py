from pathlib import Path
import json,hashlib
B=Path(__file__).resolve().parent
# TSV candidates use literal backslash-n because they have one physical line per row.
# Freeze converts that authoring convention exactly once to a display newline.
# Resource values use outer Android quotes, preserving whitespace and apostrophes.
def shown(v):
 if isinstance(v,dict):return {k:shown(x) for k,x in v.items()}
 return v.replace('\\n','\n')
def serialized(v):
 if isinstance(v,dict):return {k:serialized(x) for k,x in v.items()}
 return '"'+v.replace('\\','\\\\').replace('"','\\"').replace('\n','\\n')+'"'
def freeze(tag):
 records=[]
 for suffix in ['P0','P1','dependency']:
  p=B/f'{tag}-{suffix}-author-packet.json';d=json.loads(p.read_text())
  for r in d['rows']:
   v=shown(r['candidate_display_value']);r['candidate_display_value']=v;r['candidate_resource_value']=serialized(v);r['candidate_resource_attributes']=r['english']['attributes']
  d['serialization_contract']='freeze_display_packets.py: shown once from single-line TSV; serialized outer Android double quotes, slash/quote escapes, actual LF to raw backslash-n. Source data preserved separately; candidate only.'
  p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');records.append({'path':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'rows':len(d['rows'])})
 (B/f'{tag}-frozen-packet-bindings.json').write_text(json.dumps(records,indent=2)+'\n')
if __name__=='__main__':
 import sys
 freeze(sys.argv[1])
