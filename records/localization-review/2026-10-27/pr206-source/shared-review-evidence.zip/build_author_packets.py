from pathlib import Path
import hashlib,json,re,xml.etree.ElementTree as E
B=Path(__file__).resolve().parent
S=Path('yo-zu-xh-p0-p1-20261027/source')
def dump(p,data):p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def params(v):return sorted(re.findall(r'%(?:\d+\$)?[-+,.\d]*[a-zA-Z]',v))
def node(n):
 if n is None:return None
 return {'value':{c.get('quantity'):c.text or '' for c in n} if n.tag=='plurals' else ''.join(n.itertext()),'attributes':dict(n.attrib)}
def build(tag,tier):
 inv=json.loads((B/f'{tag}-inventory.json').read_text());tsv=dict(line.split('\t',1) for line in (B/f'{tag}-{tier}-candidates.tsv').read_text().splitlines());rows=[r for r in inv['rows'] if r['tier']==tier]
 assert len(tsv)==len(rows)=={'P0':92,'P1':249}[tier]
 for row in rows:
  key=row['identity'].split('/')[1];target=tsv[key]
  assert params(target)==params(row['english']['value']),key
  row['candidate_display_value']=target;row['author_status']='candidate-awaiting-independent-review'
  row['author_note']='Complete value, not a keyword judgment; display candidate before Android serialization. No source integration or independent/native-reader/runtime acceptance.'
 dump(B/f'{tag}-{tier}-author-packet.json',{'scope':f'Full {len(rows)} {tier} source-bound rows; candidate only','source_commit':inv['source_commit'],'source_tree':inv['source_tree'],'locale':tag,'inventory_sha256':hashlib.sha256((B/f'{tag}-inventory.json').read_bytes()).hexdigest(),'rows':rows})
def dependencies(tag):
 inv=json.loads((B/f'{tag}-inventory.json').read_text());known={r['identity']:r for r in inv['rows']};en={n.get('name'):n for n in E.parse(S/'Paintroid/src/main/res/values/strings.xml').getroot()};cur={n.get('name'):n for n in E.parse(S/inv['catalogue_path']).getroot()};rows=[]
 tsv=dict(line.split('\t',1) for line in (B/f'{tag}-dependency-candidates.tsv').read_text().splitlines())
 for k,v in tsv.items():
  ident='string/'+k;row=known.get(ident,{'identity':ident,'tier':'adjacent-dependency','english':node(en[k]),'current':node(cur.get(k)),'direct_consumers':[]})
  if not row['direct_consumers']:
   for p in (S/'Paintroid/src/main/java').rglob('*.kt'):
    lines=p.read_text().splitlines()
    for i,line in enumerate(lines):
     if re.search(r'R\.string\.'+re.escape(k)+r'\b',line):
      a=max(0,i-4);z=min(len(lines),i+5);row['direct_consumers'].append({'path':p.relative_to(S).as_posix(),'line':i+1,'start_line':a+1,'end_line':z,'context':'\n'.join(lines[a:z])})
  assert params(v)==params(row['english']['value']),k
  row['candidate_display_value']=v;row['author_status']='candidate-awaiting-independent-review';rows.append(row)
 plurals=B/f'{tag}-plural-candidates.json'
 if plurals.exists():
  for k,v in json.loads(plurals.read_text()).items():
   row={'identity':'plurals/'+k,'tier':'adjacent-dependency','english':node(en[k]),'current':node(cur.get(k)),'direct_consumers':[],'candidate_display_value':v,'author_status':'candidate-awaiting-independent-review'}
   for p in (S/'Paintroid/src/main/java').rglob('*.kt'):
    lines=p.read_text().splitlines()
    for i,line in enumerate(lines):
     if re.search(r'R\.plurals\.'+re.escape(k)+r'\b',line):
      a=max(0,i-4);z=min(len(lines),i+5);row['direct_consumers'].append({'path':p.relative_to(S).as_posix(),'line':i+1,'start_line':a+1,'end_line':z,'context':'\n'.join(lines[a:z])})
   for value in v.values():assert params(value)==params(row['english']['value']['other']),k
   rows.append(row)
 dump(B/f'{tag}-dependency-author-packet.json',{'scope':'Atomic controls/count dependencies; priority rows carry their existing identity with no duplicate credit','source_commit':inv['source_commit'],'source_tree':inv['source_tree'],'locale':tag,'rows':rows,'plural_category_source':'https://www.unicode.org/cldr/charts/49/supplemental/language_plural_rules.html; MI candidate other only; independent category and runtime review pending'})
if __name__=='__main__':
 import sys
 if sys.argv[2]=='dependencies':dependencies(sys.argv[1])
 else:build(sys.argv[1],sys.argv[2])
