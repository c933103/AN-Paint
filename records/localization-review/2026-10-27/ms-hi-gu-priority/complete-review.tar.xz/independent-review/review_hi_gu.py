from pathlib import Path
import json,hashlib,re,xml.etree.ElementTree as ET,collections,unicodedata
root=Path(__file__).resolve().parents[1];source=root/'source';tree=json.loads((root/'base-tree.json').read_text());blobs={x['path']:x['sha'] for x in tree['tree'] if x['type']=='blob'}
def cat(path):
 a=list(ET.parse(source/path).getroot());d={n.tag+'/'+n.attrib['name']:{'value':({c.get('quantity'):c.text for c in n} if n.tag=='plurals' else n.text),'attributes':dict(n.attrib)} for n in a};assert len(a)==len(d);return d
def bare(x):return None if x is None else {k:x[k] for k in ['value','attributes']}
def digest(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
enpath='Paintroid/src/main/res/values/strings.xml';en=cat(enpath);tiers=json.loads((source/'translations/string-importance.json').read_text())['tiers'];expected={k:t['id'] for t in tiers if t['id'] in ['P0','P1'] for k in t['keys']};rx=re.compile(r'%(?:\d+\$)?[-#+ 0,(]*\d*(?:\.\d+)?[a-zA-Z]');paths={enpath,'translations/string-importance.json','Paintroid/src/main/java/org/catrobat/paintroid/classic/ScanlineFill.kt','Paintroid/src/main/java/org/catrobat/paintroid/classic/PaintDocument.kt'}
holds={'string/'+k for k in ['formats22_derived_exported','ui_save_as','ui_save_as_jpeg','ui_save_as_jpeg_xl','ui_save_as_png','ui_foreground_background_colour_palette','ui_pinch_and_pan_mode']}
def why(k,r):
 if k in ['ui_collapse_tool_category','ui_expand_tool_category']:return 'Actual selected-tool accessibility label uses an explicit tool noun, so grammatical agreement does not depend on the injected tool name; category, chosen tool and expansion action all retained.'
 if k=='ui_draw_again':return 'Actual chooseTool(drawingTool) callback resumes the previous drawing tool rather than redrawing the picture.'
 if k=='ui_tolerance':return 'Fill-only slider is passed to ScanlineFill squared ARGB colour-distance threshold; colour-difference limit states the real technical meaning without social-tolerance ambiguity.'
 if k in ['ui_fit','ui_fit_image','ui_fit_selection34','ui_fit_entire_canvas_in_view']:return 'Transitive Fit action with explicit image/canvas/whole-canvas referent matches the current consumer; no intransitive imperative error.'
 if k in ['ui_scales_the_image_unlock_the_ratio_to_stretch','ui_lock_aspect_ratio']:return 'Actual width-height aspect lock and independent dimension resizing checked; both enlargement and reduction are possible, not only growth.'
 if k in ['ui_height_in','ui_width_in','ui_trim_in_pixels','ui_trim_in_percent','ui_pixels_6ec9c2','ui_percent_fd8671']:return 'Neutral unit/edge wrapper composes with existing labels without inflection or English mixed-language templates. All placeholders and unit distinctions retained.'
 if k=='ui_keeps_pixels_at_the_top_left_smaller_canvas':return 'Actual top-left anchoring and discard beyond either right OR bottom edge retained; localized Undo label matches current command.'
 if k=='ui_higher_quality_usually_makes_a_larger_file_lossless':return 'Full quality/file-size probability and lossless every-colour-value guarantee retained; explicit mode noun ties lossless to the adjacent checkbox label.'
 if k=='ui_the_encoder_did_not_finish':return 'Encoding operation did not finish, not an assertion that the encoder object itself is unfinished.'
 if k in ['ui_paste_hint34','ui_autosave_is_paused_to_protect_that_draft_use','ui_recovery_copy_exported_extract_canvas_png_from_the','ui_a_separate_recovery_copy_has_been_kept_use']:return 'Complete message checked against actual localized File, Save as, export recovery, load-image and insertion menu labels; all preservation and extraction instructions retained.'
 if k.startswith('formats22_animation') or k=='formats22_at_least_frames':return 'Actual still-image-only import and exact/lower-bound frame-count composition checked; invariant count-label wording supports arbitrary counts without plural mismatch.'
 if k in ['save20_gif_description','save20_dither']:return 'GIF still-image/256-colour/first-frame semantics complete; the same dithering term names the actual checkbox.'
 if k.startswith('gallery_credit') or k=='legacy_credits_unreadable':return 'Credit/attribution information, restore/save failure and exact previous-copy preservation claims remain complete; no forced author-only narrowing.'
 if not r['direct_consumers']:return 'Standalone resource wording only: natural label with no current direct consumer; no installed UI or behavioral certification.'
 return 'Complete current/source value and real caller reviewed for semantics, qualifiers, natural wording, numeric formatting and related UI terminology.'
summary={}
for lang in ['hi','gu']:
 p=json.loads((root/f'candidate-public/{lang}-complete-author-packet.json').read_text());path=f'Paintroid/src/main/res/values-{lang}/strings.xml';local=cat(path);paths.add(path);assert {r['identity']:r['tier'] for r in p['rows']}==expected;assert {r['identity'] for r in p['rows'] if r['author_disposition']=='held-absent'}==holds;out=[];changes={};display={};dependencies=[];nfc=[]
 original=json.loads((root/f'candidate-versions/v1/{lang}-complete-author-packet.json').read_text()) if (root/f'candidate-versions/v1/{lang}-complete-author-packet.json').exists() else None
 original_values={r['identity']:r.get('proposal') for r in original['rows']+original['outside_priority_dependencies']} if original else {}
 for r in p['rows']+p['outside_priority_dependencies']:
  key=r['identity'];k=key.split('/')[1];assert bare(r['english'])==en[key],(lang,key,'source');assert bare(r['current'])==local.get(key),(lang,key,'previous')
  for c in r['direct_consumers']:
   paths.add(c['path']);lines=(source/c['path']).read_text().splitlines();assert '\n'.join(lines[c['start_line']-1:c['end_line']])==c['context'];assert 'R.string.'+k in lines[c['line']-1]
  value=r.get('proposal');old=bare(r['current'])
  if key in holds:assert old is None and value is None;decision='hold_absent';reason='Five exact dormant P0 holds, unknown third-placeholder palette composition, and dormant pinch-mode context remain unresolved; do not add or claim active review.'
  else:
   assert isinstance(value,str) and value
   assert hashlib.sha256(value.encode()).hexdigest()==r['proposal_sha256'],(lang,k,'proposal digest')
   if r['english']['attributes'].get('formatted')=='false':assert value.count('%')==r['english']['value'].count('%')
   else:assert sorted(rx.findall(value))==sorted(rx.findall(r['english']['value'])),(lang,k,'tokens')
   assert value.count('\\n')==r['english']['value'].count('\\n'),(lang,k,'newlines')
   if not unicodedata.is_normalized('NFC',value):nfc.append(key)
   if old is None:decision='accept_new_active' if r['direct_consumers'] else 'accept_new_wording_only'
   elif old['value'].removeprefix('"').removesuffix('"')!=value:decision='accept_current_correction'
   else:decision='accept_current_bounded' if r['direct_consumers'] else 'accept_current_wording_only'
   reason=why(k,r);display[k]=value
   if old is None or old['value'].removeprefix('"').removesuffix('"')!=value:changes[k]={'identity':key,'tier':r['tier'],'source':bare(r['english']),'previous_target':old,'reviewed_value':value,'reviewed_value_encoding':'Android resource text without optional wrapping quotes; unchanged current quoted values must remain byte-for-byte.', 'original_submitted_value':original_values.get(key),'decision':'revise' if key in original_values and original_values[key]!=value else 'accept','rationale':reason,'direct_consumers':r['direct_consumers']}
  row=dict(r,decision=decision,reviewed_value=value,rationale=reason,confidence='Medium model linguistic judgment; high exact source/format/current-caller binding. No native-human or installed-UI certification.')
  (out if key in expected else dependencies).append(row)
 result={'source_commit':p['source_commit'],'source_tree':p['source_tree'],'locale':lang,'catalogue_path':path,'scope':'Complete 92 P0 plus 249 P1 independent current/source review, seven exact absent holds, and seven finite adjacent P2 dependencies. No prior independent accepted pairs recovered, so none invented.','rows':out,'dependencies':dependencies,'accepted_resource_text_values':display,'accepted_display_values':{k:v.replace('\\n','\n') for k,v in display.items()},'integration_values':changes,'value_encoding':'reviewed_value is unquoted Android resource text with literal backslash-n escapes; accepted_display_values decodes those newlines. Existing unchanged wrapping quotes stay byte-for-byte and are not new edits.','counts':dict(collections.Counter(x['decision'] for x in out)),'dependency_counts':dict(collections.Counter(x['decision'] for x in dependencies)),'non_NFC_existing_values_retained':nfc,'limits':['Source-bound model review, not native-human/whole-language certification.','Dormant simple labels receive wording-only acceptance; Main is a valid standalone label here, but no screen usage is assumed.','Seven absent holds are exact unresolved identities, not a blanket P1 freeze or user-consent barrier.','Latin format names, integer/decimal placeholders, literal percent formatted=false and explicit newlines retained.','Actual localized menu/checkbox/unit composition checked; full P2 catalogue not in scope.','No app resources modified by reviewer; author owns integration and runtime checks.','User release/PR/help/callback/archive stops preserved.']}
 (root/f'independent-review/{lang}-complete-review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');summary[lang]={'priority':result['counts'],'dependencies':result['dependency_counts'],'integration_values':len(changes),'display_values':len(display)}
verified={}
for path in paths:
 b=(source/path).read_bytes();h=hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest();assert h==blobs[path],path;verified[path]=h
(root/'independent-review/hi-gu-verification.json').write_text(json.dumps({'source_commit':p['source_commit'],'source_tree':p['source_tree'],'verified_git_blobs':verified,'locales':summary,'supplemental_terminology_evidence':[{'term':'યામ (coordinate)','url':'https://www.gsebeservice.com/assets/news/std10%20part2.pdf','scope':'Official Gujarat education board indexed source uses the term for point coordinates; corroborates this term only, not the complete translation.'}]},ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,indent=2));print('verified source blobs:',len(verified))
