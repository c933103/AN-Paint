from pathlib import Path
import json,hashlib,xml.etree.ElementTree as E,re,collections,unicodedata
root=Path(__file__).resolve().parents[1];s=root/'source';p=json.loads((root/'candidate-public/ms-complete-author-inventory.json').read_text());tree=json.loads((root/'base-tree.json').read_text());blobs={r['path']:r['sha'] for r in tree['tree'] if r['type']=='blob'}
paths={'Paintroid/src/main/res/values/strings.xml','Paintroid/src/main/res/values-ms/strings.xml','translations/string-importance.json'}
def cat(path):return {n.tag+'/'+n.attrib['name']:n for n in E.parse(s/path).getroot() if 'name' in n.attrib}
en=cat('Paintroid/src/main/res/values/strings.xml');ms=cat('Paintroid/src/main/res/values-ms/strings.xml');pri={k:t['id'] for t in json.loads((s/'translations/string-importance.json').read_text())['tiers'] if t['id'] in ['P0','P1'] for k in t['keys']};assert len(p['rows'])==341 and {r['identity']:r['tier'] for r in p['rows']}==pri
holdkeys={'string/formats22_derived_exported','string/ui_save_as','string/ui_save_as_jpeg','string/ui_save_as_jpeg_xl','string/ui_save_as_png','string/ui_foreground_background_colour_palette','string/ui_main23','string/ui_pinch_and_pan_mode'}
reasons={
'colour_unsupported_icc_model':'Retains ICC model-conversion limitation and RGB export prerequisite in a colour-managed application.',
'commons_svg_original_size_too_large':'Retains original-size Android bitmap limit and explicitly says no resize occurred.',
'commons_svg_original_size_unavailable':'Retains missing usable original-size declaration and explicitly rules out a canvas-sized substitute.',
'formats22_animation_poster':'Separate default PNG image, replacement of animated frames and static save result are all explicit.',
'formats22_animation_unknown':'Retains uncertainty about multiple frames; does not misreport confirmed animation or full preservation.',
'formats22_ascii_description':'Plain text/light-dark characters/monospaced display/non-reopenable rendition all retained.',
'formats22_derived_exported':'Complete wording retains exported copy versus unsaved full drawing distinction, but no current consumer establishes use; hold preserved.',
'gallery_credit_could_not_save':'Save or restore failure, existing persisted credits retained and retry all explicit.',
'gallery_credit_too_large':'Retains recoverability-size consequence and preservation of previous drawing plus credits.',
'legacy_credits_unreadable':'Distinguishes unreadable saved credits from preserved stored copies.',
'save20_gif_description':'Still image, 256-colour ceiling, gradient smoothing and first-frame opening all retained. Penditeran agrees with checkbox and DBP computing term.',
'save20_lossy_quality_description':'Retains more detail and usual, not inevitable, larger-file qualifier.',
'save20_unsupported_image_colour':'Retains current converter limitation and sRGB PNG in colour-managed editor remedy.',
'ui_a_separate_recovery_copy_has_been_kept_use':'Complete recovery-copy preservation and ZIP/canvas.png/normal-resize instructions; quoted command agrees with live menu.',
'ui_android_could_not_find_a_file_picker_enable':'Distinguishes missing picker from cancelled or denied operation; names Files/Documents and Android settings remedy.',
'ui_autosave_is_paused_to_protect_that_draft_use':'Protects prior draft separately from current work; actual Fail, Eksport salinan pemulihan, Simpan sebagai, Format fail labels agree.',
'ui_choose_a_smaller_output_copy_the_source_images':'Output-copy reduction does not imply mutation of source resolution or crop settings.',
'ui_codec_resize_memory_floor':'Original-image/source-tile decoding prerequisite and may-still-exceed-memory qualifier retained.',
'ui_d_d_pixels_2f_mp_exceeds_the_current':'Four numeric arguments, complete-image/transform/selection reserves, memory-dependent limit, preallocation rejection and no automatic resize retained. Pilihan matches current selection UI terminology.',
'ui_drawing_canvas_pinch_and_move_two_fingers_to':'Both two-finger zoom/pan and one-finger Navigate pan retained; Alih dan zum exactly names current mode.',
'ui_export_did_not_save23':'Export creation does not claim current image saved; Simpan/Simpan sebagai prerequisite explicit.',
'ui_export_explanation23':'Icon/Base64/ASCII export choices and unchanged current image/ordinary Save destination all retained.',
'ui_higher_quality_usually_makes_a_larger_file_lossless':'Usual larger-file qualifier and every-colour-value preservation in lossless mode explicit.',
'ui_history_unavailable34':'Recovered canvas is separated from unreadable undo history and preserved original draft copy.',
'ui_keeps_pixels_at_the_top_left_smaller_canvas':'Top-left anchoring, right/bottom pixel loss and actual Buat asal remedy retained.',
'ui_recovery_copy_exported_extract_canvas_png_from_the':'ZIP/canvas.png and actual Fail > Buka imej command retained; settings and floating selection are not omitted.',
'ui_save_explanation23':'File name/location/format/settings reuse all explicit; ordinary Save context, not derived export.',
'ui_share_explanation34':'Save-copy-then-share order and unchanged current Save destination retained.',
'ui_the_decoder_and_editing_buffers_need_about_the':'Approximate requirement and separate current safe budget retain both placeholders and smaller-copy remedy.',
'ui_the_full_image_and_working_buffers_exceed_the':'Budget exceedance OR Android allocation failure retained, not falsely attributed solely to RAM; resize-copy and source-unchanged promise explicit.',
'ui_this_file_is_not_a_supported_image_use':'Every listed format and Base64 image-text alternative retained.'}
rows=[]
for r in p['rows']:
 k=r['identity'];name=k.split('/')[1]
 for field,c in [('english',en),('current',ms)]:
  assert r[field]['value']==c[k].text and r[field]['attributes']==dict(c[k].attrib)
  h=hashlib.sha256(json.dumps(c[k].text,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest();assert h==r[field]['value_json_sha256']
 for c in r['direct_consumers']:
  paths.add(c['path']);lines=(s/c['path']).read_text().splitlines();assert '\n'.join(lines[c['start_line']-1:c['end_line']])==c['context']
 if r.get('prior_receipt'):
  q=r['prior_receipt'];assert q['reviewed_english_sha256']==r['english']['value_json_sha256'];assert q['reviewed_localized_sha256']==r['current']['value_json_sha256'];decision='carry_prior_exact_acceptance';reason='Historical independently accepted complete source/target hashes match exactly; no new review credit.'
 elif r.get('prior_memory_successor'):
  q=r['prior_memory_successor'];paths.add(q['path']);assert q['source']==r['english']['value'] and q['target']==r['current']['value'];decision='carry_prior_exact_memory_successor';reason='Later corrected memory-source acceptance matches exact current complete value; prior wording is not replayed.'
 else:
  assert name in reasons;decision='hold_current_context' if k in holdkeys else 'accept_current_bounded';reason=reasons[name]
  a=re.findall(r'%(?:\d+\$)?[-#+ 0,(<]*(?:\d+)?(?:\.\d+)?[sdf]',r['english']['value']);b=re.findall(r'%(?:\d+\$)?[-#+ 0,(<]*(?:\d+)?(?:\.\d+)?[sdf]',r['current']['value']);assert collections.Counter(a)==collections.Counter(b)
  assert unicodedata.normalize('NFC',r['current']['value'])==r['current']['value']
 rows.append(dict(r,review={'decision':decision,'exact_accepted_current_value':r['current']['value'] if decision!='hold_current_context' else None,'rationale':reason,'confidence':'medium-high model/source judgment' if not decision.startswith('carry') else 'source-bound prior receipt','context_limit':('No current direct consumer; exact held key remains held.' if k in holdkeys and not r['direct_consumers'] else 'Wording-only, no current direct consumer.' if not r['direct_consumers'] else 'Static current caller; no installed-layout/runtime/native-human certification.')}))
verified={}
for path in paths:
 b=(s/path).read_bytes();h=hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest();assert h==blobs[path],path;verified[path]=h
result={'schema_version':1,'locale':'ms','source_commit':p['source_commit'],'source_tree':p['source_tree'],'scope':'Full341 P0+P1 accounting:310 exact prior carries,30 independently accepted current complete values,1 unchanged no-current-consumer hold. No source/test edits; no invented candidate count.','rows':rows,'verified_git_blobs':verified,'counts':dict(collections.Counter(r['review']['decision'] for r in rows)),'terminology_source':{'url':'https://prpm.dbp.gov.my/Cari1?d=371752&keyword=paparan+1','bounded_attestation':'DBP computing term dithering = penditeran; not a whole-string/native certification.'},'limitations':['All existing per-entry no-consumer limits retained, including five dormant P0 identities and palette/main/pinch-context limits. Historical wording receipts do not close context holds.','No whole-language fluency, installed-layout, TalkBack or physical-device acceptance.','No required linguistic edits found among31 previously unmapped complete values; author/root own durable evidence publication.']}
(root/'independent-review/ms-complete-review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(result['counts'],'verified blobs',len(verified))
