from pathlib import Path
import json,hashlib,xml.etree.ElementTree as E
root=Path(__file__).resolve().parents[1];source=root/'source';tree=json.loads((root/'base-tree.json').read_text());blobs={r['path']:r['sha'] for r in tree['tree'] if r['type']=='blob'}
def nodes(path):
 a=list(E.parse(path).getroot());d={n.tag+'/'+n.attrib['name']:{'value':({c.get('quantity'):c.text for c in n} if n.tag=='plurals' else n.text),'attributes':dict(n.attrib)} for n in a};assert len(a)==len(d);return d
fpath=source/'tools/fixtures/current_localization/malay_hindi_gujarati_priority_wording.json';fixture=json.loads(fpath.read_text());result={}
for tag in ['hi','gu','ms']:
 path=f'Paintroid/src/main/res/values-{tag}/strings.xml';original=root/'baseline-resources'/f'{tag}.xml';data=original.read_bytes();h=hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest();assert h==blobs[path];old=nodes(original);cur=nodes(source/path);expected=dict(old)
 changes={}
 if tag in ['hi','gu']:
  r=json.loads((root/'independent-review'/f'{tag}-complete-review.json').read_text());changes=r['integration_values'];cohort=fixture['locales'][tag];assert set(cohort['values'])==set(changes)
  for k,v in changes.items():
   key='string/'+k;assert old.get(key)==v['previous_target'];target='"'+v['reviewed_value']+'"';expected[key]={'value':target,'attributes':v['source']['attributes']};w=cohort['values'][k]
   assert w['target']==target and w['source']==v['source']['value'] and w['attributes']==v['source']['attributes'];assert w['display']==r['accepted_display_values'][k];oldv=v['previous_target'];assert w['previous_target']==(oldv['value'] if oldv else None) and w['previous_attributes']==(oldv['attributes'] if oldv else None)
  for x in r['rows']:
   if x['decision']=='hold_absent':assert x['identity'] not in cur
   else:assert cur[x['identity']]['value'].removeprefix('"').removesuffix('"')==x['reviewed_value']
 assert cur==expected,tag
 result[tag]={'original_git_blob_verified':h,'entire_catalogue_matches_exact_reviewed_delta':True,'total_entries':len(cur),'changed_values':len(changes),'unchanged_values':len(old)-sum(v['previous_target'] is not None for v in changes.values()),'integrated_sha256':hashlib.sha256((source/path).read_bytes()).hexdigest()}
changed=[];historical=0
for path,sha in blobs.items():
 p=source/path
 if not p.exists():changed.append({'path':path,'change':'removed'});continue
 b=p.read_bytes();h=hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()
 if h!=sha:changed.append({'path':path,'sha256':hashlib.sha256(b).hexdigest()})
 if path.startswith('tools/fixtures/'):assert h==sha,('historical fixture modified',path);historical+=1
out={'source_commit':r['source_commit'],'source_tree':r['source_tree'],'locales':result,'existing_fixture_blobs_unchanged':historical,'tracked_delta':changed,'new_fixture_sha256':hashlib.sha256(fpath.read_bytes()).hexdigest(),'encoding_check':'Each actual edit is exactly the reviewed resource text enclosed in Android wrapper double quotes; unchanged existing wrappers and aliases remain byte-for-byte.','limits':['Exact XML values/attributes and unchanged historical fixture readback; runtime/compiler proof requires author CI.','Fixture changed/context partition sensitivity correction requested separately.','No whole-language/native-human certification.']};(root/'independent-review/integration-readback.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n');print(json.dumps(out,indent=2,ensure_ascii=False))
