from pathlib import Path
import sys,json,hashlib,copy,types,xml.etree.ElementTree as E,re
from unittest.mock import patch
r=Path(__file__).resolve().parents[1];s=r/'source';stage=r/'option-successor';sys.path.insert(0,str(s/'tools'))
import hausa_igbo_lingala_priority_expectations as h
import test_current_localization_contracts as c
import memory_warning_source_review as m
p=stage/'hausa_igbo_lingala_priority_expectations.py';n=types.ModuleType('staged');exec(compile(p.read_text(),str(p),'exec'),n.__dict__)
rows=json.loads((s/'tools/fixtures/language_option_additions_20261012.json').read_text())['languages'];count=0;shared=0
def reject(fn):
 global count
 try:fn()
 except (ValueError,AssertionError):count+=1;return
 raise AssertionError('accepted invalid mutation')
for tag in h.TAGS:
 old=next(x for x in rows if x['tag']==tag);root=E.parse(s/old['catalogue']).getroot();xml=E.tostring(root,encoding='unicode');n.require_priority_option_successor(old,xml)
 for i,node in enumerate(root):
  for child in range(len(node)) if node.tag=='plurals' else [None]:
   d=copy.deepcopy(root);t=d[i] if child is None else d[i][child];t.text=(t.text or '')+' corrupted';reject(lambda:n.require_priority_option_successor(old,E.tostring(d,encoding='unicode')))
 for row in rows:
  if row['tag']!=tag:reject(lambda:n.require_priority_option_successor(row,xml))
 for field,val in [('translation_status','complete'),('linguistic_review','accepted'),('fallback','translated'),('source_strings_present',346),('source_plurals_present',1),('name','wrong'),('catalogue','wrong')]:
  d=copy.deepcopy(old);d[field]=val;reject(lambda:n.require_priority_option_successor(d,xml))
 for mode in ('missing','extra','attribute','duplicate'):
  d=copy.deepcopy(root)
  if mode=='missing':d.remove(d[0])
  elif mode=='extra':E.SubElement(d,'string',name='extra').text='extra'
  elif mode=='duplicate':d.append(copy.deepcopy(d[0]))
  else:d[0].set('bad','true')
  reject(lambda:n.require_priority_option_successor(old,E.tostring(d,encoding='unicode')))
 for key in m.KEYS:
  assert m.current_source_expectation(key,tag,None)==h.current_row(tag,key)['target'];reject(lambda:m.current_source_expectation(key,tag,'old'));shared+=1
  for field,value in [('source','BAD'),('attributes',{'name':key,'formatted':'false'}),('previous_target','BAD')]:
   original=m.ha_ig_ln_row
   def row(t,k):return dict(original(t,k),**{field:value}) if (t,k)==(tag,key) else original(t,k)
   with patch.object(m,'ha_ig_ln_row',side_effect=row):reject(lambda:m.current_source_expectation(key,tag,None));shared+=1
 for key in c.EXPECTED_KEYS[c.FAMILIES[2]]|{c.TAGGED_COLOUR_KEY}:
  for field,value in [('source','BAD'),('attributes',{'name':key,'formatted':'false'}),('previous_target','BAD')]:
   original=c.ha_ig_ln_row
   def row(t,k):return dict(original(t,k),**{field:value}) if (t,k)==(tag,key) else original(t,k)
   with patch.object(c,'ha_ig_ln_row',side_effect=row):reject(c.current_tagged_colour_data if key==c.TAGGED_COLOUR_KEY else lambda:c.wording_fixture(c.FAMILIES[2]));shared+=1
before=json.loads((s/'translations/language-options.json').read_text());after=json.loads((stage/'language-options.json').read_text())
assert isinstance(before,dict)
# Compare the entire metadata document after exactly three status changes.
expected=copy.deepcopy(before)
def change(x):
 if isinstance(x,dict):
  if x.get('tag') in h.TAGS:assert x['translation_status']=='not-started';x['translation_status']='partial-priority-reviewed'
  for v in x.values():change(v)
 elif isinstance(x,list):
  for v in x:change(v)
change(expected);assert after==expected
jvm=(stage/'AppLanguageTest.kt').read_text()
for tag in h.TAGS:
 block=jvm.split('else if (tag == "'+tag+'") {')[1].split('} else')[0]
 pairs=re.findall(r'assertEquals\("((?:\\.|[^"\\])*)",wrapped.getString\(R.string.(\w+)\)\)',block);assert len(pairs)==4
 for value,key in pairs:assert json.loads('"'+value+'"')==h.display(tag,key)
oldhost=json.loads((r/'independent-review/test-sensitivity-review.json').read_text())['current_host_sha256_before_owner_regeneration'];host=s/'tools/test_hausa_igbo_lingala_priority_wording.py';raw=host.read_text();reverted=raw.replace("self.assertIn(display(tag,command).removesuffix('…'),display(tag,key))",'self.assertIn(display(tag,command),display(tag,key))')
reverted=reverted.replace('                    # Menu ellipsis announces a following dialog; prose route labels may omit only this suffix.\n','')
start=reverted.index('    def test_tagged_colour_projection_rejects_unbound_source_or_attributes(self):');end=reverted.index('    def test_dimension_unit_and_crop_side_templates_use_actual_consumer_slots(self):',start);reverted=reverted[:start]+reverted[end:]
reverted=reverted.replace('test_exact_new_values_and_complete_command_references_are_bound_to_controls','test_preserved_alias_and_complete_command_references_are_bound_to_controls').replace('for command in commands:\n                    self.assertIn(display(tag,command),display(tag,key))','for command in commands:self.assertIn(display(tag,command),display(tag,key))');assert hashlib.sha256(reverted.encode()).hexdigest()==oldhost
out={'result':'PASS','independent_rejected_mutations':count,'shared_finite_guard_mutations':shared,'staged_files_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in stage.iterdir()if p.is_file()},'regenerated_host_sha256':hashlib.sha256(host.read_bytes()).hexdigest(),'scope':'Exact three empty-to-reviewed option successors; all scalar/plural children and metadata/identity/attribute mutations rejected; 51 finite memory/SVG/colour probes; metadata only three status fields; 12 JVM expected values equal exact accepted decoded values, SU/YO/ZU existing branches retained. Complete original-to-staged diff independently read, no runtime certification.'};(r/'independent-review/option-successor-independent-review.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
