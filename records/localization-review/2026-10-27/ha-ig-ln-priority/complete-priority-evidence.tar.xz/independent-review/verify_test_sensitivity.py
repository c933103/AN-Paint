from pathlib import Path
import sys,json,hashlib,copy,xml.etree.ElementTree as E,unittest,types
r=Path(__file__).resolve().parents[1];s=r/'source';sys.path.insert(0,str(s/'tools'))
import test_hausa_igbo_lingala_priority_wording as g
import hausa_igbo_lingala_priority_expectations as h
f=g.fixture(h.NAME);g.require_shape(f);count=0
for tag,loc in f['locales'].items():
 for identity in loc['priority_status']:
  x=copy.deepcopy(f);x['locales'][tag]['priority_status'][identity]='accept_unbounded'
  try:g.require_shape(x)
  except ValueError:count+=1
  else:raise AssertionError((tag,identity,'status'))
 for identity in loc['wording_only']:
  x=copy.deepcopy(f);x['locales'][tag]['wording_only'].remove(identity)
  try:g.require_shape(x)
  except ValueError:count+=1
  else:raise AssertionError((tag,identity,'context'))
 for change in ['extra','alias','predecessor']:
  x=copy.deepcopy(f);q=x['locales'][tag]
  if change=='extra':q['catalogue_identities'].append('string/unreviewed')
  elif change=='alias':q['accepted']['ui_save']='@string/ui_cancel'
  else:q['predecessors']['ui_save']={'type':'string','target':'fake','attributes':{'name':'ui_save'}}
  try:g.require_shape(x)
  except ValueError:count+=1
  else:raise AssertionError((tag,change))
 root=E.parse(g.catalogues.catalogue_paths()[tag]).getroot()
 for key,target in loc['accepted'].items():
  source=f['sources'][key];node=root.find(f"./{source['type']}[@name='{key}']")
  for childindex in range(len(node)) if source['type']=='plurals' else [None]:
   changed=copy.deepcopy(node);child=changed if childindex is None else changed[childindex];child.text=(child.text or '')+' corrupted';sample=E.Element('resources');sample.append(changed)
   try:g.require_complete(sample,key,source,target,loc['target_attribute_exceptions'].get(key,{'name':key}))
   except ValueError:count+=1
   else:raise AssertionError((tag,key,childindex,'target'))
bs=chr(92);assert h._display(bs+'n')=='\n' and h._display(bs+bs+'n')==bs+'n';assert h._display('"a'+bs+'"b"')=='a"b'
# Test the precisely staged suffix-only correction in isolated reviewer memory, not author source.
p=s/'tools/test_hausa_igbo_lingala_priority_wording.py';src=p.read_text();before='self.assertIn(display(tag,command),display(tag,key))';after="self.assertIn(display(tag,command).removesuffix('…'),display(tag,key))";assert src.count(before)==1;staged=src.replace(before,after);module=types.ModuleType('reviewer_staged_ha_ig_ln');module.__file__=str(p);exec(compile(staged,str(p),'exec'),module.__dict__);result=unittest.TextTestRunner(verbosity=1).run(unittest.defaultTestLoader.loadTestsFromModule(module));assert result.wasSuccessful()
jvm=s/'Paintroid/src/test/java/org/catrobat/paintroid/local/HausaIgboLingalaPriorityWordingTest.kt';out={'result':'pass','independent_negative_probes':count,'staged_suffix_only_host_tests':result.testsRun,'author_source_mutated':False,'jvm_sha256':hashlib.sha256(jvm.read_bytes()).hexdigest(),'jvm_scope':'15 prior reviewed actual-consumer methods inherited; complete exact delta read. HAone1/LNone0,1/IGother actualcount0/1/2/3, strict noalias guard. Hosted compile/runtime pending.','suffix_scope':'Only one terminal U+2026 omitted for prose-control inclusion, complete resource fixture comparison unchanged.','current_host_sha256_before_owner_regeneration':hashlib.sha256(src.encode()).hexdigest()};(r/'independent-review/test-sensitivity-review.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
