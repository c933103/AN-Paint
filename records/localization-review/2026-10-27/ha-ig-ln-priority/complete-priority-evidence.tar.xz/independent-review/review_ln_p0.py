from pathlib import Path
import json,hashlib,collections,xml.etree.ElementTree as E,sys
r=Path(__file__).resolve().parents[1];s=r/'source';p=r/'candidate-public/ln-complete-author-packet.json';d=json.loads(p.read_text());sys.path.insert(0,str(s/'tools'))
from test_slovak_slovenian_catalan_priority_wording import token_contract
from translation_catalogues import android_string_errors,format_string_errors
en={n.get('name'):n for n in E.parse(s/'Paintroid/src/main/res/values/strings.xml').getroot()};cur={n.get('name'):n for n in E.parse(s/d['catalogue_path']).getroot()};out=[];contexts=set()
issues={'formats22_animation_poster':'Distinguish separate default PNG image from first animated frame; full successor pending.', 'ui_a_separate_recovery_copy_has_been_kept_use':'Actual load/open action, not entering image; bind full paragraph to exact File/Export/Load controls.', 'ui_recovery_copy_exported_extract_canvas_png_from_the':'Same exact load/open control in full ZIP/floating-selection paragraph.', 'ui_d_d_pixels_2f_mp_exceeds_the_current':'Full4args: reserve workspace and allocate memory to oversized bitmap, not bitmap larger than memory; lexical second-check needed.', 'ui_sampled_resize_memory_explanation':'Estimate term Bokati ya mémoire may suggest cutting memory; full sampled decode/buffers/detail loss/unchanged original retained in successor.', 'ui_the_previous_draft_needs_more_memory_to_reopen':'Preserve MORE/additional memory, not merely much memory.', 'save20_gif_description':'Complete paragraph and exact dither checkbox require atomic companion review.'}
for x in d['rows']:
 if x['tier']!='P0':continue
 k=x['identity'].split('/')[1];assert x['current'] is None and k not in cur;assert x['english']['value']==en[k].text and x['english']['attributes']==en[k].attrib
 for c in x['direct_consumers']:
  ls=(s/c['path']).read_text().splitlines();assert ls[c['start_line']-1:c['end_line']]==c['context'].split('\n');contexts.add((c['path'],c['line']))
 row=dict(x);v=x.get('proposal')
 if v is None or k in ['ui_main23','ui_fg','ui_bg']:decision='hold_absent';accepted=None;reason='Preserve explicit dormant/context/layout-sensitive hold; no inferred completion.'
 elif k in issues:decision='pending_complete_successor';accepted=None;reason=issues[k]
 else:decision='accept_new_active' if x['direct_consumers'] else 'accept_new_wording_only';accepted=v;reason='Full source/target independently read and source-bound; full operations/qualifiers/errors/preservation/counts retained.'
 if v is not None:
  assert token_contract(v)==token_contract(en[k].text),(k,'tokens');assert v.count(r'\n')==en[k].text.count(r'\n'),(k,'newlines');assert not android_string_errors(v);assert not format_string_errors(v,en[k].get('formatted')!='false')
 row.update(decision=decision,reviewed_value=accepted,reviewed_attributes=en[k].attrib,reason=reason);out.append(row)
o={'scope':'Full92 Lingala P0 complete-value review;7 complete successors pending,249P1 and atomic dependencies remain separate' ,'input_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source_commit':d['source_commit'],'rows':out,'counts':dict(collections.Counter(v['decision'] for v in out)),'verified_caller_windows':len(contexts),'limits':'Independent model review; no native-human, installed/runtime or source-integration claim.'};(r/'independent-review/ln-p0-independent-review.json').write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n');print(o['counts'])
