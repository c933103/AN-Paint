from pathlib import Path
import json,hashlib,xml.etree.ElementTree as E,collections
P=Path(__file__).resolve().parents[1];S=P.parent/'as-km-lo-p0-p1-20261027/source';p=P/'candidate-public/ha-complete-author-packet.json';d=json.load(open(p));en={x.get('name'):x for x in E.parse(S/'Paintroid/src/main/res/values/strings.xml').getroot()};cur={x.get('name'):x for x in E.parse(S/d['catalogue_path']).getroot()};out=[]
rev={'gallery_credit_could_not_save':'Attribution metadata covers creator/source/license, not exclusively rights holders; broaden masu haƙƙin hoton.','gallery_credit_too_large':'Same complete credits-metadata issue.','legacy_credits_unreadable':'Same complete credits-metadata issue.','ui_d_d_pixels_2f_mp_exceeds_the_current':'Use selected regions, e.g. wuraren da aka zaɓa, not options zaɓuɓɓuka; retain complete4args/noallocation/noauto-resize paragraph.','ui_keeps_pixels_at_the_top_left_smaller_canvas':'Explicit pixel positions relative to upper-left; retain right OR bottom clipping+exact Undo.','ui_sampled_resize_memory_explanation':'Clarify reduced/sample decoding instead of reading with samples/examples; preserve complete canvas/clipboard/buffers/detail loss/original unchanged.'}
for row in d['rows']:
 if row['tier']!='P0':continue
 r=dict(row);k=r['identity'].split('/')[1];e=cur.get(k);assert all(r['english'][f]==v for f,v in {'value':en[k].text,'attributes':en[k].attrib}.items());assert r['current']is None and e is None
 for x in r['direct_consumers']:
  ls=(S/x['path']).read_text().splitlines();assert ls[x['start_line']-1:x['end_line']]==x['context'].split('\n')
 if r.get('proposal')is None:r.update(decision='hold_absent',reviewed_value=None,reason='Preserve submitted dormant-route hold.')
 elif k in rev:r.update(decision='revise_complete_value',reviewed_value=None,reason=rev[k])
 elif k=='save20_gif_description':r.update(decision='pending_atomic_dither_control',reviewed_value=None,reason='Whole description must bind exact checkbox dependency and encoder.')
 else:r.update(decision='accept_new_active'if r['direct_consumers']else'accept_new_wording_only',reviewed_value=r['proposal'],reason='Complete source/target read; operation,error,preservation,memory/storage qualifiers retained. Exact forthcoming control/route labels required before integration.')
 r['reviewed_attributes']=en[k].attrib;out.append(r)
r={'scope':'Full92HausaP0 reviewed;87proposals. Not remaining249P1 or wholetrio acceptance.','source_commit':d['source_commit'],'input_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'rows':out,'counts':dict(collections.Counter(x['decision']for x in out)),'limits':['Model linguistic review, not native-human certification.','No source edits;six complete-value revisions+atomicGIF dependency pending.','Control/menu labels to be checked with fullP1/dependencies.']};(P/'independent-review/ha-p0-independent-review.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(r['counts'])
