from pathlib import Path
import json,hashlib,collections,xml.etree.ElementTree as E,re,sys
r=Path(__file__).resolve().parents[1];s=r/'source';load=lambda p:json.loads(p.read_text());p=r/'candidate-public/ha-complete-author-packet.json';dep=r/'candidate-public/ha-adjacent-dependencies.json';data=load(p);deps=load(dep);prior=load(r/'independent-review/ha-p0-independent-review.json');old={v['identity']:v for v in prior['rows']};sys.path.insert(0,str(s/'tools'))
from test_slovak_slovenian_catalan_priority_wording import token_contract
from translation_catalogues import android_string_errors,format_string_errors
def idx(p):return {n.tag+'/'+n.get('name'):{'value':{c.get('quantity'):c.text for c in n} if n.tag=='plurals' else n.text,'attributes':n.attrib} for n in E.parse(p).getroot()}
en=idx(s/'Paintroid/src/main/res/values/strings.xml');cur=idx(s/data['catalogue_path']);out=[];companions=[];contexts=set()
revisions={'string/ui_scales_the_image_unlock_the_ratio_to_stretch':'Yana sauya girman hoton. Buɗe kullen rabon faɗi da tsawo don sauya kowannensu dabam.','string/ui_tolerance':'Iyakacin bambancin launi'}
holds={'string/ui_main23':'Ambiguous dormant Main role; first is not established main route.','string/ui_bg':'Compact colour status label requires layout-sensitive evidence; not covered by static wording acceptance.','string/ui_fg':'Compact colour status label requires layout-sensitive evidence; not covered by static wording acceptance.'}
for x in data['rows']+deps['rows']:
 identity=x['identity'];assert {k:x['english'][k] for k in ['value','attributes']}==en[identity];assert x['current']==cur.get(identity)
 for c in x['direct_consumers']:
  lines=(s/c['path']).read_text().splitlines();assert lines[c['start_line']-1:c['end_line']]==c['context'].split('\n');contexts.add((c['path'],c['line']))
 v=x.get('proposal');row=dict(x);reason='Complete submitted source/target independently read: operation/error/preservation/formatting qualifiers and actual caller scope retained.'
 if v is None or identity in holds:decision='hold_absent';accepted=None;reason=holds.get(identity,'Preserve explicit dormant-route/context hold; no target inserted.')
 elif identity in revisions and v!=revisions[identity]:decision='revise_complete_value';accepted=None;reason='Complete successor proposed and awaiting author second-check.';row['proposed_successor']=revisions[identity]
 else:
  decision='accept_new_active' if x['direct_consumers'] else 'accept_new_wording_only';accepted=v
  if x['tier']=='P0' and identity!='string/save20_gif_description':assert old[identity]['reviewed_value']==v,(identity,'unreviewed P0 drift')
  pairs=[(en[identity]['value'],v)] if isinstance(v,str) else [(en[identity]['value'][q],value) for q,value in v.items()]
  for eng,target in pairs:
   assert token_contract(eng)==token_contract(target),(identity,'tokens');assert eng.count(r'\n')==target.count(r'\n'),(identity,'newlines')
   assert not android_string_errors(target),(identity,'Android escape')
   assert not format_string_errors(target,en[identity]['attributes'].get('formatted')!='false'),(identity,'format')
 row.update(decision=decision,reviewed_value=accepted,reviewed_attributes=en[identity]['attributes'],reason=reason)
 (out if x['tier'] in ['P0','P1'] else companions).append(row)
assert len(out)==341 and len(companions)==15
summary={'scope':'Full341 Hausa priority plus15 atomic companions. Prior92P0 acceptance carried exactly except complete GIF/control pair now accepted.','source_commit':data['source_commit'],'packet_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'dependencies_sha256':hashlib.sha256(dep.read_bytes()).hexdigest(),'rows':out,'dependencies':companions,'counts':dict(collections.Counter(x['decision'] for x in out)),'dependency_counts':dict(collections.Counter(x['decision'] for x in companions)),'verified_caller_windows':len(contexts),'limits':['Independent model complete-value review, not native-human/installed/runtime certification.','No source mutation; held rows remain absent.','No IG/LN review credit.']};(r/'independent-review/ha-complete-independent-review.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(summary['counts'],summary['dependency_counts'],len(contexts))
