from pathlib import Path
import json,hashlib,xml.etree.ElementTree as E
r=Path(__file__).resolve().parents[1];s=r/'source';load=lambda p:json.loads(p.read_text());fpath=s/'tools/fixtures/current_localization/hausa_igbo_lingala_priority_wording.json';f=load(fpath);tree=load(r/'integration-base-tree.json');base={x['path']:x for x in tree['tree']if x['type']=='blob'};assert tree['sha']=='30e324237a54b14ba6de408d4ec8fc6c132e4252'
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def cat(path):
 out={}
 for e in E.parse(path).getroot():
  identity=e.tag+'/'+e.get('name');assert identity not in out
  if e.tag=='plurals':
   assert all(c.tag=='item' and c.attrib=={'quantity':c.get('quantity')} and len(c)==0 for c in e);v={c.get('quantity'):c.text for c in e};assert len(v)==len(e)
  else:assert len(e)==0;v=e.text
  out[identity]={'value':v,'attributes':e.attrib}
 return out
en=cat(s/'Paintroid/src/main/res/values/strings.xml');counts={};contexts=set()
for tag in ['ha','ig','ln']:
 reviewp=r/f'independent-review/{tag}-complete-independent-review.json';review=load(reviewp);ledger=load(r/f'independent-review/{tag}-integration-ledger.json');assert ledger['rows']==review['rows'] and ledger['dependencies']==review['dependencies'];assert ledger['provenance']['independent_receipt_sha256']==hashlib.sha256(reviewp.read_bytes()).hexdigest();rel=ledger['catalogue_path'];original=r/f'original-catalogues/{tag}.xml';assert blob(original.read_bytes())==base[rel]['sha'];before=cat(original);after=cat(s/rel);accepted={x['identity']:x for x in review['rows']+review['dependencies']if x['decision'].startswith('accept')};changes={k for k in before.keys()|after.keys()if before.get(k)!=after.get(k)};assert changes==set(accepted)
 fl=f['locales'][tag];assert set(fl['changed'])=={k.split('/')[1]for k in changes};assert fl['priority_status']=={x['identity']:x['decision']for x in review['rows']};assert fl['predecessors']=={} and fl['unchanged_accepted']==[]
 assert set(fl['wording_only'])=={x['identity']for x in review['rows']if x['decision']=='accept_new_wording_only'}
 for x in review['rows']+review['dependencies']:
  identity=x['identity'];kind,key=identity.split('/');assert before.get(identity)==x['current'];assert {k:x['english'][k]for k in ['value','attributes']}==en[identity]
  src=f['sources'][key];assert src=={'type':kind,'source':en[identity]['value'],'attributes':en[identity]['attributes']}
  for c in x['direct_consumers']:
   cp=s/c['path'];assert blob(cp.read_bytes())==base[c['path']]['sha'];ls=cp.read_text().splitlines();assert ls[c['start_line']-1:c['end_line']]==c['context'].split('\n');contexts.add((c['path'],c['line']))
  if identity in accepted:
   assert after[identity]=={'value':x['reviewed_value'],'attributes':x['reviewed_attributes']};assert fl['accepted'][key]==x['reviewed_value'];assert ledger['integration_values'][key]=={'previous_target':x['current'],'reviewed_value':x['reviewed_value'],'reviewed_attributes':x['reviewed_attributes']}
  else:assert x['decision']=='hold_absent' and identity not in after and key in fl['held_absent']
 assert set(fl['held_absent'])=={x['identity'].split('/')[1]for x in review['rows']if x['decision']=='hold_absent'}
 assert set(fl['catalogue_identities'])==set(after)
 for k in before.keys()-changes:assert after[k]==before[k]
 counts[tag]={'exact_typed_additions':len(changes),'priority_accepted':331,'atomic_companions':15,'holds':10,'unchanged_other_xml':len(before.keys()-changes)}
# Full inherited fixture tree, not just current_localization subset.
fixturepaths=[p for p in base if p.startswith('tools/fixtures/')];assert all(blob((s/p).read_bytes())==base[p]['sha']for p in fixturepaths)
out={'result':'pass','base_tree':tree['sha'],'counts':counts,'total_typed_additions':1038,'unique_verified_caller_windows':len(contexts),'all_inherited_fixture_blobs_unchanged':len(fixturepaths),'current_localization_subset':sum(p.startswith('tools/fixtures/current_localization/')for p in fixturepaths),'fixture_sha256':hashlib.sha256(fpath.read_bytes()).hexdigest(),'limits':'Exact source/fixture/author-derived-ledger equality to independent full receipts. No new linguistic credit or runtime/compiled claim.'};(r/'independent-review/integrated-priority-review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
