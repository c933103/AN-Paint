"""Complete source/target/typed scope guards plus actual composition contracts."""
from collections import Counter
from copy import deepcopy
import json
import unittest
import xml.etree.ElementTree as ET
from current_localization_contracts import fixture
from test_danish_norwegian_p0_wording import FULL_FORMAT_TOKEN
import translation_catalogues as catalogues
from hausa_igbo_lingala_priority_expectations import NAME,TAGS,current_row,display

HOLDS=frozenset({'formats22_derived_exported','ui_save_as','ui_save_as_jpeg','ui_save_as_jpeg_xl','ui_save_as_png','ui_foreground_background_colour_palette','ui_pinch_and_pan_mode','ui_main23','ui_fg','ui_bg'})
DEPENDENCIES=frozenset({'formats22_at_least_frames','ui_top','ui_width_in','ui_lossless_format','save20_dither','ui_quality','ui_trim_in_pixels','ui_trim_in_percent','ui_rounded_rectangle','ui_star','ui_curve','ui_arrow','ui_heart','ui_image_shown_in_crop_preview','ui_crop_preview_images'})
# Insert exact independently accepted partitions and finite previous values here.
# GENERATED_ACCEPTED_PARTITIONS


def priority_ids():
    manifest=json.loads((catalogues.DATA/'string-importance.json').read_text())
    return {key for tier in manifest['tiers'] if tier['id'] in ('P0','P1') for key in tier['keys']}


def require_shape(data):
    names={identity.split('/',1)[1] for identity in priority_ids()}
    if data.get('schema_version')!=1 or set(data.get('locales',{}))!=TAGS:raise ValueError('Exact schema/locale set differs')
    if set(data.get('sources',{}))!=names|DEPENDENCIES:raise ValueError('Complete shared English source set differs')
    expected=names-HOLDS|DEPENDENCIES
    for tag,locale in data['locales'].items():
        if locale.get('priority_status')!=PRIORITY_STATUS[tag]:raise ValueError('Exact341 dispositions differ')
        if set(locale.get('wording_only',[]))!=WORDING_ONLY[tag]:raise ValueError('Exact source-only context limits differ')
        if set(locale.get('held_absent',[]))!=HOLDS:raise ValueError('Exact absent hold set differs')
        if set(locale.get('accepted',{}))!=expected:raise ValueError('Complete accepted typed target set differs')
        if set(locale.get('unchanged_accepted',[]))!=UNCHANGED[tag] or set(locale.get('changed',[]))!=expected-UNCHANGED[tag]:raise ValueError('Edited/retained partition differs')
        if locale.get('predecessors')!=PREDECESSORS[tag]:raise ValueError('Exact previous value/type/attribute binding differs')
        if locale.get('outside_review')!=OUTSIDE_REVIEW[tag]:raise ValueError('Unrelated prior values differ')
        if locale.get('target_attribute_exceptions')!=ATTRIBUTE_EXCEPTIONS[tag]:raise ValueError('Exact target attribute exceptions differ')
        if len(locale['changed'])!=EDIT_COUNTS[tag]:raise ValueError('Exact edited count differs')
        typed={('plurals' if k=='ui_crop_preview_images' else 'string')+'/'+k for k in expected}
        typed|={row['type']+'/'+k for k,row in OUTSIDE_REVIEW[tag].items()}
        if set(locale.get('catalogue_identities',[]))!=typed or len(locale['catalogue_identities'])!=len(typed):raise ValueError('Exact catalogue typed union differs')
        for key,value in locale['accepted'].items():
            typ=data['sources'][key]['type']
            if typ=='string' and (not isinstance(value,str) or not value):raise ValueError('Missing complete string')
            if typ=='plurals' and (not isinstance(value,dict) or set(value)!=({'one','other'} if tag in ('ha','ln') else {'other'}) or not all(value.values())):raise ValueError('Complete plural quantity set differs')
    for locale in data['locales'].values():
        if any(isinstance(v,str) and v.startswith('@string/') for v in locale['accepted'].values()):raise ValueError('No aliases in exact new additions')
    return data


def require_complete(root,key,source,target,attributes):
    nodes=root.findall(f"./{source['type']}[@name='{key}']")
    if len(nodes)!=1 or nodes[0].attrib!=attributes:raise ValueError('Typed resource identity/attributes differ')
    node=nodes[0]
    if source['type']=='string':
        if list(node) or node.text!=target:raise ValueError('Complete string differs')
        pairs=[(target,source['source'])]
    else:
        if any(n.tag!='item' or set(n.attrib)!={'quantity'} or list(n) for n in node):raise ValueError('Malformed plural children')
        values={n.get('quantity'):n.text for n in node}
        if len(values)!=len(node) or values!=target:raise ValueError('Complete plural differs')
        pairs=[(v,source['source'][q])for q,v in values.items()]
    for value,english in pairs:
        if Counter(FULL_FORMAT_TOKEN.findall(value))!=Counter(FULL_FORMAT_TOKEN.findall(english)) or value.count(r'\n')!=english.count(r'\n'):raise ValueError('Full format/newline contract differs')
        if FULL_FORMAT_TOKEN.sub('',value).count('%')!=FULL_FORMAT_TOKEN.sub('',english).count('%'):raise ValueError('Literal percent contract differs')


class HausaIgboLingalaPriorityWordingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data=require_shape(fixture(NAME));cls.roots={tag:ET.parse(catalogues.catalogue_paths()[tag]).getroot()for tag in TAGS}
        cls.english=ET.parse(catalogues.RES/'values/strings.xml').getroot()

    def test_complete_341_identity_set_and_all_fifteen_atomic_dependencies(self):
        self.assertEqual(341,len(priority_ids()))
        for tag,locale in self.data['locales'].items():
            actual={e.tag+'/'+e.get('name')for e in self.roots[tag]}
            self.assertEqual(set(locale['catalogue_identities']),actual);self.assertEqual(len(actual),len(self.roots[tag]))
            self.assertEqual({'string/'+key for key in HOLDS},priority_ids()-actual)
            for key,target in locale['accepted'].items():
                with self.subTest(tag=tag,key=key):require_complete(self.roots[tag],key,self.data['sources'][key],target,locale['target_attribute_exceptions'].get(key,{'name':key}))

    def test_every_complete_english_value_and_attributes_remain_source_bound(self):
        for key,row in self.data['sources'].items():
            require_complete(self.english,key,row,row['source'],row['attributes'])

    def test_exact_changed_partition_and_predecessors_reject_laundering(self):
        for tag,locale in self.data['locales'].items():
            for mode in ('remove','extra','wrong-locale','move-edit','move-retained','missing-predecessor','forged-predecessor','wrong-attrs','hold-credit','context-credit','wording-limit','extra-catalogue'):
                bad=deepcopy(self.data);b=bad['locales'][tag]
                if mode=='remove':b['accepted'].pop(next(iter(b['accepted'])))
                elif mode=='extra':b['accepted']['invented']='unexpected'
                elif mode=='wrong-locale':bad['locales']['en']=bad['locales'].pop(tag)
                elif mode=='move-edit':k=b['changed'].pop();b['unchanged_accepted'].append(k)
                elif mode=='move-retained':
                    if not b['unchanged_accepted']:continue # HA/IG/LN has no inherited accepted values.
                    k=b['unchanged_accepted'].pop();b['changed'].append(k)
                elif mode=='missing-predecessor':
                    if not b['predecessors']:continue # No predecessor exists for new HA/IG/LN values.
                    b['predecessors'].pop(next(iter(b['predecessors'])))
                elif mode=='forged-predecessor':
                    if b['predecessors']:b['predecessors'][next(iter(b['predecessors']))]['target']='forged'
                    else:b['predecessors']['ui_save']={'type':'string','target':'forged','attributes':{'name':'ui_save'}}
                elif mode=='wrong-attrs':b['target_attribute_exceptions']['ui_quality']={'name':'ui_quality'}
                elif mode=='hold-credit':b['priority_status']['string/ui_save_as']='accept_new_active'
                elif mode=='context-credit':b['priority_status'][next(iter(WORDING_ONLY[tag]))]='accept_new_active'
                elif mode=='wording-limit':b['wording_only'].pop()
                else:b['catalogue_identities'].append('string/unreviewed_extra')
                with self.subTest(tag=tag,mode=mode),self.assertRaises(ValueError):require_shape(bad)

    def test_each_complete_target_rejects_truncation_wrong_locale_and_format_drift(self):
        for tag,locale in self.data['locales'].items():
            for key,target in locale['accepted'].items():
                source=self.data['sources'][key];attrs=locale['target_attribute_exceptions'].get(key,{'name':key})
                for mode in ('truncate','wrong-locale','attribute'):
                    root=deepcopy(self.roots[tag]);n=root.find(f"./{source['type']}[@name='{key}']")
                    if mode=='attribute':n.set('translatable','false')
                    elif mode=='truncate':
                        if source['type']=='string':n.text=n.text[:-1]
                        else:n[0].text=n[0].text[:-1]
                    else:
                        other=next((self.data['locales'][t]['accepted'][key]for t in TAGS if t!=tag and self.data['locales'][t]['accepted'][key]!=target),None)
                        if other is None:continue
                        if source['type']=='string':n.text=other
                        else:
                            for child in n:child.text=other.get(child.get('quantity'),other['other'])
                    with self.subTest(tag=tag,key=key,mode=mode),self.assertRaises(ValueError):require_complete(root,key,source,target,attrs)

    def test_plural_missing_extra_duplicate_and_every_complete_child_corruption_reject(self):
        key='ui_crop_preview_images';source=self.data['sources'][key]
        for tag,locale in self.data['locales'].items():
            for quantity in locale['accepted'][key]:
                for mode in ('remove','extra','duplicate','wrong-type','truncate','newline','attribute','markup'):
                    root=deepcopy(self.roots[tag]);n=root.find("./plurals[@name='ui_crop_preview_images']");child=n.find(f"./item[@quantity='{quantity}']")
                    if mode=='remove':n.remove(child)
                    elif mode=='extra':ET.SubElement(n,'item',quantity='many').text=child.text
                    elif mode=='duplicate':n.append(deepcopy(child))
                    elif mode=='wrong-type':child.text=child.text.replace('%3$d','%3$s')
                    elif mode=='truncate':child.text=child.text[:-1]
                    elif mode=='newline':child.text=child.text.replace(r'\n',' ')
                    elif mode=='attribute':child.set('formatted','false')
                    else:ET.SubElement(child,'b').text='markup'
                    with self.subTest(tag=tag,quantity=quantity,mode=mode),self.assertRaises(ValueError):require_complete(root,key,source,locale['accepted'][key],{'name':key})

    def test_unrelated_existing_values_and_all_exact_absent_holds_preserved(self):
        for tag,locale in self.data['locales'].items():
            root=self.roots[tag]
            for key,row in locale['outside_review'].items():
                source={'type':row['type'],'source':row['target']}
                require_complete(root,key,source,row['target'],row['attributes'])
            for key in HOLDS:self.assertEqual([],root.findall(f"./string[@name='{key}']"))

    def test_exact_new_values_and_complete_command_references_are_bound_to_controls(self):
        for tag in TAGS:self.assertNotEqual(display(tag,'ui_save'),display(tag,'ui_save_a5d0d9'))
        for tag in TAGS:
            for key,commands in {
                'ui_autosave_is_paused_to_protect_that_draft_use':['ui_menu_file','ui_export_recovery_copy','save20_title','save20_file_format'],
                'ui_recovery_copy_exported_extract_canvas_png_from_the':['ui_menu_file','ui_load_image'],
                'ui_paste_hint34':['ui_draw26','ui_category_insert','ui_other_images34']}.items():
                for command in commands:
                    # Menu ellipsis announces a following dialog; prose route labels may omit only this suffix.
                    self.assertIn(display(tag,command).removesuffix('…'),display(tag,key))

    def test_tagged_colour_projection_rejects_unbound_source_or_attributes(self):
        from unittest.mock import patch
        import test_current_localization_contracts as contracts
        original=contracts.ha_ig_ln_row
        for tag in TAGS:
            for field in ('source','attributes'):
                def altered(actual_tag,key):
                    row=deepcopy(original(actual_tag,key))
                    if actual_tag==tag:row[field]='unbound source' if field=='source' else {'name':key,'formatted':'false'}
                    return row
                with self.subTest(tag=tag,field=field),patch.object(contracts,'ha_ig_ln_row',side_effect=altered),self.assertRaises(ValueError):
                    contracts.current_tagged_colour_data()

    def test_dimension_unit_and_crop_side_templates_use_actual_consumer_slots(self):
        source=(catalogues.ROOT/'Paintroid/src/main/java/org/catrobat/paintroid/classic/DimensionControls.kt').read_text()
        crop=(catalogues.ROOT/'Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt').read_text()
        self.assertIn('R.string.ui_width_in',source);self.assertIn('R.string.ui_height_in',source)
        self.assertIn('R.string.ui_trim_in_percent',crop);self.assertIn('R.string.ui_trim_in_pixels',crop)
        self.assertIn('R.plurals.ui_crop_preview_images',crop)
        for tag in TAGS:
            self.assertEqual('%1$s',FULL_FORMAT_TOKEN.search(display(tag,'ui_width_in')).group())
            self.assertIn('canvas.png',display(tag,'ui_recovery_copy_exported_extract_canvas_png_from_the'))

    def test_complete_quality_and_animation_dependency_contracts(self):
        for tag in TAGS:
            self.assertIn('(%)',display(tag,'ui_quality'))
            self.assertEqual({'name':'ui_quality','formatted':'false'},current_row(tag,'ui_quality')['attributes'])
            self.assertEqual(['%1$d'],FULL_FORMAT_TOKEN.findall(display(tag,'formats22_at_least_frames')))
            self.assertEqual(['%1$s','%2$s'],FULL_FORMAT_TOKEN.findall(display(tag,'formats22_animation_message')))
            self.assertEqual(['%1$s'],FULL_FORMAT_TOKEN.findall(display(tag,'ui_lossless_format')))

if __name__=='__main__':unittest.main()
