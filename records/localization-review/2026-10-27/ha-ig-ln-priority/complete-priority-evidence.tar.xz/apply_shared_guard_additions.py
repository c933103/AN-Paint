from pathlib import Path
B=Path(__file__).resolve().parent;S=B/'source';T=S/'tools'
p=T/'memory_warning_source_review.py';s=p.read_text();assert 'HA_IG_LN_ADDITIONS' not in s
s=s.replace('from pathlib import Path','from pathlib import Path\nfrom hausa_igbo_lingala_priority_expectations import MEMORY_ADDITIONS as HA_IG_LN_ADDITIONS, current_row as ha_ig_ln_row')
anchor='    if (tag,key) in NE_PA_ADDITIONS:'
block='''    if (tag,key) in HA_IG_LN_ADDITIONS:
        queue=review_record()
        old=next(o for o in queue['options'] if o['tag']==tag)['terms'][key]['value']
        row=ha_ig_ln_row(tag,key)
        if historical_value is not None or old is not None or row['previous_target'] is not None or not row['changed']:
            raise ValueError('Historical Hausa/Igbo/Lingala warning addition must be absent: '+tag+'/'+key)
        if row['source']!=queue['keys'][key]['corrected_english'] or row['attributes']!={'name':key}:
            raise ValueError('Hausa/Igbo/Lingala warning source or attributes differ: '+tag+'/'+key)
        return row['target']
'''
assert anchor in s;s=s.replace(anchor,block+anchor,1);p.write_text(s)
for fn in ['test_memory_warning_source_review.py','test_memory_warning_successors.py']:
 p=T/fn;s=p.read_text();s=s.replace('import JV_SU_KY_ADDITIONS,','import HA_IG_LN_ADDITIONS, JV_SU_KY_ADDITIONS,')
 s=s.replace(' | NE_PA_ADDITIONS',' | NE_PA_ADDITIONS | HA_IG_LN_ADDITIONS')
 if fn=='test_memory_warning_successors.py':
  s=s.replace('-len(NE_PA_ADDITIONS)','-len(NE_PA_ADDITIONS)-len(HA_IG_LN_ADDITIONS)').replace('+len(NE_PA_ADDITIONS)','+len(NE_PA_ADDITIONS)+len(HA_IG_LN_ADDITIONS)')
 p.write_text(s)
p=T/'test_current_localization_contracts.py';s=p.read_text();assert 'HA_IG_LN_TAGS' not in s
s=s.replace('from language_option_additions import ADDED_TAGS','from language_option_additions import ADDED_TAGS\nfrom hausa_igbo_lingala_priority_expectations import TAGS as HA_IG_LN_TAGS, current_row as ha_ig_ln_row, display as ha_ig_ln_display')
s=s.replace(' | NE_PA_TAGS',' | NE_PA_TAGS | HA_IG_LN_TAGS')
anchor='    return require_wording_shape(data, EXPECTED_KEYS[name], wording_tags(name))'
block='''        for tag in sorted(HA_IG_LN_TAGS):
            for key in EXPECTED_KEYS[name]:
                row=ha_ig_ln_row(tag,key)
                if (tag in data['values'][key] or row['previous_target'] is not None or not row['changed']
                        or row['source']!=data['values'][key]['default'] or row['attributes']!={'name':key}):
                    raise ValueError('Hausa/Igbo/Lingala SVG addition binding differs: '+tag+'/'+key)
                data['values'][key][tag]=row['target']
            data['additional_reviewed_tags'].append(tag)
            data['additional_locale_review_status'][tag]='independent_model_static_priority_review; no native-human or runtime/layout certification'
'''
assert anchor in s;s=s.replace(anchor,block+anchor,1)
anchor='        data[tag]=jv_su_ky_display(tag,TAGGED_COLOUR_KEY)\n    return data'
replace='''        data[tag]=jv_su_ky_display(tag,TAGGED_COLOUR_KEY)
    for tag in sorted(HA_IG_LN_TAGS):
        row=ha_ig_ln_row(tag,TAGGED_COLOUR_KEY)
        if tag in data or row['previous_target'] is not None or not row['changed']:
            raise ValueError('Hausa/Igbo/Lingala tagged colour predecessor differs: '+tag)
        data[tag]=ha_ig_ln_display(tag,TAGGED_COLOUR_KEY)
    return data'''
assert anchor in s;s=s.replace(anchor,replace,1)
anchor="            raise ValueError('Tagged-colour differs from complete Javanese/Sundanese/Kyrgyz value: '+tag)\n    return data"
replace="""            raise ValueError('Tagged-colour differs from complete Javanese/Sundanese/Kyrgyz value: '+tag)
    for tag in HA_IG_LN_TAGS:
        if data[tag]!=ha_ig_ln_display(tag,TAGGED_COLOUR_KEY):
            raise ValueError('Tagged-colour differs from complete Hausa/Igbo/Lingala value: '+tag)
    return data"""
assert anchor in s;s=s.replace(anchor,replace,1)
s=s.replace('+len(NE_PA_TAGS)','+len(NE_PA_TAGS)+len(HA_IG_LN_TAGS)').replace('-len(NE_PA_TAGS)','-len(NE_PA_TAGS)-len(HA_IG_LN_TAGS)');p.write_text(s)
p=S/'Paintroid/src/test/java/org/catrobat/paintroid/local/TaggedColourImportTest.kt';s=p.read_text();anchor='        assertEquals(90, expected.length())'
block='''        assertEquals(90, expected.length())
        val haIgLnPriority=JSONObject(File("../tools/fixtures/current_localization/hausa_igbo_lingala_priority_wording.json").readText()).getJSONObject("locales")
        for(tag in listOf("ha","ig","ln")) {
            assertFalse(expected.has(tag))
            expected.put(tag,haIgLnPriority.getJSONObject(tag).getJSONObject("accepted").getString("save20_unsupported_image_colour"))
        }
        assertEquals(93, expected.length())'''
assert anchor in s;s=s.replace(anchor,block,1);old='assertEquals(80, fallbacks) // 171 offered - 90 exact current values - 1 inherited.';assert old in s;s=s.replace(old,'assertEquals(77, fallbacks) // 171 offered - 93 exact current values - 1 inherited.');p.write_text(s)
print('Applied exact finite JV/SU/KY additions; all inherited families and frozen oracles preserved.')
