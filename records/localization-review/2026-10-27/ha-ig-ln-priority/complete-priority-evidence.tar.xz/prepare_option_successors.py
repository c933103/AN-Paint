from pathlib import Path
import json
B=Path(__file__).resolve().parent;S=B/'source';O=B/'option-successor';O.mkdir(exist_ok=True)
p=S/'tools/hausa_igbo_lingala_priority_expectations.py';s=p.read_text();s+='''
# Finite current successors; the original zero-coverage language-option fixture remains immutable.
PRIORITY_OPTION_STATUS='partial-priority-reviewed'

def require_priority_option_successor(historical_row,xml):
    import xml.etree.ElementTree as ET
    from language_option_additions import require_untranslated_option
    tag=historical_row.get('tag')
    names={'ha':'Hausa','ig':'Igbo','ln':'Lingála'}
    if tag not in TAGS or historical_row.get('name')!=names[tag] or historical_row.get('catalogue')!=f'Paintroid/src/main/res/values-b+{tag}/strings.xml':
        raise ValueError('Outside exact Hausa/Igbo/Lingala option successors')
    require_untranslated_option(historical_row,'<resources/>')
    locale=fixture(NAME)['locales'][tag];accepted=locale['accepted'];root=ET.fromstring(xml)
    if root.tag!='resources' or root.attrib or (root.text or '').strip():raise ValueError('Malformed current catalogue')
    if len(root)!=346 or {n.tag+'/'+n.get('name','')for n in root}!=set(locale['catalogue_identities']):raise ValueError('Exact accepted typed identity set differs')
    if len(accepted)!=346 or locale['outside_review']:raise ValueError('Exact empty predecessor successor scope differs')
    for node in root:
        key=node.get('name');expected=accepted[key]
        if node.attrib!=locale['target_attribute_exceptions'].get(key,{'name':key}):raise ValueError('Exact target attributes differ')
        if node.tag=='string':
            if list(node) or node.text!=expected:raise ValueError('Exact accepted string differs')
        elif node.tag=='plurals':
            if len(node)!=len(expected) or any(n.tag!='item' or set(n.attrib)!={'quantity'} or list(n)for n in node) or {n.get('quantity'):n.text for n in node}!=expected:raise ValueError('Exact complete plural differs')
        else:raise ValueError('Unexpected resource type')
    return root
''';(O/p.name).write_text(s)
p=S/'tools/test_language_option_additions.py';s=p.read_text().replace('from language_option_additions import FIRST_ADDED_TAGS','from hausa_igbo_lingala_priority_expectations import TAGS as PRIORITY_OPTION_TAGS, PRIORITY_OPTION_STATUS, require_priority_option_successor\nfrom language_option_additions import FIRST_ADDED_TAGS')
s=s.replace("SUNDANESE_OPTION_STATUS if tag=='su' else 'not-started'","PRIORITY_OPTION_STATUS if tag in PRIORITY_OPTION_TAGS else SUNDANESE_OPTION_STATUS if tag=='su' else 'not-started'")
anchor="            if row['tag']=='su':";block='''            if row['tag'] in PRIORITY_OPTION_TAGS:
                tag=row['tag'];root=require_priority_option_successor(row,path.read_text())
                self.assertEqual([],catalogues.validate_catalogue(tag))
                missing_strings=source_strings-{n.get('name')for n in root if n.tag=='string'}
                missing_plurals=source_plurals-{n.get('name')for n in root if n.tag=='plurals'}
                self.assertTrue(missing_strings);self.assertFalse(missing_plurals)
                self.assertEqual([f"{tag}: missing {len(missing_strings)} strings: {', '.join(sorted(missing_strings)[:20])}"],catalogues.validate_catalogue(tag,require_complete=True))
                continue
''';assert anchor in s;s=s.replace(anchor,block+anchor,1)
s=s.replace("row = json.loads(ADDITIONS_PATH.read_text())['languages'][0]","row = next(r for r in json.loads(ADDITIONS_PATH.read_text())['languages'] if r['tag']=='yo')")
new='''    def test_only_exact_full_priority_values_supersede_three_original_empty_options(self):
        from copy import deepcopy
        rows=json.loads(ADDITIONS_PATH.read_text())['languages']
        for tag in sorted(PRIORITY_OPTION_TAGS):
            old=next(r for r in rows if r['tag']==tag);xml=(ROOT/old['catalogue']).read_text()
            require_priority_option_successor(old,xml)
            with self.assertRaises(ValueError):require_untranslated_option(old,xml)
            for row in rows:
                if row['tag']!=tag:
                    with self.subTest(tag=tag,foreign=row['tag']),self.assertRaises(ValueError):require_priority_option_successor(row,xml)
            for field,value in [('translation_status','complete'),('linguistic_review','accepted'),('fallback','translated'),('source_strings_present',346)]:
                bad=deepcopy(old);bad[field]=value
                with self.subTest(tag=tag,field=field),self.assertRaises(ValueError):require_priority_option_successor(bad,xml)
            original=ET.fromstring(xml)
            for index,node in enumerate(original):
                bad=deepcopy(original)
                if node.tag=='string':bad[index].text=(node.text or '')+' altered'
                else:bad[index][0].text=(node[0].text or '')+' altered'
                with self.subTest(tag=tag,key=node.get('name')),self.assertRaises(ValueError):require_priority_option_successor(old,ET.tostring(bad,encoding='unicode'))
            for mode in ('missing','extra','attribute'):
                bad=deepcopy(original)
                if mode=='missing':bad.remove(bad[0])
                elif mode=='extra':ET.SubElement(bad,'string',name='unreviewed').text='unreviewed'
                else:bad[0].set('formatted','false')
                with self.subTest(tag=tag,mode=mode),self.assertRaises(ValueError):require_priority_option_successor(old,ET.tostring(bad,encoding='unicode'))

'''
s=s.replace("if __name__ == '__main__':",new+"if __name__ == '__main__':");(O/p.name).write_text(s)
p=S/'translations/language-options.json';d=json.loads(p.read_text())
for row in d['options']:
 if row['tag'] in ('ha','ig','ln'):assert row['translation_status']=='not-started';row['translation_status']='partial-priority-reviewed'
(O/p.name).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
p=S/'Paintroid/src/test/java/org/catrobat/paintroid/local/AppLanguageTest.kt';s=p.read_text();start=s.index('fun sixNewOptionsKeepTheirIdentity');end=s.index('fun furtherOptionsIncluding',start);part=s[start:end];anchor='''            } else {
                assertEquals("File",wrapped.getString(R.string.ui_menu_file))''';assert anchor in part
new=''
for tag in ('ha','ig','ln'):
 d=json.loads((B/f'independent-review/{tag}-integration-ledger.json').read_text())['accepted_resource_text_values'];new+='            } else if (tag == "'+tag+'") {\n'
 for key in ['ui_menu_file','ui_brush','ui_save','language20_translation_note']:
  v=d[key].replace('\\n','\n');new+='                assertEquals('+json.dumps(v,ensure_ascii=False).replace('$','\\$')+',wrapped.getString(R.string.'+key+'))\n'
new+=anchor;part=part.replace(anchor,new,1);part=part.replace('the other five options keep English fallback','the other options retain their exact reviewed or English fallback contracts');s=s[:start]+part+s[end:];(O/p.name).write_text(s)
print('Staged exact 3-locale current option successors, immutable historical six-language fixture and SU preserved; YO/ZU English unchanged.')
