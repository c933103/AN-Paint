from pathlib import Path
import shutil,subprocess,sys
B=Path(__file__).resolve().parent;S=B/'source';E=B/'local-evidence'
for mode in ('ordinary','optimized'):
 assert (E/f'full-{mode}.exit').exists(),'Original cohort still running'
 shutil.copy2(E/f'full-{mode}.log',E/f'initial-full-{mode}.log');shutil.copy2(E/f'full-{mode}.exit',E/f'initial-full-{mode}.exit')
p=S/'tools/test_hausa_igbo_lingala_priority_wording.py';shutil.copy2(p,E/'initial-priority-host-test.py')
subprocess.run([sys.executable,str(B/'prepare_host_tests.py')],check=True)
p=S/'tools/test_current_localization_contracts.py';s=p.read_text();old="""        if tag in data or row['previous_target'] is not None or not row['changed']:
            raise ValueError('Hausa/Igbo/Lingala tagged colour predecessor differs: '+tag)""";new="""        if (tag in data or row['previous_target'] is not None or not row['changed']
                or row['source'] != ET.parse(catalogues.RES / 'values/strings.xml').find("./string[@name='"+TAGGED_COLOUR_KEY+"']").text or row['attributes'] != {'name':TAGGED_COLOUR_KEY}):
            raise ValueError('Hausa/Igbo/Lingala tagged colour predecessor/source/attributes differ: '+tag)""";assert old in s;s=s.replace(old,new,1);p.write_text(s)
print('Applied precise ellipsis-only prose successor and strict tagged-colour source/attributes binding; complete resources unchanged.')
