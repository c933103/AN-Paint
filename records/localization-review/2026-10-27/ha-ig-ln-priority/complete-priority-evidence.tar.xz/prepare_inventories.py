from pathlib import Path
import collections,hashlib,json,re,sys,xml.etree.ElementTree as E
B=Path(__file__).resolve().parent;S=B/'source';OUT=B/'candidate-public';OUT.mkdir(exist_ok=True)
PIN='acca529544f1646e5cbf437766a4c1c7e7ac44df';TREE='285648cbf59354ef6160db49253870fd898b7db8'
sys.path.insert(0,str(S/'tools'));import translation_catalogues as c
source={e.tag+'/'+e.get('name'):e for e in E.parse(S/'Paintroid/src/main/res/values/strings.xml').getroot()}
tiers={k:t['id'] for t in json.loads((S/'translations/string-importance.json').read_text())['tiers'] for k in t['keys']};priority={k for k,t in tiers.items() if t in ('P0','P1')}
holds={'string/'+k for k in ('formats22_derived_exported','ui_save_as','ui_save_as_jpeg','ui_save_as_jpeg_xl','ui_save_as_png','ui_foreground_background_colour_palette','ui_pinch_and_pan_mode')}
def node(e):
 if e is None:return None
 return {'value':e.text,'attributes':e.attrib,'value_json_sha256':hashlib.sha256(json.dumps(e.text,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()}
refs=collections.defaultdict(list);paths={'AGENTS.md','CI.md','translations/string-importance.json','Paintroid/src/main/res/values/strings.xml'}
for p in (S/'Paintroid/src/main').rglob('*'):
 if p.suffix not in ('.kt','.java','.xml') or '/res/values' in str(p):continue
 lines=p.read_text(errors='replace').splitlines()
 for i,line in enumerate(lines):
  for key in re.findall(r'R\.(?:string|plurals)\.([A-Za-z0-9_]+)',line):
   if 'string/'+key not in priority:continue
   rel=str(p.relative_to(S));paths.add(rel);lo=max(0,i-4);hi=min(len(lines),i+5)
   refs[key].append({'path':rel,'line':i+1,'start_line':lo+1,'end_line':hi,'context':'\n'.join(lines[lo:hi]),'url':f'https://github.com/c933103/AN-Paint/blob/{PIN}/{rel}#L{lo+1}-L{hi}'})
summary={}
for loc in ('ha','ig','ln'):
 p=c.catalogue_paths()[loc];paths.add(str(p.relative_to(S)));current={e.tag+'/'+e.get('name'):e for e in E.parse(p).getroot()};rows=[]
 for ident in sorted(priority):
  key=ident.split('/')[1];old=current.get(ident)
  status='retained-complete-value-independent-review-needed' if old is not None else 'missing-value-authoring-needed'
  r={'identity':ident,'tier':tiers[ident],'english':node(source[ident]),'current':node(old),'direct_consumers':refs[key],'author_disposition':status}
  if ident in holds and old is None:
   assert not refs[key];r['author_disposition']='hold-absent';r['hold_reason']='Exact no-current-consumer hold preserved for explicit full review; not a blanket priority freeze.'
  rows.append(r)
 counts={'priority_identities':341,'catalogue_present':len(current),'P0_present':sum(r['tier']=='P0' and r['current'] is not None for r in rows),'P1_present':sum(r['tier']=='P1' and r['current'] is not None for r in rows),'exact_absent_holds':len(holds-set(current)),'mapped_exact_prior_acceptances':0,'dispositions':dict(collections.Counter(r['author_disposition'] for r in rows))};summary[loc]=counts
 packet={'source_commit':PIN,'source_tree':TREE,'locale':loc,'catalogue_path':str(p.relative_to(S)),'scope':'Full341 eligibility and retained-review preparation for next continuous trio; Hausa/Igbo/Lingala authoring/current-value inventories. No mapped exact historical priority acceptance recovered; no claim that no historical work existed. All candidate translations remain pending authoring and independent review. Published prior source is inherited without new credit.','counts':counts,'rows':rows}
 (OUT/f'{loc}-complete-inventory.json').write_text(json.dumps(packet,ensure_ascii=False,indent=2)+'\n')
bindings=[]
base={x['path']:x for x in json.loads((B/'base-tree.json').read_text())['tree'] if x['type']=='blob'}
for p in sorted(paths):
 raw=(S/p).read_bytes();sha=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();assert sha==base[p]['sha'];bindings.append({'path':p,'git_blob_sha1':sha,'sha256':hashlib.sha256(raw).hexdigest(),'url':f'https://github.com/c933103/AN-Paint/blob/{PIN}/{p}'})
(OUT/'source-bindings.json').write_text(json.dumps({'source_commit':PIN,'source_tree':TREE,'verified_repository_blobs_and_modes':1428,'bindings':bindings},indent=2)+'\n');print(summary)
