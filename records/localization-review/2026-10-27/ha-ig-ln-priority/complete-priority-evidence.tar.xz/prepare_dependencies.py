from pathlib import Path
import json,re,hashlib,xml.etree.ElementTree as E
B=Path(__file__).resolve().parent;S=B/'source';v=json.loads((B/'dependency-proposals.json').read_text());base=json.loads((B/'source-binding.json').read_text())
source={e.get('name'):e for e in E.parse(S/'Paintroid/src/main/res/values/strings.xml').getroot()}
def node(e):return {'value':({n.get('quantity'):n.text for n in e} if e.tag=='plurals' else e.text),'attributes':e.attrib} if e is not None else None
for loc,vals in v.items():
 inv=json.loads((B/f'candidate-public/{loc}-complete-inventory.json').read_text());cur={e.get('name'):e for e in E.parse(S/inv['catalogue_path']).getroot()};rows=[]
 for k,val in vals.items():
  refs=[]
  for p in (S/'Paintroid/src/main').rglob('*'):
   if p.suffix not in ('.kt','.java','.xml') or '/res/values' in str(p):continue
   lines=p.read_text(errors='replace').splitlines()
   for i,line in enumerate(lines):
    if not re.search(r'R\.(?:string|plurals)\.'+re.escape(k)+r'\b',line):continue
    lo=max(0,i-4);hi=min(len(lines),i+5);refs.append({'path':str(p.relative_to(S)),'line':i+1,'start_line':lo+1,'end_line':hi,'context':'\n'.join(lines[lo:hi])})
  rows.append({'identity':source[k].tag+'/'+k,'tier':'P2-adjacent','english':node(source[k]),'current':node(cur.get(k)),'proposal':val,'proposal_sha256':hashlib.sha256(json.dumps(val,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'proposed_attributes':source[k].attrib,'direct_consumers':refs,'scope':'Atomic complete-value companion to priority animation/quality/crop/dimension values; unchanged existing value earns no edit credit.'})
 (B/f'candidate-public/{loc}-adjacent-dependencies.json').write_text(json.dumps({'source_commit':inv['source_commit'],'source_tree':inv['source_tree'],'locale':loc,'rows':rows},ensure_ascii=False,indent=2)+'\n')
 print(loc,len(rows))
