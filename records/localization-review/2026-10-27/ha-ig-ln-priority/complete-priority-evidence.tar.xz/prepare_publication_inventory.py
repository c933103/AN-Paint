from pathlib import Path
import hashlib,json,sys,xml.etree.ElementTree as E
B=Path(__file__).resolve().parent;S=B/'source';base={e['path']:e for e in json.loads((B/'integration-base-tree.json').read_text())['tree'] if e['type']=='blob'}
actual={}
for p in S.rglob('*'):
 if not p.is_file() or '__pycache__'in p.parts or p.suffix=='.pyc':continue
 rel=str(p.relative_to(S));raw=p.read_bytes();sha=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();actual[rel]={'path':rel,'sha':sha,'mode':'100755'if p.stat().st_mode&0o111 else'100644','type':'blob','bytes':len(raw)}
changes=[e for k,e in sorted(actual.items())if k not in base or e['sha']!=base[k]['sha'] or e['mode']!=base[k]['mode']];removals=sorted(set(base)-set(actual));assert not removals
(B/'source-delta.json').write_text(json.dumps({'source_commit':'c44e1118b78da5cde84f0e48a05726b99bd930ff','source_tree':'30e324237a54b14ba6de408d4ec8fc6c132e4252','changed_paths':changes,'removed_paths':removals},indent=2)+'\n')
sys.path.insert(0,str(S/'tools'));import translation_catalogues as c
manifest=json.loads((S/'translations/string-importance.json').read_text());tiers={k:t['id']for t in manifest['tiers']for k in t['keys']};rows=[]
for tag in c.offered_tags():
 p=c.catalogue_paths()[tag];current=E.parse(p).getroot();old=B/'original-catalogues'/f'{tag}.xml';before=E.parse(old).getroot()if old.exists()else current
 def counts(root):
  ids={e.tag+'/'+e.get('name')for e in root};return {'typed_entries':len(ids),'P0_present':sum(tiers.get(k)=='P0'for k in ids),'P1_present':sum(tiers.get(k)=='P1'for k in ids)}
 rows.append({'locale':tag,'before':counts(before),'after':counts(current)})
assert len(rows)==171
(B/'all171-source-presence.json').write_text(json.dumps({'scope':'Current source presence only, not linguistic acceptance. Before is exact published PR194 c44e111 baseline. Original complete review acca5295 was rebound without English/target/caller changes; no new credit from ancestry.','rows':rows,'totals':{phase:{k:sum(r[phase][k]for r in rows)for k in('typed_entries','P0_present','P1_present')}for phase in('before','after')}},indent=2)+'\n')
print('changed',len(changes));print('\n'.join(e['path']for e in changes));print('bytes',sum(e['bytes']for e in changes))
