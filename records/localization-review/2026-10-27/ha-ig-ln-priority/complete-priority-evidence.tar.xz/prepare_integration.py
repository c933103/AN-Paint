from pathlib import Path
import json,hashlib,shutil,xml.etree.ElementTree as E
B=Path(__file__).resolve().parent;J=B.parent/'jv-su-ky-p0-p1-20261027';S=B/'source';base=json.loads((J/'fresh-terminal/remote-tree.json').read_text());assert base['sha']=='30e324237a54b14ba6de408d4ec8fc6c132e4252'
blob=lambda d:hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest()
for r in base['tree']:
 if r['type']!='blob':continue
 p=J/'source'/r['path'];assert blob(p.read_bytes())==r['sha'],r['path'];q=S/r['path'];q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
(B/'integration-base-tree.json').write_text(json.dumps(base,indent=2)+'\n')
eng={e.get('name'):e for e in E.parse(S/'Paintroid/src/main/res/values/strings.xml').getroot()}
def val(e):return {'value':{c.get('quantity'):c.text for c in e} if e.tag=='plurals' else e.text,'attributes':e.attrib}
rebound=[]
for loc in ('ha','ig','ln'):
 p=B/f'independent-review/{loc}-complete-independent-review.json';r=json.loads(p.read_text());packet=B/f'candidate-public/{loc}-complete-author-packet.json';dep=B/f'candidate-public/{loc}-adjacent-dependencies.json';assert hashlib.sha256(packet.read_bytes()).hexdigest()==r['packet_sha256'];assert hashlib.sha256(dep.read_bytes()).hexdigest()==r['dependencies_sha256'];inv=json.loads(packet.read_text());cur={e.get('name'):e for e in E.parse(S/inv['catalogue_path']).getroot()};accepted={};edits={};holds=[];contexts=set()
 for row in r['rows']+r['dependencies']:
  k=row['identity'].split('/',1)[1];e=val(eng[k]);assert e['value']==row['english']['value'] and e['attributes']==row['english']['attributes'];assert (val(cur[k])if k in cur else None)==row['current']
  for w in row['direct_consumers']:
   lines=(S/w['path']).read_text().splitlines();assert '\n'.join(lines[w['start_line']-1:w['end_line']])==w['context'];contexts.add((w['path'],w['start_line'],w['end_line']))
  if row['decision'].startswith('accept'):
   accepted[k]=row['reviewed_value'];assert row['reviewed_value']==row['proposal'];edits[k]={'previous_target':row['current'],'reviewed_value':row['reviewed_value'],'reviewed_attributes':row['reviewed_attributes']}
  else:assert row['decision']=='hold_absent' and row['current'] is None;holds.append(k)
 assert len(accepted)==346 and len(holds)==10
 out={'locale':loc,'catalogue_path':inv['catalogue_path'],'rows':r['rows'],'dependencies':r['dependencies'],'accepted_resource_text_values':accepted,'integration_values':edits,'held_absent':sorted(holds),'wording_only_or_route_limited_identities':[x['identity']for x in r['rows']if x['decision']=='accept_new_wording_only'],'provenance':{'independent_receipt_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'original_source':r['source_commit'],'integration_source':'c44e1118b78da5cde84f0e48a05726b99bd930ff','additional_linguistic_credit_from_rebind':0}}
 (B/f'independent-review/{loc}-integration-ledger.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');rebound.append({'locale':loc,'accepted':346,'held_absent':holds,'exact_caller_windows':len(contexts),'all_original_english_current_and_caller_values_unchanged':True})
(B/'integration-parent-rebind-author.json').write_text(json.dumps(rebound,indent=2)+'\n');print(rebound)
s=(J/'integrate_priority.py').read_text().replace("('jv','su','ky')","('ha','ig','ln')").replace('-complete-review.json','-integration-ledger.json').replace('len(accepted)==349','len(accepted)==346').replace('javanese_sundanese_kyrgyz','hausa_igbo_lingala').replace('seven exact absent holds','ten exact absent holds')
s=s.replace("'ui_pinch_and_pan_mode'}","'ui_pinch_and_pan_mode','ui_main23','ui_fg','ui_bg'}")
(B/'integrate_priority.py').write_text(s)
