"""Recompute PR189 source, compiled-test and original device-artifact evidence."""
from pathlib import Path
import collections,hashlib,json,re,shutil,sys,tempfile,unittest,xml.etree.ElementTree as E,zipfile
root=Path(__file__).resolve().parent
lane=root.parent/'it-el-tr-p0-p1-20261027'
art=root/'original-artifacts'
head='0ba9f9dd90f2017c1bf3f360020aa6c8850a68dc'
run=40494757661
sha=lambda b:hashlib.sha256(b).hexdigest()
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
final=json.loads((lane/'published-tree-readback.json').read_text())
merge=json.loads((root/'tested-merge-commit.json').read_text())
assert merge['tree']['sha']==final['sha'] and merge['parents'][1]['sha']==head
expected={x['path']:x for x in final['tree'] if x['type']=='blob'}
metadata=json.loads((root/'artifacts-metadata.json').read_text())['artifacts']
prefixes={'apk-source':'apk-and-source','instrumentation':'instrumentation-apks','regression':'regression-and-lint','probes':'exact-script-generation','core':'emulator-core','position':'emulator-position','union':'emulator-api-35'}
verified=[]
for stem,prefix in prefixes.items():
 m=next(x for x in metadata if x['name'].startswith(prefix));b=(art/(stem+'.zip')).read_bytes()
 assert len(b)==m['size_in_bytes'] and sha(b)==m['digest'].removeprefix('sha256:')
 assert m['workflow_run']['id']==run and m['workflow_run']['head_sha']==head
 with zipfile.ZipFile(art/(stem+'.zip')) as z:assert z.testzip() is None
 verified.append({'id':m['id'],'name':m['name'],'sha256':sha(b),'size_bytes':len(b)})
with zipfile.ZipFile(art/'apk-source.zip') as z:
 info=json.loads(z.read('build/delivery/build-info.json'))
 sourcebytes=z.read('build/delivery/AN-Paint-source.zip')
 assert sha(sourcebytes)==info['source_sha256']
 assert sha(z.read('app/build/outputs/apk/debug/app-debug.apk'))==info['apk_sha256']
 (root/'AN-Paint-source.zip').write_bytes(sourcebytes)
assert info['commit']==merge['sha'] and info['run_id']==str(run)
sourcezip=zipfile.ZipFile(root/'AN-Paint-source.zip');missing=[];bad=[]
for path,x in expected.items():
 try:b=sourcezip.read('AN-Paint/'+path)
 except KeyError:missing.append(path);continue
 if blob(b)!=x['sha']:bad.append(path)
assert missing==['.gitignore','.idea/codeStyles/Project.xml','colorpicker/.gitignore'] and not bad,(missing,bad)
work=root/'inventory-source';work.mkdir(exist_ok=True)
for path in expected:
 if path not in missing:
  p=work/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(sourcezip.read('AN-Paint/'+path))
sys.path.insert(0,str(work/'tools'))
from run_android_instrumentation import declared_tests,source_tests_sha256,parse_protocol
from app_instrumentation_matrix import verify_reports
from compose_device_reports import compose
extracted={}
extraction=Path(tempfile.mkdtemp(prefix='verification-extraction-',dir=root))
for stem in ['core','position','union']:
 p=extraction/stem;p.mkdir()
 with zipfile.ZipFile(art/(stem+'.zip')) as z:z.extractall(p)
 extracted[stem]=p
appdir=work/'app/src/androidTest';paintdir=work/'Paintroid/src/androidTest'
coverage=verify_reports(appdir,extracted['union'],35)
assert coverage['success']
selection=json.loads((extracted['union']/'artifact-selection.json').read_text())
assert selection['run_id']==run and selection['workflow_head']==head and selection['checkout']==merge['sha']
for group in ['core','position']:
 m=next(x for x in metadata if x['name'].startswith(prefixes[group]))
 assert selection['selected'][group]['artifact_id']==m['id'] and selection['selected'][group]['digest']==m['digest']
# Recompose independent original group archives; never use the CI union as its own oracle.
composed=compose(appdir,extracted['core'],extracted['position'],35,{'GITHUB_SHA':merge['sha'],'GITHUB_RUN_ID':str(run),'GITHUB_RUN_ATTEMPT':'1','BUILD_VARIANT':'debug'})
assert composed['success'] and composed['completed_tests']==coverage['completed_tests']
assert json.loads((extracted['core']/'composed-device-identity.json').read_text())==json.loads((extracted['union']/'composed-device-identity.json').read_text())
raw_reports=[]
for s in sorted(extracted['union'].rglob('summary.json')):
 d=json.loads(s.read_text())
 if 'cases' not in d:continue
 log=s.parent/'instrumentation.log';assert log.exists()
 identities={(x['classname'],x['name']) for x in d['cases']}
 parsed=parse_protocol(log.read_text(),identities,returncode=d['returncode'],timed_out=d['timed_out'])
 assert parsed['success'] and parsed['completed_tests']==d['completed_tests'],str(s)
 rel=s.relative_to(extracted['union']);assert s.read_bytes()==(extracted['core']/rel).read_bytes()
 assert log.read_bytes()==(extracted['core']/rel.parent/'instrumentation.log').read_bytes()
 raw_reports.append({'path':str(rel),'tests':len(identities),'log_sha256':sha(log.read_bytes())})
paint=json.loads((extracted['union']/'Paintroid/androidTest-results/summary.json').read_text())
assert {(x['classname'],x['name']) for x in paint['cases']}==declared_tests(paintdir,sdk_level=35)
assert paint['source_tests_sha256']==source_tests_sha256(paintdir)
ident=json.loads((extracted['union']/'composed-device-identity.json').read_text())
assert ident['commit']==info['commit'] and ident['source_sha256']==info['source_sha256'] and ident['apk_sha256']==info['apk_sha256']
with zipfile.ZipFile(art/'instrumentation.zip') as z:assert sha(z.read('app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk'))==ident['test_apk_sha256']
assert source_tests_sha256(appdir)==ident['source_tests_sha256']
reg=zipfile.ZipFile(art/'regression.zip');totals=collections.Counter();suites=[];new=[]
for path in reg.namelist():
 if '/test-results/' in path and path.endswith('.xml'):
  e=E.fromstring(reg.read(path));suites.append(path)
  for k in ['tests','failures','errors','skipped']:totals[k]+=int(e.attrib.get(k,0))
  assert not e.findall('.//failure') and not e.findall('.//error')
  if 'ItalianGreekTurkishPriorityWordingTest.xml' in path:new=[x.attrib['name'] for x in e.findall('testcase')]
assert totals['failures']==totals['errors']==totals['skipped']==0
kt=sourcezip.read('AN-Paint/Paintroid/src/test/java/org/catrobat/paintroid/local/ItalianGreekTurkishPriorityWordingTest.kt').decode()
methods=re.findall(r'@Test\s+fun\s+(\w+)\(',kt)
assert set(new)==set(methods) and len(new)==len(methods)==7,(new,methods)
assert not E.fromstring(reg.read('app/build/reports/lint-results-debug.xml')).findall('issue')
with zipfile.ZipFile(art/'probes.zip') as z:
 probes=json.loads(z.read('summary.json'));assert probes['success'] and probes['tree']==final['sha']
 for p in probes['probes']:
  assert sha(z.read(p['name']+'.log'))==p['log_sha256']
  assert (p['exit_code']==0)==p['expected_success']
python_log=reg.read('build/reports/ci-phases/python.log')
markers=''.join(m.group(1) for line in python_log.decode().splitlines() if (m:=re.match(r'^([.sEF]+)(?:/usr|$)',line)))
def flatten(suite):
 for test in suite:
  if isinstance(test,unittest.TestSuite):yield from flatten(test)
  else:yield test.id()
python_ids=list(flatten(unittest.defaultTestLoader.discover(str(work/'tools'),pattern='test_*.py')))
assert len(markers)==len(python_ids) and markers.count('F')==markers.count('E')==0
assert 'exit_status=0' in reg.read('build/reports/ci-phases/python.time').decode()
hosted_python={'declared_tests':len(python_ids),'executed_successfully':markers.count('.'),'skipped_tests':[python_ids[i] for i,m in enumerate(markers) if m=='s'],'exit_status':0,'raw_log_sha256':sha(python_log),'scope':'Exact source unittest discovery-order identities mapped to every original hosted progress marker; skipped checks are not passes.'}
jobs=json.loads((root/'jobs-terminal.json').read_text())
assert len(jobs)==6 and all(x['conclusion']=='success' and x['status']=='completed' and x['run_id']==run for x in jobs)
result={'schema':1,'pr':189,'head':head,'tree':final['sha'],'tested_merge':merge['sha'],'run_id':run,
 'artifact_digests_verified':verified,'terminal_jobs':[{k:j[k] for k in ['id','name','status','conclusion','run_id']} for j in jobs],
 'source_archive_sha256':info['source_sha256'],'source_tree_blobs_verified':len(expected)-len(missing),'source_archive_omitted_repository_metadata':missing,'missing_non_metadata_source_files':[],'mismatched_source_files':bad,
 'hosted_python':hosted_python,'jvm':dict(totals,suites=len(suites),new_italian_greek_turkish_methods=new),'lint_issues':0,
 'api35':{'paintroid':paint['completed_tests'],'app':coverage['completed_tests'],'app_inventory_recomputed_from_exact_source':True,'paintroid_inventory_recomputed_from_exact_source':True,'raw_instrumentation_reports_reparsed':raw_reports,'original_core_position_recomposition_verified':True,'complete_union_revalidated':True,'missing':[],'unexpected':[],'suppressed':[],'deferred':[],'app_source_tests_sha256':source_tests_sha256(appdir),'paintroid_source_tests_sha256':source_tests_sha256(paintdir)},
 'resource_probes':{'count':len(probes['probes']),'original_log_hashes_match':True,'all_expected_outcomes_match':True,'intentional_rejection':'06-reserved-app-variant-rejected'},'apk_sha256':info['apk_sha256'],'app_test_apk_sha256':ident['test_apk_sha256'],
 'limitations':['Hosted API35 evidence does not certify native linguistic fluency, TalkBack usability, all devices, or every locale layout.','Existing colour scope remains preview-rail reachability and Cancel only for API35 en-US/hu 2x 640x320 mdpi, with separate IME/Back/footer lifecycle; not universal 2x or simultaneous whole-dialog/IME fit.','Root retains merge lease. Release pause and other explicit project holds remain unchanged.']}
(root/'independent-terminal-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['head','tree','tested_merge','run_id','source_tree_blobs_verified','jvm','lint_issues','resource_probes']},indent=2))
print('Original artifact digests:',len(verified),'API35:',paint['completed_tests'],coverage['completed_tests'],'raw reports:',len(raw_reports),'independent group recomposition passed')
