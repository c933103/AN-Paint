from pathlib import Path
import sys,json,hashlib,xml.etree.ElementTree as E
P=Path(__file__).resolve().parents[1];S=P/'source';O=P/'independent-review';sys.path.insert(0,str(S/'tools'));from javanese_sundanese_kyrgyz_priority_expectations import current_row,display
f=json.load(open(S/'tools/fixtures/current_localization/javanese_sundanese_kyrgyz_priority_wording.json'))
def cat(path):
 out={}
 for e in E.parse(path).getroot():
  k=e.attrib['name'];assert k not in out
  r={'value':e.text if e.tag=='string' else {x.attrib['quantity']:x.text for x in e},'attributes':dict(e.attrib)}
  if e.tag=='plurals':r['children_attributes']={x.attrib['quantity']:dict(x.attrib)for x in e};assert len(e)==len(r['value'])
  out[k]=r
 return out
en=cat(S/'Paintroid/src/main/res/values/strings.xml');counts={}
for l in ['jv','su','ky']:
 d=json.load(open(O/f'{l}-complete-review.json'));m=d['integration_values'];fd=f['locales'][l];before=cat(P/f'original-catalogues/{l}.xml');after=cat(S/d['catalogue_path'])
 assert set(fd['changed'])==set(m);assert {k for k in before.keys()|after.keys()if before.get(k)!=after.get(k)}==set(m)
 assert fd['accepted']==d['accepted_resource_text_values'];assert fd['priority_status']=={r['identity']:r['decision']for r in d['rows']};assert set(fd['wording_only'])==set(d['wording_only_or_route_limited_identities'])
 for k,r in m.items():
  assert before.get(k)==r['previous_target'],(l,k,'previous')
  want={'value':r['reviewed_value'],'attributes':r['reviewed_attributes']}
  if r['type']=='plurals':want['children_attributes']=r['reviewed_children_attributes']
  assert after[k]==want,(l,k,'target');assert en[k]==r['source'],(l,k,'EN')
 for k,v in d['accepted_resource_text_values'].items():
  fr=current_row(l,k);assert fr['target']==v;assert fr['source']==en[k]['value'];assert fr['attributes']==after[k]['attributes'];assert display(l,k)==d['accepted_display_values'][k],(l,k,'display')
 for k,r in before.items():
  if k not in m:assert after[k]==r
 assert set(after)==set(before)|set(m)
 for r in d['rows']:
  if r['decision']=='hold_absent':assert r['identity'].split('/')[1]not in after
 counts[l]={'edits':len(m),'accepted':len(fd['accepted']),'priority_rows':len(d['rows']),'retained_xml':len(set(before)-set(m))}
r={'result':'PASS','counts':counts,'total_edits':sum(x['edits']for x in counts.values()),'scope':'Independent complete XML/fixture/source/predecessor/attributes/plural children/display/status/context/hold equality against final ledgers; no new linguistic credit or runtime claim.'};(O/'recovery-integration-verification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
