from pathlib import Path
import sys,json,hashlib,copy,xml.etree.ElementTree as E
P=Path(__file__).resolve().parents[1];S=P/'source';O=P/'independent-review';sys.path.insert(0,str(S/'tools'))
import test_javanese_sundanese_kyrgyz_priority_wording as g
import javanese_sundanese_kyrgyz_priority_expectations as h
f=json.load(open(S/'tools/fixtures/current_localization/javanese_sundanese_kyrgyz_priority_wording.json'));g.require_shape(f);mutations=[];counts={}
def reject(x,name):
 try:g.require_shape(x)
 except ValueError:mutations.append(name)
 else:raise AssertionError('Accepted mutation '+name)
for tag in ['jv','su','ky']:
 d=json.load(open(O/f"{tag}-complete-review.json"));v=f['locales'][tag];allrows={r['identity']:r for r in d['rows']+d['dependencies']};old={n.attrib['name']:{'type':n.tag,'target':{q.attrib['quantity']:q.text for q in n}if n.tag=='plurals'else n.text,'attributes':dict(n.attrib)}for n in E.parse(P/f'original-catalogues/{tag}.xml').getroot()}
 assert v['accepted']==d['accepted_resource_text_values']
 assert v['priority_status']=={r['identity']:r['decision']for r in d['rows']}
 ctx=set(d['wording_only_or_route_limited_identities']);assert set(v['wording_only'])==ctx
 assert set(v['changed'])==set(d['integration_values']);assert set(v['unchanged_accepted'])==set(v['accepted'])-set(v['changed'])
 pred={k:old[k]for k in d['integration_values']if k in old};assert pred==v['predecessors']==g.PREDECESSORS[tag]
 outside={k:r for k,r in old.items()if r['type']+'/'+k not in allrows};assert v['outside_review']==outside
 held={};assert set(v['held_absent'])=={r['identity'].split('/')[1]for r in d['rows']if r['decision']=='hold_absent'}
 for k,value in d['accepted_display_values'].items():assert h.display(tag,k)==value,(tag,k,'exact display')
 for i,r in allrows.items():
  k=i.split('/')[1];assert f['sources'][k]['source']==r['english']['value']and f['sources'][k]['attributes']==r['english']['attributes'],(tag,i,'source')
 for i in v['priority_status']:
  x=copy.deepcopy(f);x['locales'][tag]['priority_status'][i]='accept_unbounded';reject(x,tag+'/'+i+'/status')
 for i in ctx:
  x=copy.deepcopy(f);x['locales'][tag]['wording_only'].remove(i);reject(x,tag+'/'+i+'/context')
 for k in pred:
  for mode in ['remove','forge','attrs']:
   x=copy.deepcopy(f);r=x['locales'][tag]['predecessors']
   if mode=='remove':r.pop(k)
   elif mode=='forge':r[k]['target']='forged'
   else:r[k]['attributes']['forged']='true'
   reject(x,tag+'/'+k+'/previous-'+mode)
 x=copy.deepcopy(f);x['locales'][tag]['catalogue_identities'].append('string/extra_unreviewed');reject(x,tag+'/extra-catalogue')
 counts[tag]={'priority':341,'dependencies':15,'accepted_values':len(v['accepted']),'edits':len(v['changed']),'unchanged_accepted':len(v['unchanged_accepted']),'wording_only':len(ctx),'corrected_predecessors':len(pred),'held_absent':len(v['held_absent']),'held_present':0,'outside_preserved':len(outside)}
 print(tag,counts[tag],flush=True)
bs=chr(92);assert h._display(bs+'n')=='\n'and h._display(bs+bs+'n')==bs+'n';assert h._display('actual\u200cjoiner')=='actual\u200cjoiner';assert h._display('"a'+bs+'"b"')=='a"b'
paths=['tools/fixtures/current_localization/javanese_sundanese_kyrgyz_priority_wording.json','tools/test_javanese_sundanese_kyrgyz_priority_wording.py','tools/javanese_sundanese_kyrgyz_priority_expectations.py','Paintroid/src/test/java/org/catrobat/paintroid/local/JavaneseSundaneseKyrgyzPriorityWordingTest.kt']
report={'result':'PASS','scope':'Independent exact whole fixture/accepted maps/source/retained complement/holds/outside/predecessor/attribute/display readback and all 341 disposition sensitivity per locale.','counts':counts,'independent_rejected_mutations':len(mutations),'display_decoder':'One-pass decoder equals every accepted display value; synthetic single-vs-double escape distinction verified without falsely claiming any current raw newline uses double slashes. Actual U+200C preserved.','focused_host':{'normal':'pending','optimized':'pending'},'jvm_static_review':{'methods':15,'inherited_review_plus_complete_delta_read':True,'actual_APIs_checked':True,'hosted_compile_runtime_pending':True},'limits':['No local SDK/Gradle or installed layout/TalkBack/native-human proof.','New suite covers compiled full values, dimensions, crop controls/counts, tool accessibility, animation, decoder/memory admission, save/export/share cancel, quality/lossless/dither, alignment, return-to-drawing, dirty Keep editing colour swapping and Commit selection with actual Undo/Redo bitmap preservation. No new corrupt-recovery or canvas-clipping execution is claimed.','Full aggregate/shared finite guards and exact-head hosted CI remain author-owned.'],'files':{x:hashlib.sha256((S/x).read_bytes()).hexdigest()for x in paths}}
(O/'integrated-fixture-test-review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
