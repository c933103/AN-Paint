from pathlib import Path
import json,copy,hashlib,re,collections,xml.etree.ElementTree as E,sys
D=Path(__file__).resolve().parents[1];S=D/'source';O=D/'independent-review';sys.path.insert(0,str(S/'tools'));import translation_catalogues as tc
read=lambda p:json.loads((D/p).read_text());sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
write=lambda p,v:(O/p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
B=read('candidate-public/source-bindings.json');base=read('base-tree.json')['tree'];all_verified=0
for r in base:
 if r['type']!='blob':continue
 p=S/r['path'];assert blob(p.read_bytes())==r['sha'],r['path'];assert ('100755'if p.stat().st_mode&0o111 else'100644')==r['mode'];all_verified+=1
assert all_verified==1424
for r in B['bindings']:
 b=(S/r['path']).read_bytes();assert sha(b)==r['sha256']and blob(b)==r['git_blob_sha1']
def catalogue(path):
 out={}
 for n in E.parse(S/path).getroot():
  ident=n.tag+'/'+n.attrib['name'];assert ident not in out
  r={'value':n.text or'','attributes':dict(n.attrib)}
  if n.tag=='plurals':
   assert all(c.tag=='item'and not len(c)and set(c.attrib)=={'quantity'}for c in n)
   r.update(value={c.attrib['quantity']:c.text or''for c in n},children_attributes={c.attrib['quantity']:dict(c.attrib)for c in n});assert len(r['value'])==len(n)
  else:assert n.tag=='string'and not len(n)
  out[ident]=r
 return out
EN=catalogue('Paintroid/src/main/res/values/strings.xml');fixed={'formats22_derived_exported','ui_save_as','ui_save_as_jpeg','ui_save_as_jpeg_xl','ui_save_as_png'};held=fixed|{'ui_foreground_background_colour_palette','ui_pinch_and_pan_mode'};route={'language20_current','language20_settings','ui_menu_help'}
depkeys={'formats22_at_least_frames','ui_top','ui_width_in','ui_lossless_format','save20_dither','ui_quality','ui_trim_in_pixels','ui_trim_in_percent','ui_rounded_rectangle','ui_star','ui_curve','ui_arrow','ui_heart','ui_image_shown_in_crop_preview','ui_crop_preview_images'}
unitfiles={'jv':['jv-p0-complete-review-v1.json','jv-p1-complete-review-final.json'],'su':['su-p0-complete-review-final.json','su-p1-complete-review-v1.json'],'ky':['ky-p0-complete-review-final.json','ky-p1-complete-review-v1.json']}
reasons={'formats22_at_least_frames':'Complete lower-bound phrase composes with opaque frame-count string in the already accepted full animation warning, without duplicated frame units.','ui_top':'Actual crop edge label, complete and consistent with Left/Right/Bottom.','ui_width_in':'Neutral parenthetical unit wrapper composes with the exact standalone pixel/percentage labels without requiring inflected injected text.','ui_lossless_format':'Format label interpolation and complete higher-quality paragraph describe lossless colour-value preservation atomically.','save20_dither':'Technical dithering loan reviewed with complete still-image/256-colour/gradient/first-frame GIF paragraph and actual checkbox; bounded technical confidence, not native terminology attestation.','ui_quality':'Quality slider retains literal (%) and exact canonical formatted=false; previous attributes remain explicitly null for these additions.','ui_trim_in_pixels':'Full crop amount/edge/unit wrapper preserves the supplied edge label and pixels, without requiring a declined label.','ui_trim_in_percent':'Full crop amount/edge/unit wrapper preserves the supplied edge label and percentages, without requiring a declined label.','ui_rounded_rectangle':'Complete rounded-corner rectangle tool name is coherent with rectangle and neutral selected-tool accessibility wrapper.','ui_star':'Actual star shape label, reviewed with tool enum and category interpolation.','ui_curve':'Actual curve tool label; complete geometric line sense, not an unrelated action.','ui_arrow':'Actual arrow shape label, reviewed with tool enum and category interpolation.','ui_heart':'Heart-shape label uses the conventional emotional-heart term, not an anatomical-function requirement.','ui_image_shown_in_crop_preview':'Complete description identifies the image shown in the actual crop preview.','ui_crop_preview_images':'Every locale-applicable quantity preserves width, height and image count, one Android newline and conditional movement of attached images. JV/SU other-only and KY one/other are explicit; no quantity is invented.'}
summary=[];allmaps={}
for tag in ['jv','su','ky']:
 packet=D/f'candidate-public/{tag}-complete-author-packet.json';depsfile=D/f'candidate-public/{tag}-adjacent-dependencies.json';I=json.load(open(packet));A=json.load(open(depsfile));cur=catalogue(I['catalogue_path']);prior={};provenance=[]
 for name in unitfiles[tag]:
  path=O/name;j=json.load(open(path));assert j['locale']==tag
  for r in j['rows']:assert r['identity']not in prior;prior[r['identity']]=r
  provenance.append({'path':name,'sha256':sha(path.read_bytes())})
 assert len(prior)==341 and len(I['rows'])==341 and collections.Counter(r['tier']for r in I['rows'])=={'P0':92,'P1':249}
 assert len(A['rows'])==15 and {r['identity'].split('/')[1]for r in A['rows']}==depkeys
 proposals={r['identity']:r['proposal']for r in I['rows']+A['rows']if r.get('proposal')is not None}
 def decoded(v):
  if isinstance(v,dict):return{q:decoded(s)for q,s in v.items()}
  if v.startswith('@string/'):
   ident='string/'+v.split('/',1)[1];v=proposals[ident]if ident in proposals else cur[ident]['value']
  if len(v)>1 and v[0]==v[-1]=='"':v=v[1:-1]
  return re.sub(r'\\(.)',lambda m:{'n':'\n','t':'\t','r':'\r'}.get(m[1],m[1]),v)
 rows=[];deps=[];accepted={};display={};edits={};context=[];windows=0
 for depflag,group in [(False,I['rows']),(True,A['rows'])]:
  for old in group:
   r=copy.deepcopy(old);ident=r['identity'];kind,key=ident.split('/');source=EN[ident];previous=cur.get(ident)
   assert r['english']['value']==source['value']and r['english']['attributes']==source['attributes'],(tag,ident,'English')
   if previous:assert r['current']['value']==previous['value']and r['current']['attributes']==previous['attributes'],(tag,ident,'previous')
   else:assert r['current']is None
   r['english']=copy.deepcopy(source);r['current']=copy.deepcopy(previous)
   for c in r['direct_consumers']:assert '\n'.join((S/c['path']).read_text().splitlines()[c['start_line']-1:c['end_line']])==c['context'];windows+=1
   if depflag:assert r['direct_consumers'],(tag,ident,'dependency needs actual caller')
   context_only=not r['direct_consumers']or key in route
   r['confidence']='Medium bounded model linguistic/technical confidence; high exact source/current/attribute/caller binding. No native-human, rendered-layout or accessibility-usability certification.'
   r['context_limit']='No direct current consumer: wording-only; no invented runtime referent.'if not r['direct_consumers']else'Current route-limited wording only; no Help/settings reactivation or callback execution claim.'if key in route else'Actual static caller reviewed; no new installed runtime/layout claim.'
   if key in held:
    assert not depflag and r.get('proposal')is None and previous is None and prior[ident]['decision']=='hold_absent'
    r.update(decision='hold_absent',reviewed_value=None,reviewed_attributes=None,new_pair_credit=False,rationale='Exact established no-current-consumer P0 hold.'if key in fixed else'Specific unknown palette composition or pinch-mode context remains unresolved.')
   else:
    value=r['proposal'];assert value is not None
    if not depflag:assert prior[ident]['decision'].startswith('accept')and prior[ident]['reviewed_value']==value,(tag,ident,'review provenance')
    attrs=copy.deepcopy(r.get('proposed_attributes',previous['attributes']if previous else source['attributes']))
    changed=previous is None or value!=previous['value']or attrs!=previous['attributes']
    status=('accept_new_'if previous is None else'accept_current_correction_'if changed else'accept_current_')+('wording_only'if context_only else'active'if changed else'bounded')
    reason=reasons[key]if depflag else prior[ident]['rationale']
    if key=='language20_app_language'and tag=='ky':reason='The exact quoted app-language successor restores the missing App qualifier; retained preflight proposal and explicit author second-check are preserved, with no duplicate identity credit.'
    if key=='ui_save_a5d0d9'and value.startswith('@string/'):reason='Exact inherited Save alias preserved; display resolves through the unchanged quoted or unquoted Save resource without punctuation-only rewriting.'
    if context_only:reason+=' This is source wording only, not newly established runtime context.'
    r.update(decision=status,reviewed_value=value,reviewed_attributes=attrs,new_pair_credit=True,rationale=reason)
    if not depflag:r['prior_independent_unit_disposition']={k:copy.deepcopy(prior[ident][k])for k in ['decision','proposal','reviewed_value','rationale','review_history']if k in prior[ident]}
    if kind=='plurals':
     assert set(value)==({'one','other'}if tag=='ky'else{'other'});r['reviewed_children_attributes']={q:{'quantity':q}for q in value}
    vals=value if kind=='plurals'else{'string':value};sources=source['value']if kind=='plurals'else{'string':source['value']}
    for q,v in vals.items():
     assert not tc.android_string_errors(v),(tag,ident,q);assert not tc.format_string_errors(v,attrs.get('formatted')!='false'),(tag,ident,q)
     if not v.startswith('@string/'):assert tc.placeholders(v)==tc.placeholders(sources[q]),(tag,ident,q,'tokens');assert v.count('\\n')==sources[q].count('\\n'),(tag,ident,q,'newline')
     if kind=='plurals':assert v.count(chr(92))==1 and v.count(chr(10))==0 and decoded(v).count(chr(10))==1
    accepted[key]=value;display[key]=decoded(value)
    if context_only and not depflag:context.append(ident)
    if changed:
     item={'identity':ident,'type':kind,'tier':r['tier'],'source':copy.deepcopy(source),'previous_target':copy.deepcopy(previous),'reviewed_value':value,'reviewed_attributes':attrs,'decision':'accept','rationale':reason,'direct_consumers':r['direct_consumers']}
     if kind=='plurals':item['reviewed_children_attributes']=r['reviewed_children_attributes']
     edits[key]=item
   (deps if depflag else rows).append(r)
 # Exact actual-label composition, not inferred from similar terms.
 for key in ['ui_draw26','ui_insert','ui_other_images34']:assert display[key]in display['ui_paste_hint34'],(tag,key)
 for key in ['ui_menu_file','ui_load_image']:assert display[key]in display['ui_recovery_copy_exported_extract_canvas_png_from_the'],(tag,key)
 for key in ['ui_menu_file','ui_export_recovery_copy','save20_title','save20_file_format']:assert display[key]in display['ui_autosave_is_paused_to_protect_that_draft_use'],(tag,key)
 assert display['ui_undo']in display['ui_keeps_pixels_at_the_top_left_smaller_canvas']
 assert display['save20_dither']in display['save20_gif_description']
 assert len(rows)==341 and len(deps)==15 and len(accepted)==349 and len(context)==26 and sum(r['decision']=='hold_absent'for r in rows)==7
 adds=sum(x['previous_target']is None for x in edits.values());prioritychanges=sum(x['tier']in ['P0','P1']for x in edits.values())
 obj={'source_commit':I['source_commit'],'source_tree':I['source_tree'],'locale':tag,'catalogue_path':I['catalogue_path'],'scope':'Complete 92 P0 +249 P1 values and exactly15 actual typed companions. Independent full-value read, not acceptance from presence.','rows':rows,'dependencies':deps,'accepted_resource_text_values':accepted,'accepted_display_values':display,'integration_values':edits,'counts':dict(collections.Counter(r['decision']for r in rows)),'dependency_counts':dict(collections.Counter(r['decision']for r in deps)),'wording_only_or_route_limited_identities':context,'accounting':{'priority_total':341,'accepted_priority':334,'held_priority':7,'new_current_priority_pair_acceptances':334,'prior_mapped_historical_carries':0,'prior_scope_limit':'No mapped historical exact acceptance recovered; not a claim no historical work exists. Earlier same-task retained and P0/P1 unit receipts are provenance only, not additional credit.','accepted_priority_context_limited':26,'typed_integration_edits':len(edits),'priority_edits':prioritychanges,'atomic_dependency_edits':len(edits)-prioritychanges,'additions':adds,'corrections':len(edits)-adds},'feedback_provenance':{'full_packet_sha256':sha(packet.read_bytes()),'dependency_packet_sha256':sha(depsfile.read_bytes()),'complete_unit_receipts':provenance,'retained_preflight':'independent-preflight/complete-retained-preflight.json','Kyrgyz_app_successor':'independent-preflight/ky-app-language-second-check-resolution.json','primary_terms':'independent-preflight/primary-terminology.json','plural_categories':'independent-preflight/cardinal-plural-categories.json'},'verified_source_blobs':B['bindings'],'verified_direct_consumer_windows':windows,'limits':['All accepted edits are unapplied; author owns integration, ancestry refresh and runtime gates.','Seven exact absent holds remain, and26 accepted dormant/route-limited identities do not gain active-context credit.','Bounded model review is not native-speaker, whole-catalogue, installed-layout or accessibility-usability certification.','P2 scope is exactly15 enumerated atomic companions, not a broad P2 completion claim.','Release0.0.41 pause, PR159 freeze, PR113 retarget restriction, Help/callback/archive stops and PR56 never-merge remain unchanged.','Original proposals, superseded hypotheses and author second-check receipts remain preserved.']}
 # Human-facing spacing is explicit even in concise report metadata.
 obj['scope']=obj['scope'].replace('+249','+ 249').replace('exactly15','exactly 15');obj['limits']=[s.replace('and26','and 26').replace('exactly15','exactly 15').replace('Release0.0.41','Release 0.0.41')for s in obj['limits']]
 write(f'{tag}-complete-review.json',obj);write(f'{tag}-accepted-edit-map.json',edits);allmaps[tag]=edits;summary.append({'locale':tag,**obj['accounting'],'counts':obj['counts'],'dependency_counts':obj['dependency_counts'],'ledger_sha256':sha((O/f'{tag}-complete-review.json').read_bytes()),'edit_map_sha256':sha((O/f'{tag}-accepted-edit-map.json').read_bytes())})
write('jv-su-ky-accepted-edit-maps.json',allmaps);write('complete-review-summary.json',{'source_commit':B['source_commit'],'source_tree':B['source_tree'],'all_repository_blobs_modes_verified':all_verified,'verified_relevant_source_files':len(B['bindings']),'priority_identities':1023,'typed_dependencies':45,'locales':summary,'typed_integration_edits':sum(len(x)for x in allmaps.values()),'status':'Full independent review complete; edits unapplied and author implementation/runtime gates remain.','checks':['Exact 92 P0 /249 P1 taxonomy per locale','All full source and previous values/attributes match real XML','Every actual caller window matches the source','Every applicable plural child and all formatting tokens/newlines checked','One-pass Android decoding and preserved Save aliases','Atomic command/dither/control composition verified','Seven absent holds and 26 wording-only/route-limited accepted identities each'],'edit_maps_sha256':sha((O/'jv-su-ky-accepted-edit-maps.json').read_bytes())});print(json.dumps(summary,indent=2))
