from pathlib import Path
import sys,json,copy,hashlib,importlib.util,xml.etree.ElementTree as E
P=Path(__file__).resolve().parents[1];S=P/'source';T=P/'option-successor';sys.path.insert(0,str(S/'tools'));spec=importlib.util.spec_from_file_location('staged_su',T/'javanese_sundanese_kyrgyz_priority_expectations.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
import language_option_additions as old
rows=json.load(open(old.ADDITIONS_PATH))['languages'];row=next(x for x in rows if x['tag']=='su');xml=(S/row['catalogue']).read_text();h.require_sundanese_option_successor(row,xml);count=0
def reject(r,x):
 global count
 try:h.require_sundanese_option_successor(r,x)
 except ValueError:count+=1;return
 raise AssertionError('mutation accepted')
for r in rows:
 if r['tag']!='su':reject(r,xml)
for field,v in [('translation_status','complete'),('linguistic_review','accepted'),('fallback','translated'),('source_strings_present',349)]:
 r=copy.deepcopy(row);r[field]=v;reject(r,xml)
root=E.fromstring(xml)
for i in range(len(root)):
 x=copy.deepcopy(root);node=x[i]
 if node.tag=='string':node.text=(node.text or '')+'BAD'
 else:node[0].text=(node[0].text or '')+'BAD'
 reject(row,E.tostring(x,encoding='unicode'))
a=json.load(open(S/'translations/language-options.json'));b=json.load(open(T/'language-options.json'));expected=copy.deepcopy(a)
# The container shape is preserved; only exact one metadata value may differ.
def fix(v):
 if isinstance(v,dict):
  if v.get('tag')=='su':v['translation_status']='partial-priority-reviewed'
  for x in v.values():fix(x)
 elif isinstance(v,list):
  for x in v:fix(x)
fix(expected);assert expected==b
r={'result':'PASS','independent_mutations_rejected':count,'scope':'Staged Sundanese-only option successor; all349 complete values tested, foreign locales/historical metadata mutations rejected. Current language metadata differs only exact SU status.','static_jvm':'Complete diff only exact SU four-display branch; other five fallback and all platform/identity checks unchanged. Outputs equal independently accepted displays.','files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in T.iterdir()if p.is_file()},'limits':['Staged files not yet source integration or hosted runtime proof.','No new linguistic credit.']};(P/'independent-review/su-option-successor-independent.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
