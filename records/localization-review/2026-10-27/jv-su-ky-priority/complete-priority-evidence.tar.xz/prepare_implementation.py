from pathlib import Path
B=Path(__file__).resolve().parent; A=B.parent/'as-km-lo-p0-p1-20261027'; S=B/'source'
def adapt(t):
 return t.replace('assamese_khmer_lao','javanese_sundanese_kyrgyz').replace('AssameseKhmerLao','JavaneseSundaneseKyrgyz').replace('Assamese/Khmer/Lao','Javanese/Sundanese/Kyrgyz').replace('AS_KM_LO','JV_SU_KY').replace('as_km_lo','jv_su_ky').replace("('as','km','lo')","('jv','su','ky')").replace("{'as','km','lo'}","{'jv','su','ky'}").replace('listOf("as","km","lo")','listOf("jv","su","ky")').replace("('km','lo')","('jv','ky')").replace('listOf("km","lo")','listOf("jv","ky")')
for name in ['integrate_priority.py','prepare_host_tests.py','priority_host_test_template.py','apply_shared_guard_additions.py']:
 t=adapt((A/name).read_text())
 if name=='priority_host_test_template.py': t=t.replace("tag=='as'","tag=='ky'").replace('Assamese','Sundanese')
 if name=='apply_shared_guard_additions.py':
  t=t.replace('assertEquals(84, expected.length())','assertEquals(87, expected.length())').replace('assertEquals(87, expected.length())\'\'\'','assertEquals(90, expected.length())\'\'\'')
  t=t.replace('assertEquals(86, fallbacks) // 171 offered - 84 exact current values - 1 inherited.','assertEquals(83, fallbacks) // 171 offered - 87 exact current values - 1 inherited.').replace("s.replace(old,'assertEquals(83, fallbacks) // 171 offered - 87 exact current values - 1 inherited.')","s.replace(old,'assertEquals(80, fallbacks) // 171 offered - 90 exact current values - 1 inherited.')")
 (B/name).write_text(t)
t=adapt((A/'source/tools/assamese_khmer_lao_priority_expectations.py').read_text().split('# Finite successor')[0]);t=t.replace('Khmer/Lao','Javanese/Kyrgyz');(S/'tools/javanese_sundanese_kyrgyz_priority_expectations.py').write_text(t)
t=adapt((A/'source/Paintroid/src/test/java/org/catrobat/paintroid/local/AssameseKhmerLaoPriorityWordingTest.kt').read_text());t=t.replace('tag=="as" && count in 0..1','tag=="ky" && count==1').replace('// CLDR: Assamese integer 0/1 uses one; Khmer and Lao use only other.','// CLDR: Kyrgyz uses one for integer 1; Javanese and Sundanese use other.')
(S/'Paintroid/src/test/java/org/catrobat/paintroid/local/JavaneseSundaneseKyrgyzPriorityWordingTest.kt').write_text(t)
