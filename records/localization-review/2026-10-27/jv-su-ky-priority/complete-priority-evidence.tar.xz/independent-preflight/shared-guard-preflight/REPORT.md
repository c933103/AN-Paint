# Javanese / Sundanese / Kyrgyz shared-guard preflight

**Read-only preflight, not implementation or candidate acceptance.** Bound baseline: `b05a39d4e8b828abe04ee075b6a15db7127b3124`, tree `91dbdf1542c92382fb6b7c45afa2a3a9f8161dec`. The existing complete-source receipt reports 1,424 verified blobs/modes. `source-hashes.json` additionally binds the 82 inputs used in this finite review.

The upcoming candidates are not yet authored. The changes below become necessary **only for independently accepted corresponding additions**; no target text, source edit, fixture rewrite or new review credit is supplied here.

## Important ancestry warning

All counts in `inventory.json` are this **b05 baseline + this trio only**, not a future merge oracle. The parent reports AS/KM/LO already staged on PR192 lifecycle head `2119e48a`, with tagged counts **87 direct / 1 inherited / 83 English**. That staged head was not independently reverified by this preflight. Before implementing/publishing JV/SU/KY, bind the actual current parent and **union the already-reviewed AS additions and every other inherited finite adapter**. Do not replace that newer partition with the stale b05-plus-trio numbers below. Preserve AS's second-added-option successor while adding SU's separate first-added-option successor.

## 1. Extra concrete compatibility boundary: Sundanese registration versus live coverage

`su` is in `FIRST_ADDED_TAGS` (the immutable six-option cohort), not a new picker identity. It currently has zero strings/plurals and the live `translations/language-options.json` row is:

```json
{"tag":"su","name":"Sunda","translation_status":"not-started","fallback":"default-English"}
```

After reviewed translations are inserted, the following consumers need a **su-only** finite successor:

| File / consumer | Existing assertion | Required bounded reconciliation |
| --- | --- | --- |
| `tools/test_language_option_additions.py`, `test_six_requested_identities_match_picker_platform_metadata_and_catalogues` | Live metadata always says `not-started`, `default-English`. | Preserve all six identities, names, canonical paths and platform/picker checks. Check a truthful bounded live SU status against explicit reviewed evidence; preserve five other rows unchanged. `default-English` may remain truthful as the fallback for still-untranslated keys—it must not become a claim of complete translation. |
| Same file, `test_new_catalogues_honestly_declare_untranslated_default_fallback` | Reads the immutable addition record and applies `require_untranslated_option` to **current** SU XML; then asserts empty XML/dictionaries and all source keys missing. | Keep the immutable row's historical not-started/zero-coverage fields. Split only SU's current-resource branch into an exact independently reviewed successor inventory/value/attribute/plural guard, including absence of every unaccepted/held key. Keep unchanged empty-resource assertions for ha/ig/ln/yo/zu. Do not accept any arbitrary nonempty SU XML. |
| `Paintroid/src/test/.../AppLanguageTest.kt:45–73`, `sixNewOptionsKeepTheirIdentityAndExplicitEnglishFallback` | Forces SU `File`, `Brush`, `Save`, and the English substring `New or untranslated text appears in English.` at API30/35. | Keep identity, resource locale, process locale, display name, persisted selection and platform locale-manager switch checks. Replace only SU's four output expectations with exact reviewed complete displays. Keep exact English checks for the other five. Do not simply skip SU's assertions. Retain evidence that still-untranslated keys resolve to canonical English. |
| `Paintroid/src/main/res/values-b+su/strings.xml` comment | Says translation not started and no translated entries intentionally exist. | When authorized source authoring occurs, update this SU-only description truthfully. Do not claim native/layout certification or all-source completeness. |
| `translations/language-options.json` SU metadata | `not-started` becomes inaccurate once values are authored. | Update only SU's live progress description under the project's chosen bounded status convention. Do not rewrite immutable addition provenance or other locales' coverage states. |

**Preserve unchanged:** `tools/fixtures/language_option_additions_20261012.json`, the strict `require_untranslated_option` helper, `FIRST_ADDED_TAGS`, the 171-option picker, the separate global 59/112 scope contract and all other empty catalogues. The baseline has **31 empty locales**, so this trio must leave **30 other empty catalogues** intact; exact tag/path hashes are recorded. The first cohort's five unaffected locales and the second/third cohorts must not be silently granted SU's exception.

Add negative controls for a missing/empty/English-substituted/truncated reviewed SU value, missing or forged predecessor/source/attributes, extra unaccepted key/plural, falsely complete live status, and attempts to use SU's successor for another empty locale. Preserve existing helper rejection tests, which use an unaffected historical row.

## 2. Ordinary finite message-family additions

All **15** direct positions—three locales × the two memory warnings, two original-size SVG errors and tagged-colour error—are currently physically absent. Both memory queue entries are also explicitly null for each locale. `inventory.json` retains these actual rows; historical absence is not a translation decision or acceptance.

| Family | Exact b05 baseline | Conditional b05 + these three only |
| --- | --- | --- |
| Tagged colour | 84 direct + ca-ES-valencia→ca (1 inherited) + 86 English | **87 direct / 1 inherited / 83 English**; 84 missing direct resources |
| Memory no-resize | 77 physically present / 94 absent | **80 / 91** |
| Memory assembly floor | 84 physically present / 87 absent | **87 / 84** |
| Each SVG error | 77 offered direct catalogues; 78 fixture rows including default | **80 direct; 81 fixture rows** |
| SVG extra-tag set | 18 family additions outside global scope | **21** |

No new parent inheritance is implied by jv/su/ky. The frozen tagged fixture stays **76 entries**; existing Ukrainian, MR/TA/TE, KN/ML and NE/PA successors stay separate and unchanged. The frozen memory queue stays **62 present / 109 missing per key**, and the separately accepted-warning oracle stays **120 pairs / 60 locales**.

The finite implementation touchpoints, after exact target review, are:

- A trio-specific finite expectation binding with exact `TAGS={jv,su,ky}`, six memory pairs, six SVG pairs and three tagged pairs. Bind complete source/target/display, scalar/plural kind, attributes, and historical target/attribute absence; reject missing or forged bindings. Do not synthesize targets from actual resource output.
- `tools/memory_warning_source_review.py`: add only those six approved null→target selectors; union rather than replace existing additions. `accepted_warning` should still reject these priority-only pairs unless a separate accepted-warning review explicitly authorizes expanding that different oracle.
- `tools/test_memory_warning_source_review.py`: union the six additions into current physical counts, leaving frozen 62/109 unchanged.
- `tools/test_memory_warning_successors.py`: include six pairs in the exact qualified-priority branch, validate both old absence and complete current target, and reject using current text as the historical argument. At b05 alone, `qualified-new-priority` would change **20→26**, `missing` **181→175**; held=4, canonical=2, earlier qualified categories=4/11 remain unchanged. Recompute on the actual composition parent.
- `tools/test_current_localization_contracts.py`: extend only the SVG family and tagged family, including inventory/status expectations, complete-target comparison, exact English fallback partition and finite display-decoding handling if the reviewed raw targets require quoting/escapes. Keep all existing mutation/parent-inheritance negatives.
- `Paintroid/src/test/.../TaggedColourImportTest.kt`: add three complete reviewed displays after the already-composed successor blocks; preserve the frozen 76 and all predecessor count checks. Update final direct/fallback arithmetic only after rebinding the actual parent. Keep all 171 actual Android-resource comparisons and sRGB/PNG / wrong-format token checks.

No concrete candidate diff is appropriate yet: target values, attribute choices and any additionally reviewed context/plural work do not exist. The 341 denominator is a typed priority-accounting scope here (all string identities), not permission to manufacture translations or count an unreviewed addition as accepted.

## 3. Other actual-consumer assumptions inspected

- **Javanese has a genuine current alias constraint:** `AppLanguageTest.kt:259–278` treats it as a starter catalogue, requires non-all-English Brush/Save/Cancel vocabulary, `ui_keep_editing23 != ui_discard_changes23`, and **`ui_save_a5d0d9` resolves exactly to `ui_save`**. Current Javanese source is `@string/ui_save`, and this is among the five retained values already read in the separate preflight. This is not a stale English pin; preserve the alias semantics unless a new exact reviewed requirement says otherwise.
- **Kyrgyz's** `AppLanguageTest.kt:408–417` extra-language loop checks identity, not an English wording pin. Its 35 physical strings comprise 33 priority values plus two outside-scope entries; no blanket rewrite follows from the new unit.
- No additional hardcoded jv/su/ky English-output pin was found in the bounded host/JVM tag-reference and all-offered-family scan. `ImageDisplayLocaleTest`'s known Albanian fallback pin is outside this trio; do not treat it as a JV/SU/KY defect or fix it incidentally.
- Generic all-offered Commons metadata, copy-credit, import-failure, empty-credit, external-link, native-component, redirect and Help/provider fallback tests were checked for overlap. Their protected message keys are **outside this 341-key priority set**, except the two SVG keys already listed. Their jv/su/ky English fallbacks must stay untouched in this bounded unit. `CommonsCopyCreditTranslationTest` explicitly lists all three as fallback tags; do not remove them just because unrelated priority strings become localized.
- Global identity/number-input/resource-routing loops do not force new trio English wording; preserve their invariants rather than adding translation-driven exceptions.
- `test_localized_help.py` has **actual-caption composition** guards that will newly apply to inserted priority prose: paste guidance must reference Draw→Insert→Other images; the protected-draft warning must keep the complete File→Export recovery copy and File→Save as routes in that order, with PNG/JPEG after Save as. These are not old English fallbacks to relax. Candidate prose should use the reviewed actual captions; if a necessary language-specific equivalence arises, it needs its own exact review. Stopped Help/archive/callback work is not reopened.
- GIMP/import provenance tests preserve original reference text and contexts rather than freezing current Kyrgyz target wording. The current `translation_source:GIMP` / Javanese `starter_translation:true` fields are provenance, not new acceptance receipts.

## 4. Prior receipts and held keys: evidence, not absence reasoning

The supplied eligibility reconciliation explicitly records no mapped exact receipt matches at registry revision `5ece04b6c604b98fc0e59db600c728e541d08261` and explicitly warns that this does **not** prove no historical work existed. This bounded local scan did not recover an additional genuine exact prior held-key receipt for these three. It cannot replace wider historical reconciliation if new evidence surfaces.

The current full inventories already preserve the following **seven absent keys in each locale**, based on exact no-current-consumer scope—not because the registry is empty:

- P0: `formats22_derived_exported`, `ui_save_as`, `ui_save_as_jpeg`, `ui_save_as_jpeg_xl`, `ui_save_as_png`.
- P1: `ui_foreground_background_colour_palette`, `ui_pinch_and_pan_mode`.

Keep these absent unless a separately authorized exact consumer/review decision supersedes that hold. The frozen memory queue's `needs-review` fields and ordinary current source provenance are not new held-key prohibitions. The existing retained-value report's Javanese five accepted retained values and Kyrgyz 32 accepted + one revision pending remain their separate outcomes; this preflight grants no further linguistic credit.

## 5. Verification and next checks

The **unchanged b05 source** passed 36 focused host tests (12.029 s): `test_language_option_additions`, `test_memory_warning_source_review`, `test_memory_warning_successors`, `test_current_localization_contracts`. This is baseline evidence, not a candidate pass or Android evidence. See `baseline-focused-host.log`.

After independently reviewed additions and finite successor adoption, rerun those modules, the new full-trio fixture/source/mutation tests, `test_localized_help`, `test_translations`, first/second/third option tests and the complete host suite normally and under `-O`. On the authorized exact-source Android workflow, run `AppLanguageTest` (including identity/platform round trips), `TaggedColourImportTest`, and the new trio actual-consumer test class. No Android/Kotlin compilation or runtime work occurred in this preflight.

No app/test source edit, external publication or Work task occurred. All existing project holds remain unchanged.
