from pathlib import Path
import sys,json,hashlib,re
HERE=Path(__file__).resolve().parent;LANE=HERE.parent.parent;ROOT=LANE/'source'
sys.path.insert(0,str(ROOT/'tools'));sys.dont_write_bytecode=True
import translation_catalogues as c
import test_current_localization_contracts as contracts
import memory_warning_source_review as m
from language_option_additions import FIRST_ADDED_TAGS,SECOND_ADDED_TAGS,ADDITIONS_PATH
paths=c.catalogue_paths();offered=set(c.offered_tags());strings={tag:c.read_strings(path) for tag,path in paths.items()}
keys=m.KEYS|{'commons_svg_original_size_unavailable','commons_svg_original_size_too_large','save20_unsupported_image_colour'}
rows={};metadata={o['tag']:o for o in json.loads((ROOT/'translations/language-options.json').read_text())['options']}
q=m.review_record();inventory=json.loads((LANE/'candidate-public/jv-complete-inventory.json').read_text());priority={r['identity'].split('/',1)[1] for r in inventory['rows']}
for tag in ('jv','su','ky'):
 rows[tag]={'catalogue':str(paths[tag].relative_to(ROOT)),'physical_strings':len(strings[tag]),'physical_plurals':len(c.read_plurals(paths[tag])),'metadata':metadata[tag],'family_predecessors':{}}
 for key in sorted(keys):
  assert key not in strings[tag]
  queue=next(o for o in q['options'] if o['tag']==tag)['terms'][key] if key in m.KEYS else None
  if queue is not None:assert queue['value'] is None
  rows[tag]['family_predecessors'][key]={'resource_present':False,'target':None,'attributes':None,'memory_queue_row':queue}
old=contracts.current_tagged_colour_data();inherited=contracts.TAGGED_COLOUR_INHERITED_CATALOGUES
memory={}
for key in sorted(m.KEYS):
 current={t for t in offered if key in c.read_strings(c.RES/'values/strings.xml' if t=='en-001' else paths[t])}
 historic={o['tag'] for o in q['options'] if o['terms'][key]['value'] is not None}
 memory[key]={'baseline_present':len(current),'baseline_missing':len(offered-current),'historical_present':len(historic),'historical_missing':len(offered-historic),'conditional_trio_only_present':len(current)+3,'conditional_trio_only_missing':len(offered-current)-3}
empty=sorted(t for t in offered if not strings[t] and not c.read_plurals(paths[t]))
first=json.loads(ADDITIONS_PATH.read_text());surow=next(x for x in first['languages'] if x['tag']=='su')
families={}
family_names=['commons_metadata_current_wording.json','commons_copy_credit_current_wording.json','commons_svg_current_wording.json','commons_import_failures_current_wording.json','gallery_empty_credit_current_wording.json','gallery_external_link_current_wording.json','gallery_native_component_current_wording.json','gallery_redirect_current_wording.json','help_commons_provider_current_contract.json']
for name in family_names:
 p=ROOT/'tools/fixtures/current_localization'/name
 if p.exists():
  d=json.loads(p.read_text());ks=set(d.get('values',{}));families[name]={'keys':sorted(ks),'priority_intersection':sorted(ks & priority)}
held={}
for tag in rows:
 d=json.loads((LANE/f'candidate-public/{tag}-complete-inventory.json').read_text())
 held[tag]=[{k:r[k] for k in ('identity','tier','author_disposition','hold_reason') if k in r} for r in d['rows'] if r['author_disposition']=='hold-absent']
receipt={'source_commit':'b05a39d4e8b828abe04ee075b6a15db7127b3124','source_tree':'91dbdf1542c92382fb6b7c45afa2a3a9f8161dec','scope':'Preflight only; no uncreated candidate acceptance. Counts are conditional b05 baseline + this trio ONLY, not future integration counts.','locales':rows,'tagged':{'baseline_direct':len(old),'baseline_inherited':inherited,'baseline_english':len(offered-set(old)-set(inherited)),'conditional_trio_only_direct':len(old)+3,'conditional_trio_only_inherited':len(inherited),'conditional_trio_only_english':len(offered-set(old)-set(inherited))-3},'memory':memory,'svg':{'baseline_offered_direct_per_key':len(contracts.wording_tags(contracts.FAMILIES[2]))-1,'baseline_fixture_rows_per_key':len(contracts.wording_tags(contracts.FAMILIES[2])),'conditional_trio_only_offered_direct':len(contracts.wording_tags(contracts.FAMILIES[2]))+2,'conditional_trio_only_fixture_rows':len(contracts.wording_tags(contracts.FAMILIES[2]))+3},'first_additions_su_frozen_row':surow,'first_added_tags':sorted(FIRST_ADDED_TAGS),'second_added_tags':sorted(SECOND_ADDED_TAGS),'all_empty_baseline_tags':empty,'must_remain_empty_for_this_trio':sorted(set(empty)-{'su'}),'outside_priority_family_contracts':families,'held_absent_inventory':held,'prior_receipt_qualification':'Registry reconciliation has no mapped exact matches; this does not prove no historical work existed. Frozen predecessor absence and source provenance are not linguistic review or held-value receipts.'}
(HERE/'inventory.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
inputs={}
def bind(p):
 raw=p.read_bytes();inputs[str(p.relative_to(LANE))]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
for name in ['complete-source-verification.json','eligibility-receipt-reconciliation.json','candidate-public/source-bindings.json','candidate-public/jv-complete-inventory.json','candidate-public/su-complete-inventory.json','candidate-public/ky-complete-inventory.json','independent-preflight/complete-retained-preflight.json']:
 bind(LANE/name)
for name in ['tools/language_option_additions.py','tools/test_language_option_additions.py','tools/test_language_option_additions_second.py','tools/test_language_option_additions_third.py','tools/fixtures/language_option_additions_20261012.json','tools/fixtures/language_option_additions_20261012_second.json','tools/fixtures/language_option_additions_20261014.json','tools/memory_warning_source_review.py','tools/test_memory_warning_source_review.py','tools/test_memory_warning_successors.py','tools/memory_warning_successors.py','tools/test_current_localization_contracts.py','tools/test_localized_help.py','tools/test_translations.py','translations/language-options.json','translations/source-review/memory-warnings-20261021.json','translations/source-review/memory-warning-successors-amharic-20261025.json','Paintroid/src/test/resources/tagged-colour/expected.json','tools/fixtures/current_localization/locale_contract_scope.json']:
 bind(ROOT/name)
for name in family_names:
 p=ROOT/'tools/fixtures/current_localization'/name
 if p.exists():bind(p)
for tag in ('jv','su','ky',*empty):bind(paths[tag])
for name in ['AppLanguageTest.kt','TaggedColourImportTest.kt','CommonsCopyCreditTranslationTest.kt','CommonsImportFailureTranslationTest.kt','CommonsCreditFlowTest.kt','GalleryNativeComponentFailureTest.kt','GalleryExternalLinkTest.kt','CommonsHelpProviderTranslationTest.kt','CommonsMetadataHttpTranslationTest.kt','CommonsMetadataQueryFailureTranslationTest.kt','CommonsMetadataResponseLimitTranslationTest.kt','ImageDisplayLocaleTest.kt','ApplicationLocaleConfigurationTest.kt','LocaleNumberInputTest.kt']:
 bind(ROOT/'Paintroid/src/test/java/org/catrobat/paintroid/local'/name)
(HERE/'source-hashes.json').write_text(json.dumps(inputs,indent=2)+'\n')
print('Bound inputs',len(inputs),'baseline tagged',receipt['tagged'],'baseline empties',len(empty),'preserve',len(empty)-1)
