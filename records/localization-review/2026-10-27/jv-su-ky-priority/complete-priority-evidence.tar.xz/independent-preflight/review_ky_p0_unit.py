from pathlib import Path
import json,hashlib,collections,copy,sys,xml.etree.ElementTree as E
P=Path(__file__).resolve().parents[1];S=P/'source';O=P/'independent-review';O.mkdir(exist_ok=True);sys.path.insert(0,str(S/'tools'));import translation_catalogues as tc
sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
bind=json.load(open(P/'candidate-public/source-bindings.json'))
for r in bind['bindings']:
 b=(S/r['path']).read_bytes();assert sha(b)==r['sha256'] and blob(b)==r['git_blob_sha1']
en={x.attrib['name']:x for x in E.parse(S/'Paintroid/src/main/res/values/strings.xml').getroot()};summ=[]
for tag in ['ky']:
 f=P/f'candidate-public/{tag}-complete-author-packet.json';d=json.load(open(f));loc={x.attrib['name']:x for x in E.parse(S/d['catalogue_path']).getroot()};rows=[];windows=0
 for orig in d['rows']:
  if orig['tier']!='P0':continue
  r=copy.deepcopy(orig);k=r['identity'].split('/')[1];assert en[k].text==r['english']['value'] and en[k].attrib==r['english']['attributes']
  if r['current'] is None:assert k not in loc
  else:assert loc[k].text==r['current']['value'] and loc[k].attrib==r['current']['attributes']
  for c in r['direct_consumers']:
   assert '\n'.join((S/c['path']).read_text().splitlines()[c['start_line']-1:c['end_line']])==c['context'];windows+=1
  if r['author_disposition']=='hold-absent':
   assert r.get('proposal') is None;r.update(decision='hold_absent',rationale='Exact established no-current-consumer hold; no new contextual evidence or proposed value.');rows.append(r);continue
  v=r['proposal'];assert isinstance(v,str) and v;assert not tc.android_string_errors(v);assert not tc.format_string_errors(v,r['english']['attributes'].get('formatted')!='false')
  if not v.startswith('@string/'):assert tc.placeholders(v)==tc.placeholders(r['english']['value'])
  reason='Complete value preserves the source meaning, action/result distinction, qualifiers, typed arguments and actual static caller role without a concrete required wording defect.'
  if 'credit' in k:reason='Complete source/licence/attribution scope is explicit and collection-neutral; stored-copy, previous-drawing preservation and retry clauses remain complete.'
  elif 'animation' in k or k=='save20_gif_description':reason='Still/animated distinction, first-frame/default-image handling and non-preservation warning remain complete. Exact/lower-bound frame numbers compose without number-dependent noun agreement.'
  elif any(x in k for x in ['memory','pixels_2f','encoding_budget']):reason='Complete memory estimates, source/original preservation and refusal/no-automatic-resize clauses are retained as applicable; invariant px and image subject support a 1×1 or zero-budget warning.'
  elif any(x in k for x in ['undo','history','top_left']):reason='Operation-reversal vocabulary is distinct from generic Cancel; exact future Undo label is named in the top-left anchoring/right-or-bottom loss warning. Full cache/history/recovery clauses retained.'
  elif any(x in k for x in ['recovery_copy','export_did','autosave_is_paused','save_explanation','share_explanation']):reason='Complete Save/export/share/recovery distinctions retained, with exact submitted File/Save/Save-as/Load/recovery commands and unchanged technical filenames. Atomic final control-label verification remains required.'
  if k=='ui_save_a5d0d9' and tag=='jv':reason='Retain exact existing @string/ui_save alias and its Simpen display; prior retained-value preflight is the same pair, not additional review credit.'
  r.update(decision='accept_complete_value_bounded',reviewed_value=v,reviewed_attributes=r['current']['attributes'] if r['current'] else r['english']['attributes'],rationale=reason,confidence='Medium model linguistic/technical confidence; high exact source, formatting and caller binding. No native-human, installed-layout or accessibility-usability certification.',context_limit='Wording-only, no direct current consumer.' if not r['direct_consumers'] else 'Actual static caller context; no new runtime execution claim.')
  if tag=='su' and k=='ui_the_trim_would_remove_the_entire_image':r.update(decision='revise_pending_author_second_check',reviewed_value='Lamun dipotong kieu, sakabéh gambar bakal leungit.',rationale='Replace the doubtful derived noun Pangpotongan with a direct conditional: trimming in this way removes the entire image. Complete safety meaning preserved; this is a bounded morphology/idiom judgment, not a claim of dictionary proof.')
  rows.append(r)
 assert len(rows)==92
 out={'source_commit':d['source_commit'],'source_tree':d['source_tree'],'locale':tag,'catalogue_path':d['catalogue_path'],'scope':'Full 92-identity P0 unit inside the continuing 341-identity language review. No P1/dependency or full-trio completion claim.','candidate_packet_sha256':sha(f.read_bytes()),'verified_relevant_source_files':len(bind['bindings']),'verified_direct_consumer_windows':windows,'counts':dict(collections.Counter(r['decision']for r in rows)),'rows':rows,'pending_atomic_checks':['Exact full P1 File, Load image and Undo labels and recovery menu route composition.','Frame lower-bound, GIF dither, lossless and quality controls from the complete adjacent dependency packet.'],'prior_credit':'Javanese existing Save and Save-alias pairs were already read in retained preflight; this P0 unit rebinds them without double credit. No historical independent candidate acceptance is inferred from empty registry results.','terms':[{'url':'https://help.openai.com/jv-id/articles/11084440-images-in-chatgpt','scope':'Only Javanese undo/redo/cancel/save/share UI terminology corroboration; not a native-human or whole-translation acceptance authority.'}] if tag=='jv' else [{'url':'https://github.com/GNOME/gimp/blob/master/po/ky.po','scope':'Previously inspected Kyrgyz history, Save-as, scale and system-language terminology; not complete new-sentence certification.'}]}
 dest=O/f'{tag}-p0-complete-review-v1.json';dest.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');summ.append({'locale':tag,'counts':out['counts'],'windows':windows,'sha256':sha(dest.read_bytes())})
print(json.dumps(summ,indent=2))
