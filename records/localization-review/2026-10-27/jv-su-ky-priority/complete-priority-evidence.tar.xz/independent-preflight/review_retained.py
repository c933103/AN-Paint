from pathlib import Path
import json,hashlib,copy,collections,xml.etree.ElementTree as ET,sys
D=Path(__file__).resolve().parents[1];S=D/'source';O=D/'independent-preflight';sys.path.insert(0,str(S/'tools'));import translation_catalogues as tc
sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();B=json.loads((D/'candidate-public/source-bindings.json').read_text())
for r in B['bindings']:
 b=(S/r['path']).read_bytes();assert sha(b)==r['sha256'] and blob(b)==r['git_blob_sha1']
base=json.loads((D/'base-tree.json').read_text());n=0
for r in base['tree']:
 if r['type']!='blob':continue
 p=S/r['path'];assert blob(p.read_bytes())==r['sha'];assert ('100755'if p.stat().st_mode&0o111 else '100644')==r['mode'];n+=1
assert n==1424
english={x.get('name'):x for x in ET.parse(S/'Paintroid/src/main/res/values/strings.xml').getroot()};out=[];summary=[]
for tag in ['jv','su','ky']:
 p=D/f'candidate-public/{tag}-complete-inventory.json';j=json.loads(p.read_text());assert len(j['rows'])==341 and collections.Counter(r['tier']for r in j['rows'])=={'P0':92,'P1':249}
 loc={x.get('name'):x for x in ET.parse(S/j['catalogue_path']).getroot()};present=[]
 for r in j['rows']:
  if not r['current']:continue
  r=copy.deepcopy(r);key=r['identity'].split('/',1)[1];e=english[key];v=loc[key];assert r['english']['value']==e.text and r['english']['attributes']==dict(e.attrib);assert r['current']['value']==v.text and r['current']['attributes']==dict(v.attrib)
  for c in r['direct_consumers']:assert '\n'.join((S/c['path']).read_text().splitlines()[c['start_line']-1:c['end_line']])==c['context']
  value=v.text;assert not tc.android_string_errors(value);assert not tc.format_string_errors(value,v.get('formatted')!='false')
  if not value.startswith('@string/'):assert tc.placeholders(value)==tc.placeholders(e.text)
  r.update(decision='accept_retained_bounded',reviewed_value=value,reviewed_attributes=dict(v.attrib),rationale='Complete inherited label and actual action/heading role are sound at bounded model confidence; retain exact quote/spacing/alias bytes without cosmetic rewriting.',confidence='Medium model linguistic confidence, high exact source/current/caller binding; no native-human or rendered-layout certification.',context_limit='No direct current consumer: wording-only.' if not r['direct_consumers']else 'Current Help route remains limited; no reactivation or runtime claim.' if key=='ui_menu_help'else 'Actual static caller bound; no new installed runtime/layout claim.')
  if key=='ui_save_a5d0d9':r['rationale']='Preserve exact inherited @string/ui_save alias and resolve the displayed label through the unchanged Save resource. Source continuation ellipsis does not justify changing an established alias in isolation.'
  if tag=='jv'and key in ['ui_save','ui_cancel']:r['rationale']='Official Sony Javanese manual corroborates the Save-image/Cancel labels. Existing action meaning is sound; primary scope is narrow, not whole-sentence certification.'
  if tag=='jv'and key=='ui_menu_edit':r['rationale']='Existing editing loan labels the actual Edit menu. No concrete semantic defect established; absence from consulted upstream catalogues is not evidence it is invalid.'
  if tag=='ky'and key in ['ui_resize_image','ui_resize_image_ab28be','ui_rotate','ui_undo','ui_redo','save20_title','language20_device_default']:r['rationale']='Official GNOME GIMP Kyrgyz confirms the specialised scale-image, rotation, history, Save-as or system-language term. Preserve this actual UI use; a preliminary dictionary-gloss concern is resolved by primary context, not forced into a new correction.'
  if tag=='ky'and key=='ui_languages23':r['rationale']='Language is a natural singular name for the real command opening the language picker; no need to force plural morphology solely to copy the English button label.'
  if tag=='ky'and key=='language20_app_language':r.update(decision='revise_candidate_pending_author_second_check',reviewed_value='"Колдонмонун тили"',rationale='The current bare Language heading omits the App qualifier. Proposed complete app-language title restores that scope and preserves the existing raw Android quote wrapper; author second-check and final full-map review remain required.')
  present.append(r)
 out.extend(present);summary.append({'locale':tag,'taxonomy':{'P0':92,'P1':249},'retained_rows_read':len(present),'counts':dict(collections.Counter(r['decision']for r in present)),'missing_candidates_not_accepted':sum(r['current']is None for r in j['rows'])-7,'exact_absent_holds':7,'packet_sha256':sha(p.read_bytes())})
assert len(out)==38
report={'source_commit':B['source_commit'],'source_tree':B['source_tree'],'scope':'Complete read of all 38 existing priority values within the continuing full Javanese/Sundanese/Kyrgyz 341-entry assignments. No missing candidate acceptance or full-trio completion claim.','all_repository_blobs_modes_verified':n,'verified_relevant_blobs':len(B['bindings']),'summary':summary,'rows':out,'primary_evidence':'primary-terminology.json','history':'Recovered registry has no exact/partial/superseded receipt matches for these locales; not proof that no historical work exists.','limits':['App resources remain untouched.','Only the exact Kyrgyz App-language successor is proposed; author second-check is pending.','Full missing P0/P1 values and all actual atomic dependencies remain unreviewed until submitted.','Seven precise absent holds per language remain; held routes are not reactivated.','Bounded model review is not native-speaker, whole-language, installed-layout or accessibility-usability certification.']}
(O/'complete-retained-preflight.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,indent=2));print('SHA256',sha((O/'complete-retained-preflight.json').read_bytes()))
