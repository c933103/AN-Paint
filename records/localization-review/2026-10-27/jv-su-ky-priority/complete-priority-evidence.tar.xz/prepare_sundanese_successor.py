from pathlib import Path
import json
B=Path(__file__).resolve().parent;S=B/'source';O=B/'option-successor';O.mkdir(exist_ok=True)
A=B.parent/'as-km-lo-p0-p1-20261027/source'
helper=(A/'tools/assamese_khmer_lao_priority_expectations.py').read_text().split('# Finite successor')[1]
helper='# Finite successor'+helper
helper=helper.replace('Assamese','Sundanese').replace('assamese','sundanese').replace('ASSAMESE','SUNDANESE').replace("'as'","'su'").replace('অসমীয়া','Sunda').replace('values-b+as/','values-b+su/')
p=S/'tools/javanese_sundanese_kyrgyz_priority_expectations.py';(O/p.name).write_text(p.read_text()+helper)
p=S/'tools/test_language_option_additions.py';s=p.read_text().replace('from language_option_additions import require_untranslated_option','from language_option_additions import require_untranslated_option\nfrom javanese_sundanese_kyrgyz_priority_expectations import SUNDANESE_OPTION_STATUS, require_sundanese_option_successor')
s=s.replace("self.assertEqual('not-started', entries[0]['translation_status'])","self.assertEqual(SUNDANESE_OPTION_STATUS if tag=='su' else 'not-started', entries[0]['translation_status'])")
s=s.replace("            require_untranslated_option(row, path.read_text())",'''            if row['tag']=='su':
                root=require_sundanese_option_successor(row,path.read_text())
                self.assertEqual([],catalogues.validate_catalogue('su'))
                present_strings={n.get('name') for n in root if n.tag=='string'}
                present_plurals={n.get('name') for n in root if n.tag=='plurals'}
                missing_strings=source_strings-present_strings;missing_plurals=source_plurals-present_plurals
                self.assertTrue(missing_strings);self.assertFalse(missing_plurals)
                self.assertEqual([
                    f"su: missing {len(missing_strings)} strings: {', '.join(sorted(missing_strings)[:20])}",
                ],catalogues.validate_catalogue('su',require_complete=True))
                continue
            require_untranslated_option(row, path.read_text())''')
ref=(A/'tools/test_language_option_additions_second.py').read_text();start=ref.index('    def test_only_exact_reviewed_assamese');end=ref.index("if __name__",start)
test=ref[start:end].replace('assamese','sundanese').replace('SECOND_ADDITIONS_PATH','ADDITIONS_PATH').replace("'as'","'su'")
s=s.replace("if __name__ == '__main__':",test+"if __name__ == '__main__':")
(O/p.name).write_text(s)
p=S/'translations/language-options.json';d=json.loads(p.read_text());r=next(r for r in d['options'] if r['tag']=='su');assert r['translation_status']=='not-started';r['translation_status']='partial-priority-reviewed';(O/p.name).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
p=S/'Paintroid/src/test/java/org/catrobat/paintroid/local/AppLanguageTest.kt';s=p.read_text();start=s.index('fun sixNewOptionsKeepTheirIdentity');end=s.index('fun furtherOptionsIncluding',start)
old='''            assertEquals("File",wrapped.getString(R.string.ui_menu_file))
            assertEquals("Brush",wrapped.getString(R.string.ui_brush))
            assertEquals("Save",wrapped.getString(R.string.ui_save))
            assertTrue(wrapped.getString(R.string.language20_translation_note)
                .contains("New or untranslated text appears in English."))'''
assert s[start:end].count(old)==1
v=json.loads((B/'independent-review/su-complete-review.json').read_text())['accepted_display_values'];keys=['ui_menu_file','ui_brush','ui_save','language20_translation_note']
def kotlin(v):return json.dumps(v,ensure_ascii=False).replace('$','\\$')
new='''            if (tag == "su") {
                // Exact reviewed priority successor; the other five options keep English fallback.
'''+''.join(f'                assertEquals({kotlin(v[k])},wrapped.getString(R.string.{k}))\n'for k in keys)+'''            } else {
'''+''.join('    '+x+'\n'for x in old.splitlines())+'''            }'''
s=s[:start]+s[start:end].replace(old,new)+s[end:];(O/p.name).write_text(s)
print('Staged exact Sundanese successor; frozen historical fixture untouched.')
