from pathlib import Path
import subprocess,json,hashlib
R=Path('/tmp/seasia-priority-20261029/integration');out={}
def original(p):return subprocess.check_output(['git','-C',str(R),'show','0070c5816ad31911d227fab50ea193e2a39b13ab:'+p],text=True)
def check(p,s,changes):
 new=(R/p).read_text();old=original(p);assert s==old,p
 out[p]={'base_bytes':len(old.encode()),'new_bytes':len(new.encode()),'new_sha256':hashlib.sha256(new.encode()).hexdigest(),'all_other_original_bytes_exact':True,'bounded_changes':changes}
p='tools/memory_warning_source_review.py';s=(R/p).read_text();s=s.replace('from hindi_gujarati_priority_expectations import MEMORY_ADDITIONS as HI_GU_ADDITIONS, current_row as hi_gu_row\n','',1);a=s.index('    if (tag,key) in HI_GU_ADDITIONS:');b=s.index('    if (tag,key) in AS_KM_LO_ADDITIONS:',a);s=s[:a]+s[b:];check(p,s,['Import exact4 HI/GU key/tag pairs','Accept only previously absent HI/GU complete source-bound warning additions; reject mismatched source/attributes/predecessors'])
for p in ['tools/test_memory_warning_source_review.py','tools/test_memory_warning_successors.py']:
 s=(R/p).read_text().replace('KN_ML_ADDITIONS, HI_GU_ADDITIONS,','KN_ML_ADDITIONS,').replace('KN_ML_ADDITIONS | HI_GU_ADDITIONS |','KN_ML_ADDITIONS |');check(p,s,['Add HI/GU4 exact pairs to existing addition union, retaining all original assertions and other locales'])
p='tools/test_current_localization_contracts.py';s=(R/p).read_text();s=s.replace('from hindi_gujarati_priority_expectations import TAGS as HI_GU_TAGS, current_row as hi_gu_row, display as hi_gu_display\n','',1)
for indent,startmark,endmark in [(8,'for tag in sorted(HI_GU_TAGS):','for tag in sorted(NE_PA_TAGS):'),(4,'for tag in sorted(HI_GU_TAGS):','for tag in sorted(NE_PA_TAGS):'),(4,'for tag in HI_GU_TAGS:','for tag in NE_PA_TAGS:')]:
 a=s.index('\n'+' '*indent+startmark)+1;b=s.index('\n'+' '*indent+endmark,a)+1;s=s[:a]+s[b:]
s=s.replace('KN_ML_TAGS | HI_GU_TAGS |','KN_ML_TAGS |').replace('set(KN_ML_TAGS) | set(HI_GU_TAGS) |','set(KN_ML_TAGS) |').replace('or catalogue in SO_WO_HT_TAGS or catalogue in HI_GU_TAGS)','or catalogue in SO_WO_HT_TAGS)');check(p,s,['Finite2 HI/GU SVG/colour additions with prior-absence/source/attribute checks','Explicit HI/GU union membership and Android outer quote decoding; all other original bytes preserved'])
Path('/tmp/seasia-priority-20261029/shared-hi-gu-preservation-proof.json').write_text(json.dumps(out,indent=2)+'\n')
for p in out:print(p,'PASS original bytes restored by reversing only listed HI/GU changes')
