from pathlib import Path
import subprocess,json,hashlib,re,xml.etree.ElementTree as E,collections
R=Path('/tmp/seasia-priority-20261029/thai');root=R.parent;base='4dadb287b1f8a5e16451fa0817652670f0b1d05f';out={}
def original(p):return subprocess.check_output(['git','-C',str(R),'show',base+':'+p],text=True)
def check(p,s,scope):
 old=original(p);new=(R/p).read_text();assert s==old,p
 out[p]={'old_bytes':len(old.encode()),'new_bytes':len(new.encode()),'new_sha256':hashlib.sha256(new.encode()).hexdigest(),'all_other_bytes_exact':True,'scope':scope}
p='tools/memory_warning_source_review.py';s=(R/p).read_text();s=s.replace('from thai_priority_expectations import MEMORY_ADDITIONS as THAI_ADDITIONS, current_row as thai_row\n','');s=re.sub(r'    if \(tag,key\) in THAI_ADDITIONS:.*?(?=    if \(tag,key\) in AS_KM_LO_ADDITIONS:)','',s,flags=re.S);check(p,s,'Exactly2 Thai memory warning additions, source/attrs/prior-absence guarded')
for p in ['tools/test_memory_warning_source_review.py','tools/test_memory_warning_successors.py']:
 s=(R/p).read_text().replace('HI_GU_ADDITIONS, THAI_ADDITIONS,','HI_GU_ADDITIONS,').replace('| HI_GU_ADDITIONS | THAI_ADDITIONS |','| HI_GU_ADDITIONS |');check(p,s,'Only2 Thai pairs added to existing finite union')
p='tools/test_current_localization_contracts.py';s=(R/p).read_text().replace('from thai_priority_expectations import TAGS as THAI_TAGS, current_row as thai_row, display as thai_display\n','')
for pat in [r'        for tag in sorted\(THAI_TAGS\):.*?(?=        for tag in sorted\(HI_GU_TAGS\):)',r'    for tag in sorted\(THAI_TAGS\):.*?(?=    for tag in sorted\(HI_GU_TAGS\):)',r'    for tag in THAI_TAGS:.*?(?=    for tag in HI_GU_TAGS:)']:s=re.sub(pat,'',s,flags=re.S)
s=s.replace('| HI_GU_TAGS | THAI_TAGS |','| HI_GU_TAGS |').replace('| set(HI_GU_TAGS) | set(THAI_TAGS) |','| set(HI_GU_TAGS) |').replace('or catalogue in HI_GU_TAGS or catalogue in THAI_TAGS)','or catalogue in HI_GU_TAGS)');check(p,s,'Only finite Thai SVG/colour full-value bindings, unions and outer quote support')
p='Paintroid/src/test/java/org/catrobat/paintroid/local/TaggedColourImportTest.kt';s=(R/p).read_text();s=re.sub(r'    @Test fun replacementThai.*?(?=    @Test fun explicitSrgb)','',s,flags=re.S);s=s.replace('        ThaiPriorityExpectations.addTagged(expected,ThaiPriorityExpectations.fixture())\n        assertEquals(144, expected.length())\n','').replace('assertEquals(27, fallbacks) // 171 offered - 144 direct, including Thai replacement; no inherited catalogue.','assertEquals(28, fallbacks) // 171 offered - 143 direct, including recovered HI/GU; no inherited catalogue.');check(p,s,'Only Thai negative probes and1 added expected tag;143/28 successor becomes144/27 after all preserved checkpoints')
p='Paintroid/src/test/java/org/catrobat/paintroid/local/CommonsSvgErrorTranslationTest.kt';s=(R/p).read_text().replace('"am","ast","gu","th")','"am","ast","gu")');s=re.sub(r'        "th" to mapOf\(.*?\n        \),\n','',s,count=1,flags=re.S);check(p,s,'Only Thai representative and2 exact independently reviewed SVG reasons; unrelated locale tests exact')
packet=json.loads((root/'thai-replacement-accepted.json').read_text());p='Paintroid/src/main/res/values-th/strings.xml'
def nodes(text):
 d={}
 for n in E.fromstring(text):
  if 'name' not in n.attrib:continue
  n.tail=None;d[n.tag+'/'+n.attrib['name']]=E.tostring(n,encoding='unicode')
 return d
old=nodes(original(p));new=nodes((R/p).read_text());changed={r['identity'] for r in packet['rows'] if r['decision']=='candidate'};assert all(new[k]==v for k,v in old.items() if k not in changed)
for row in packet['rows']:
 if row['decision']=='candidate':
  n=E.fromstring(new[row['identity']]);v={c.attrib['quantity']:c.text for c in n} if n.tag=='plurals' else n.text;assert v==row['proposed']['value'];assert n.attrib==row['proposed']['attributes']
out['catalogue']={'accepted_edits':len(changed),'unrelated_original_nodes_exact':len(old.keys()-changed),'by_tier':dict(collections.Counter(r['tier'] for r in packet['rows'] if r['decision']=='candidate')),'independent_required_fill_change_applied':True}
(root/'thai-preservation-proof.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out['catalogue']))
