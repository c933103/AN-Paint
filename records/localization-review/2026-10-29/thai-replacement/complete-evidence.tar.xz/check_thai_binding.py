import json,subprocess,xml.etree.ElementTree as E,hashlib
from pathlib import Path
r=Path('/tmp/seasia-priority-20261029');repo=r/'thai';p=json.loads((r/'thai-replacement-accepted.json').read_text());base=p['source_commit'];pred='8ca88befb765d19dee0e0db05a4033e9d1fbf60b'
def raw(path,ref=base):return subprocess.check_output(['git','-C',str(repo),'show',ref+':'+path],text=True)
def vals(text):
 return {n.tag+'/'+n.attrib['name']:{'attributes':n.attrib,'value':{c.attrib['quantity']:c.text for c in n} if n.tag=='plurals' else n.text} for n in E.fromstring(text) if 'name'in n.attrib}
a=vals(raw('Paintroid/src/main/res/values/strings.xml'));b=vals(raw('Paintroid/src/main/res/values-th/strings.xml'));windows=0;files={}
for row in p['rows']:
 assert a[row['identity']]==row['source'];assert b.get(row['identity'])==row['current']
 for c in row['direct_consumers']:
  if c['path'] not in files:files[c['path']]=raw(c['path'])
  lines=files[c['path']].splitlines();assert '\n'.join(lines[c['start_line']-1:c['end_line']])==c['context'];windows+=1
for f,t in files.items():assert (repo/f).read_text()==t
assert raw('Paintroid/src/main/res/values/strings.xml')==(repo/'Paintroid/src/main/res/values/strings.xml').read_text()
receipt={'source_commit':base,'explicit_predecessor':pred,'full_source_current_rows_exact':len(p['rows']),'quoted_consumer_windows_exact':windows,'full_consumer_files_unchanged':len(files),'fixture_sha256':hashlib.sha256((repo/'tools/fixtures/current_localization/thai_priority_replacement.json').read_bytes()).hexdigest(),'claim':'Mechanical binding only; wording review receipt separately bounded. No complete all-call-site/runtime certification.'}
(r/'thai-current-binding.json').write_text(json.dumps(receipt,indent=2)+'\n');print(receipt)
