# Vietnamese vi P0+P1 linguistic review

Reviewed all 341 current English/Vietnamese pairs in one batch: 92 P0 + 249 P1, against develop 4355869e2e198b5616419291cba225b018444fab (tree b9b148d5d8ef7c7b088500a9c177f9f59304b800).

## Result

- 336 newly accepted complete pairs.
- 1 earlier accepted pair carried with exact English/target matching and its original bounded scope.
- 4 current values need corrections; proposed replacements are candidates only, not integrated or independently reviewed.
- No missing priority values. One Save alias resolved. No plurals occur in this specific 341-key selection.
- 311 entries have direct static consumer references; 30 accepted entries are wording-only because no direct production reference was found. Absence of such references is not proof of runtime unreachability.
- All 21 existing vi receipts exact-match current complete values. Counting 336 fresh accepts without double-counting the one overlapping old receipt yields 357 bounded-current / 4 correction-needed / 356 present-review-unknown among the 717-entry catalogue before candidate integration.

## Four proposed corrections

1. ui_the_encoder_did_not_finish (P0): “Quá trình mã hóa không hoàn tất.” Makes the failed encoding process the grammatical subject rather than an incomplete-sounding encoder.
2. ui_drawing_canvas_pinch_and_move_two_fingers_to (P1): matches the actual “Di chuyển và thu phóng” tool name instead of calling it “Điều hướng”; clarifies that the canvas is panned.
3. ui_no_resize_fits_decoder_memory (P1): states that decoder buffers still exceed available memory at the smallest output. The current Vietnamese incorrectly makes the output contain the buffers.
4. ui_show_magnified_drawing_preview (P1): “Hiện bản xem trước phóng đại khi vẽ” replaces an unnatural verb/noun stack with a clear preview checkbox label.

## Files

- vi-p0-p1-review.json: complete 341-entry judgments, exact source/target hashes, consumer references, individual reasons and limits.
- correction-candidates.json: four exact current/proposed pairs and rationales.
- candidate.diff and candidate/Paintroid/src/main/res/values-vi/strings.xml: temporary integration input, only four resource-value replacements.
- prior-vi-receipts-rebound.json: exact current-value checks for all 21 historical vi receipts.
- tracker-summary.json: compact counts suitable for the durable tracker, not a production acceptance assertion.
- validation.json: lightweight XML, keys, placeholder/newline, alias, NFC and exact-change validation.
- context-excerpts.txt: relevant current static consumer excerpts.

## Limits

This is a model linguistic and static-context review, not native-speaker certification, whole-language acceptance, UI-fit/layout verification, live accessibility testing or runtime certification. No Gradle, build, APK, emulator, CI, version or release work was performed. No shared production source, GitHub issue/PR or repository was changed. Existing source and receipt evidence was reused; no new screenshot claims are made. Nôm vi-Hani and its held work remain untouched. Tracker PR56 remains an intentional draft, never merged by this review.

Pinned GIMP Vietnamese terms in translations/gimp-catalogues.json were supporting terminology evidence, not automatic review credit. A narrow official GIMP documentation check confirmed dithering semantics (https://docs.gimp.org/3.0/en_GB/gimp-filter-dither.html); it did not establish a Vietnamese terminology standard.
