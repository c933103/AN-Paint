# Bounded unresolved wording second check

Six of seven existing target substitutes accepted. Hungarian is revised once more; the new exact Hungarian value remains a candidate requiring a separate check. The Lithuanian GIF checkbox dependency is accepted as a pair. No production source was changed.

Source tree: b9b148d5d8ef7c7b088500a9c177f9f59304b800
Local source HEAD: ddffe57016c689b2a7868c31e415dcb625f5c6b5

## Exact decisions

### vi · string/ui_show_magnified_drawing_preview · accept

Hiện bản xem trước phóng đại của bản vẽ

The noun phrase “bản xem trước phóng đại” clearly names the preview and “của bản vẽ” identifies its content. Repeated bản is not a grammatical defect. Omitting khi vẽ avoids making the label read as a stroke-only condition.

The shared checkbox controls both cursorMagnifier and activeMagnifier. magnifierVisible permits cursor support without requiring an active drawing stroke. The rendering is a magnified view of document content, not a document-size change.

UTF-8 value SHA256: df6cfddb6508a6fccd1a5430a5752e59e159b3d3b0506fde39ec3df96d61e775
JSON-string SHA256: b3bd038e64ead5ab8ec9765fea2b214a1bc2c59cde2c753c91cd488dab822a38

Exact existing substitute independently accepted in this bounded review.

### vi · string/ui_no_resize_fits_decoder_memory · accept

Ngay cả khi chọn kích thước đầu ra nhỏ nhất, vẫn không thể tải và chỉnh sửa ảnh này trong giới hạn bộ nhớ hiện tại. Hãy hủy và dùng ảnh nguồn nhỏ hơn.

“Ngay cả khi chọn kích thước đầu ra nhỏ nhất” retains the minimum-output concession; “vẫn không thể tải và chỉnh sửa ảnh này trong giới hạn bộ nhớ hiện tại” is grammatical and scopes the limitation to the whole operation. The cancel/smaller-source instruction is retained, with hủy matching the action Hủy.

The warning is appended when native work exists and the complete admission predicate fails for a 1×1 output. It describes inability to load/edit within the current limits, not decoder-only excess. The adjacent explanation retains decoder/source-work context.

UTF-8 value SHA256: 1a677fb89a78855fcb640f498fc72e6935b80dc49eb68dbacef41f38d05c30aa
JSON-string SHA256: d62815d58cf9e39225d045d22863cc7ab9ce9af86f409711c0706c10cda9d03c

Exact existing substitute independently accepted in this bounded review.

### hu · string/ui_no_resize_fits_decoder_memory · revise

A jelenlegi memóriakorlátok miatt a kép még a legkisebb kimeneti mérettel sem tölthető be szerkesztésre. Válassza a Mégse lehetőséget, és használjon kisebb forrásképet.

“A jelenlegi memóriakorlátok miatt” names the current memory constraints without claiming device RAM exhaustion. “még ... sem” preserves even-the-smallest negation. “tölthető be szerkesztésre” is a clear loading-for-editing construction and avoids awkward double coordination. The exact Mégse button label and smaller-source instruction are retained.

The submitted substitute is an improvement over decoder-buffers-alone wording, but still lists loading plus decoder work and frames the result as quantitative budget insufficiency. Admission covers ordinary/import/native/decoded work, editing/compositing buffers, resident pixels and allocation constraints. Naming the complete load-for-editing operation avoids attributing rejection to a selected subset.

UTF-8 value SHA256: 4e4c9dd53627e79a52ac3bbe1e7986af5c632773488cabf2a30ae9bc111ca86f
JSON-string SHA256: 7a92b07c2cbeca80d0ba6bd7986cff87dd84ce7d5a13f08a9ae9ead7c09fd425

New replacement authored and assessed here; not yet independently second-reviewed.

### lt · string/gallery_credit_could_not_save · accept

Vaizdų priskyrimo informacijos nepavyko išsaugoti arba atkurti. Anksčiau išsaugota priskyrimo informacija išliko. Bandykite dar kartą.

The mass-noun construction “priskyrimo informacijos nepavyko išsaugoti arba atkurti” is grammatical. “Anksčiau išsaugota priskyrimo informacija išliko” agrees in the singular feminine and expresses retained earlier information. The retry imperative is unchanged.

The message covers failure to save/restore credit sessions or values. Earlier saved data is preserved; it does not promise that the newly attempted edit was saved. Creative Commons independently supports priskyrimas as the attribution concept, including notices and licensing information rather than only author names. The code stores editable text associated with a source, so informacija or countable įrašai makes the storage referent clearer without changing that concept. The bounded related-title/action inspection found the same priskyrimo root; the complete warnings do not require mechanically replacing every short label to remain coherent.

UTF-8 value SHA256: dad278dfad514f43493e82a5e1a81b061e34da225e06c04af20da0315bdd51e7
JSON-string SHA256: 20f822c0031284be0f522e0a9a33b7eae4b7279f21891c0dafed706a8bc14469

Exact existing substitute independently accepted in this bounded review.

### lt · string/gallery_credit_too_large · accept

Dėl šios vaizdų priskyrimo informacijos piešinys taptų per didelis, kad jį būtų galima atkurti. Ankstesnis piešinys ir priskyrimo informacija išsaugoti.

“Dėl šios ... informacijos” has correct genitive agreement. “piešinys taptų per didelis, kad jį būtų galima atkurti” retains the prospective too-large-to-restore warning. The masculine-plural išsaugoti can agree with the mixed coordinated subjects piešinys and informacija; it does not imply that only the image was kept.

The attempted credit edit/attachment is validated against restorable document metadata/history before acceptance. The conditional taptų and preserved previous drawing/credit information remain intact. Creative Commons independently supports priskyrimas as the attribution concept, including notices and licensing information rather than only author names. The code stores editable text associated with a source, so informacija or countable įrašai makes the storage referent clearer without changing that concept. The bounded related-title/action inspection found the same priskyrimo root; the complete warnings do not require mechanically replacing every short label to remain coherent.

UTF-8 value SHA256: 4b4c19f0a5b7896f9de53c6dbcd8b13396ea22cdd44da150ddc25e174320e31f
JSON-string SHA256: ba96888e7945993c0702bb89cdd60ce2e19d941b6f55d14fcb345614d80afd3a

Exact existing substitute independently accepted in this bounded review.

### lt · string/legacy_credits_unreadable · accept

Kai kurių išsaugotų priskyrimo įrašų nepavyko perskaityti. Jų saugomos kopijos išsaugotos.

“Kai kurių išsaugotų priskyrimo įrašų” supplies an explicit countable noun with the expected genitive after nepavyko perskaityti. “Jų saugomos kopijos išsaugotos” preserves the distinction between unreadable content and retained copies. The repeated storage wording is slightly heavy but intelligible and not a reason to introduce a new substitute.

The archive reader increments unreadableSnapshots while preserving the original stored file. This warning therefore concerns some unreadable stored records and retained copies, not successful recovery of their text. Creative Commons independently supports priskyrimas as the attribution concept, including notices and licensing information rather than only author names. The code stores editable text associated with a source, so informacija or countable įrašai makes the storage referent clearer without changing that concept. The bounded related-title/action inspection found the same priskyrimo root; the complete warnings do not require mechanically replacing every short label to remain coherent.

UTF-8 value SHA256: d30f0a4de3eeebc8269e2a0cfaf1e0bd0316641f2d7008d0aeef63986504a952
JSON-string SHA256: a770fe98e6660a1fd5219d9e89ba11166a661f9148661623d0ab326fed927150

Exact existing substitute independently accepted in this bounded review.

### lt · string/save20_gif_description · accept

Nejudantis vaizdas, iki 256 spalvų. Spalvų smulkinimas glotnina spalvų perėjimus. Animuoti GIF atveriami kaip pirmasis kadras.

GIMP’s Lithuanian indexed-colour documentation uses smulkinimas for the same palette/dithering process, and its gradient option is Smulkinimas. “Spalvų smulkinimas” makes that graphic-process term explicit and grammatical as the subject of glotnina. This is product-language precedent, not a universal mandatory standard.

The description is displayed for GIF beside its dithering checkbox. The encoder produces one still frame with an at-most-256-colour palette and optional error diffusion. Only the dithering terminology is changed; the existing first-frame import statement is preserved, not independently runtime-tested.

UTF-8 value SHA256: 206e42589e7b47df87601556bdd4df84fffc43ababd52cd79d297b6c722ad779
JSON-string SHA256: c54474e0f49c6dec38524b83ca87b405135e1ca48e652d52306d80376347cf09

Exact existing substitute independently accepted in this bounded review.

### lt · string/save20_dither · accept

Smulkinti spalvas

Smulkinti is the action-form counterpart of smulkinimas; spalvas provides the direct object and preserves the colour-dithering scope. It does not say to resize the image.

This checkbox is visible for GIF and its state is passed to the export encoder. Use it together with the GIF description so the same process has the same root.

UTF-8 value SHA256: 4ec8bc56824831b11754334d208e54d4c0776ebfee62a282c22d39674ead6257
JSON-string SHA256: 8422a17b9ef008092614e75a3215c8f2f9596e859cbaac4aec81e2def477e315

Exact existing substitute independently accepted in this bounded review.

## Credit terminology scope

The expanded warning nouns refer to the same established attribution root used by the related UI. Information is appropriate for stored editable text and records for countable archive entries. There is no semantic need to rewrite every related short label as a condition of accepting these three exact warning substitutes. This is not blanket acceptance of the unchanged label family or a universal terminology certification.

## Memory semantic caution

The minimum-size loading/editing operation cannot be admitted under the current constraints.
It does not follow that the decoder working buffers by themselves exceed the budget.
The predicate also includes allocation/pixel guards. This review does not assert an allocation-only rejection at 1×1 is reachable for valid source dimensions.

## Primary terminology sources

- https://creativecommons.org/licenses/by/4.0/deed.lt — The official Lithuanian attribution heading covers attribution and associated licence/change notices. This supports the root, not independent native-language certification of every UI sentence.
- https://docs.gimp.org/3.0/lt/gimp-image-convert-indexed.html — Official GIMP Lithuanian documentation uses the smulkinimas root for indexed-palette dithering and describes approximation by groups of available-colour pixels.
- https://docs.gimp.org/3.0/lt/gimp-tool-gradient.html — The official Lithuanian gradient tool labels its dithering option Smulkinimas.

## Limitations

- No source integration, production resource edits, Gradle, builds, APKs, CI, runtime, publication or release.
- Acceptance is scoped to the exact submitted candidate values and inspected consumers; it does not accept the unchanged production values.
- The seven primary targets and one named dependency do not constitute a whole-locale or whole-tier completion claim.
- No native-speaker claim. Medium-high model judgment is not language-community certification.
- Hungarian has a newly authored replacement; it remains a candidate until separately cross-reviewed.
- Primary terminology sources support the chosen roots. They do not prescribe every surrounding phrase.
