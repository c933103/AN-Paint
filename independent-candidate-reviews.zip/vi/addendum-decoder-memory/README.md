# Vietnamese decoder-memory review correction

Only ui_no_resize_fits_decoder_memory is reopened. The previous ACCEPT is withdrawn and replaced with REVISE. Other three decisions are unchanged.

Recommended complete value:
Ngay cả khi chọn kích thước đầu ra nhỏ nhất, vẫn không thể tải và chỉnh sửa ảnh này trong giới hạn bộ nhớ hiện tại. Hãy hủy và dùng ảnh nguồn nhỏ hơn.

Reason:
The prior acceptance incorrectly inferred that decoder buffers alone exceed the memory budget. ImageResizeDialog:46 tests the complete ImportMemoryRequirements.accepts predicate for 1×1 output and appends the warning to the full loading/editing estimate. ImageImport:75–84 includes the greater of ordinary/import-native or decoded work plus metadata, additional target editing/compositing buffers, and resident image memory. The admission predicate also applies bitmap/allocation-size constraints. Consequently neither decoder-only excess nor even numerical estimatedBytes excess is the sole possible failure reason. The replacement names the combined loading/editing operation as unable to fit current memory limits and does not attribute failure to a single component.

“Ngay cả khi chọn kích thước đầu ra nhỏ nhất” retains the minimum-output concession. “vẫn không thể tải và chỉnh sửa ảnh này trong giới hạn bộ nhớ hiện tại” is a grammatical whole-operation warning and aligns with the immediately preceding “Bộ nhớ ước tính để tải/chỉnh sửa”. The adjacent codec-memory explanation retains the source/tile decoding detail. “Hãy hủy và dùng ảnh nguồn nhỏ hơn.” is preserved exactly.

The original English also names decoder buffers narrowly; this recommendation uses the actual combined loading/editing context rather than asserting that decoder buffers alone exceed the budget.

Effective four-proposal outcome: 2 accept, 2 revise, 0 hold. No production values were changed.

Historical receipt remains unchanged:
/tmp/vi-independent-wording-review-20261021/independent-review.json
ae2fa10a50b1585f89427b19900aa79b194aba9f958aee8a54ce882a75c1cdd3

The substitute is assessed by this reviewer only and has not been separately cross-reviewed or integrated. No builds, test execution, production changes, or release work was performed. No runtime/native-human/live-accessibility claims.
