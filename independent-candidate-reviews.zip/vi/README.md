# Independent Vietnamese wording review

Source tree: b9b148d5d8ef7c7b088500a9c177f9f59304b800
Observed local HEAD: ddffe57016c689b2a7868c31e415dcb625f5c6b5
Supplied develop commit, independently verified remotely by parent: 4355869e2e198b5616419291cba225b018444fab.

Result: 3 accept, 1 revise, 0 hold. No production edits.

## string/ui_the_encoder_did_not_finish: ACCEPT
English: The encoder did not finish.
Current: Bộ mã hóa không hoàn tất.
Proposed: Quá trình mã hóa không hoàn tất.
Recommended complete value: Quá trình mã hóa không hoàn tất.
Reason: “Quá trình mã hóa” is a complete, idiomatic process subject for “không hoàn tất”. It reports noncompletion without adding a cause, data-loss claim, or retry promise. All three current consumers throw this IOException when Bitmap.compress returns false, so the process-result wording preserves the full English meaning and is clearer than the elliptical current encoder-as-subject wording.

## string/ui_drawing_canvas_pinch_and_move_two_fingers_to: ACCEPT
English: Drawing canvas. Pinch and move two fingers to zoom and pan. Navigate mode also pans with one finger.
Current: Khung vẽ. Chụm và di chuyển hai ngón tay để thu phóng và di chuyển. Chế độ Điều hướng cũng cho phép di chuyển bằng một ngón.
Proposed: Khung vẽ. Chụm và di chuyển hai ngón tay để thu phóng và di chuyển khung vẽ. Chế độ “Di chuyển và thu phóng” cũng cho phép di chuyển khung vẽ bằng một ngón tay.
Recommended complete value: Khung vẽ. Chụm và di chuyển hai ngón tay để thu phóng và di chuyển khung vẽ. Chế độ “Di chuyển và thu phóng” cũng cho phép di chuyển khung vẽ bằng một ngón tay.
Reason: The complete instruction remains grammatical and maps zoom to “thu phóng” and pan to “di chuyển khung vẽ”. The latter identifies the viewport/canvas movement rather than moving painted content. The quoted “Di chuyển và thu phóng” exactly matches current vi ui_navigate, which is the label for PaintTool.ZOOM. The final clause retains the additional one-finger navigation operation and does not claim one-finger zoom.

## string/ui_no_resize_fits_decoder_memory: ACCEPT
English: Even the smallest output cannot fit this image’s decoder working buffers in the current memory budget. Cancel and use a smaller source image.
Current: Ngay cả đầu ra nhỏ nhất cũng không thể chứa các bộ đệm làm việc của bộ giải mã ảnh này trong giới hạn bộ nhớ hiện tại. Hãy hủy và dùng ảnh nguồn nhỏ hơn.
Proposed: Ngay cả khi chọn kích thước đầu ra nhỏ nhất, các bộ đệm làm việc của bộ giải mã ảnh này vẫn vượt quá giới hạn bộ nhớ hiện tại. Hãy hủy và dùng ảnh nguồn nhỏ hơn.
Recommended complete value: Ngay cả khi chọn kích thước đầu ra nhỏ nhất, các bộ đệm làm việc của bộ giải mã ảnh này vẫn vượt quá giới hạn bộ nhớ hiện tại. Hãy hủy và dùng ảnh nguồn nhỏ hơn.
Reason: The concessive “Ngay cả khi chọn kích thước đầu ra nhỏ nhất” correctly conditions the remaining decoder-memory requirement on minimum output dimensions. It removes the current implication that the output itself must contain the decoder buffers. The main clause places the limit on current memory, not storage space or file size, and retains the instruction to cancel and use a smaller source image. ImageResizeDialog constructs this message when native work is present and a 1×1 output is still inadmissible; ImageImport explains that source/tile decode work need not shrink with output.

## string/ui_show_magnified_drawing_preview: REVISE
English: Show magnified drawing preview
Current: Hiện xem trước vẽ phóng đại
Proposed: Hiện bản xem trước phóng đại khi vẽ
Recommended complete value: Hiện bản xem trước phóng đại của bản vẽ
Reason: The proposed “bản xem trước phóng đại” repairs the current unnatural word stack, but “khi vẽ” introduces an avoidable temporal reading (“while drawing”) absent from the English. This same checkbox controls cursorMagnifier as well as activeMagnifier. In current static source, magnifierVisible accepts supportsCursor() without requiring down or cursorDrawing, so the lens can describe the cursor position before an active stroke. “Hiện bản xem trước phóng đại của bản vẽ” preserves the preview as the object and the drawing as its content, without suggesting a stroke-only visibility condition. This is a clarity precaution rather than a claim that every reader must misread the proposed wording.

All four complete English/current/proposed/recommended values contain no placeholders, percent signs, or newline escapes; exact source values and NFC were checked.
The magnifier substitute has been assessed by this reviewer, not yet by a second reviewer.
This is model linguistic/static-source review only. It does not establish whole-language acceptance, native-human certification, runtime behavior, UI fit, or live accessibility results. No build, Gradle, APK, CI, emulator, PR, version, or release work was performed.
