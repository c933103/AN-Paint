# Independent es-ES check: five proposed values

Result: **accept 5, revise 0, hold 0** as bounded linguistic candidates. Four improve clarity/idiom; Porcentaje is optional cosmetic consistency. No newly corrected save/cancel/output-state mistranslation was established in the five original values.

Inspected clean checkout: `ddffe57016c689b2a7868c31e415dcb625f5c6b5`, tree `b9b148d5d8ef7c7b088500a9c177f9f59304b800`. Requested source commit `4355869e2e198b5616419291cba225b018444fab` is coordinator supplied and absent as a local object. The supplied current tree is independently verified.

This is a five-proposal review, not independent re-review or certification of all 341 priority values. No shared production edit or build was performed.

## string/save20_destination_error: ACCEPT

English: The completed image could not replace its destination.
Current: La imagen terminada no pudo sustituir su destino.
Accepted candidate: No se ha podido sustituir el archivo de destino por la imagen terminada.

Classification: recommended referent/semantic-clarity repair; not a newly discovered save-state failure.

The original su destino is an unnatural and opaque object of sustituir. The proposed archivo de destino names the file operand of renameTo, and sustituir X por Y has the correct replacement direction. The negated perfect does not assert replacement succeeded or that output was saved. It is idiomatic Spain Spanish. Retaining imagen terminada follows the English completed image; no broader terminology rewrite is needed.

The inspected export call creates the cache output file before encoding; Base64 import calls decodeToFile(file, file) on an existing staged file. Thus the current consumers support file replacement, even when the user chooses a new external document. This is not evidence that an existing user-selected document is being overwritten. A hypothetical later caller with a nonexistent codec target would need source wording reconsideration; it is not a current hold.

Candidate UTF-8 SHA-256: `63ba20d149ae80a2963efad100cb9442d4009d54371ea0abe7f391dd05b0bb89`.

## string/ui_export_explanation23: ACCEPT

English: Export an icon, Base64 text or ASCII art. Exporting keeps the current image and its Save destination unchanged.
Current: Exporta un icono, texto Base64 o arte ASCII. Exportar no cambia la imagen actual ni su destino de Guardar.
Accepted candidate: Exporta un icono, texto Base64 o arte ASCII. La exportación no modifica la imagen actual ni su destino de guardado.

Classification: recommended idiomatic terminology; existing state meaning already intact.

All three output types remain explicit: un icono, texto Base64 and arte ASCII. Destino de guardado is idiomatic and matches the existing share explanation. No modifica preserves both unchanged current image and unchanged save destination. It does not say export marks the working image saved or unlocks a pending after-save action. La exportación/no modifica is an acceptable optional rephrasing of the already idiomatic Exportar/no cambia, not a required state correction.

This is export explanatory text, not a cancel label or a promise that cancelling saves output. The scoped inspection confirms export bypasses updating savedTarget/markSaved and reports export_did_not_save when an after-save action remains. No runtime behavior certification is implied.

Candidate UTF-8 SHA-256: `bef4adefd41f2019a375c7cb721c371311bb69586482f09cc53aed8785ffe227`.

## string/ui_higher_quality_usually_makes_a_larger_file_lossless: ACCEPT

English: Higher quality usually makes a larger file. Lossless keeps every colour value.
Current: Una calidad mayor suele producir un archivo más grande. Sin pérdida conserva todos los valores de color.
Accepted candidate: Una calidad mayor suele producir un archivo más grande. La compresión sin pérdidas conserva todos los valores de color.

Classification: recommended explicit grammatical subject/terminology; not a change to lossless behavior.

La compresión sin pérdidas is a natural explicit subject for conserva. The proposed text retains suele (usually), a larger file rather than an unconditional size guarantee, and todos los valores de color rather than a weaker visual-quality claim. Sin pérdida is not inherently invalid Spanish; the improvement is the complete explanatory subject and idiom, not a rule that singular pérdida is always wrong. The existing %1$s sin pérdida option label need not change.

The visible explanation is selected for supported quality/lossless formats, with PNG hidden. It does not claim every export format is lossless. This wording review does not independently certify encoders.

Candidate UTF-8 SHA-256: `8b4d7544903a0393298c279592b4f388d8f4f877f87232c8c88324ed823a4cd9`.

## string/ui_the_image_was_saved_but_android_could_not: ACCEPT

English: The image was saved, but Android could not open sharing: %1$s
Current: La imagen se guardó, pero Android no pudo abrir el sistema de compartir: %1$s
Accepted candidate: La imagen se ha guardado, pero Android no ha podido abrir las opciones para compartir: %1$s

Classification: recommended idiom for share chooser; existing save-success/share-failure distinction already intact.

Las opciones para compartir is natural and describes the Android chooser. The successful save and subsequent failed opening remain unambiguous and %1$s is preserved exactly. Se ha guardado/no ha podido fits a just-completed result in Spain Spanish. The original se guardó/no pudo is also grammatical and not evidence of Latin-American leakage; changing the tense is optional, not a semantic fix. The proposed wording does not claim that sharing completed or that the saved file was lost.

The call is inside shareSavedImage after file output completes. The catch surrounds FileProvider/intent construction and chooser launch, so the broad could-not-open wording is suitable without asserting a narrower technical cause. Cancelling an opened chooser is not this caught launch failure.

Candidate UTF-8 SHA-256: `97ca59598b0b51bf626aeac69dfdb871909c9e827a0c6ac38388a2f8bacda429`.

## string/ui_percent: ACCEPT

English: Percent
Current: porcentaje
Accepted candidate: Porcentaje

Classification: optional cosmetic capitalization consistency only.

Porcentaje is appropriate sentence-style initial capitalization for the standalone radio-button label beside Píxeles. It preserves the unit meaning. The separate ui_percent_fd8671 remains lowercase for embedding in accessibility phrases such as Ancho en porcentaje. This is not a correctness, warning-semantics, accessibility-runtime or release-blocking defect.

No percentage sign or formatted numeric value is added or removed. Actual visual fit and spoken rendering are outside this review.

Candidate UTF-8 SHA-256: `b4a5e919985497f9c972af30f32b65212192675f5055b06c13bb8c174bf328d6`.

## Checks and limits

All five complete source/current/candidate values match the supplied findings, per-key record and parsed resource files. Placeholders, literal percent signs, Android literal newlines, resource inventory and attributes are preserved. Exactly five candidate resource values differ. The lowercase embedded accessibility unit is unchanged.

The JSON receipt contains complete values, per-value hashes, exact static source excerpts, source links and whole-file hashes. It records the source-binding limitation and all non-runtime limits. No candidate has been integrated; rebind exact accepted values after integration before changing current acceptance accounting.
