# Hungarian independent wording review

Result: 17 of 18 priority proposals accepted as proposed; 1 requires semantic refinement. Both adjacent P2 crop proposals accepted separately. No production text changed.

Source: remote develop `4355869e2e198b5616419291cba225b018444fab` as supplied; independently checked local HEAD `ddffe57016c689b2a7868c31e415dcb625f5c6b5` has tree `b9b148d5d8ef7c7b088500a9c177f9f59304b800` and clean status.

## Required refinement

`ui_no_resize_fits_decoder_memory`: describe the complete loading requirement plus decoder buffers, not buffers alone exceeding the budget. The supplied Vietnamese candidate has the same issue; its receipt was only read, not changed.

Még a legkisebb kimeneti méret mellett sem elegendő a jelenlegi memóriakeret a kép betöltéséhez és a dekóder munkapuffereihez. Válassza a Mégse lehetőséget, és használjon kisebb forrásképet.

## Decision boundaries

Acceptance is bounded model linguistic/static-context acceptance of proposed text. It is not native-speaker, runtime, screenshot, layout, accessibility-behavior, whole-language, all-341-priority-key or P2-tier acceptance. Current production and coverage totals do not advance from this report. The one replacement suggested here should receive a targeted second check.

## Per-key decisions

### string/save20_destination_error (P0): accept

English: The completed image could not replace its destination.
Current Hungarian: A kész kép nem tudta lecserélni a célfájlt.
Submitted proposal: A célfájlt nem sikerült lecserélni az elkészült képre.

The impersonal failed-action construction is idiomatic and preserves the attempted replacement, rather than giving the completed image human agency. The destination file remains the object. This is acceptable both in export replacement and in the shared Base64 import replacement helper.

Consumers: DibCodec.kt:25–38, BitmapFileCodec.kt:12–25, TextImageCodec.kt:13–23, TextImageCodec.kt:58–63, IcoCodec.kt:95–101, ClassicPaintActivity.kt:1364–1367, ClassicPaintActivity.kt:1411–1415

Actual save ioFailed prefix composition, from ClassicPaintActivity.kt:1366,1414.
Current: A kép nem menthető. A kész kép nem tudta lecserélni a célfájlt.
Proposed: A kép nem menthető. A célfájlt nem sikerült lecserélni az elkészült képre.

The TextImageCodec.replace helper is also used by decodeToFile; an import caller can use the open-image prefix rather than the save prefix.
Current: A kép nem nyitható meg. A kész kép nem tudta lecserélni a célfájlt.
Proposed: A kép nem nyitható meg. A célfájlt nem sikerült lecserélni az elkészült képre.

### string/save20_encoding_budget (P0): accept

English: The image and encoding buffers exceed the export memory budget.
Current Hungarian: A kép és kódolási pufferek meghaladják az exportmemória-keretet.
Submitted proposal: A kép és a kódolási pufferek memóriaigénye meghaladja az exportálás memóriakeretét.

Memóriaigénye correctly makes the combined memory requirement the subject of the budget comparison. The article before kódolási pufferek and the possessive memóriakeretét produce a natural complete Hungarian sentence. No cause beyond the source budget excess is added.

Consumers: TextImageCodec.kt:26–33, TextImageCodec.kt:54–57, IcoCodec.kt:73–77, DibCodec.kt:35–38, BitmapFileCodec.kt:20–25, ClassicPaintActivity.kt:1411–1415

Actual save ioFailed prefix composition, from ClassicPaintActivity.kt:1366,1414.
Current: A kép nem menthető. A kép és kódolási pufferek meghaladják az exportmemória-keretet.
Proposed: A kép nem menthető. A kép és a kódolási pufferek memóriaigénye meghaladja az exportálás memóriakeretét.

### string/save20_gif_description (P0): accept

English: Still image, up to 256 colours. Dithering smooths colour gradients. Animated GIFs open as their first frame.
Current Hungarian: Állókép, legfeljebb 256 szín. A dithering simítja a színátmeneteket. Az animált GIF-ek első képkockaként nyílnak meg.
Submitted proposal: Állókép, legfeljebb 256 színnel. A színszórás simítja a színátmeneteket. Az animált GIF-ekből az első képkocka nyílik meg.

The instrumental színnel fits the still-image description, színszórás is coherent with the existing adjacent Színek szórása checkbox, and GIF-ekből az első képkocka clearly describes which part is opened. The proposal retains the 256-colour limit and makes no animation-support promise.

Consumers: SaveOptionsDialog.kt:62–65, SaveOptionsDialog.kt:85–103

### string/ui_autosave_image_encoding_failed (P0): accept

English: Autosave image encoding failed.
Current Hungarian: Az automatikus mentési kép kódolása sikertelen.
Submitted proposal: Nem sikerült kódolni a képet az automatikus mentéshez.

The proposal identifies encoding the image for autosave as the failed operation. It avoids the cumbersome automatikus mentési kép noun stack without implying a completed save or loss of the existing draft. Static origin is the canvas PNG compression failure; the exact raw exception message is recorded rather than directly displayed in the current main activity.

Consumers: AutosaveStore.kt:124–140, ClassicPaintActivity.kt:1608–1620

### string/ui_autosave_selection_encoding_failed (P0): accept

English: Autosave selection encoding failed.
Current Hungarian: Az automatikus mentési kijelölés kódolása sikertelen.
Submitted proposal: Nem sikerült kódolni a kijelölést az automatikus mentéshez.

The same grammatical improvement correctly applies to the floating selection, not the full canvas. Kijelölést remains the accusative object of kódolni. Static origin is floating PNG compression failure; do not equate its recording in lastAutosaveError with a verified visible notice.

Consumers: AutosaveStore.kt:130–140, ClassicPaintActivity.kt:1608–1620

### string/ui_history_unavailable34 (P0): accept

English: The canvas was restored, but its undo history could not be read. The original draft has been kept as a recovery copy.
Current Hungarian: A vászon visszaállt, de a visszavonási előzmény nem olvasható. Az eredeti piszkozat helyreállítási másolatként megmaradt.
Submitted proposal: A vászon visszaállítása sikerült, de a visszavonási előzményeket nem sikerült beolvasni. Az eredeti piszkozat helyreállítási másolatként megmaradt.

Visszavonási előzményeket is the natural collective/plural UI expression here. The separate success and failure clauses preserve the distinction between recovered canvas and unreadable undo history. The second sentence retains the original-draft recovery copy and does not imply the undo history was recovered. The notice is assigned only after the copy-preservation call returns.

Consumers: EditorDraftRecovery.kt:55–65, ClassicPaintActivity.kt:225–231

### string/ui_keeps_pixels_at_the_top_left_smaller_canvas (P0): accept

English: Keeps pixels at the top left. Smaller canvas dimensions discard pixels beyond the right/bottom edge; Undo restores them.
Current Hungarian: A bal felső képpontokat tartja meg. A kisebb vászonméret eltávolítja a jobb/alsó szélen túli képpontokat; a Visszavonás visszaállítja őket.
Submitted proposal: A képpontok helyzete a bal felső sarokhoz képest változatlan marad. Kisebb vászonméret esetén a jobb vagy alsó szélen túli képpontok törlődnek; a Visszavonás visszaállítja őket.

The proposed sentence correctly expresses fixed coordinates relative to the top-left corner, not retention of only a group of top-left pixels. It preserves right/bottom clipping and Undo. The static non-stretch implementation draws the old bitmap at 0,0 on the new canvas, supporting this reading.

Consumers: ClassicPaintActivity.kt:1003–1017, PaintDocument.kt:423–432

### string/ui_the_previous_draft_could_not_be_moved_to (P0): accept

English: The previous draft could not be moved to a recovery copy.
Current Hungarian: Az előző piszkozat nem mozgatható helyreállítási másolatba.
Submitted proposal: Az előző piszkozatot nem sikerült helyreállítási másolatként áthelyezni.

The proposal naturally reports an unsuccessful completed attempt and treats the recovery copy as the preserved role of the moved draft. It does not claim the old draft was successfully saved. The originating helper throws it for a missing source or failed rename; the current recovery caller can replace this raw error with a general preservation notice, so no direct rendering of this exact sentence is claimed.

Consumers: AutosaveStore.kt:99–114, EditorDraftRecovery.kt:36–46, EditorDraftRecovery.kt:61–65

### string/language20_translation_note (P1): accept

English: App language\n\nTranslations are maintained in AN Paint’s language resources. New or untranslated text appears in English.
Current Hungarian: Ez a nyelvi változat az AN Paint összes fordítható felületi szövegét tartalmazza.
Submitted proposal: Alkalmazás nyelve\n\nA fordításokat az AN Paint nyelvi erőforrásaiban tartjuk karban. Az új vagy le nem fordított szövegek angolul jelennek meg.

The candidate restores every source component: the app-language title, maintenance in the language resources, and English fallback for new/untranslated text. It removes the current unsupported assertion that all translatable UI text is present. The first-person plural tartjuk karban is a conventional product voice, not an extra service commitment.

Consumers: AppLanguage.kt:142–159

### string/ui_bottom (P1): accept

English: Bottom
Current Hungarian: Alul
Submitted proposal: Alsó szél

Alsó szél is a noun phrase suitable both for the visible edge field and as possessor in the composed vágása label. It repairs the adverb Alul vágása while retaining the bottom-edge referent. Acceptance covers these static field/template uses, not actual screen-reader delivery.

Consumers: ImageCropDialog.kt:69–75, ImageCropDialog.kt:98–118

Exact string substitution for actual pixel/percent contentDescription calls, not runtime speech evidence.
Current: Alul vágása képpontban | Alul vágása százalékban
Proposed: Alsó szél vágása képpontban | Alsó szél vágása százalékban

### string/ui_colour_palette_tap_for_foreground_hold_for_background (P1): accept

English: Colour palette. Tap for foreground; hold for background. Scroll for more colours.
Current Hungarian: Színpaletta. Koppintás az előtérhez; hosszan nyomás a háttérhez. Görgessen további színekért.
Submitted proposal: Színpaletta. Az előtérszín kiválasztásához koppintson egy színre; a háttérszín kiválasztásához tartsa nyomva. További színekért görgessen.

The polite imperatives koppintson, tartsa nyomva and görgessen form coherent gesture instructions. Előtérszín and háttérszín specify colour selection rather than vaguely referring to spatial foreground/background. The object of tartsa nyomva is recoverable from egy színre, and the actual swatches have distinct click and long-click handlers.

Consumers: ClassicPaintActivity.kt:602–623

### string/ui_colour_tap_foreground_hold_background (P1): accept

English: Colour #%1$s. Tap foreground, hold background.
Current Hungarian: Szín #%1$s. Koppintás előtérhez, hosszan nyomás háttérhez.
Submitted proposal: Szín: #%1$s. Koppintson az előtérszín kiválasztásához; tartsa nyomva a háttérszín kiválasztásához.

The swatch instruction preserves the hexadecimal value and the foreground-tap/background-hold distinction using grammatical imperatives. The colon after Szín is natural for a value label. Tartsa nyomva is a normal long-press instruction without needing an additional time promise.

Consumers: ClassicPaintActivity.kt:606–623, ClassicPaintActivity.kt:1416–1419

Static substitution using actual first palette hex 000000 (ClassicPaintActivity.kt:607,615).
Current: Szín #000000. Koppintás előtérhez, hosszan nyomás háttérhez.
Proposed: Szín: #000000. Koppintson az előtérszín kiválasztásához; tartsa nyomva a háttérszín kiválasztásához.

### string/ui_draw_again (P1): accept

English: Draw again
Current Hungarian: Rajzolás újra
Submitted proposal: Rajzolás folytatása

Rajzolás folytatása is idiomatic for resuming the previously used drawing tool. The consumer is the navigation/zoom panel button calling chooseTool(drawingTool), not Undo/Redo or a command to redraw the image from scratch, so folytatása clarifies the intended action.

Consumers: ClassicPaintActivity.kt:758–764

### string/ui_left (P1): accept

English: Left
Current Hungarian: Bal
Submitted proposal: Bal szél

Bal alone is serviceable as a terse visible direction, but Bal vágása is awkward as a standalone composed description. Bal szél supplies the noun required by the possessive construction while remaining accurate for the trim-from-left field.

Consumers: ImageCropDialog.kt:69–75, ImageCropDialog.kt:98–118

Exact string substitution for actual pixel/percent contentDescription calls, not runtime speech evidence.
Current: Bal vágása képpontban | Bal vágása százalékban
Proposed: Bal szél vágása képpontban | Bal szél vágása százalékban

### string/ui_no_resize_fits_decoder_memory (P1): revise

English: Even the smallest output cannot fit this image’s decoder working buffers in the current memory budget. Cancel and use a smaller source image.
Current Hungarian: Még a legkisebb kimenet sem fér el ennek a képnek a dekóder-munkapuffereivel a jelenlegi memóriakeretben. Szakítsa meg és használjon kisebb forrásképet.
Submitted proposal: A kép dekóderének munkapufferei még a legkisebb kimeneti méret mellett sem férnek el a jelenlegi memóriakeretben. Válassza a Mégse lehetőséget, és használjon kisebb forrásképet.
Recommended substitute: Még a legkisebb kimeneti méret mellett sem elegendő a jelenlegi memóriakeret a kép betöltéséhez és a dekóder munkapuffereihez. Válassza a Mégse lehetőséget, és használjon kisebb forrásképet.

Revise the proposed subject: munkapufferei ... nem férnek el says the decoder buffers themselves exceed the current budget. The condition actually rejects the complete loading/editing estimate at 1×1, including resident pixels and extra buffers; it does not prove that the native working buffers alone exceed workingBytes. The revised recommendation puts insufficiency on loading plus decoder buffers, preserves the minimum-output condition and the smaller-source instruction, and uses the exact Mégse button label. This is a semantic precision concern from the static consumer, not a native-language or runtime defect claim.

Consumers: ImageResizeDialog.kt:34–50, ImageImport.kt:27–45, ImageImport.kt:63–84, ImageMemoryPolicy.kt:35–43

Exact composition template from ImageResizeDialog.kt:48–49, retaining symbolic arguments. The first string already ends with a newline; the branch adds another. Values below show Android newline escapes as literal \n, not measured UI output.
Current: Másolat: %1$s\nDekódolt kép ebben a méretben: %2$s\nBecsült betöltési/szerkesztési memória: %3$s\n\nMég a legkisebb kimenet sem fér el ennek a képnek a dekóder-munkapuffereivel a jelenlegi memóriakeretben. Szakítsa meg és használjon kisebb forrásképet.
Proposed: Másolat: %1$s\nDekódolt kép ebben a méretben: %2$s\nBecsült betöltési/szerkesztési memória: %3$s\n\nA kép dekóderének munkapufferei még a legkisebb kimeneti méret mellett sem férnek el a jelenlegi memóriakeretben. Válassza a Mégse lehetőséget, és használjon kisebb forrásképet.
Recommended: Másolat: %1$s\nDekódolt kép ebben a méretben: %2$s\nBecsült betöltési/szerkesztési memória: %3$s\n\nMég a legkisebb kimeneti méret mellett sem elegendő a jelenlegi memóriakeret a kép betöltéséhez és a dekóder munkapuffereihez. Válassza a Mégse lehetőséget, és használjon kisebb forrásképet.

### string/ui_right (P1): accept

English: Right
Current Hungarian: Jobb
Submitted proposal: Jobb szél

Jobb szél is accurate as an edge noun phrase and composes naturally as Jobb szél vágása. It removes the awkward adjectival ellipsis in Jobb vágása without changing crop direction or units.

Consumers: ImageCropDialog.kt:69–75, ImageCropDialog.kt:98–118

Exact string substitution for actual pixel/percent contentDescription calls, not runtime speech evidence.
Current: Jobb vágása képpontban | Jobb vágása százalékban
Proposed: Jobb szél vágása képpontban | Jobb szél vágása százalékban

### string/ui_this_file_is_not_a_supported_image_use (P1): accept

English: This file is not a supported image. Use PNG, JPEG, JPEG XL, WebP, HEIC, AVIF, BMP, GIF, DIB, TIFF, ICO, PDF or Base64 image text.
Current Hungarian: Ez a fájl nem támogatott kép. Használjon PNG, JPEG, JPEG XL, WebP, HEIC, AVIF, BMP, GIF, DIB, TIFF, ICO, PDF vagy Base64 képszöveget.
Submitted proposal: Ez a fájl nem támogatott kép. Használjon PNG-, JPEG-, JPEG XL-, WebP-, HEIC-, AVIF-, BMP-, GIF-, DIB-, TIFF-, ICO- vagy PDF-fájlt, illetve Base64-kódolású képszöveget.

The hyphenated shared-head list correctly attaches fájlt to the image/PDF format names, while illetve separates Base64-encoded image text. This fixes the current reading that the entire format list modifies képszöveget. All formats are preserved and the text does not promise every file with those extensions is decodable. Képszöveget is a technical compound but its Base64 qualifier makes the intended text representation clear enough; no further rewrite is required for this bounded correction.

Consumers: ImageImport.kt:120–140, TextImageCodec.kt:9–23, ClassicPaintActivity.kt:1275–1285, ClassicPaintActivity.kt:1411–1415

Actual import ioFailed prefix composition.
Current: A kép nem nyitható meg. Ez a fájl nem támogatott kép. Használjon PNG, JPEG, JPEG XL, WebP, HEIC, AVIF, BMP, GIF, DIB, TIFF, ICO, PDF vagy Base64 képszöveget.
Proposed: A kép nem nyitható meg. Ez a fájl nem támogatott kép. Használjon PNG-, JPEG-, JPEG XL-, WebP-, HEIC-, AVIF-, BMP-, GIF-, DIB-, TIFF-, ICO- vagy PDF-fájlt, illetve Base64-kódolású képszöveget.

### string/ui_trim_amounts_must_be_zero_or_greater (P1): accept

English: Trim amounts must be zero or greater.
Current Hungarian: A vágási értékeknek nullának vagy nagyobbnak kell lenniük.
Submitted proposal: A vágási értékeknek nullának vagy annál nagyobbnak kell lenniük.

Annál makes the comparative relation to zero explicit and fluent. Zero remains allowed, and the wording retains the numeric trim-value requirement. The old wording was understandable by ellipsis; this is a clarity correction, not proof of a different accepted numeric range. The finite-number check is broader than the English explanation and is not silently added to the translation.

Consumers: ImageAssembly.kt:39–50, ImageCropDialog.kt:85–95, ImageCropDialog.kt:148–156

### string/ui_top (P2): accept

English: Top
Current Hungarian: Felül
Submitted proposal: Felső szél

Felső szél supplies the missing edge noun in both the field label and the generated possessive crop description. It fixes Felül vágása consistently with the three priority edge proposals. This is an isolated adjacent P2 proposal assessment, not review of the P2 tier.

Consumers: ImageCropDialog.kt:69–75, ImageCropDialog.kt:98–118

Exact string substitution for actual pixel/percent contentDescription calls, not runtime speech evidence.
Current: Felül vágása képpontban | Felül vágása százalékban
Proposed: Felső szél vágása képpontban | Felső szél vágása százalékban

### plurals/ui_crop_preview_images (P2): accept

English:
- one: Preview: %1$d × %2$d px\nApply to %3$d image. Cropping placed images may move their attached images.
- other: Preview: %1$d × %2$d px\nApply to %3$d images. Cropping placed images may move their attached images.
Current Hungarian:
- one: Előnézet: %1$d × %2$d px\nAlkalmazás %3$d képre. Az elhelyezett kép vágása áthelyezi a csatolásait.
- other: Előnézet: %1$d × %2$d px\nAlkalmazás %3$d képre. Az elhelyezett képek vágása áthelyezi a csatolásaikat.
Submitted proposal:
- one: Előnézet: %1$d × %2$d px\nAlkalmazás %3$d képre. Az elhelyezett képek vágása elmozdíthatja a hozzájuk csatolt képeket.
- other: Előnézet: %1$d × %2$d px\nAlkalmazás %3$d képre. Az elhelyezett képek vágása elmozdíthatja a hozzájuk csatolt képeket.

Both proposed quantity forms restore the modal elmozdíthatja (may move) and name the affected objects as hozzájuk csatolt képeket (images attached to them), not abstract attachments. The generic plural elhelyezett képek is appropriate in both forms because the final sentence is a general warning, just as in English; the count-specific sentence correctly uses the singular noun képre after a Hungarian numeral. Static attachment layout depends on the parent edge, so cropping can move children but need not move all of them.

Consumers: ImageCropDialog.kt:85–95, ImageAssembly.kt:154–159, ImageAssembly.kt:196–220

Static illustrative substitution for one; width=320, height=240, selected image count=1. The numeric sample is not an observed device state.
Current: Előnézet: 320 × 240 px\nAlkalmazás 1 képre. Az elhelyezett kép vágása áthelyezi a csatolásait.
Proposed: Előnézet: 320 × 240 px\nAlkalmazás 1 képre. Az elhelyezett képek vágása elmozdíthatja a hozzájuk csatolt képeket.

Static illustrative substitution for other; width=320, height=240, selected image count=2. The numeric sample is not an observed device state.
Current: Előnézet: 320 × 240 px\nAlkalmazás 2 képre. Az elhelyezett képek vágása áthelyezi a csatolásaikat.
Proposed: Előnézet: 320 × 240 px\nAlkalmazás 2 képre. Az elhelyezett képek vágása elmozdíthatja a hozzájuk csatolt képeket.

## Cross-language decoder-memory concern

The Vietnamese main clause also says the decoder buffers exceed the limit; the same aggregate-estimate concern applies. Reopen only this candidate, not the rest of that independent review.

With a 100 MiB working budget, 70 MiB native work, 40 MiB resident bitmap memory and a 1-pixel target, the complete estimate can exceed 110 MiB while native work is below 100 MiB. This is arithmetic from the source expression, not execution or a runtime reproduction.

The English itself uses a compressed/awkward output-fitting-buffers construction. It is safer to preserve total memory insufficiency, minimum output, decoder work and cancellation guidance without asserting that buffers alone exceed the entire budget.

## Files

- independent-review.json: exact values/hashes, per-key rationale, source excerpts and composed examples.
- README.md: human-readable full review.

No builds or releases were performed.
