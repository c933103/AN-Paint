# Independent Lithuanian wording review

Accept the exact 17-edit candidate within bounded linguistic/static-consumer scope. Keep the four unchanged terminology holds. Correct illustrative category pairings in the receipt; this does not require changing the translation patch.

Source tree: `b9b148d5d8ef7c7b088500a9c177f9f59304b800`.

## Exact decisions

- 14 priority candidate edits: ACCEPT.
- 3 external P2 dependency edits: ACCEPT, with their atomic groups.
- 3 priority labels: ACCEPT only after both crop templates are changed.
- 4 unchanged terminology values: HOLD, with source-informed follow-on substitutes below.
- No XML-value revision required within the 17-edit patch. One evidence-example correction is required.

## Evidence correction

Existing examples pair Piešimas with Elipsė and Laisvos formos žymėjimas. Those are linguistically possible artificial substitutions but not the real category/selected-tool pairs in ToolCategoryButton.kt.
Use Įterpti with Elipsė and Žymėjimas with Laisvos formos žymėjimas. For feminine tool agreement inside Piešimas, use Akvarelė. Correct source-valid examples are included in this receipt.

## Per-key review

### string/formats22_animation_message

Decision: accept_candidate; scope: priority_candidate_edit; confidence: high.

English: This %1$s contains %2$s frames. AN Paint edits still images and does not preserve animation.

Current: Šis %1$s turi %2$s kadrus. AN Paint redaguoja nejudančius vaizdus ir animacijos neišsaugo.

Proposed: Šio %1$s vaizdo kadrų skaičius: %2$s. AN Paint redaguoja nejudančius vaizdus ir animacijos neišsaugo.

Accept the count-label construction. The consumer supplies exact decimal integer strings or bent + integer, not an inflected noun. Kadrų skaičius: avoids singular/plural case selection at 2, 10, 11, 21, 22 and lower bounds; Šio ... vaizdo is grammatical with the format token. Still-image-only editing and loss of animation remain explicit.

Consumers: [`Paintroid/src/main/java/org/catrobat/paintroid/classic/ImportSelection.kt:92`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ImportSelection.kt#L92).

### string/formats22_animation_unknown

Decision: accept_candidate; scope: priority_candidate_edit; confidence: high.

English: This %1$s is too complex to confirm whether it contains multiple frames. AN Paint will open only a still image and will not preserve any animation.

Current: Šis %1$s per sudėtingas patvirtinti, ar turi kelis kadrus. AN Paint atvers tik nejudantį vaizdą ir animacijos neišsaugos.

Proposed: Šis %1$s vaizdas yra per sudėtingas, kad būtų galima nustatyti, ar jame yra keli kadrai. AN Paint atvers tik nejudantį vaizdą ir animacijos neišsaugos.

Accept. The kad būtų galima nustatyti clause is idiomatic and preserves uncertainty about multiple frames. It does not assert that animation was detected. Vaizdas supplies the noun needed with the format token; subsequent atvers/neišsaugos retain the future consequence.

Consumers: [`Paintroid/src/main/java/org/catrobat/paintroid/classic/ImportSelection.kt:91`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ImportSelection.kt#L91).

### string/ui_d_d_pixels_2f_mp_exceeds_the_current

Decision: accept_candidate; scope: priority_candidate_edit; confidence: high.

English: %1$d × %2$d pixels (%3$.2f MP) exceeds the current safe editing budget of %4$.2f MP. AN Paint keeps the complete image in memory and reserves space for transforms and selections. Available memory determines this budget. The operation was stopped before allocating the oversized bitmap. No automatic resizing was applied.

Current: %1$d × %2$d pikseliai (%3$.2f MP) viršija dabartinę saugią redagavimo ribą %4$.2f MP. AN Paint laiko visą vaizdą atmintyje ir rezervuoja vietą transformacijoms bei žymėjimams. Šią ribą lemia turima atmintis. Veiksmas sustabdytas prieš paskiriant per didelį rastrinį vaizdą. Automatinis dydžio keitimas netaikytas.

Proposed: Vaizdas, kurio matmenys %1$d × %2$d px (%3$.2f MP), viršija dabartinę saugią redagavimo ribą (%4$.2f MP). AN Paint laiko visą vaizdą atmintyje ir rezervuoja vietą transformacijoms bei žymėjimams. Šią ribą lemia turima atmintis. Veiksmas sustabdytas prieš skiriant atmintį per dideliam rastriniam vaizdui. Automatinis dydžio keitimas netaikytas.

Accept. Explicit Vaizdas makes the singular predicate viršija unambiguous; px avoids inflecting a counted unit after a pair of dimensions. The threshold remains the current memory-determined safe editing limit, not a file-size limit. Skiriant atmintį ... rastriniam vaizdui correctly expresses bitmap allocation. All full-image residency, transform/selection reserve, preallocation stop and no-auto-resize claims are retained.

Consumers: [`Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageMemoryPolicy.kt:46`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageMemoryPolicy.kt#L46).

### string/language20_translation_note

Decision: accept_candidate; scope: priority_candidate_edit; confidence: high.

English: App language\n\nTranslations are maintained in AN Paint’s language resources. New or untranslated text appears in English.

Current: Šioje kalbos versijoje yra visas verčiamas AN Paint sąsajos tekstas.

Proposed: Programos kalba\n\nVertimai tvarkomi AN Paint kalbų ištekliuose. Naujas arba neišverstas tekstas rodomas anglų kalba.

Accept. Restores all three source elements: app-language heading, maintenance in language resources, and English fallback for new/untranslated text. The old claim of completeness is not retained. Literal Android \n\n boundary matches the English resource.

Consumers: [`Paintroid/src/main/java/org/catrobat/paintroid/classic/AppLanguage.kt:149`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/AppLanguage.kt#L149).

### string/ui_collapse_tool_category

Decision: accept_candidate; scope: priority_candidate_edit; confidence: high.

English: %1$s: %2$s selected. Collapse tools and options

Current: %1$s: pasirinkta %2$s. Suskleisti įrankius ir parinktis

Proposed: %1$s. Pasirinktas įrankis: %2$s. Suskleisti įrankius ir parinktis

Accept. Pasirinktas agrees with explicit masculine įrankis rather than the variable tool label; the colon makes feminine Akvarelė/Elipsė and noun phrases independent labels. Suskleisti is the correct collapse action. Source categories should be represented accurately in examples, as noted separately.

Consumers: [`Paintroid/src/main/java/org/catrobat/paintroid/classic/ToolCategoryButton.kt:27`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ToolCategoryButton.kt#L27).

### string/ui_colour_palette_tap_for_foreground_hold_for_background

Decision: accept_candidate; scope: priority_candidate_edit; confidence: high.

English: Colour palette. Tap for foreground; hold for background. Scroll for more colours.

Current: Spalvų paletė. Palieskite priekinio plano spalvai; laikykite nuspaudę fonui. Slinkite, kad matytumėte daugiau spalvų.

Proposed: Spalvų paletė. Palieskite spalvą, kad pasirinktumėte priekinio plano spalvą; palaikykite nuspaudę, kad pasirinktumėte fono spalvą. Slinkite, kad matytumėte daugiau spalvų.

Accept. The imperative plus purpose clause makes foreground and background selection explicit and maps to click versus long-click. Palaikykite nuspaudę is appropriate for holding a swatch; the scroll instruction remains. Repetition of spalvą is stylistic verbosity, not a meaning defect.

Consumers: [`Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:604`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt#L604).

### string/ui_colour_tap_foreground_hold_background

Decision: accept_candidate; scope: priority_candidate_edit; confidence: high.

English: Colour #%1$s. Tap foreground, hold background.

Current: Spalva #%1$s. Palieskite priekiniam planui, laikykite nuspaudę fonui.

Proposed: Spalva #%1$s. Palieskite, kad pasirinktumėte priekinio plano spalvą; palaikykite nuspaudę, kad pasirinktumėte fono spalvą.

Accept. Correct click/hold mapping and foreground/background distinction. The one literal # precedes a six-digit hex argument that has no # in the consumer, so there is no duplication. The purpose clauses remove the clipped original datives without adding a new action.

Consumers: [`Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:615`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt#L615).

### string/ui_d_d_px_d_pixels_2f_mp

Decision: accept_candidate; scope: priority_candidate_edit; confidence: high.

English: %1$d × %2$d px · Pixel count: %3$,d (%4$.2f MP)

Current: %1$d × %2$d px · %3$,d pikseliai (%4$.2f MP)

Proposed: %1$d × %2$d px · Pikselių skaičius: %3$,d (%4$.2f MP)

Accept. Pikselių skaičius is a natural count heading and matches current English exactly in meaning. It is not a fixed plural attached to the value. Width, height, grouped total count and MP formatting remain in the original order.

Consumers: [`Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageImport.kt:15`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageImport.kt#L15).

### string/ui_enter_valid_dimensions

Decision: accept_candidate; scope: priority_candidate_edit; confidence: high.

English: Enter valid dimensions.

Current: Įveskite galiojančius matmenis.

Proposed: Įveskite tinkamus matmenis.

Accept as idiomatic improvement. Tinkamus describes acceptable numeric dimensions; the old galiojančius is awkward technical phrasing, not necessarily a separate semantic failure or an expiry promise. The consumer uses this only when DimensionControls returns no valid size.

Consumers: [`Paintroid/src/main/java/org/catrobat/paintroid/classic/AssemblyActivity.kt:311`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/AssemblyActivity.kt#L311).

### string/ui_expand_tool_category

Decision: accept_candidate; scope: priority_candidate_edit; confidence: high.

English: %1$s: %2$s selected. Expand tools and options

Current: %1$s: pasirinkta %2$s. Išskleisti įrankius ir parinktis

Proposed: %1$s. Pasirinktas įrankis: %2$s. Išskleisti įrankius ir parinktis

Accept. Uses the same agreement-safe label structure as collapse, with Išskleisti as the correct expansion action. No need to inflect each variable tool label or change its standalone resource.

Consumers: [`Paintroid/src/main/java/org/catrobat/paintroid/classic/ToolCategoryButton.kt:27`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ToolCategoryButton.kt#L27).

### string/ui_height_in

Decision: accept_candidate; scope: priority_candidate_edit; confidence: high.

English: Height in %1$s

Current: Aukštis %1$s vienetais

Proposed: Aukštis %1$s

Accept only with both unit keys and the width template. Aukštis pikseliais / Aukštis procentais are grammatical instrumental-unit phrases. Removing vienetais avoids a redundant or ungrammatical second unit phrase.

Atomic group: dimension-unit-hints.

Consumers: [`Paintroid/src/main/java/org/catrobat/paintroid/classic/DimensionControls.kt:82`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/DimensionControls.kt#L82).

### string/ui_none

Decision: accept_candidate; scope: priority_candidate_edit; confidence: medium-high.

English: None

Current: Nėra

Proposed: Nepažymėti nė vieno

Accept as a select-none action for the verified crop checkbox list. Nepažymėti nė vieno has the genitive licensed by negation and an understood vaizdo. It is more informative than status-like Nėra. A cancellation-style wording would also be possible, but is not required. The sibling Visi is retained; no claim is made that longer button text has been layout-tested.

Consumers: [`Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt:135`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt#L135).

### string/ui_percent_fd8671

Decision: accept_candidate; scope: priority_candidate_edit; confidence: high.

English: percent

Current: procentai

Proposed: procentais

Accept only in the four-key dimension group. Procentais is instrumental plural and composes correctly with Plotis/Aukštis. Direct source references were independently rechecked: the key is used in the two contentDescription constructions, not the standalone radio labels.

Atomic group: dimension-unit-hints.

Consumers: [`Paintroid/src/main/java/org/catrobat/paintroid/classic/DimensionControls.kt:81`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/DimensionControls.kt#L81), [`Paintroid/src/main/java/org/catrobat/paintroid/classic/DimensionControls.kt:82`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/DimensionControls.kt#L82).

### string/ui_pixels_6ec9c2

Decision: accept_candidate; scope: priority_candidate_edit; confidence: high.

English: pixels

Current: pikseliai

Proposed: pikseliais

Accept only in the four-key dimension group. Pikseliais is instrumental plural; it is suitable regardless of the current numeric value because it names the measurement unit, not a counted quantity. Standalone Pikseliai is a distinct key and remains unchanged.

Atomic group: dimension-unit-hints.

Consumers: [`Paintroid/src/main/java/org/catrobat/paintroid/classic/DimensionControls.kt:81`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/DimensionControls.kt#L81), [`Paintroid/src/main/java/org/catrobat/paintroid/classic/DimensionControls.kt:82`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/DimensionControls.kt#L82).

### string/ui_trim_in_percent

Decision: accept_candidate; scope: external_P2_dependency; confidence: medium-high.

English: %1$s trim in percent

Current: %1$s apkirpimas procentais

Proposed: %1$s: apkirpimas procentais

Accept with the pixel counterpart. The colon lets each edge resource function as a separate heading, avoiding the left/right nominative-noun concatenation. Procentais denotes the input unit and does not claim an absolute crop size. Symmetry with pixel mode is necessary because the consumer replaces the content description on unit changes.

Atomic group: crop-edge-hints.

Consumers: [`Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt:104`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt#L104).

### string/ui_trim_in_pixels

Decision: accept_candidate; scope: external_P2_dependency; confidence: medium-high.

English: %1$s trim in pixels

Current: %1$s apkirpimas pikseliais

Proposed: %1$s: apkirpimas pikseliais

Accept with the percent counterpart. Kairė: apkirpimas pikseliais and Dešinė: apkirpimas pikseliais are intelligible label-plus-description forms. Viršuje/Apačioje work as independent location headings. The strongest original grammar defect is the bare left/right concatenation, not a claim that every top/bottom phrase is independently ungrammatical.

Atomic group: crop-edge-hints.

Consumers: [`Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt:104`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt#L104), [`Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt:116`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt#L116).

### string/ui_width_in

Decision: accept_candidate; scope: external_P2_dependency; confidence: high.

English: Width in %1$s

Current: Plotis %1$s vienetais

Proposed: Plotis %1$s

Accept as an external P2 dependency in the same four-key dimension group. Plotis pikseliais / Plotis procentais are correct. Updating only the shared units while retaining vienetais here would leave an inferior sibling construction.

Atomic group: dimension-unit-hints.

Consumers: [`Paintroid/src/main/java/org/catrobat/paintroid/classic/DimensionControls.kt:81`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/DimensionControls.kt#L81).

### string/ui_left

Decision: accept_current_if_dependencies_applied; scope: dependent_priority_label; confidence: medium-high.

English: Left

Current: Kairė

Proposed: Kairė

Kairė is an acceptable short heading naming the left edge. The colon templates, rather than an unmotivated change to the shared edge label, repair its crop-field composition.

Required dependencies: string/ui_trim_in_pixels, string/ui_trim_in_percent.

Consumers: [`Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt:72`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt#L72).

### string/ui_right

Decision: accept_current_if_dependencies_applied; scope: dependent_priority_label; confidence: medium-high.

English: Right

Current: Dešinė

Proposed: Dešinė

Dešinė is an acceptable short heading naming the right edge. Keep it independent from apkirpimas with the paired colon templates.

Required dependencies: string/ui_trim_in_pixels, string/ui_trim_in_percent.

Consumers: [`Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt:72`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt#L72).

### string/ui_bottom

Decision: accept_current_if_dependencies_applied; scope: dependent_priority_label; confidence: medium-high.

English: Bottom

Current: Apačioje

Proposed: Apačioje

Apačioje is an acceptable location heading for the bottom crop margin. It differs morphologically from Kairė/Dešinė but remains understandable; the colon makes the boundary explicit. Uniform standalone heading morphology would be optional consistency work, not required for this candidate.

Required dependencies: string/ui_trim_in_pixels, string/ui_trim_in_percent.

Consumers: [`Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt:72`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt#L72).

### string/gallery_credit_could_not_save

Decision: hold_current; scope: existing_terminology_hold; confidence: medium.

English: The image credits could not be saved or restored. Existing saved credits have been kept. Try again.

Current: Vaizdų priskyrimų nepavyko išsaugoti arba atkurti. Anksčiau išsaugoti priskyrimai išliko. Bandykite dar kartą.

Unchanged in current candidate. Suggested follow-on substitute: Vaizdų priskyrimo informacijos nepavyko išsaugoti arba atkurti. Anksčiau išsaugota priskyrimo informacija išliko. Bandykite dar kartą.

Retain the hold on the unchanged bare-plural priskyrimai in this candidate, not on the save/restore/preservation logic. Creative Commons directly verifies priskyrimas as attribution terminology; it does not establish the naturalness of plural database/UI records called priskyrimai. The supplied follow-on substitute retains that established root but makes the stored information/record explicit. Review the full credit UI coherently before treating this as resolved; do not narrow the concept to only authors, because source/licence notices and editable additions are stored too.

Follow-on dependency: {"scope": "coherent credit label and warning terminology", "examples": ["string/ui_image_credits", "string/gallery_edit_credits", "string/gallery_credit_saved", "string/legacy_credits_title", "string/legacy_credits_hint"], "status": "terminology decision not included in the 17-edit candidate"}.

References: [https://creativecommons.org/licenses/by/4.0/deed.lt](https://creativecommons.org/licenses/by/4.0/deed.lt).

Consumers: [`Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:238`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt#L238), [`Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:899`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt#L899), [`Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:1185`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt#L1185), [`Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:1188`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt#L1188), [`Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:1194`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt#L1194), [`Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:1198`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt#L1198), [`Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:1469`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt#L1469), [`Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:1479`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt#L1479), [`Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:1486`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt#L1486), [`Paintroid/src/main/java/org/catrobat/paintroid/classic/MediaGalleryActivity.kt:62`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/MediaGalleryActivity.kt#L62), [`Paintroid/src/main/java/org/catrobat/paintroid/classic/MediaGalleryActivity.kt:243`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/MediaGalleryActivity.kt#L243), [`Paintroid/src/main/java/org/catrobat/paintroid/classic/MediaGalleryActivity.kt:415`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/MediaGalleryActivity.kt#L415), [`Paintroid/src/main/java/org/catrobat/paintroid/classic/GalleryCredits.kt:79`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/GalleryCredits.kt#L79), [`Paintroid/src/main/java/org/catrobat/paintroid/classic/GalleryCredits.kt:113`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/GalleryCredits.kt#L113).

### string/gallery_credit_too_large

Decision: hold_current; scope: existing_terminology_hold; confidence: medium.

English: These image credits would make the drawing too large to restore. Your previous drawing and credits have been kept.

Current: Dėl šių vaizdų priskyrimų piešinys taptų per didelis, kad jį būtų galima atkurti. Ankstesnis piešinys ir priskyrimai išsaugoti.

Unchanged in current candidate. Suggested follow-on substitute: Dėl šios vaizdų priskyrimo informacijos piešinys taptų per didelis, kad jį būtų galima atkurti. Ankstesnis piešinys ir priskyrimo informacija išsaugoti.

Retain the hold on the unchanged bare-plural priskyrimai in this candidate, not on the save/restore/preservation logic. Creative Commons directly verifies priskyrimas as attribution terminology; it does not establish the naturalness of plural database/UI records called priskyrimai. The supplied follow-on substitute retains that established root but makes the stored information/record explicit. Review the full credit UI coherently before treating this as resolved; do not narrow the concept to only authors, because source/licence notices and editable additions are stored too.

Follow-on dependency: {"scope": "coherent credit label and warning terminology", "examples": ["string/ui_image_credits", "string/gallery_edit_credits", "string/gallery_credit_saved", "string/legacy_credits_title", "string/legacy_credits_hint"], "status": "terminology decision not included in the 17-edit candidate"}.

References: [https://creativecommons.org/licenses/by/4.0/deed.lt](https://creativecommons.org/licenses/by/4.0/deed.lt).

Consumers: [`Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:1209`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt#L1209), [`Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:1444`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt#L1444), [`Paintroid/src/main/java/org/catrobat/paintroid/classic/GalleryCredits.kt:111`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/GalleryCredits.kt#L111).

### string/legacy_credits_unreadable

Decision: hold_current; scope: existing_terminology_hold; confidence: medium.

English: Some saved credits could not be read. Their stored copies have been kept.

Current: Kai kurių išsaugotų priskyrimų nepavyko perskaityti. Jų saugomos kopijos išsaugotos.

Unchanged in current candidate. Suggested follow-on substitute: Kai kurių išsaugotų priskyrimo įrašų nepavyko perskaityti. Jų saugomos kopijos išsaugotos.

Retain the hold on the unchanged bare-plural priskyrimai in this candidate, not on the save/restore/preservation logic. Creative Commons directly verifies priskyrimas as attribution terminology; it does not establish the naturalness of plural database/UI records called priskyrimai. The supplied follow-on substitute retains that established root but makes the stored information/record explicit. Review the full credit UI coherently before treating this as resolved; do not narrow the concept to only authors, because source/licence notices and editable additions are stored too.

Follow-on dependency: {"scope": "coherent credit label and warning terminology", "examples": ["string/ui_image_credits", "string/gallery_edit_credits", "string/gallery_credit_saved", "string/legacy_credits_title", "string/legacy_credits_hint"], "status": "terminology decision not included in the 17-edit candidate"}.

References: [https://creativecommons.org/licenses/by/4.0/deed.lt](https://creativecommons.org/licenses/by/4.0/deed.lt).

Consumers: [`Paintroid/src/main/java/org/catrobat/paintroid/classic/LegacyImageCreditsActivity.kt:93`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/LegacyImageCreditsActivity.kt#L93).

### string/save20_gif_description

Decision: hold_current; scope: existing_terminology_hold; confidence: medium.

English: Still image, up to 256 colours. Dithering smooths colour gradients. Animated GIFs open as their first frame.

Current: Nejudantis vaizdas, iki 256 spalvų. Diteringas glotnina spalvų perėjimus. Animuoti GIF atveriami kaip pirmasis kadras.

Unchanged in current candidate. Suggested follow-on substitute: Nejudantis vaizdas, iki 256 spalvų. Spalvų smulkinimas glotnina spalvų perėjimus. Animuoti GIF atveriami kaip pirmasis kadras.

Retain the hold on the unchanged Diteringas value in this 17-edit candidate. A real primary-source Lithuanian graphics precedent now exists: GIMP uses Smulkinimas for dithering in gradient and indexed-colour documentation. Recommend the supplied paired substitute with save20_dither = Smulkinti spalvas as a follow-on terminology edit. This is grounded product terminology, not a claim of a universal or legally mandated standard. Do not silently count the unmodified current value as accepted.

Follow-on dependency: {"key": "string/save20_dither", "english": "Dither colours", "current": "Diteruoti spalvas", "suggested": "Smulkinti spalvas", "status": "new terminology dependency, outside the accepted 17 edits"}.

References: [https://docs.gimp.org/3.0/lt/gimp-image-convert-indexed.html](https://docs.gimp.org/3.0/lt/gimp-image-convert-indexed.html), [https://docs.gimp.org/3.0/lt/gimp-tool-gradient.html](https://docs.gimp.org/3.0/lt/gimp-tool-gradient.html).

Consumers: [`Paintroid/src/main/java/org/catrobat/paintroid/classic/SaveOptionsDialog.kt:95`](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/SaveOptionsDialog.kt#L95).

## Source-valid illustrative compositions

### animation

- Šio GIF vaizdo kadrų skaičius: 2. AN Paint redaguoja nejudančius vaizdus ir animacijos neišsaugo.
- Šio GIF vaizdo kadrų skaičius: 10. AN Paint redaguoja nejudančius vaizdus ir animacijos neišsaugo.
- Šio GIF vaizdo kadrų skaičius: 11. AN Paint redaguoja nejudančius vaizdus ir animacijos neišsaugo.
- Šio GIF vaizdo kadrų skaičius: 21. AN Paint redaguoja nejudančius vaizdus ir animacijos neišsaugo.
- Šio GIF vaizdo kadrų skaičius: 22. AN Paint redaguoja nejudančius vaizdus ir animacijos neišsaugo.
- Šio GIF vaizdo kadrų skaičius: bent 2. AN Paint redaguoja nejudančius vaizdus ir animacijos neišsaugo.
- Šio GIF vaizdo kadrų skaičius: bent 10. AN Paint redaguoja nejudančius vaizdus ir animacijos neišsaugo.
- Šio GIF vaizdo kadrų skaičius: bent 21. AN Paint redaguoja nejudančius vaizdus ir animacijos neišsaugo.

### dimensions

- Plotis pikseliais
- Plotis procentais
- Aukštis pikseliais
- Aukštis procentais

### tool_categories

- Piešimas. Pasirinktas įrankis: Pieštukas. Išskleisti įrankius ir parinktis
- Piešimas. Pasirinktas įrankis: Akvarelė. Išskleisti įrankius ir parinktis
- Įterpti. Pasirinktas įrankis: Elipsė. Išskleisti įrankius ir parinktis
- Žymėjimas. Pasirinktas įrankis: Laisvos formos žymėjimas. Išskleisti įrankius ir parinktis
- Piešimas. Pasirinktas įrankis: Pieštukas. Suskleisti įrankius ir parinktis
- Piešimas. Pasirinktas įrankis: Akvarelė. Suskleisti įrankius ir parinktis
- Įterpti. Pasirinktas įrankis: Elipsė. Suskleisti įrankius ir parinktis
- Žymėjimas. Pasirinktas įrankis: Laisvos formos žymėjimas. Suskleisti įrankius ir parinktis

### crop

- Kairė: apkirpimas pikseliais
- Viršuje: apkirpimas pikseliais
- Dešinė: apkirpimas pikseliais
- Apačioje: apkirpimas pikseliais
- Kairė: apkirpimas procentais
- Viršuje: apkirpimas procentais
- Dešinė: apkirpimas procentais
- Apačioje: apkirpimas procentais

## Limits

- Independent model review, not a native-human or whole-language certification.
- No builds, Gradle, APK, CI dispatch, emulator, device, Android/JVM formatting, installed UI or TalkBack runs.
- No source edits, releases or integration actions. Temporary receipt only for parent-owned durable tracker.
- Direct source references and XML aliases were searched in Paintroid/src/main. This does not prove absence of all dynamic use.
- Four terminology substitute suggestions are separate from the accepted 17-edit patch and do not change its acceptance tally.
- No layout or speech-output claim; longer palette/button strings remain unmeasured.
