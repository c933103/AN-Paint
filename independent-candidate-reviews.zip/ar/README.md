# Independent Arabic correction review — 21 October 2026

**Result: accept all eight complete proposals linguistically. No revisions or holds.**

This is a separate model-assisted Modern Standard Arabic review of the eight proposed values only, not native-human certification and not a re-review of all 341 keys. Production files remain untouched. No builds or runtime checks were run.

Source: requested published commit `4355869e2e198b5616419291cba225b018444fab`; independently verified local tree `b9b148d5d8ef7c7b088500a9c177f9f59304b800`. The local snapshot HEAD is `ddffe57016c689b2a7868c31e415dcb625f5c6b5`. The parent owns the published-commit-to-tree mapping; this reviewer checked the actual source bytes and tree.

Acceptance applies to the exact full values and hashes in `independent-review.json`. All three English/current/proposed values match their source or candidate, the eight proposals match the full decisions file, formatter tokens and resource attributes are preserved, and the patch exactly matches the source-to-candidate diff.

## Per-key decisions

### 1. string/formats22_animation_message — ACCEPT (P0)

English: This %1$s contains %2$s frames. AN Paint edits still images and does not preserve animation.

Current Arabic: يحتوي %1$s هذا على %2$s إطارًا. يحرر AN Paint الصور الثابتة ولا يحتفظ بالحركة.

Accepted proposal: عدد الإطارات في ملف %1$s هذا: %2$s. يحرر AN Paint الصور الثابتة ولا يحتفظ بالحركة.

Accept the full proposed value. The label construction عدد الإطارات ...: separates the noun from its numerical value, so it works for the actual exact counts including 2, 3–10, 11 and 100 and for the composed lower bound such as 3 على الأقل. It avoids the old invariant accusative singular إطارًا after every count. ملف makes explicit the already-known imported-file context; it does not change the object or warning. The entire second sentence still says that AN Paint edits still images and does not retain animation.

ImportSelection.showAnimation, lines 89–96, passes format as String and frames as a String. frames is either frameCount.toString() or formats22_at_least_frames with an Int; frameCount below 2 uses the separate unknown-animation message. The proposed sentence therefore does not label an unknown count as exact. A count label is also grammatically compatible with a symbolic count, but no arbitrary symbolic-count producer was found or executed. The following still/poster warning remains a separate string and is unchanged.

Source: [ImportSelection.kt:89–96](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ImportSelection.kt#L89-L96), [AnimationInfo.kt:6–17](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/AnimationInfo.kt#L6-L17)

### 2. string/save20_gif_description — ACCEPT (P0)

English: Still image, up to 256 colours. Dithering smooths colour gradients. Animated GIFs open as their first frame.

Current Arabic: صورة ثابتة، حتى 256 لونًا. ينعّم التمويه المتعمد تدرجات الألوان. تفتح صور GIF المتحركة بإطارها الأول.

Accepted proposal: صورة ثابتة، حتى 256 لونًا. ينعّم تمويه الألوان بالنقط تدرجات الألوان. تفتح صور GIF المتحركة بإطارها الأول.

Accept the full proposed value. تمويه الألوان بالنقط identifies the palette-colour approximation operation rather than a generic intentional blur, and it is exactly the existing label of the adjacent dithering checkbox. تدرجات الألوان remains the object being smoothed, not a substitute name for the operation or a claim that a new gradient is created. The subject تمويه correctly takes ينعّم. The still-image limit, up-to-256-colour limit and opening animated GIFs as their first frame all remain intact; 256 لونًا has the appropriate counted-noun construction.

SaveOptionsDialog lines 64 and 90–95 show the named checkbox and this explanation together for GIF. ImageExporter passes the dither setting through BitmapFileCodec to LegacyImageEncoder.gif. The encoder uses an indexed palette and optional neighbour error diffusion when the palette is not exact; it is not a blur filter. The exact phrase is accepted in this app context, not asserted as the only standard Arabic translation of dithering.

Source: [SaveOptionsDialog.kt:64–95](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/SaveOptionsDialog.kt#L64-L95), [ImageExporter.kt:14–18](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageExporter.kt#L14-L18), [BitmapFileCodec.kt:11–16](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/BitmapFileCodec.kt#L11-L16), [LegacyImageEncoder.java:138–204](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/LegacyImageEncoder.java#L138-L204)

### 3. string/ui_bg — ACCEPT (P1)

English: BG

Current Arabic: BG

Accepted proposal: خلفية

Accept خلفية as a concise visible background-role label. It translates the function conveyed by the English abbreviation BG and agrees with the surrounding Arabic term لون الخلفية. It does not replace the actual hexadecimal colour code, invert the background/foreground roles or alter the independently supplied accessible description.

ColourStatusButton draws the backgroundColour label alongside its computed hex value, with a separate background edit target and content description. This is a human-readable role abbreviation, not a format identifier that needs to remain Latin.

Source: [ColourStatusButton.kt:17–36](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ColourStatusButton.kt#L17-L36), [ColourStatusButton.kt:40–68](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ColourStatusButton.kt#L40-L68)

### 4. string/ui_d_d_px_d_pixels_2f_mp — ACCEPT (P1)

English: %1$d × %2$d px · Pixel count: %3$,d (%4$.2f MP)

Current Arabic: %1$d × %2$d px · %3$,d بكسل (%4$.2f ميغابكسل)

Accepted proposal: %1$d × %2$d px · عدد البكسلات: %3$,d (%4$.2f ميغابكسل)

Accept the full proposed value. عدد البكسلات explicitly distinguishes the total pixel count from width × height, restoring the current English label. It also avoids treating arbitrary totals as if one fixed counted-noun form fits all values. The numeric placeholders keep exactly the original types, grouping flag, precision, order and units: Int width, Int height, Long product and floating-point megapixels. The word ميغابكسل remains a displayed unit.

ImageDimensions requires positive dimensions, computes width.toLong() * height, and passes all four arguments to describe(). The count label handles totals such as 2, 3, 10, 11 and 786,432 without a singular/dual/plural suffix tied to the number. px is intentionally retained as a unit token.

Source: [ImageImport.kt:12–16](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageImport.kt#L12-L16)

### 5. string/ui_fg — ACCEPT (P1)

English: FG

Current Arabic: FG

Accepted proposal: مقدمة

Accept مقدمة as a concise visible foreground-role label. It translates the function conveyed by the English abbreviation FG and agrees with the surrounding Arabic term لون المقدمة. It is a role noun, not an added instruction or a replacement for the hexadecimal value. The paired مقدمة / خلفية labels preserve the semantic contrast.

ColourStatusButton draws the foreground label alongside its computed hex value and has a separate foreground edit target and accessible description. The bare noun is natural in a compact colour-role label even though the full phrase is used elsewhere.

Source: [ColourStatusButton.kt:17–36](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ColourStatusButton.kt#L17-L36), [ColourStatusButton.kt:40–68](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ColourStatusButton.kt#L40-L68)

### 6. string/ui_hex_rrggbb — ACCEPT (P1)

English: Hex #RRGGBB

Current Arabic: سداسي #RRGGBB

Accepted proposal: سداسي عشري #RRGGBB

Accept سداسي عشري #RRGGBB. سداسي عشري explicitly identifies hexadecimal/base 16, while سداسي alone is ambiguous. A short adjectival label is appropriate for this field; no additional noun is required. The literal #RRGGBB remains byte-identical and is not translated or reversed.

AdvancedColourDialog uses the string as the hex field label and accessible description. The parser at lines 352–355 accepts a leading # followed by exactly six hexadecimal digits, and sync emits # plus six hex digits. The proposed term describes this representation rather than a six-sided shape or merely a six-character length.

Source: [AdvancedColourDialog.kt:225–246](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/AdvancedColourDialog.kt#L225-L246), [AdvancedColourDialog.kt:348–370](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/AdvancedColourDialog.kt#L348-L370)

### 7. string/ui_invalid_selection_outline — ACCEPT (P1)

English: Invalid selection outline.

Current Arabic: مخطط التحديد غير صالح.

Accepted proposal: محيط التحديد غير صالح.

Accept محيط التحديد غير صالح. In this context محيط names the selection boundary/contour more precisely than مخطط, which commonly denotes a plan or diagram. It does not claim that the selection pixels or mask were deleted or that every selection is invalid. غير صالح retains the original invalid-state meaning and agrees with masculine singular محيط.

SelectionOutline is a display-outline vector separate from the lossless selection mask. read() reconstructs contour points and uses this message when too many contours are supplied. محيط here denotes the geometric boundary, not a numeric perimeter measurement. The general warning appropriately avoids exposing an unsupported specific cause in the UI.

Source: [SelectionOutline.kt:12–46](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/SelectionOutline.kt#L12-L46)

### 8. string/ui_trim_amounts_must_fit_inside_each_image_use — ACCEPT (P1)

English: Trim amounts must fit inside each image; use whole pixels or percentages.

Current Arabic: يجب أن تلائم مقادير القص داخل كل صورة؛ استخدم بكسلات صحيحة أو نسبًا مئوية.

Accepted proposal: يجب ألا تتجاوز مقادير القص أبعاد كل صورة؛ استخدم أعدادًا صحيحة من البكسلات أو نسبًا مئوية.

Accept the full proposed value. يجب ألا تتجاوز ... أبعاد كل صورة is grammatical and states the per-image dimensional constraint more clearly than تلائم ... داخل. أعدادًا صحيحة من البكسلات unambiguously means integer pixel quantities, unlike بكسلات صحيحة, which can suggest valid/correct pixels. أو نسبًا مئوية retains percentages as the alternative input mode and does not incorrectly require whole-number percentages.

CropMargins.rect first rejects negative/nonfinite values. Its amount() checks each converted margin against the corresponding dimension and requires whole-number input only outside percentage mode. A separate later check rejects an empty crop. The proposal states the current error condition without promising that individually valid margins always leave a nonempty image, adding a positivity requirement, or changing the warning state.

Source: [ImageAssembly.kt:39–50](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageAssembly.kt#L39-L50)

## Scope boundaries

- No native-human or native-speaker certification.
- No runtime, screenshot, glyph shaping, mixed-script bidi, text-fit, font-size or TalkBack acceptance.
- FG/BG Arabic labels are accepted linguistically; their custom-drawn layout and accessibility rendering have not been tested. No text was shortened or changed merely to accommodate an untested layout.
- Static composition examples use illustrative ASCII digits and do not certify Android formatting, digit localization or display ordering.
- No source edit, Gradle, AAPT2, APK, CI, emulator, version/release change, PR or publication was performed.

The two formatted proposals preserve `%1$s` / `%2$s`, and `%1$d` / `%2$d` / `%3$,d` / `%4$.2f`, respectively. None of these eight values contains `%%`; no literal percent escape was added, removed or confused with a parameter. The `#RRGGBB` syntax and `px` unit are unchanged.

## Supplemental reference use

Arabic count categories are corroborated by [Unicode CLDR](https://unicode.org/cldr/charts/49/supplemental/language_plural_rules.html#ar). [Android’s Arabic colour-resource documentation](https://developer.android.com/guide/topics/resources/more-resources?hl=ar) supports the hexadecimal term. [Adobe’s dithering explanation](https://helpx.adobe.com/ph_fil/photoshop-elements/desktop/saving-printing-and-sharing-photos/dithering-web-images.html) supports the distinction between palette approximation and a blur/gradient operation. These sources do not certify the complete AN Paint translations.

No implementation or publication is included in this receipt. The root task owns any subsequent integration and durable publication.
