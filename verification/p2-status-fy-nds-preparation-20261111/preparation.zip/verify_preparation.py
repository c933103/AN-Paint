import hashlib,json,pathlib,stat,xml.etree.ElementTree as E
w=pathlib.Path(__file__).resolve().parent
load=lambda n:json.loads((w/n).read_text())
git=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
norm=lambda tree:{e['path']:{k:e[k] for k in ['path','mode','type','sha']} for e in tree['tree'] if e['type']!='tree'}
base=load('base-tree.json');fresh=load('fresh-tree.json');expected={e['path']:e for e in load('expected-tree.json')}
assert not base['truncated'] and not fresh['truncated'] and norm(base)==norm(fresh)
old={p['number']:{k:p[k] for k in ['head','base','ref']} for p in load('owners.json')};new={p['number']:{k:p[k] for k in ['head','base','ref']} for p in load('fresh-owners.json')};assert old==new
accepted=load('accepted-map.json');review=load('review.json');inputs=load('inputs.json');integration=load('integration.json');candidate=load('candidate.json')
assert review['candidate_sha256']==hashlib.sha256((w/'candidate.json').read_bytes()).hexdigest()
assert review['accepted_map_sha256']==hashlib.sha256(json.dumps(accepted,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert len(review['reviews'])==sum(map(len,candidate.values()))
reviewed=set()
for d in review['reviews']:
 t,k=d['locale'],d['key'];assert (t,k) not in reviewed;reviewed.add((t,k));assert d['source_value']==inputs['source'][k]['text'] and d['candidate_value']==candidate[t][k]
 if d['final_value_decision']=='accept': assert d['accepted_value']==d['final_value']==accepted[t][k]
 else: assert d['final_value_decision']=='hold' and k not in accepted.get(t,{})
held=load('held-absence.json');blobs=load('held-blobs.json')
for pair in held:
 assert new[pair['pr']]['head']==pair['head'];b=blobs[pair['blob']];assert git(b.encode())==pair['blob']
 assert not set(candidate[pair['tag']])&{n.get('name') for n in E.fromstring(b)}
count=0
for f in (w/'source').rglob('*'):
 path=f.relative_to(w/'source').as_posix()
 if f.is_file() and path in expected:
  assert git(f.read_bytes())==expected[path]['sha'],path
  assert ('100755' if f.stat().st_mode&stat.S_IXUSR else '100644')==expected[path]['mode'],path
  count+=1
changes=[path for path in expected if expected[path]!=norm(fresh)[path]]
assert set(changes)=={inputs['paths'][t] for t,v in accepted.items() if v} and set(expected)==set(norm(fresh))
for tag,values in accepted.items():
 path=inputs['paths'][tag];txt=(w/'source'/path).read_text();nodes={n.get('name'):n for n in E.fromstring(txt)}
 for k,v in values.items():
  n=nodes[k];assert n.text==v and n.attrib==inputs['source'][k]['attributes']
  txt=txt.replace('    '+E.tostring(n,encoding='unicode').rstrip()+'\n','')
 assert git(txt.encode())==norm(fresh)[path]['sha'],tag
 assert git((w/'source'/path).read_bytes())==integration[tag]['blob']
out={'base':inputs['base'],'base_tree':inputs['base_tree'],'complete_source_tree_unchanged':True,'checked_materialized_files':count,'complete_expected_leaves':len(expected),'open_owners':len(new),'held_heads':len({p['head'] for p in held}),'held_catalogue_pairs':len(held),'git_verified_held_blobs':len(blobs),'new_values':sum(map(len,accepted.values())),'old_nodes_preserved':sum(integration[t]['old_nodes_preserved'] for t in accepted),'source_changes':len(changes)}
(w/'preparation-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
