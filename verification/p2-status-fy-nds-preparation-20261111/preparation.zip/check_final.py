import json,pathlib,subprocess,sys
w=pathlib.Path(__file__).resolve().parent
subprocess.run([sys.executable,str(w/'integrate.py')],check=True)
with (w/'host-checks.log').open('w') as out:
 subprocess.run([sys.executable,'-m','unittest','test_translations.TranslationCatalogueTests','test_translations.AndroidResourceValidationTests','test_string_importance.StringImportanceTests','-v'],cwd=w/'source/tools',stdout=out,stderr=subprocess.STDOUT,check=True)
with (w/'proposed-recount.json').open('w') as out:
 subprocess.run([sys.executable,str(w/'source/tools/string_importance.py'),'--all-locales','--json'],stdout=out,check=True)
integ=json.loads((w/'integration.json').read_text());changes={x['path']:x['blob'] for x in integ.values() if isinstance(x,dict)}
leaves=[{**{k:e[k] for k in ['path','mode','type']},'sha':changes.get(e['path'],e['sha'])} for e in json.loads((w/'base-tree.json').read_text())['tree'] if e['type']!='tree']
(w/'expected-tree.json').write_text(json.dumps(leaves,indent=2)+'\n')
print('Final-source host checks passed. No new format parameters; no separate JDK sample needed.')
