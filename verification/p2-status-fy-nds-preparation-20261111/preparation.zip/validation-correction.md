# Preparation serialization correction

The first integration attempt stopped before changing XML or running host tests. The revised Frisian unsupported-image-URL sentence contained an ordinary ASCII apostrophe in dy't without Android escaping. The existing android_string_errors validator correctly rejected it as an unescaped Android apostrophe. The linguistic reviewer was asked to bind the same rendered wording with Android-safe dy\'t serialization and refresh the accepted-map hash. No application branch or CI was created. Final-source validation is recorded separately after correction.

A follow-on verification attempt then found expected-tree.json absent because integration had stopped; that was a consequence of the failed preparation, not an additional product test failure. No failed attempt is counted as passed.

Correction completed: the review binds Android-safe dy\'t, with ordinary rendered apostrophe unchanged; accepted-map SHA-256 796415812c7f0ce6110a9e88367b6f898d662c1a2e2323c97727c4a76edd7c43. Final integration and all 46 affected existing host tests passed. All 777 old complete XML nodes/attributes remained unchanged. Initial candidate decisions remain 9 accepted unchanged, 5 revised and 2 held; final-value decisions are normalized to 14 accepted and 2 held. No additional linguistic revisions were made in this serialization correction.
