"""Validate preserved hosted receipts against the reviewed candidate source."""
import hashlib
import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).parent
SOURCE = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT.parent / 'source'

def require(value, message):
    if not value:
        raise ValueError(message)

def read(name):
    return json.loads((ROOT / name).read_text())

summary = read('jvm-summary.json')
run = read('final-run.json')
merge = read('merge-commit.json')
require(run['status'] == 'completed' and run['conclusion'] == 'success', 'Run not successful')
require(run['head_sha'] == summary['source_head'], 'Wrong source head')
require(merge['sha'] == summary['hosted_checkout'], 'Wrong hosted checkout')
require(merge['tree']['sha'] == summary['source_tree'] == summary['hosted_tree'], 'Tree mismatch')
jobs = read('final-jobs.json')['jobs']
require(len(jobs) == 6 and all(j['status'] == 'completed' and j['conclusion'] == 'success' for j in jobs), 'Incomplete jobs')
test = SOURCE / 'Paintroid/src/test/java/org/catrobat/paintroid/local/EsperantoPriorityWordingTest.kt'
expected = set(re.findall(r'@Test fun (\w+)\(', test.read_text()))
xmls = list((ROOT / 'junit').glob('*.xml'))
totals = {k: 0 for k in ('tests', 'failures', 'errors', 'skipped')}
consumer_found = False
for path in xmls:
    root = ET.parse(path).getroot()
    cases = root.findall('testcase')
    require(len(cases) == int(root.get('tests')), 'Missing test cases')
    require(all(not any(case.find(tag) is not None for tag in ('failure', 'error', 'skipped')) for case in cases), 'Nonpassing JVM case')
    for key in totals:
        totals[key] += int(root.get(key, 0))
    if root.get('name') == summary['consumer_test_class']:
        consumer_found = True
        actual = [case.get('name') for case in cases]
        require(set(actual) == expected and len(actual) == len(expected) == 3, 'Consumer identity mismatch')
        require(all(not list(case) for case in cases), 'Nonpassing consumer')
require(consumer_found, 'Missing consumer suite')
require(totals == summary['jvm_totals'] and len(xmls) == summary['jvm_suite_count'], 'JVM aggregate mismatch')
require(all(totals[k] == 0 for k in ('failures', 'errors', 'skipped')), 'Nonpassing JVM tests')
require(not ET.parse(ROOT / 'lint-results-debug.xml').getroot().findall('issue'), 'Lint issues')
sys.path.insert(0, str(SOURCE / 'tools'))
from run_android_instrumentation import declared_tests, source_tests_sha256
source_tests = SOURCE / 'app/src/androidTest'
coverage = read('emulator-summary/app/coverage.json')
identity = read('emulator-summary/composed-device-identity.json')
require(coverage['success'] and coverage['execution_status'] == 'passed', 'Emulator union failed')
require(identity['commit'] == summary['hosted_checkout'] and identity['run_id'] == str(run['id']), 'Emulator identity mismatch')
require(identity['source_tests_sha256'] == source_tests_sha256(source_tests), 'Emulator source mismatch')
require(set(map(tuple, coverage['completed'])) == declared_tests(source_tests, sdk_level=35), 'Emulator app union mismatch')
require(len(coverage['completed']) == len(set(map(tuple, coverage['completed']))) == 45, 'Duplicate/missing emulator methods')
native = read('emulator-summary/Paintroid/androidTest-results/summary.json')
require(native['success'] and native['completed_tests'] == native['expected_tests'] == 74, 'Native suite incomplete')
require(not native['missing'] and not native['unexpected'] and not native['errors'], 'Native suite mismatches')
require(all(case['status'] == 'passed' for case in native['cases']), 'Native suite failure')
print(json.dumps({'success': True, 'jvm': totals, 'consumer_cases': sorted(expected), 'api35_app_methods': 45, 'api35_native_methods': 74, 'source_tree': summary['source_tree']}, indent=2))
