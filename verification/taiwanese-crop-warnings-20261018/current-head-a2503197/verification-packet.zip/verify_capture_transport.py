"""Read-only independent replay of unchanged source capture verifiers; no visual claim."""
from pathlib import Path
import json
import sys
import tempfile

SOURCE = Path(__file__).resolve().parent / 'source'
sys.path.insert(0, str(SOURCE / 'tools'))
from dialog_evidence_transport import extract as extract_dialog
from vertical_evidence_transport import extract as extract_vertical
from vertical_locale_matrix import verify_screenshots
from vertical_control_reachability import verify as verify_reachability


def verify(root):
    root = Path(root)
    with tempfile.TemporaryDirectory(prefix='anpaint-capture-verification-') as temporary:
        temporary = Path(temporary)
        dialog = extract_dialog(root / 'dialog-export', temporary / 'dialog',
                                root / 'app-dialog/androidTest-results/summary.json')
        vertical = extract_vertical(root / 'vertical-locale-export', temporary / 'vertical', 35)
        screenshots = verify_screenshots(temporary / 'vertical')
        reachability = verify_reachability(temporary / 'vertical/reachability', 35)
        receipts = {'dialog-evidence.json': dialog, 'vertical-locale-export.json': vertical,
                    'vertical-locale-screenshots.json': screenshots,
                    'vertical-control-reachability.json': reachability}
        for filename, result in receipts.items():
            assert result == json.loads((root / filename).read_text()), filename
        verified_files = 0
        for extracted, original in [(temporary / 'dialog', root / 'app/dialog-evidence'),
                                    (temporary / 'vertical', root / 'app/vertical-locale-evidence')]:
            expected = {p.relative_to(extracted) for p in extracted.rglob('*') if p.is_file()}
            actual = {p.relative_to(original) for p in original.rglob('*') if p.is_file()}
            assert expected == actual
            for path in expected:
                assert (extracted / path).read_bytes() == (original / path).read_bytes(), path
            verified_files += len(expected)
        return {'success': True, 'dialog_cases': len(dialog['cases']),
                'vertical_exports': len(vertical['locales']),
                'vertical_data_files': vertical['data_files'],
                'vertical_matrix_screenshots': screenshots['expected_screenshots'],
                'native_reachability_cases': len(reachability['cases']),
                'native_reachability_screenshots': reachability['screenshots'],
                'all_extracted_files_byte_equal': verified_files,
                'scope': 'Exact source, complete inventories, native state/bounds and transport/content hashes; no independent pixel, glyph, linguistic or physical-device review'}


if __name__ == '__main__':
    print(json.dumps(verify(Path(sys.argv[1])), indent=2))
