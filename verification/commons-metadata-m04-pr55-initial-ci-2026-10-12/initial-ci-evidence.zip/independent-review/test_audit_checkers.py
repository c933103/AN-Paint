"""Synthetic checker tests only. Creates no claimed CI evidence."""
import json, pathlib, tempfile, unittest
from PIL import Image
from audit_junit_renders import junit_audit,render_audit,TAGS,EVIDENCE
class CheckerTest(unittest.TestCase):
    def junit(self,body,expected):
        with tempfile.TemporaryDirectory() as td:
            p=pathlib.Path(td);(p/'TEST-fixture.xml').write_text(body)
            return junit_audit(p,expected)
    def test_exact_identity_sdk_suffix_is_preserved(self):
        xml='<testsuite tests="2" failures="0" errors="0" skipped="0"><testcase classname="C" name="a"/><testcase classname="C" name="a[30]"/></testsuite>'
        self.assertEqual('PASS',self.junit(xml,[['C','a'],['C','a[30]']])['status'])
        self.assertEqual('FAIL',self.junit(xml,[['C','a'],['C','a[35]']])['status'])
    def test_duplicates_fail(self):
        self.assertEqual('FAIL',self.junit('<testsuite><testcase classname="C" name="a"/><testcase classname="C" name="a"/></testsuite>',[['C','a']])['status'])
    def test_failure_error_and_skip_all_fail(self):
        for tag in ('failure','error','skipped'):
            with self.subTest(tag=tag):self.assertEqual('FAIL',self.junit(f'<testsuite><testcase classname="C" name="a"><{tag}>test fixture</{tag}></testcase></testsuite>',[['C','a']])['status'])
    def test_malformed_and_count_mismatch_fail(self):
        for xml in ('<nope','<testsuite tests="2"><testcase classname="C" name="a"/></testsuite>'):
            self.assertEqual('FAIL',self.junit(xml,[['C','a']])['status'])
    def test_missing_artifact_does_not_pass(self):
        with tempfile.TemporaryDirectory() as td:self.assertEqual('FAIL',junit_audit(pathlib.Path(td),[['C','a']])['status'])
    def test_render_inventory_and_control_corruption(self):
        expected={(t,a):'Synthetic test only '+t+'\u180e\u202f' for t in TAGS for a in ('copy','insert')}
        with tempfile.TemporaryDirectory() as td:
            root=pathlib.Path(td)
            for tag in TAGS:
                for w,h in ((320,640),(640,320)):
                    for scale in (1.0,2.0):
                        for action in ('copy','insert'):
                            stem=f'api35-{tag}-{w}x{h}-font{scale}-{action}'
                            im=Image.new('RGB',(w*2,h*2),'white');im.putpixel((1,1),(0,0,0));im.save(root/(stem+'.png'))
                            data=dict(evidence_kind=EVIDENCE,locale=tag,font_scale=scale,action=action,message=expected[(tag,action)],all_characters_laid_out=True)
                            (root/(stem+'.json')).write_text(json.dumps(data))
            self.assertEqual('PASS',render_audit(root,expected)['status'])
            path=root/'api35-mnc-Mong-320x640-font1.0-copy.json';original=path.read_text();data=json.loads(original);data['message']=data['message'].replace('\u180e','');path.write_text(json.dumps(data))
            self.assertEqual('FAIL',render_audit(root,expected)['status']);path.write_text(original)
            png=root/'api35-en-GB-320x640-font1.0-copy.png';png.unlink()
            self.assertEqual('FAIL',render_audit(root,expected)['status'])
if __name__=='__main__':unittest.main(verbosity=2)
