#!/usr/bin/env python3
"""Exact PR55 JUnit/render audit, including incomplete/failed artifacts.

Use the downloaded, externally source-bound regression artifact. This program
cannot derive GitHub run authenticity from JUnit or pixels. It never marks
image shaping/readability as manually reviewed. Frozen checkout is read-only.
"""
import argparse, collections, hashlib, json, pathlib, subprocess, sys
import xml.etree.ElementTree as ET
TREE='d80218496e45bbefcaa378d40e5cd9846b7988ee'
MERGE='14b1fdf8e02ebe6f765d63906f05c7e808524b76'
TAGS=('en-GB','ain-Kana','ain-Latn','bo','ryu','fr','ar','ja','vi-Hani','mn-Mong','mnc-Mong','lzh-Hant','en-XV','qaa-Zsye-XV')
EVIDENCE='Robolectric NATIVE rendering, not installed-device capture'
def sha(b):return hashlib.sha256(b).hexdigest()
def read_source(repo,path):return subprocess.check_output(['git','show',TREE+':'+path],cwd=repo)
def records(counter):return [{'classname':c,'name':n,'count':v} for (c,n),v in sorted(counter.items()) if v]
def junit_audit(directory,expected):
    errors=[]; files=[]; cases=[]; failures=[]; skipped=[]
    for path in sorted(directory.rglob('TEST-*.xml')) if directory.exists() else []:
        data=path.read_bytes();files.append({'path':str(path.relative_to(directory)),'sha256':sha(data)})
        try: root=ET.fromstring(data)
        except ET.ParseError as ex:errors.append(str(path)+': '+str(ex));continue
        for suite in root.iter('testsuite'):
            immediate=suite.findall('testcase')
            if 'tests' in suite.attrib and int(suite.get('tests'))!=len(immediate):errors.append(str(path)+': declared test count mismatch')
            for field,tag in [('failures','failure'),('errors','error'),('skipped','skipped')]:
                if field in suite.attrib and int(suite.get(field))!=sum(bool(c.findall(tag)) for c in immediate):errors.append(str(path)+': declared '+field+' mismatch')
        for case in root.iter('testcase'):
            key=(case.get('classname',''),case.get('name',''));cases.append(key)
            if not all(key):errors.append(str(path)+': testcase identity missing')
            for tag in ('failure','error','skipped'):
                for node in case.findall(tag):
                    record={'classname':key[0],'name':key[1],'kind':tag,'type':node.get('type'),'message':node.get('message'),'detail':node.text or '', 'xml':str(path.relative_to(directory))}
                    (skipped if tag=='skipped' else failures).append(record)
    actual=collections.Counter(cases); wanted=collections.Counter(tuple(x) for x in expected)
    missing=wanted-actual;extra=actual-wanted;duplicates={k:v for k,v in actual.items() if v>1}
    ok=bool(files) and not any((errors,failures,skipped,missing,extra,duplicates))
    return {'status':'PASS' if ok else 'FAIL','expected_count':sum(wanted.values()),'actual_count':len(cases),'passing_testcases':len(cases)-len({(x['classname'],x['name']) for x in failures+skipped}),'missing':records(missing),'unexpected':records(extra),'duplicates':records(duplicates),'failures_and_errors':failures,'skipped':skipped,'parse_or_count_errors':errors,'xml_files':files}
def messages(repo):
    fixture=json.loads(read_source(repo,'tools/fixtures/commons_metadata_query_failure_scope.json'))
    def resources(p):return {n.get('name'):''.join(n.itertext()) for n in ET.fromstring(read_source(repo,p)) if n.tag=='string'}
    defaults=resources('Paintroid/src/main/res/values/strings.xml');out={}
    for entry in fixture['entries']:
        tag=entry['tag']
        if tag not in TAGS:continue
        values=defaults|resources(entry['path'])
        for action,key in [('copy','commons_credit_copy_failed_reason'),('insert','ui_could_not_load_gallery_image')]:
            raw=values[key].replace('%1$s',values['commons_metadata_query_failed'])
            # Exact 14 reviewed profiles contain no Android quotation syntax
            # other than escaped apostrophes; fail closed if scope changes.
            raw=raw.replace("\\'","'")
            if '\\' in raw or '"' in raw:raise ValueError('unsupported Android quoting in '+tag)
            out[(tag,action)]=raw
    if set(out)!={(t,a) for t in TAGS for a in ('copy','insert')}:raise ValueError('render locale fixture incomplete')
    return out

def render_audit(directory,expected_messages):
    from PIL import Image
    wanted={f'api35-{tag}-{w}x{h}-font{scale}-{action}':(tag,w,h,scale,action) for tag in TAGS for w,h in [(320,640),(640,320)] for scale in (1.0,2.0) for action in ('copy','insert')}
    present={p.name:p for p in directory.iterdir() if p.is_file()} if directory.exists() else {}
    required={stem+suffix for stem in wanted for suffix in ('.png','.json')}
    missing=sorted(required-set(present));unexpected=sorted(set(present)-required);problems=[];checked=[]
    for stem,(tag,w,h,scale,action) in sorted(wanted.items()):
        png=present.get(stem+'.png');metadata=present.get(stem+'.json')
        if png is None or metadata is None:continue
        try:
            data=json.loads(metadata.read_bytes());reason=expected_messages[(tag,action)]
            expected={'evidence_kind':EVIDENCE,'locale':tag,'font_scale':scale,'action':action,'message':reason,'all_characters_laid_out':True}
            if data!=expected:problems.append({'file':metadata.name,'reason':'JSON mismatch','expected':expected,'actual':data})
            with Image.open(png) as im:
                im.load()
                if im.format!='PNG' or im.size!=(w*2,h*2):problems.append({'file':png.name,'reason':'format or xhdpi dimensions differ','format':im.format,'size':im.size})
                if all(lo==hi for lo,hi in im.convert('RGB').getextrema()):problems.append({'file':png.name,'reason':'uniform image'})
                size=list(im.size)
            checked.append({'stem':stem,'dimensions':size,'png_sha256':sha(png.read_bytes()),'json_sha256':sha(metadata.read_bytes()),'u180e_count':data.get('message','').count('\u180e'),'u202f_count':data.get('message','').count('\u202f')})
        except Exception as ex:problems.append({'file':stem,'reason':str(ex)})
    return {'status':'PASS' if not (missing or unexpected or problems) else 'FAIL','expected_pairs':112,'complete_pairs_checked':len(checked),'missing_files':missing,'unexpected_files':unexpected,'errors':problems,'pairs':checked,'visual_review':'UNRUN by this script; inspect actual pixels and maintain scroll/reachability limits. JSON text and PNG existence do not prove shaping.'}
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--repo',type=pathlib.Path,required=True);p.add_argument('--junit',type=pathlib.Path,required=True);p.add_argument('--renders',type=pathlib.Path,required=True);p.add_argument('--output',type=pathlib.Path,required=True);a=p.parse_args()
    inventory_bytes=read_source(a.repo,'verification/commons-metadata-m04-pr52-composition-2026-10-12/expected-jvm-identities.json');inventory=json.loads(inventory_bytes)
    if inventory['expected_count']!=890 or len(inventory['expected'])!=890:raise ValueError('expected inventory changed')
    result={'expected_source':{'merge':MERGE,'tree':TREE,'run_id':'38239121942','binding_limit':'Requires externally verified run/artifact identity; no source binding inferred from JUnit.'},'inventory_sha256':sha(inventory_bytes),'junit':junit_audit(a.junit,inventory['expected']),'renders':render_audit(a.renders,messages(a.repo))}
    result['status']='PASS' if result['junit']['status']==result['renders']['status']=='PASS' else 'FAIL'
    a.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:result[k] for k in ('status','expected_source','inventory_sha256')},indent=2));print('JUnit',result['junit']['status'],result['junit']['actual_count'],'/ 890; renders',result['renders']['status'],result['renders']['complete_pairs_checked'],'/ 112');sys.exit(0 if result['status']=='PASS' else 1)
if __name__=='__main__':main()
