# PR55 independent hosted-artifact review (in progress)

Binding: run 38239121942, synthetic merge `14b1fdf8e02ebe6f765d63906f05c7e808524b76`, reviewed tree `d80218496e45bbefcaa378d40e5cd9846b7988ee`. Parent verified remote run/artifact provenance; this review verifies actual downloaded contents. The source checkout is unchanged.

## Checked

- PASS: `audit_delivery.py` / `delivery-result.json`: outer artifact digest, build-info commit/run/debug variant, APK/source hashes, exact embedded-source equality, all 1,944 included tracked blobs versus immutable Git tree, exact three existing omissions, 6,258 extra native-source files confined to four existing native-source roots, and all 14 packaged font-directory assets byte-identical.
- PASS: all seven exact-script logs: hash, successful outcome, exact commands, producer-before-consumer order, up-to-date state and generated XML hashes including incremental comment/restoration. Source wrapper/build hashes match. This verifies retained toolchain receipts; it is not a fresh Gradle rerun.
- PASS: six synthetic checker tests in `checker-selftest.log`, including SDK suffix, duplicate, failure/error/skip, missing, malformed/count and script-control corruption rejection. These synthetic tests are not application test evidence.

## Actual failed JVM artifact

FAIL: exact 890 identities ran, 889 passed and one failed. No missing, extra, duplicate, skipped or malformed/count anomalies. Failure is the normal-landscape M04 line-width assertion. Capture order identifies ain-Kana copy as first failing profile, but its pixels/metrics were not saved, so actual clipping versus a fixture/assertion issue remains unresolved. See `failure-diagnosis.md` and `junit-render-result.json`.

Only 85 of 112 planned PNG/JSON pairs exist; all available pairs pass automated content/dimension/control checks. Seven actual images were directly inspected, listed with limits in `visual-inspection.json`. A separate reading-start capture issue is recorded. No complete visual/shaping acceptance is claimed.

PASS: actual compiled APK has exact default+59 M04 values plus the generated mixed-script Korean alias, 61 configurations total; Manchu U+180E positions 7/18/27 and Mongolian U+202F positions 7/17/30 survive compilation. See `audit_compiled_m04.py` / `compiled-m04-result.json`.

PASS: outer regression ZIP digest and all 2,073 extracted file bytes match; phase receipts record Python660/660, native build and lint passes, and JVM failure. See `regression-artifact-binding.json`.

Instrumentation, APK signing/alignment, universal ABI verification, installed flows and upgrade signing are not established by these checks. A debug APK with matching source is not a fully verified release.

## Reproduce

```sh
python3 audit_delivery.py --repo /workspace/shared/anpaint-m04-composition-20261012 --archive /workspace/shared/anpaint-pr55-ci-20261012/apk-and-source.zip --probes /workspace/shared/anpaint-pr55-ci-20261012/exact-script --output delivery-result.json
python3 -m unittest -v test_audit_checkers
python3 audit_junit_renders.py --repo /workspace/shared/anpaint-m04-composition-20261012 --junit EXTRACTED/Paintroid/build/test-results/testDebugUnitTest --renders EXTRACTED/Paintroid/build/reports/commons-metadata-m04 --output junit-render-result.json
```

The extraction root may differ: pass the actual explicit directories; do not merge attempts or variants. Test identities include their SDK suffix unchanged. PNG checks establish format/dimensions/nonuniform pixels and paired exact metadata; they cannot establish legibility, shaping, accessibility, installed rendering or simultaneous visibility of a scrollable message.
