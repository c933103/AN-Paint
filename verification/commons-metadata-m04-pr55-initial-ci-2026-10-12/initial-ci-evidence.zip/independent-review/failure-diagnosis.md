# PR55 first-run JVM diagnosis

## Blocking result

Run 38239121942 on synthetic merge `14b1fdf8e02ebe6f765d63906f05c7e808524b76`, exact reviewed tree `d80218496e45bbefcaa378d40e5cd9846b7988ee`, failed JVM verification. Actual inventory exactly matches all 890 expected identities: 889 pass, one fails; no skipped, duplicate, missing or unexpected identity. All four M04 translation execution identities (two methods at SDK30/35) passed. All 16 M04 flow methods ran, with 15 passes and one failure.

Failure: `CommonsMetadataQueryFailureFlowTest.shortLandscapeM04RetainsFullAccessibleTextAtNormalScale`, `readable()` line398:

```kotlin
assertTrue(layout.getLineLeft(line)>=-1f && layout.getLineRight(line)<=layout.width+1f)
```

The only normal-landscape capture is `api35-en-GB-640x320-font1.0-copy`. Source order is copy first, then en-GB, ain-Kana, ain-Latn, etc. Therefore the first failing profile is inferred to be ain-Kana copy, 640x320 DP, font1.0. There is no failing-profile PNG, line index, left/right metric, ink raster or locale diagnostic in the empty JUnit stdout/stderr. Actual clipping versus a line-metric/fixture issue is UNRESOLVED. Do not change the one-pixel allowance, dismiss the failure, or call a rerun a fix.

Actual captures: 85 complete PNG/JSON pairs, 27 absent (all remaining normal-landscape profiles). Every available pair passed exact full message, Unicode control, expected xhdpi dimensions and readable-image-file checks. The other three rendering methods each completed all 28 profiles. This is not a 112-render pass or full visual acceptance.

## Separate evidence issue

The vertical branch explicitly scrolls to both endpoints, then calls `rail.resetToReadingStart()`. `ColumnScrollView.resetToReadingStart()` only sets `positioned=false` and requests layout. There is no further measure/layout before the vertical capture. Thus a screenshot may still represent the ending scroll position. No scroll position is stored in current M04 JSON. This does not invalidate the endpoint reachability checks or establish a production defect, but it does prevent accepting the image as verified reading-start evidence. A successor can retain both endpoint checks, perform actual layout, and record/assert the intended reading-start scroll.

## Unaffected outcomes

Independent APK/source/font and compiled-resource checks PASS; see delivery-result.json and compiled-m04-result.json. Seven exact-script probes PASS their retained receipt/hash/source checks. Actual regression phase receipts establish Python 660/660 (196.589s), native build PASS, lint PASS, JVM FAIL. All 2,073 extracted regression files exactly match the digest-verified ZIP.

## Next evidence

Preserve frozen source and original failed artifacts. A scoped diagnostic successor should capture each failing profile's actual pixels, view/layout/line geometry and an unclipped text-layout ink raster before assertions, retain every historical threshold/oracle, and report aggregate failure after collecting profiles. A repair writer owns proposed source changes; the independent reviewer has not changed application or repository files.
