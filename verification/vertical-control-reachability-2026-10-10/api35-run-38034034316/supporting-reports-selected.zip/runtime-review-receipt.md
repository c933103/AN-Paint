## Fresh exact-source API35 result: bounded native reachability and redraw accepted

[Run 38034034316](https://github.com/c933103/AN-Paint/actions/runs/38034034316), attempt 1, completed successfully for PR41 head `107376cbd9a0eafcd3cedbae0365802702b525ff`. The tested merge `d21d5f467a72c9dd222c57c98c5bfe8bdf5b7ecb` has exactly the reviewed tree `52901eb86069390da168b6c86b99b67d3e1db8f5`; its parents are unchanged PR18 `66c39ca` and this head.

### Compilation and regressions

- Production and instrumented-test APKs compiled successfully.
- 755 JVM cases across 79 XML files passed, with zero failures, errors or skips. This includes all 12 slider gesture cases and six new redraw cases configured for API30/API35.
- Android lint: zero issues.
- CI host: 411 tests in 56.676 seconds, with two optional Pillow-dependent decoder skips. The exact combined local run passed all 411 with zero skips in 63.171 seconds; the corrected focused command passed all 13 checks. The separately recorded mistyped module command was an invocation error.
- All 98 installed API35 methods passed: 74 native, 18 ordinary, four vertical, one seed and one verify. Source-bound report verification independently confirmed the exact 24-method app union, captured SDK35, no omitted/duplicate/unexpected methods and no phase errors/timeouts.

### Full retained matrix and actual pixels

All eight locale/orientation receipts and all 96 original PNGs are present. The original archives were SHA-256 verified, PNGs fully decoded, and the complete 32-image plus 64-image inventories independently checked.

The independent reviewer inspected all 96 original images at full resolution, including all four locales in both orientations. Quality labels visibly show the actual 1/100 endpoints with the corresponding thumbs; all eight dedicated filename preview captures now show `Untitled.jpg`, matching their editable field. Native popups, revealed controls, descriptions, actions and returned workspace states show no remaining blocker within this bounded matrix. The implementation reviewer additionally opened all 24 endpoint/filename originals.

All 28 recorded native slider gestures have DOWN/MOVE/UP, no CANCEL, no ancestor-scroll movement, no telemetry errors/drops, removed observers and the intended endpoint. Full control/readout/thumb bounds, repeated endpoints, native form scrolling, distinct Cancel draft versus remembered quality, reopen/PNG/Back, canvas/tool preservation and the intercepted Choose location flow pass. Choose location is still canceled by the ActivityMonitor before an external provider opens; no destination, actual file write, permission or encoding is certified by this probe.

Identical pixels occur where states are intentionally identical: the eight initial JPEG-quality/before pairs and the English/Manchu landscape minimum/filename pairs. No minimum/maximum or closed-Save/open-popup pair is identical.

### Measured provisioning and retained failure semantics

Reported invocation elapsed seconds (including setup): native 40.548; ordinary 151.290; English/Manchu 113.108; Literary Chinese/emoji 107.346; seed 5.793; verify 7.250. The whole runner reached successful instrumentation completion at +467 seconds within the unchanged 15-minute outer cap.

Both disjoint vertical invocations ran once and stayed below their own 180-second ceiling. Their combined reported invocation time was 220.454 seconds, including per-invocation setup. The explicit aggregate allowance is 360 seconds, increased from 180; this is workload provisioning, not a speed improvement. Original Kotlin gestures, anti-fling tails, assertions, orientation paths, capture waits and image requirements remain unchanged. The accepted-credit live PID, Gallery, external force-stop, confirmed process absence and fresh verify boundary also passed.

### Exact original artifact identities

- Emulator artifact `11663376109`: 4,866,626 bytes; SHA-256 `30c7dec8fa5f8fd8b95e36e5c6ba3f6e564e6a96ea7a079a0719c9589992062c`.
- Regression artifact `11663420081`: 32,274,243 bytes; SHA-256 `0d6292ce072d4f3c2864e8b9b4e14694842efbe933705e0059a664b54df29048`.
- APK/source artifact `11663363805`: 145,997,644 bytes; Actions-reported SHA-256 `7896d7c0500e089205bc5523c0de261f304117aa36ff846d8e27e13fdb3b7483`.
- Instrumentation APK artifact `11662949627`: 97,775,076 bytes; Actions-reported SHA-256 `8c6698efe2abc7f00bf104d683de3cdfb77bfa390dedfac81c1b3a44dd1c4bf6`.

The emulator and regression archives were downloaded and independently parsed. The two APK archives are identified by verified run metadata; they were not downloaded for this evidence review. All four artifact workflow bindings match this exact run and head.

### Scope and prior failures

This accepts the demonstrated API35 native slider ownership, control reachability and vertical text-update behavior for the tested four-locale/two-orientation matrix. It does not certify API30 installed behavior, physical devices, all routes/strings/glyphs, linguistic correctness, simultaneous visibility of every form column, a release or merge readiness. PR41 remains draft, stacked on unchanged draft PR18. No fresh Codex review or repeated quota request is claimed.

The original [ancestor-interception failure](https://github.com/c933103/AN-Paint/pull/41#issuecomment-6094627822) and [timeout/stale-render failure](https://github.com/c933103/AN-Paint/pull/41#issuecomment-6094873111) remain failed. The complete prior rejected 72-PNG artifact is [durably preserved separately](https://github.com/c933103/AN-Paint/pull/41#issuecomment-6095164105); the fresh result does not overwrite or retroactively pass it.
