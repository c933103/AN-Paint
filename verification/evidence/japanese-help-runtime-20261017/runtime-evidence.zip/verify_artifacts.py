#!/usr/bin/env python3
"""Verify downloaded PR123 runtime evidence without counting copied summaries twice."""
from pathlib import Path
import hashlib
import json
import zipfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
ARTIFACTS = [
    (12112638002, 'regression.zip', 83960886, 'a36c0f7c3781c0131dffd46deae08c6470ba6bbd7a0cd9d1e6693443c424a980'),
    (12113090526, 'position-api35.zip', 1890719, '288704bc19774455b0860f0333df804349522dcdd40e0c67cbc719f4381ed985'),
    (12113166404, 'api35-aggregate.zip', 11460765, 'c6484fa4e950bbfba762b54625fa60da55eda53ac1e091c2783930fc1c92ecb0'),
]
receipts = []
for artifact_id, filename, size, sha256 in ARTIFACTS:
    data = (ROOT / filename).read_bytes()
    if len(data) != size or hashlib.sha256(data).hexdigest() != sha256:
        raise AssertionError(f'Artifact digest mismatch: {artifact_id}')
    receipts.append({'artifact_id': artifact_id, 'filename': filename, 'size_bytes': size,
                     'sha256': sha256, 'github_digest_verified': True})
(ROOT / 'evidence' / 'artifact-verification.json').write_text(json.dumps(receipts, indent=2) + '\n')

def total_junit(archive, filter_name):
    totals = {key: 0 for key in ('tests', 'failures', 'errors', 'skipped')}
    paths = []
    with zipfile.ZipFile(ROOT / archive) as z:
        for name in z.namelist():
            if filter_name(name):
                root = ET.fromstring(z.read(name))
                paths.append(name)
                for key in totals:
                    totals[key] += int(root.get(key, '0'))
    return totals, paths

jvm, paths = total_junit('regression.zip', lambda n: '/test-results/' in n and n.endswith('.xml'))
if len(paths) != 115 or jvm != {'tests': 1105, 'failures': 0, 'errors': 0, 'skipped': 0}:
    raise AssertionError((len(paths), jvm))

device, paths = total_junit('api35-aggregate.zip', lambda n: '/TEST-' in n and n.endswith('.xml'))
if len(paths) != 10 or device != {'tests': 119, 'failures': 0, 'errors': 0, 'skipped': 0}:
    raise AssertionError((len(paths), device))
summaries = []
with zipfile.ZipFile(ROOT / 'api35-aggregate.zip') as z:
    copied = z.read('app/dialog-evidence/source-summary.json')
    original = z.read('app-dialog/androidTest-results/summary.json')
    if copied != original:
        raise AssertionError('Dialog source-summary copy differs')
    for name in z.namelist():
        if not name.endswith('/summary.json'):
            continue
        data = json.loads(z.read(name))
        if 'completed_tests' not in data:
            continue
        if not data['success'] or data['errors'] or data['missing'] or data['unexpected']:
            raise AssertionError(name)
        summaries.append({'path': name, 'expected_tests': data['expected_tests'],
                          'completed_tests': data['completed_tests'], 'success': data['success'],
                          'errors': data['errors'], 'missing': data['missing'], 'unexpected': data['unexpected']})
summary = {'device_sdk': 35, 'summary_files': len(summaries),
           'expected_tests': sum(x['expected_tests'] for x in summaries),
           'completed_tests': sum(x['completed_tests'] for x in summaries),
           'junit_totals': device, 'summaries': summaries,
           'excluded_copy': 'app/dialog-evidence/source-summary.json',
           'excluded_copy_is_byte_identical_to': 'app-dialog/androidTest-results/summary.json'}
if summary['expected_tests'] != 119 or summary['completed_tests'] != 119:
    raise AssertionError(summary)
(ROOT / 'evidence' / 'api35-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'jvm': jvm, 'device': device, 'artifacts': receipts}, indent=2))
