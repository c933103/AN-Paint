import json, pathlib, re, unicodedata, xml.etree.ElementTree as ET
out=pathlib.Path('/workspace/shared/anpaint-p2-west-six-evidence')
inputs=json.loads((out/'inputs.json').read_text())
prefix=inputs['source']['formats22_page_description']['text'].split('Number of pages:')[0]
keys=list(inputs['source'])
texts={
'ca-ES-valencia':[
'Tria una pàgina',
prefix+'Nombre de pàgines: %3$d. Trieu una sola pàgina per a editar-la com a imatge.',
'Número de pàgina',
'Pàgina anterior',
'Pàgina següent',
'Obri la pàgina',
'Previsualització de la pàgina seleccionada',
'Introduïu un número de pàgina de l’1 al %1$d.',
'Pàgina %1$d de %2$d · S’està carregant la previsualització…',
'Pàgina %1$d de %2$d · Dimensions en píxels: %3$d × %4$d',
'Previsualització no disponible: %1$s',
'No hi ha prou memòria per a esta previsualització. En obrir la pàgina, s’oferiran dimensions més menudes quan siga possible.',
'No s’ha pogut llegir el PDF. Pot ser que el fitxer estiga danyat o que utilitze funcions no compatibles amb esta versió d’Android.',
'El PDF requereix una contrasenya o utilitza un xifratge no compatible. Guardeu-ne una còpia sense protecció abans d’importar-la.',
'El PDF ha de ser un fitxer no buit de 512 MiB com a màxim.',
'El nombre de pàgines del PDF ha d’estar entre 1 i %1$d.',
'La selecció de pàgina del PDF ja no és vàlida. Trieu una pàgina d’este document.',
'Les dimensions de la pàgina PDF no són vàlides o són massa grans per a importar-la.',
'L’àrea d’escapçament del PDF ha de ser un rectangle d’amplada i alçada superiors a zero, completament dins de la pàgina seleccionada.',
'La renderització del PDF supera el límit de memòria disponible per a imatges.'
],
'fy':[
'Kies in side',
prefix+'Tal siden: %3$d. Kies ien side om as ôfbylding te bewurkjen.',
'Sidenûmer',
'Foarige side',
'Folgjende side',
'Side iepenje',
'Foarbyld fan de selektearre side',
'Fier in sidenûmer fan 1 oant en mei %1$d yn.',
'Side %1$d fan %2$d · Foarbyld wurdt laden…',
'Side %1$d fan %2$d · Ôfmjittingen yn piksels: %3$d × %4$d',
'Foarbyld net beskikber: %1$s',
'Der is net genôch ûnthâld foar dit foarbyld. By it iepenjen fan de side wurde lytsere ôfmjittingen oanbean as dat mooglik is.',
'De PDF koe net lêzen wurde. De triem kin skansearre wêze of funksjes brûke dy’t dizze Android-ferzje net stipet.',
'De PDF hat in wachtwurd nedich of brûkt fersifering dy’t net stipe wurdt. Bewarje in ûnbeskerme kopy foardat jo dy ymportearje.',
'De PDF moat in net-lege triem wêze fan op syn heechst 512 MiB.',
'It tal siden yn de PDF moat op syn minst 1 en op syn heechst %1$d wêze.',
'De sideseleksje foar de PDF is net mear jildich. Kies in side út dit dokumint.',
'De ôfmjittingen fan de PDF-side binne ûnjildich of te grut om te ymportearjen.',
'It bysnijgebiet fan de PDF moat in rjochthoeke mei in breedte en hichte grutter as nul wêze en hielendal binnen de selektearre side lizze.',
'It renderjen fan de PDF giet oer it beskikbere ûnthâldbudzjet foar ôfbyldingen hinne.'
],
'ga':[
'Roghnaigh leathanach',
prefix+'Líon na leathanach: %3$d. Roghnaigh leathanach amháin le cur in eagar mar íomhá.',
'Uimhir leathanaigh',
'An leathanach roimhe seo',
'An chéad leathanach eile',
'Oscail an leathanach',
'Réamhamharc ar an leathanach roghnaithe',
'Cuir isteach uimhir leathanaigh ó 1 go %1$d.',
'Leathanach %1$d as %2$d · Réamhamharc á luchtú…',
'Leathanach %1$d as %2$d · Toisí i bpicteilíní: %3$d × %4$d',
'Níl réamhamharc ar fáil: %1$s',
'Níl go leor cuimhne ann don réamhamharc seo. Nuair a osclófar an leathanach, tairgfear toisí níos lú más féidir.',
'Níorbh fhéidir an PDF a léamh. D’fhéadfadh an comhad a bheith damáistithe nó gnéithe a úsáid nach dtacaíonn an leagan seo de Android leo.',
'Tá focal faire de dhíth ar an PDF nó úsáideann sé criptiú nach dtacaítear leis. Sábháil cóip gan chosaint sula n-iompórtálfaidh tú í.',
'Caithfidh an PDF a bheith ina chomhad nach bhfuil folamh agus nach mó ná 512 MiB.',
'Caithfidh líon na leathanach sa PDF a bheith idir 1 agus %1$d.',
'Níl an roghnúchán leathanaigh PDF bailí a thuilleadh. Roghnaigh leathanach ón doiciméad seo.',
'Tá toisí an leathanaigh PDF neamhbhailí nó rómhór le hiompórtáil.',
'Caithfidh limistéar bearrtha an PDF a bheith ina dhronuilleog le leithead agus airde níos mó ná nialas, go hiomlán laistigh den leathanach roghnaithe.',
'Sáraíonn rindreáil an PDF an teorainn chuimhne atá ar fáil d’íomhánna.'
]}
translations={loc:dict(zip(keys,values,strict=True)) for loc,values in texts.items()}
(out/'candidate-west.json').write_text(json.dumps({'translations':translations},ensure_ascii=False,indent=2)+'\n')
checks={}
root=pathlib.Path('/workspace/shared/anpaint-p2-west-six-20261110')
for loc,values in translations.items():
 existing={el.get('name') for el in ET.parse(root/inputs['paths'][loc]).getroot()}
 assert not existing.intersection(keys)
 for key,text in values.items():
  assert sorted(re.findall(r'%\d+\$[sd]',text)) == sorted(re.findall(r'%\d+\$[sd]',inputs['source'][key]['text'])),(loc,key)
  assert unicodedata.normalize('NFC',text)==text,(loc,key)
  assert not any(ch in text for ch in ['"',"'",'\n']), (loc,key)
  assert text.count('\\n')==inputs['source'][key]['text'].count('\\n'),(loc,key)
  ET.fromstring('<string name="'+key+'">'+text+'</string>')
 checks[loc]={'new_absent_pairs':len(values),'exact_key_set':set(values)==set(keys),'placeholder_multiset':'passed','NFC':'passed','XML_text':'passed','raw_description_separator_codepoints':[92,110]}
(out/'candidate-west-checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(checks,ensure_ascii=False,indent=2))
