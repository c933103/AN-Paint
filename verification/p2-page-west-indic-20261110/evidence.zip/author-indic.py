import json
import re
import unicodedata
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/shared/anpaint-p2-west-six-20261110')
OUT = Path('/workspace/shared/anpaint-p2-west-six-evidence')
inputs = json.loads((OUT / 'inputs.json').read_text())
source = inputs['source']
separator = re.search(r'\\+n', source['formats22_page_description']['text']).group()
translations = {
    'kn': {
        'formats22_select_page': 'ಒಂದು ಪುಟವನ್ನು ಆಯ್ಕೆಮಾಡಿ',
        'formats22_page_description': '%1$s · %2$s' + separator + 'ಪುಟಗಳ ಸಂಖ್ಯೆ: %3$d. ಚಿತ್ರವಾಗಿ ಸಂಪಾದಿಸಲು ಒಂದು ಪುಟವನ್ನು ಆಯ್ಕೆಮಾಡಿ.',
        'formats22_page_number': 'ಪುಟ ಸಂಖ್ಯೆ',
        'formats22_previous_page': 'ಹಿಂದಿನ ಪುಟ',
        'formats22_next_page': 'ಮುಂದಿನ ಪುಟ',
        'formats22_open_page': 'ಪುಟವನ್ನು ತೆರೆಯಿರಿ',
        'formats22_page_preview': 'ಆಯ್ಕೆಮಾಡಿದ ಪುಟದ ಮುನ್ನೋಟ',
        'formats22_page_range': '1 ರಿಂದ %1$d ವರೆಗಿನ ಪುಟ ಸಂಖ್ಯೆಯನ್ನು ನಮೂದಿಸಿ.',
        'formats22_loading_page': 'ಒಟ್ಟು %2$d ಪುಟಗಳಲ್ಲಿ %1$dನೇ ಪುಟ · ಮುನ್ನೋಟವನ್ನು ಲೋಡ್ ಮಾಡಲಾಗುತ್ತಿದೆ…',
        'formats22_page_dimensions': 'ಒಟ್ಟು %2$d ಪುಟಗಳಲ್ಲಿ %1$dನೇ ಪುಟ · %3$d × %4$d ಪಿಕ್ಸೆಲ್‌ಗಳು',
        'formats22_preview_unavailable': 'ಮುನ್ನೋಟ ಲಭ್ಯವಿಲ್ಲ: %1$s',
        'formats22_preview_memory': 'ಈ ಮುನ್ನೋಟಕ್ಕೆ ಸಾಕಷ್ಟು ಮೆಮೊರಿ ಇಲ್ಲ. ಪುಟವನ್ನು ತೆರೆದಾಗ, ಸಾಧ್ಯವಾದರೆ ಚಿಕ್ಕ ಆಯಾಮಗಳನ್ನು ಆಯ್ಕೆಮಾಡುವ ಅವಕಾಶ ಸಿಗುತ್ತದೆ.',
        'formats22_pdf_invalid': 'PDF ಅನ್ನು ಓದಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ. ಕಡತವು ಹಾನಿಗೊಳಗಾಗಿರಬಹುದು ಅಥವಾ ಈ Android ಆವೃತ್ತಿಯಲ್ಲಿ ಬೆಂಬಲಿಸದ ವೈಶಿಷ್ಟ್ಯಗಳನ್ನು ಬಳಸುತ್ತಿರಬಹುದು.',
        'formats22_pdf_encrypted': 'PDF ಗೆ ಗುಪ್ತಪದ ಅಗತ್ಯವಿದೆ ಅಥವಾ ಅದು ಬೆಂಬಲಿಸದ ಗೂಢಲಿಪೀಕರಣವನ್ನು ಬಳಸುತ್ತದೆ. ಆಮದು ಮಾಡುವ ಮೊದಲು ರಕ್ಷಣೆಯಿಲ್ಲದ ಪ್ರತಿಯನ್ನು ಉಳಿಸಿ.',
        'formats22_pdf_file_size': 'PDF ಕಡತವು ಖಾಲಿಯಾಗಿರಬಾರದು ಮತ್ತು ಅದರ ಗಾತ್ರ 512 MiB ಮೀರಿರಬಾರದು.',
        'formats22_pdf_page_count': 'PDF ನಲ್ಲಿ 1 ರಿಂದ %1$d ವರೆಗೆ ಪುಟಗಳಿರಬೇಕು.',
        'formats22_pdf_page_index': 'PDF ಪುಟದ ಆಯ್ಕೆ ಈಗ ಮಾನ್ಯವಾಗಿಲ್ಲ. ಈ ದಸ್ತಾವೇಜಿನಿಂದ ಒಂದು ಪುಟವನ್ನು ಆಯ್ಕೆಮಾಡಿ.',
        'formats22_pdf_dimensions': 'PDF ಪುಟದ ಆಯಾಮಗಳು ಅಮಾನ್ಯವಾಗಿವೆ ಅಥವಾ ಆಮದು ಮಾಡಲು ತುಂಬಾ ದೊಡ್ಡದಾಗಿವೆ.',
        'formats22_pdf_crop': 'PDF ಕ್ರಾಪ್ ಆಯ್ಕೆಮಾಡಿದ ಪುಟದೊಳಗಿರುವ, ಖಾಲಿಯಲ್ಲದ ಆಯತಾಕಾರದ ಪ್ರದೇಶವಾಗಿರಬೇಕು.',
        'formats22_pdf_memory': 'PDF ಅನ್ನು ಚಿತ್ರವಾಗಿ ರಚಿಸಲು ಬೇಕಾಗುವ ಮೆಮೊರಿಯು ಚಿತ್ರಗಳಿಗಾಗಿ ಲಭ್ಯವಿರುವ ಮೆಮೊರಿ ಮಿತಿಯನ್ನು ಮೀರುತ್ತದೆ.',
    },
    'ml-IN': {
        'formats22_select_page': 'ഒരു താൾ തിരഞ്ഞെടുക്കുക',
        'formats22_page_description': '%1$s · %2$s' + separator + 'താളുകളുടെ എണ്ണം: %3$d. ചിത്രമായി എഡിറ്റ് ചെയ്യാൻ ഒരു താൾ തിരഞ്ഞെടുക്കുക.',
        'formats22_page_number': 'താൾ നമ്പർ',
        'formats22_previous_page': 'മുൻപത്തെ താൾ',
        'formats22_next_page': 'അടുത്ത താൾ',
        'formats22_open_page': 'താൾ തുറക്കുക',
        'formats22_page_preview': 'തിരഞ്ഞെടുത്ത താളിന്റെ തിരനോട്ടം',
        'formats22_page_range': '1 മുതൽ %1$d വരെയുള്ള ഒരു താൾ നമ്പർ നൽകുക.',
        'formats22_loading_page': '%2$d താളുകളിൽ %1$d-ാം താൾ · തിരനോട്ടം ലോഡ് ചെയ്യുന്നു…',
        'formats22_page_dimensions': '%2$d താളുകളിൽ %1$d-ാം താൾ · %3$d × %4$d പിക്സലുകൾ',
        'formats22_preview_unavailable': 'തിരനോട്ടം ലഭ്യമല്ല: %1$s',
        'formats22_preview_memory': 'ഈ തിരനോട്ടത്തിന് മതിയായ മെമ്മറി ഇല്ല. താൾ തുറക്കുമ്പോൾ, സാധ്യമെങ്കിൽ ചെറിയ അളവുകൾ തിരഞ്ഞെടുക്കാനുള്ള അവസരം ലഭിക്കും.',
        'formats22_pdf_invalid': 'PDF വായിക്കാനായില്ല. ഫയൽ കേടായിരിക്കാം, അല്ലെങ്കിൽ ഈ Android പതിപ്പ് പിന്തുണയ്ക്കാത്ത സവിശേഷതകൾ ഉപയോഗിക്കുന്നതാകാം.',
        'formats22_pdf_encrypted': 'PDF ന് രഹസ്യവാക്ക് ആവശ്യമാണ്, അല്ലെങ്കിൽ അത് പിന്തുണയ്ക്കാത്ത എൻക്രിപ്ഷൻ ഉപയോഗിക്കുന്നു. ഇറക്കുമതി ചെയ്യുന്നതിന് മുമ്പ് പരിരക്ഷയില്ലാത്ത ഒരു പകർപ്പ് സംരക്ഷിക്കുക.',
        'formats22_pdf_file_size': 'PDF ഫയൽ ശൂന്യമാകരുത്. അതിന്റെ വലുപ്പം 512 MiB ൽ കൂടരുത്.',
        'formats22_pdf_page_count': 'PDF ൽ 1 മുതൽ %1$d വരെ താളുകൾ ഉണ്ടായിരിക്കണം.',
        'formats22_pdf_page_index': 'PDF താളിന്റെ തിരഞ്ഞെടുപ്പ് ഇനി സാധുവല്ല. ഈ പ്രമാണത്തിൽ നിന്ന് ഒരു താൾ തിരഞ്ഞെടുക്കുക.',
        'formats22_pdf_dimensions': 'PDF താളിന്റെ അളവുകൾ അസാധുവാണ്, അല്ലെങ്കിൽ ഇറക്കുമതി ചെയ്യാൻ കഴിയാത്തത്ര വലുതാണ്.',
        'formats22_pdf_crop': 'PDF ക്രോപ്പ് പ്രദേശം തിരഞ്ഞെടുത്ത താളിനുള്ളിലുള്ള ശൂന്യമല്ലാത്ത ഒരു ദീർഘചതുരമായിരിക്കണം.',
        'formats22_pdf_memory': 'PDF റെൻഡർ ചെയ്യാൻ വേണ്ട മെമ്മറി ചിത്രങ്ങൾക്കായി ലഭ്യമായ മെമ്മറി പരിധി കവിയുന്നു.',
    },
    'pa-IN': {
        'formats22_select_page': 'ਇੱਕ ਸਫ਼ਾ ਚੁਣੋ',
        'formats22_page_description': '%1$s · %2$s' + separator + 'ਸਫ਼ਿਆਂ ਦੀ ਗਿਣਤੀ: %3$d। ਚਿੱਤਰ ਵਜੋਂ ਸੋਧਣ ਲਈ ਇੱਕ ਸਫ਼ਾ ਚੁਣੋ।',
        'formats22_page_number': 'ਸਫ਼ਾ ਨੰਬਰ',
        'formats22_previous_page': 'ਪਿਛਲਾ ਸਫ਼ਾ',
        'formats22_next_page': 'ਅਗਲਾ ਸਫ਼ਾ',
        'formats22_open_page': 'ਸਫ਼ਾ ਖੋਲ੍ਹੋ',
        'formats22_page_preview': 'ਚੁਣੇ ਸਫ਼ੇ ਦੀ ਝਲਕ',
        'formats22_page_range': '1 ਤੋਂ %1$d ਤੱਕ ਦਾ ਸਫ਼ਾ ਨੰਬਰ ਦਿਓ।',
        'formats22_loading_page': 'ਕੁੱਲ %2$d ਸਫ਼ਿਆਂ ਵਿੱਚੋਂ ਸਫ਼ਾ %1$d · ਝਲਕ ਲੋਡ ਕੀਤੀ ਜਾ ਰਹੀ ਹੈ…',
        'formats22_page_dimensions': 'ਕੁੱਲ %2$d ਸਫ਼ਿਆਂ ਵਿੱਚੋਂ ਸਫ਼ਾ %1$d · %3$d × %4$d ਪਿਕਸਲ',
        'formats22_preview_unavailable': 'ਝਲਕ ਉਪਲਬਧ ਨਹੀਂ ਹੈ: %1$s',
        'formats22_preview_memory': 'ਇਸ ਝਲਕ ਲਈ ਕਾਫ਼ੀ ਮੈਮੋਰੀ ਨਹੀਂ ਹੈ। ਸਫ਼ਾ ਖੋਲ੍ਹਣ ਵੇਲੇ, ਜਿੱਥੇ ਸੰਭਵ ਹੋਵੇ, ਛੋਟੇ ਮਾਪ ਚੁਣਨ ਦਾ ਵਿਕਲਪ ਦਿੱਤਾ ਜਾਵੇਗਾ।',
        'formats22_pdf_invalid': 'PDF ਪੜ੍ਹੀ ਨਹੀਂ ਜਾ ਸਕੀ। ਹੋ ਸਕਦਾ ਹੈ ਕਿ ਫਾਇਲ ਖ਼ਰਾਬ ਹੋਵੇ ਜਾਂ ਅਜਿਹੀਆਂ ਵਿਸ਼ੇਸ਼ਤਾਵਾਂ ਵਰਤਦੀ ਹੋਵੇ ਜਿਨ੍ਹਾਂ ਦਾ Android ਦਾ ਇਹ ਵਰਜਨ ਸਮਰਥਨ ਨਹੀਂ ਕਰਦਾ।',
        'formats22_pdf_encrypted': 'PDF ਲਈ ਪਾਸਵਰਡ ਲੋੜੀਂਦਾ ਹੈ ਜਾਂ ਇਹ ਅਸਮਰਥਿਤ ਇਨਕ੍ਰਿਪਸ਼ਨ ਵਰਤਦੀ ਹੈ। ਆਯਾਤ ਕਰਨ ਤੋਂ ਪਹਿਲਾਂ ਬਿਨਾਂ ਸੁਰੱਖਿਆ ਵਾਲੀ ਕਾਪੀ ਸੰਭਾਲੋ।',
        'formats22_pdf_file_size': 'PDF ਫਾਇਲ ਖਾਲੀ ਨਹੀਂ ਹੋਣੀ ਚਾਹੀਦੀ ਅਤੇ ਇਸ ਦਾ ਆਕਾਰ 512 MiB ਤੋਂ ਵੱਧ ਨਹੀਂ ਹੋਣਾ ਚਾਹੀਦਾ।',
        'formats22_pdf_page_count': 'PDF ਵਿੱਚ 1 ਤੋਂ %1$d ਤੱਕ ਸਫ਼ੇ ਹੋਣੇ ਚਾਹੀਦੇ ਹਨ।',
        'formats22_pdf_page_index': 'PDF ਸਫ਼ੇ ਦੀ ਚੋਣ ਹੁਣ ਵੈਧ ਨਹੀਂ ਹੈ। ਇਸ ਦਸਤਾਵੇਜ਼ ਵਿੱਚੋਂ ਇੱਕ ਸਫ਼ਾ ਚੁਣੋ।',
        'formats22_pdf_dimensions': 'PDF ਸਫ਼ੇ ਦੇ ਮਾਪ ਅਵੈਧ ਹਨ ਜਾਂ ਆਯਾਤ ਕਰਨ ਲਈ ਬਹੁਤ ਵੱਡੇ ਹਨ।',
        'formats22_pdf_crop': 'PDF ਦਾ ਕਰੋਪ ਖੇਤਰ ਚੁਣੇ ਸਫ਼ੇ ਦੇ ਅੰਦਰ ਇੱਕ ਅਜਿਹਾ ਆਇਤਕਾਰ ਹੋਣਾ ਚਾਹੀਦਾ ਹੈ ਜੋ ਖਾਲੀ ਨਾ ਹੋਵੇ।',
        'formats22_pdf_memory': 'PDF ਨੂੰ ਰੈਂਡਰ ਕਰਨ ਲਈ ਲੋੜੀਂਦੀ ਮੈਮੋਰੀ ਚਿੱਤਰਾਂ ਲਈ ਉਪਲਬਧ ਮੈਮੋਰੀ ਦੀ ਹੱਦ ਤੋਂ ਵੱਧ ਹੈ।',
    },
}

contexts = {
    'formats22_select_page': ('ImportSelection.kt:105', 'Dialog title for PDF or TIFF, including a one-page document. Choose one page, not a document or a range.'),
    'formats22_page_description': ('ImportSelection.kt:93', 'Description: %1$s format kind (PDF/TIFF), %2$s display name, %3$d total pages. Select exactly one page to edit as raster image, not editable PDF text/vector. Preserve literal source separator bytes.'),
    'formats22_page_number': ('ImportSelection.kt:97', 'Accessible name of numeric page input. One-based visible page number, not page count.'),
    'formats22_previous_page': ('ImportSelection.kt:96; LegacyImageCreditsActivity.kt:58', 'Accessible label for previous-page arrow and visible button in legacy credit pagination. Keep format-neutral page wording.'),
    'formats22_next_page': ('ImportSelection.kt:98; LegacyImageCreditsActivity.kt:59', 'Accessible label for next-page arrow and visible button in legacy credit pagination. Keep format-neutral page wording.'),
    'formats22_open_page': ('ImportSelection.kt:107', 'Positive action opens current one-based selection, converted internally to zero-based page index. Not a save command.'),
    'formats22_page_preview': ('ImportSelection.kt:102', 'ImageView accessible description. Preview of selected page, not a command to select or open the page.'),
    'formats22_page_range': ('ImportSelection.kt:118', 'Shown for missing, nonnumeric or out-of-range page input. Inclusive lower bound 1 and total-count upper bound %1$d. Not a request to enter a range.'),
    'formats22_loading_page': ('ImportSelection.kt:119', 'Loading state: %1$d current one-based page, %2$d total page count. Preview loading, not document import completion.'),
    'formats22_page_dimensions': ('ImportSelection.kt:133', 'Success status: %1$d current one-based page, %2$d total count, %3$d source width, %4$d source height. Width × height in pixels. Uses source dimensions, not 384-pixel preview size.'),
    'formats22_preview_unavailable': ('ImportSelection.kt:136', 'Exception status wrapping %1$s error.message. Preview unavailable does not establish that the page cannot be opened.'),
    'formats22_preview_memory': ('ImportSelection.kt:138', 'Preview OutOfMemoryError fallback. Opening offers smaller dimensions only when possible. No guarantee of successful opening or downsize.'),
    'formats22_pdf_invalid': ('PdfCodec.kt:135-151', 'Unreadable/signature/native error. Damage OR unsupported features in this Android version are possible causes, not established facts.'),
    'formats22_pdf_encrypted': ('PdfCodec.kt:145-146', 'SecurityException message. Password required OR unsupported encryption. Save an unprotected copy before importing; does not promise password entry or decryption in this app.'),
    'formats22_pdf_file_size': ('PdfCodec.kt:105-108,134', 'A file must have more than zero bytes and at most 512 MiB inclusive. Not smaller than 512 MiB, not MB, and not a memory-budget limit.'),
    'formats22_pdf_page_count': ('PdfCodec.kt:122-124', 'Checked total page count must be 1..%1$d inclusive; current MAX_PAGES is 4096. Keep parameter, not fixed count.'),
    'formats22_pdf_page_index': ('PdfCodec.kt:126-128', 'Selection is no longer valid. Rechoose a page from this document. Not a diagnosed corrupt page or instruction to find a different PDF.'),
    'formats22_pdf_dimensions': ('PdfCodec.kt:113-118', 'Page dimensions invalid OR too large to import. Applies to page width/height, not page count or PDF file size.'),
    'formats22_pdf_crop': ('PdfCodec.kt:75-78', 'Crop must be a non-empty rectangle completely inside the selected page. Keep both geometry/nonemptiness and selected-page containment.'),
    'formats22_pdf_memory': ('PdfCodec.kt:70-71,105-110', 'Rendering needs exceed available image memory budget. Budget includes bitmap/document/rendering headroom; not financial cost or disk capacity. Admission is an estimate, not a universal hard allocator bound.'),
}

glossaries = {
    'kn': {
        'page': 'ಪುಟ', 'preview': 'ಮುನ್ನೋಟ', 'image': 'ಚಿತ್ರ', 'pixels': 'ಪಿಕ್ಸೆಲ್‌ಗಳು',
        'file': 'ಕಡತ', 'dimensions': 'ಆಯಾಮಗಳು', 'memory': 'ಮೆಮೊರಿ', 'import': 'ಆಮದು',
        'password': 'ಗುಪ್ತಪದ', 'encryption': 'ಗೂಢಲಿಪೀಕರಣ', 'crop': 'ಕ್ರಾಪ್',
        'notes': 'Polite imperatives match current canonical ಆಯ್ಕೆಮಾಡಿ/ತೆರೆಯಿರಿ. Page number/total count are reordered naturally; numeric ordinal ನೇ binds only the current page. Rendering is composed as creating the PDF as an image. Encryption terminology is an author composition, not a direct source sentence.'
    },
    'ml-IN': {
        'page': 'താൾ', 'preview': 'തിരനോട്ടം', 'image': 'ചിത്രം', 'pixels': 'പിക്സലുകൾ',
        'file': 'ഫയൽ', 'dimensions': 'അളവുകൾ', 'memory': 'മെമ്മറി', 'import': 'ഇറക്കുമതി',
        'password': 'രഹസ്യവാക്ക്', 'encryption': 'എൻക്രിപ്ഷൻ', 'crop': 'ക്രോപ്പ്',
        'notes': 'Uses canonical PDF page താൾ and preview തിരനോട്ടം consistently. Numeric ordinal -ാം attaches only to current page. Plural പിക്സലുകൾ follows current prose rather than mechanically copying the old label പിക്സല്‍. Save സംരക്ഷിക്കുക remains the canonical command; protection is പരിരക്ഷ to avoid confusing repeated save/protect wording.'
    },
    'pa-IN': {
        'page': 'ਸਫ਼ਾ', 'preview': 'ਝਲਕ', 'image': 'ਚਿੱਤਰ', 'pixels': 'ਪਿਕਸਲ',
        'file': 'ਫਾਇਲ', 'dimensions': 'ਮਾਪ', 'memory': 'ਮੈਮੋਰੀ', 'import': 'ਆਯਾਤ',
        'password': 'ਪਾਸਵਰਡ', 'encryption': 'ਇਨਕ੍ਰਿਪਸ਼ਨ', 'crop': 'ਕਰੋਪ',
        'notes': 'Gurmukhi Punjabi. Canonical PDF hint and MediaWiki navigation support ਸਫ਼ਾ; historical GIMP also has ਪੇਜ਼ and ਸਫ਼ੇ, not adopted mechanically. Common ਪਾਸਵਰਡ is an author terminology choice rather than adopting MediaWiki ਪਾਰਸ਼ਬਦ. Memory/rendering limit is technical, not financial. Crop uses a complete relative clause for nonempty rectangle.'
    },
}

backtranslations = {
    'formats22_select_page': 'Choose one page.',
    'formats22_page_description': 'Format · filename [unchanged separator] Number of pages: total. Choose one page to edit as an image.',
    'formats22_page_number': 'Page number.',
    'formats22_previous_page': 'Previous page.',
    'formats22_next_page': 'Next page.',
    'formats22_open_page': 'Open the page.',
    'formats22_page_preview': 'Preview of the selected page.',
    'formats22_page_range': 'Enter a page number from 1 through the supplied maximum.',
    'formats22_loading_page': 'Current page out of total pages · Loading the preview.',
    'formats22_page_dimensions': 'Current page out of total pages · width × height pixels.',
    'formats22_preview_unavailable': 'Preview is unavailable: the supplied error.',
    'formats22_preview_memory': 'There is insufficient memory for this preview. On opening the page, an option to choose smaller dimensions will be offered where possible.',
    'formats22_pdf_invalid': 'The PDF could not be read. The file may be damaged or may use features that this Android version does not support.',
    'formats22_pdf_encrypted': 'The PDF requires a password or uses unsupported encryption. Save an unprotected copy before importing.',
    'formats22_pdf_file_size': 'The PDF file must not be empty, and its size must not exceed 512 MiB.',
    'formats22_pdf_page_count': 'The PDF must contain from 1 through the supplied maximum number of pages.',
    'formats22_pdf_page_index': 'The PDF page selection is no longer valid. Choose one page from this document.',
    'formats22_pdf_dimensions': 'The PDF page dimensions are invalid or are too large to import.',
    'formats22_pdf_crop': 'The PDF crop must be a nonempty rectangular region inside the selected page.',
    'formats22_pdf_memory': 'The memory required to render the PDF exceeds the memory limit available for images.',
}

sys.path.insert(0, str(ROOT / 'tools'))
from translation_catalogues import android_string_errors, format_string_errors, placeholders
checks = []
rows = []
canonical_evidence = {}
reference_keys = [
    'formats22_pdf_raster_hint', 'formats22_import_limit', 'formats22_open_still',
    'ui_preview', 'ui_image', 'ui_pixels', 'ui_crop_image',
    'ui_crop_must_stay_inside_the_canvas', 'ui_choose_dimensions_no_larger_than_the_original',
    'ui_not_enough_memory_to_inspect_this_image', 'ui_rectangle', 'ui_save', 'ui_load_image',
    'ui_the_crop_must_contain_at_least_one_pixel', 'ui_the_crop_must_stay_inside_the_image'
]
for locale, values in translations.items():
    path = inputs['paths'][locale]
    existing = {e.attrib.get('name'): ''.join(e.itertext()) for e in ET.parse(ROOT / path).getroot()}
    assert set(values) == set(source), locale
    assert len(values) == 20
    assert set(values).isdisjoint(existing), locale
    canonical_evidence[locale] = {
        'path': path,
        'url': 'https://github.com/c933103/AN-Paint/blob/' + inputs['base_sha'] + '/' + path,
        'role': 'Current contextual terminology only. Not a prior approval claim or authority over meaning.',
        'entries': {key: existing[key] for key in reference_keys if key in existing}
    }
    for key, value in values.items():
        assert placeholders(value) == placeholders(source[key]['text']), (locale, key)
        assert not android_string_errors(value), (locale, key)
        assert not format_string_errors(value), (locale, key)
        assert unicodedata.normalize('NFC', value) == value, (locale, key)
        assert not any(c in value for c in ['\n', '\r', '\t']), (locale, key)
        if key == 'formats22_page_description':
            assert re.findall(r'\\+n', value) == [separator]
        rows.append({
            'locale': locale, 'path': path, 'key': key,
            'source': source[key]['text'], 'attributes': source[key]['attributes'],
            'current': None, 'current_state': 'absent at the stated base',
            'candidate': value, 'consumer': contexts[key][0],
            'context_and_semantic_check': contexts[key][1],
            'author_backtranslation': backtranslations[key],
            'support': ['Current canonical terminology for ' + locale, 'Pinned upstream terminology listed under primary_sources; complete sentence is newly composed from source and actual consumer'],
            'status': 'new author candidate; changed-only independent review required'
        })
    checks.append({'locale': locale, 'new_keys': 20, 'absent_pairs': 20, 'typed_placeholders': 'match', 'android_escaping': 'pass', 'NFC': 'pass', 'source_description_separator_code_points': list(map(ord,separator))})

gimp = json.loads((ROOT / 'translations/gimp-catalogues.json').read_text())
primary = json.loads((OUT / 'indic-upstream-excerpts.json').read_text())
for lang in ['kn','ml','pa']:
    original = next(s for s in gimp['sources'] if s['locale'] == lang and s['domain'] == 'po')
    primary.append({
        'id': 'gimp-' + lang + '-main',
        'repository': gimp['repository'], 'revision': gimp['revision'],
        'path': original['path'], 'blob_sha': original['source_blob_sha'],
        'source_sha256': original['source_sha256'],
        'url': gimp['repository'] + '/blob/' + gimp['revision'] + '/' + original['path'],
        'license': gimp['license'], 'translator_notice': original['header'],
        'provenance': 'Pinned primary excerpts inspected from translations/gimp-catalogues.json at the AN Paint base. The Malayalam full file was also retrieved via read-only GitHub and its returned blob SHA agrees.',
        'support': 'Terminology only, not a sentence mirror or present acceptance.',
        'entries': [e for e in original['entries'] if e['msgid'] in ['Image','Preview','Pixels','Rectangle Select','Rectangle: ','File Name:','_File','_Save','_Edit','Select All']]
    })

notes = {
    'scope': '60 newly authored P2 page-picker/PDF candidates: 20 each kn, ml-IN, pa-IN',
    'base_sha': inputs['base_sha'], 'base_tree': inputs['base_tree'],
    'authoring_method': 'Full source and real-consumer reading, current canonical terminology comparison, pinned primary terminology inspection, complete contextual composition and author semantic self-check. No mechanical replacement or inherited acceptance.',
    'inputs': str(OUT / 'inputs.json'), 'all_target_pairs_absent_at_base': True,
    'description_separator': {'code_points': list(map(ord, separator)), 'length': len(separator), 'interpretation': 'Actual parsed source is one backslash followed by n. Preserved exactly. JSON escapes that backslash. Runtime line breaking/rendering is not certified.'},
    'canonical_terminology_evidence': canonical_evidence,
    'primary_sources': primary,
    'source_lookup_limit': 'GIMP po-plug-ins/ml.po does not exist at the pinned commit (GitHub 404). Existing GIMP po/ml.po and pinned MediaWiki Malayalam supply the cited terminology. No language evidence is inferred from the absent file.',
    'glossaries_and_choices': glossaries,
    'entries': rows,
    'candidate_only_checks': checks,
    'tests_read_not_run': [
        {'path': 'Paintroid/src/test/java/org/catrobat/paintroid/local/OrdinaryPriorityFollowthroughTest.kt', 'scope': 'Real page chooser PDF/TIFF count 1/2 routing, visible/accessibility bindings, range/enable states and cancel. Existing coverage is not evidence of these new candidates rendering.'},
        {'path': 'Paintroid/src/test/java/org/catrobat/paintroid/local/ImportSelectionFlowTest.kt', 'scope': 'Ownership/cancel/disposal and retained selected page through crop/undo/reload.'},
        {'path': 'Paintroid/src/test/java/org/catrobat/paintroid/local/JapanesePdfFailureTest.kt', 'scope': 'Generic reader causes remain possibilities; encrypted and file-size errors keep specific routing. Japanese text does not approve Indic prose.'},
        {'path': 'Paintroid/src/androidTest/java/org/catrobat/paintroid/classic/PdfCodecTest.kt', 'scope': 'Actual PDF page/count/144-dpi dimensions, source pixel crop, budget rejection, malformed input and unchanged original. Read only, not executed.'},
        {'path': 'Paintroid/src/test/java/org/catrobat/paintroid/local/LegacyImageCreditsActivityTest.kt', 'scope': 'Previous/next shared navigation; pagination preserves text and restores selected page without overflowing Binder state.'}
    ],
    'limits': [
        'Candidate-only until independent changed-only source/context review. Model authored and self-checked, not native-human certification.',
        'No application XML or production/test files changed. No GitHub publication, branch, PR, Work-side task, merge, CI or release action performed.',
        'No compiled Android, device, glyph/shaping/layout, TalkBack/speech or screenshot claim. No runtime newline rendering claim.',
        '171 globally offered options does not establish complete coverage or quality. Earlier withdrawn wording/progress claims are not restored.',
        'Held #299/#306/#308/P1/#400 work excluded. #395 merge and #400 retry denials untouched.',
        'No copied current-wording test oracle or per-edit production test framework created. These notes are temporary candidate review evidence.'
    ]
}
(OUT / 'candidate-indic.json').write_text(json.dumps({'translations':translations},ensure_ascii=False,indent=2)+'\n')
(OUT / 'candidate-indic-notes.json').write_text(json.dumps(notes,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'candidate':str(OUT/'candidate-indic.json'),'notes':str(OUT/'candidate-indic-notes.json'),'checks':checks},ensure_ascii=False,indent=2))
