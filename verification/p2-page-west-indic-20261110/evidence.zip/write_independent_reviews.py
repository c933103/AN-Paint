import collections, copy, hashlib, json, pathlib, re, subprocess, unicodedata, xml.etree.ElementTree as ET
out=pathlib.Path('/workspace/shared/anpaint-p2-west-six-evidence')
repo=pathlib.Path('/workspace/shared/anpaint-p2-west-six-20261110')
inputs=json.loads((out/'inputs.json').read_text())
keys=list(inputs['source'])
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert sha==inputs['base_sha']
reasons={
'ca-ES-valencia':[
'Tria is a Valencian singular command and una pàgina selects one document page; the title also works for a one-page document.',
'The complete sentence states the number of pages, then asks to select one page for image editing. The instructional Trieu and per a editar-la are grammatical; the two identity fields and total are intact.',
'Número de pàgina names the editable page index, not the total count. It is suitable as the field accessibility label.',
'Pàgina anterior denotes the preceding page without restricting the content to PDF, so both import and retained-credit pagination remain covered.',
'Pàgina següent denotes the following page and remains valid for both document pages and paginated credit text.',
'Obri is the Valencian imperative of obrir; la pàgina is the chosen page, not a request to open the whole document.',
'The noun phrase denotes a preview of the selected page, preserving the accessibility purpose rather than naming the full imported image.',
'Introduïu requests entry of a page number; de l’1 al maximum gives the inclusive range and preserves the sole integer argument.',
'Page and total remain in their correct argument order. S’està carregant marks the preview as still loading rather than already available.',
'The phrase labels page position and dimensions in pixels; the ordered width-by-height arguments describe the source page, not the scaled preview.',
'No disponible describes unavailable preview, and the colon introduces the unchanged dynamic error detail.',
'Prou memòria refers to memory insufficiency. The subsequent offer is tied to opening the page and qualified by quan siga possible, not guaranteed resizing.',
'Pot ser que governs both possible causes: damaged file or features incompatible with this Android version. It does not assert a diagnosed corruption.',
'Requereix una contrasenya o utilitza un xifratge no compatible preserves the alternatives. Guardeu-ne una còpia sense protecció is a technical unprotected-copy instruction before import.',
'Fitxer no buit rejects zero bytes, and com a màxim includes exactly 512 MiB without converting the unit or weakening the conjunction.',
'The number-of-pages construction accepts any integer count between the stated endpoints; 1 and the dynamic maximum are retained.',
'Ja no és vàlida conveys that the page selection has become invalid; the remedy explicitly selects a page in this document.',
'No són vàlides o són massa grans retains the invalid-or-too-large distinction. Importar-la refers naturally to the page.',
'Width and height must each exceed zero and the rectangle must be completely inside the selected page; this describes crop geometry, not nonblank content.',
'Renderització and límit de memòria disponible per a imatges describe a rendering memory budget, not file-storage capacity or monetary cost.'
],
'fy':[
'Kies in side is a grammatical imperative selecting a page, including when only one page exists.',
'Tal siden states the total, and Kies ien side asks for one page to edit as an image. The complete composition preserves both identity fields and does not imply whole-document editing.',
'Sidenûmer is the page-number field label; it does not confuse the current index with the total number of pages.',
'Foarige side means previous page and is neutral enough for both document import and retained-credit text pagination.',
'Folgjende side means next page and has no PDF-only restriction that would break its second consumer.',
'Side iepenje is a conventional action-label infinitive naming the selected page to open.',
'Foarbyld fan de selektearre side specifies the selected-page preview; the canonical preview term is independently appropriate here.',
'Fan 1 oant en mei explicitly includes the upper bound. Fier ... yn is a complete separable-verb instruction to enter the page number.',
'Side current fan total preserves position and total. Foarbyld wurdt laden conveys in-progress preview loading.',
'Ôfmjittingen yn piksels labels the source-page dimensions with width first and height second, after the correct current/total position.',
'Net beskikber expresses preview unavailability, and the separate error argument remains intact after the colon.',
'Ûnthâld is working memory. Smaller dimensions are offered on page opening only as dat mooglik is, retaining the conditional behavior.',
'Kin skansearre wêze of funksjes brûke keeps damage and unsupported features as possible explanations, with support tied to this Android version.',
'Wachtwurd and fersifering convey password and encryption. The disjunction and the instruction to save an unprotected copy before importing it both remain explicit.',
'Net-lege rejects an empty file and op syn heechst gives an inclusive 512 MiB upper bound; this is file size, not rendering memory.',
'Op syn minst 1 and op syn heechst maximum make both page-count bounds explicitly inclusive.',
'Net mear jildich preserves the stale-selection meaning, followed by choosing a page from this same document.',
'Ûnjildich of te grut preserves invalidity or excessive dimensions as separate causes preventing import.',
'The full clause requires a rectangle with positive width and height lying entirely inside the selected page, not merely containing visible content.',
'Renderjen and ûnthâldbudzjet foar ôfbyldingen identify image-rendering memory admission. Giet oer ... hinne correctly states that the available budget is exceeded.'
],
'ga':[
'Roghnaigh leathanach is the correct singular imperative with a page as object, rather than a file or page range.',
'Líon na leathanach uses the genitive plural correctly. Leathanach amháin le cur in eagar mar íomhá specifies one page for editing as an image and retains both identity fields.',
'Uimhir leathanaigh is a grammatical genitive phrase for page number and works as the input accessibility label.',
'An leathanach roimhe seo denotes the previous page, with no PDF limitation; it works for the retained-credit text consumer too.',
'An chéad leathanach eile denotes the next page, not the first document page, and works in both pagination consumers.',
'Oscail an leathanach is a grammatical command to open the selected page.',
'Réamhamharc ar an leathanach roghnaithe denotes the preview of the selected page and preserves the image accessibility purpose.',
'Cuir isteach asks for input; ó 1 go the maximum expresses the integer page range naturally and preserves its endpoints.',
'Leathanach current as total is an established page-position construction. Á luchtú describes ongoing loading of the preview.',
'Toisí i bpicteilíní uses the appropriate eclipsis and labels dimensions, preserving source width then height rather than introducing preview size.',
'Níl réamhamharc ar fáil states unavailability and retains the dynamic reason in its separate final argument.',
'Cuimhne refers to memory. Nuair a osclófar ties the offer to opening and más féidir keeps smaller dimensions conditional.',
'D’fhéadfadh covers both possible file damage and use of features unsupported by this Android version. The relative clause does not turn possibility into certainty.',
'Focal faire or unsupported criptiú preserves both causes. Cóip gan chosaint is the technical unprotected copy, saved before importing it, with feminine í agreeing with cóip.',
'The two relative conditions require a nonempty file and a size not greater than 512 MiB, preserving the inclusive limit.',
'Líon na leathanach is the page count; idir 1 agus maximum is an ordinary inclusive count interval in this validation context.',
'Bailí a thuilleadh under negation conveys no longer valid. The second sentence asks for a page from this document rather than another file.',
'The predicative neamhbhailí nó rómhór retains invalid versus too-large page dimensions as alternative import failures.',
'Dronuilleog with width and height greater than zero and entirely within the selected page expresses the required positive crop geometry.',
'Rindreáil and teorainn chuimhne ... d’íomhánna state that PDF rendering exceeds available image memory, without suggesting disk space or a monetary budget.'
],
'kn':[
'ಒಂದು ಪುಟವನ್ನು ಆಯ್ಕೆಮಾಡಿ is a complete polite instruction to select one page; it does not suggest a whole file or a range.',
'ಪುಟಗಳ ಸಂಖ್ಯೆ gives the total count and ಚಿತ್ರವಾಗಿ ಸಂಪಾದಿಸಲು explains editing one selected page as an image; both identity arguments remain unchanged.',
'ಪುಟ ಸಂಖ್ಯೆ accurately labels the current page-number input rather than the total page count.',
'ಹಿಂದಿನ ಪುಟ means the previous page without a PDF qualifier, so it remains suitable for credit-text pagination.',
'ಮುಂದಿನ ಪುಟ means the following page and remains neutral across document and credit-text consumers.',
'ಪುಟವನ್ನು ತೆರೆಯಿರಿ is a polite imperative to open the selected page.',
'ಆಯ್ಕೆಮಾಡಿದ ಪುಟದ ಮುನ್ನೋಟ identifies the preview of the selected page, not a preview-selection command.',
'ರಿಂದ ... ವರೆಗಿನ gives the page-number interval from 1 through the dynamic maximum and ನಮೂದಿಸಿ requests input.',
'The reordered total comes first in ಒಟ್ಟು ... ಪುಟಗಳಲ್ಲಿ; ನೇ attaches only to the current page. The final clause describes ongoing preview loading.',
'The reordered total/current construction remains correct, with only the current index ordinalized; width then height are pixel dimensions of the page.',
'ಮುನ್ನೋಟ ಲಭ್ಯವಿಲ್ಲ states that the preview is unavailable and retains the complete error-detail argument.',
'Insufficient ಮೆಮೊರಿ is followed by an opportunity to choose smaller dimensions on opening, qualified by ಸಾಧ್ಯವಾದರೆ; it does not promise success.',
'The first sentence states read failure. ಹಾನಿಗೊಳಗಾಗಿರಬಹುದು and ಬಳಸುತ್ತಿರಬಹುದು preserve possible damage or unsupported features, tied to this Android version.',
'ಗುಪ್ತಪದ and ಗೂಢಲಿಪೀಕರಣ distinguish password from encryption. ಅಥವಾ preserves the alternative, and the unprotected copy is to be saved before import.',
'ಖಾಲಿಯಾಗಿರಬಾರದು rejects an empty file and ಮೀರಿರಬಾರದು permits exactly 512 MiB, preserving both file-admission conditions.',
'1 ರಿಂದ maximum ವರೆಗೆ naturally expresses the inclusive number of pages the PDF must contain.',
'ಈಗ ಮಾನ್ಯವಾಗಿಲ್ಲ with the selection subject conveys that it is no longer valid and gives the remedy of choosing a page from this document.',
'ಅಮಾನ್ಯವಾಗಿವೆ ಅಥವಾ ... ತುಂಬಾ ದೊಡ್ಡದಾಗಿವೆ retains invalidity or excessive dimensions as alternatives preventing import.',
'Revised the generic nonempty rectangle to explicit width and height greater than zero and complete containment in the selected page, avoiding an interpretation about visible contents.',
'The complete wording explains rendering as creating the PDF as an image and says the required memory exceeds the available image-memory limit; it is not file storage.'
],
'ml-IN':[
'ഒരു താൾ തിരഞ്ഞെടുക്കുക selects a single page with a normal instruction form, consistent with the PDF-page sense of താൾ.',
'താളുകളുടെ എണ്ണം states the count and ചിത്രമായി എഡിറ്റ് ചെയ്യാൻ gives the purpose of editing one page as an image; the two identity arguments remain intact.',
'താൾ നമ്പർ is the page-number input label and is distinct from a count of pages.',
'മുൻപത്തെ താൾ means the previous page and works for both PDF/TIFF and credit-text pagination.',
'അടുത്ത താൾ means the next page without implying a particular document type.',
'താൾ തുറക്കുക is a conventional action instruction to open the chosen page.',
'തിരഞ്ഞെടുത്ത താളിന്റെ തിരനോട്ടം specifically names the selected-page preview and has the correct genitive relation.',
'1 മുതൽ maximum വരെയുള്ള gives the inclusive page-number range, followed by an instruction to supply one number.',
'The total comes first as total താളുകളിൽ, while -ാം belongs only to the current page; ലോഡ് ചെയ്യുന്നു denotes ongoing loading.',
'Total and current remain correctly assigned after reordering, and the pixel values preserve source width followed by height.',
'തിരനോട്ടം ലഭ്യമല്ല states preview unavailability and leaves the reason argument intact after the colon.',
'Insufficient മെമ്മറി is distinct from storage. സാധ്യമെങ്കിൽ qualifies the chance to choose smaller dimensions on opening the page.',
'കേടായിരിക്കാം and ഉപയോഗിക്കുന്നതാകാം retain both causes as possibilities; the unsupported features are relative to this Android version.',
'രഹസ്യവാക്ക് and എൻക്രിപ്ഷൻ preserve password versus encryption. The second sentence explicitly saves an unprotected copy before import; പരിരക്ഷ is protection, not the save command.',
'ശൂന്യമാകരുത് prohibits an empty file, while 512 MiB ൽ കൂടരുത് includes the exact upper limit; both conditions are retained.',
'1 മുതൽ maximum വരെ is a natural inclusive count interval for the required PDF pages.',
'ഇനി സാധുവല്ല conveys that the page selection is no longer valid; the replacement must come from this document.',
'അസാധുവാണ് or too large to import preserves both dimension failures without conflating them with a file-byte limit.',
'Revised ശൂന്യമല്ലാത്ത to explicit positive width and height and whole-page containment, so the crop condition cannot be mistaken for nonblank image content.',
'റെൻഡർ ചെയ്യാൻ വേണ്ട മെമ്മറി and ചിത്രങ്ങൾക്കായി ... പരിധി identify required rendering memory and its available image-memory limit, rather than disk capacity.'
],
'pa-IN':[
'ਇੱਕ ਸਫ਼ਾ ਚੁਣੋ is a normal imperative selecting one page, with the Gurmukhi page noun used consistently.',
'ਸਫ਼ਿਆਂ ਦੀ ਗਿਣਤੀ gives the total and ਚਿੱਤਰ ਵਜੋਂ ਸੋਧਣ ਲਈ gives editing-as-image purpose; one page and both identity fields are retained.',
'ਸਫ਼ਾ ਨੰਬਰ labels the page-number field, not a count of all pages.',
'ਪਿਛਲਾ ਸਫ਼ਾ means previous page and is suitable for the shared credit-text pagination consumer.',
'ਅਗਲਾ ਸਫ਼ਾ means next page and remains independent of the document format.',
'ਸਫ਼ਾ ਖੋਲ੍ਹੋ is a grammatical instruction to open the selected page.',
'ਚੁਣੇ ਸਫ਼ੇ ਦੀ ਝਲਕ names a preview of the selected page and retains the selected-page relation.',
'1 ਤੋਂ maximum ਤੱਕ gives the inclusive allowed page-number interval, and ਦਿਓ asks for an input number.',
'ਕੁੱਲ total ਸਫ਼ਿਆਂ ਵਿੱਚੋਂ ਸਫ਼ਾ current correctly distinguishes total from current page; the final passive clause states that the preview is loading.',
'The total-before-current construction retains the intended argument roles, followed by width-by-height in pixels for the source page.',
'ਝਲਕ ਉਪਲਬਧ ਨਹੀਂ ਹੈ states preview unavailability and preserves the dynamic error detail after the colon.',
'ਕਾਫ਼ੀ ਮੈਮੋਰੀ ਨਹੀਂ identifies memory insufficiency. ਜਿੱਥੇ ਸੰਭਵ ਹੋਵੇ keeps the smaller-dimension choice conditional when opening the page.',
'ਹੋ ਸਕਦਾ ਹੈ ਕਿ governs damage or unsupported features as alternatives, without asserting corruption; Android support is tied to this version.',
'ਪਾਸਵਰਡ or ਅਸਮਰਥਿਤ ਇਨਕ੍ਰਿਪਸ਼ਨ preserves both causes. ਬਿਨਾਂ ਸੁਰੱਖਿਆ ਵਾਲੀ ਕਾਪੀ means the unprotected copy to save before importing.',
'ਖਾਲੀ ਨਹੀਂ and not greater than 512 MiB express both nonemptiness and the inclusive file-size bound without changing units.',
'1 ਤੋਂ maximum ਤੱਕ states the inclusive number of pages the document must contain.',
'ਹੁਣ ਵੈਧ ਨਹੀਂ expresses that the page choice is no longer valid, with a specific remedy of choosing a page in this document.',
'ਅਵੈਧ ਹਨ ਜਾਂ ... ਬਹੁਤ ਵੱਡੇ ਹਨ keeps invalidity and excessive dimensions distinct from each other and from byte-size limits.',
'Revised the nonempty-relative clause to require width and height above zero and complete containment in the chosen page, retaining rectangle geometry without referring to visible content.',
'ਲੋੜੀਂਦੀ ਮੈਮੋਰੀ for rendering exceeds the memory available for images; the sentence makes a technical memory limit rather than a disk or financial budget claim.'
]}
revisions={
 'kn':{'formats22_pdf_crop':'PDF ಕ್ರಾಪ್ ಪ್ರದೇಶವು ಶೂನ್ಯಕ್ಕಿಂತ ಹೆಚ್ಚಿನ ಅಗಲ ಮತ್ತು ಎತ್ತರವಿರುವ ಆಯತಾಕಾರವಾಗಿರಬೇಕು ಮತ್ತು ಆಯ್ಕೆಮಾಡಿದ ಪುಟದೊಳಗೆ ಸಂಪೂರ್ಣವಾಗಿ ಇರಬೇಕು.'},
 'ml-IN':{'formats22_pdf_crop':'PDF ക്രോപ്പ് പ്രദേശം പൂജ്യത്തേക്കാൾ വലിയ വീതിയും ഉയരവുമുള്ള ഒരു ദീർഘചതുരമായിരിക്കണം. അത് പൂർണമായും തിരഞ്ഞെടുത്ത താളിനുള്ളിലായിരിക്കണം.'},
 'pa-IN':{'formats22_pdf_crop':'PDF ਦਾ ਕਰੋਪ ਖੇਤਰ ਇੱਕ ਆਇਤਕਾਰ ਹੋਣਾ ਚਾਹੀਦਾ ਹੈ ਜਿਸ ਦੀ ਚੌੜਾਈ ਅਤੇ ਉਚਾਈ ਸਿਫ਼ਰ ਤੋਂ ਵੱਧ ਹੋਣ ਅਤੇ ਜੋ ਪੂਰੀ ਤਰ੍ਹਾਂ ਚੁਣੇ ਸਫ਼ੇ ਦੇ ਅੰਦਰ ਹੋਵੇ।'}
}
limits=[
 'Independent model linguistic/source-context review only; no native-human language certification.',
 'No Android compilation, installed-app exhaustive check, font/glyph/shaping/layout screenshot review, or TalkBack/speech acceptance was performed by this reviewer.',
 'Existing tests were inspected, not executed here; other locales and existing test results do not approve these new values.',
 'Canonical and pinned upstream wording provide contextual terminology only. Neither earlier approvals nor withdrawn localization completion claims receive acceptance credit.',
 'The exact parsed description separator is backslash followed by n, code points [92,110]. It is preserved; runtime newline rendering is not certified.',
 'This review makes no release, overall localization completeness, merge, CI or deployment acceptance claim.',
 'No app files, authors’ candidates, remote records, Work tasks or held branches were changed; #395 merge and #400 retry denials remain untouched.'
]
sourcefiles=[
 'Paintroid/src/main/java/org/catrobat/paintroid/classic/ImportSelection.kt',
 'Paintroid/src/main/java/org/catrobat/paintroid/classic/PdfCodec.kt',
 'Paintroid/src/main/java/org/catrobat/paintroid/classic/LegacyImageCreditsActivity.kt',
 'Paintroid/src/test/java/org/catrobat/paintroid/local/OrdinaryPriorityFollowthroughTest.kt',
 'Paintroid/src/test/java/org/catrobat/paintroid/local/LocaleNumberInputTest.kt',
 'Paintroid/src/test/java/org/catrobat/paintroid/local/ImportSelectionFlowTest.kt',
 'Paintroid/src/test/java/org/catrobat/paintroid/local/ImportSelectionTitleTest.kt',
 'Paintroid/src/test/java/org/catrobat/paintroid/local/JapanesePdfFailureTest.kt',
 'Paintroid/src/test/java/org/catrobat/paintroid/local/LegacyImageCreditsActivityTest.kt',
 'Paintroid/src/androidTest/java/org/catrobat/paintroid/classic/PdfCodecTest.kt'
]
criteria={
 'formats22_select_page':'Choose one page of PDF or TIFF, including a one-page document.',
 'formats22_page_description':'Preserve format/name/count arguments and raw separator; choose one page to edit as an image.',
 'formats22_page_number':'Current one-based page-number input, not total count.',
 'formats22_previous_page':'Previous page, shared with retained-credit text pagination.',
 'formats22_next_page':'Next page, shared with retained-credit text pagination.',
 'formats22_open_page':'Open the selected page.',
 'formats22_page_preview':'Accessibility description of the selected-page preview.',
 'formats22_page_range':'Inclusive integer range 1 through the supplied total.',
 'formats22_loading_page':'One-based current page, total pages, preview still loading.',
 'formats22_page_dimensions':'One-based current page and total; full source width then height in pixels, not scaled preview dimensions.',
 'formats22_preview_unavailable':'Preview unavailable with a separate dynamic error detail.',
 'formats22_preview_memory':'Insufficient memory; opening offers smaller dimensions only when possible.',
 'formats22_pdf_invalid':'Cannot read; damage or this Android version’s unsupported features are possible, not established causes.',
 'formats22_pdf_encrypted':'Password required OR unsupported encryption; save an unprotected copy before import.',
 'formats22_pdf_file_size':'Nonempty file AND no larger than 512 MiB inclusive.',
 'formats22_pdf_page_count':'Inclusive page-count interval 1 through the supplied maximum.',
 'formats22_pdf_page_index':'Selection is no longer valid; choose a page from this document.',
 'formats22_pdf_dimensions':'Page dimensions are invalid OR too large for import.',
 'formats22_pdf_crop':'Rectangle has positive width and positive height and lies wholly inside the selected page.',
 'formats22_pdf_memory':'PDF rendering exceeds available image-memory budget; not storage or a monetary budget.'
}
format_pattern=re.compile(r'%(?:\d+\$)?[-#+ 0,(]*\d*(?:\.\d+)?[a-zA-Z%]')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def validate(value,source,locale,key):
 assert collections.Counter(format_pattern.findall(value))==collections.Counter(format_pattern.findall(source)),(locale,key,'placeholder')
 assert value.count('\\n')==source.count('\\n'),(locale,key,'separator')
 assert '\n' not in value and '\r' not in value,(locale,key,'real newline')
 assert unicodedata.normalize('NFC',value)==value,(locale,key,'NFC')
 assert '"' not in value and "'" not in value,(locale,key,'Android quote')
 ET.fromstring('<string name="'+key+'">'+value+'</string>')
 return {'placeholder_multiset':'match','raw_separator_count':'match','NFC':'pass','XML_text':'pass','unescaped_ASCII_quote_or_apostrophe':'absent'}
for group in ['west','indic']:
 candidate_path=out/f'candidate-{group}.json'
 candidates=json.loads(candidate_path.read_text())['translations']
 accepted=copy.deepcopy(candidates)
 entries=[]; counts=collections.Counter(); bylocale={}; checks={}
 for locale,values in candidates.items():
  assert list(values)==keys,(locale,'key order/set')
  assert len(reasons[locale])==20
  existing={e.attrib.get('name') for e in ET.parse(repo/inputs['paths'][locale]).getroot()}
  assert not set(keys)&existing
  accepted[locale].update(revisions.get(locale,{}))
  loccounts=collections.Counter()
  for i,(key,candidate) in enumerate(values.items()):
   final=accepted[locale][key]
   decision='revised' if final!=candidate else 'unchanged'
   confidence='high' if i in [0,2,3,4,5,6,7,10,14,15] else 'medium-high'
   extra=[]
   if key=='formats22_page_description':extra.append('Literal separator is preserved as [92,110]; no runtime line-break claim.')
   if key in ['formats22_loading_page','formats22_page_dimensions'] and locale in ['kn','ml-IN']:
    extra.append('Digit-plus-ordinal construction reviewed as text; exact numeral shaping and spoken output on devices are untested.')
   if key=='formats22_pdf_crop' and decision=='revised':
    extra.append('Longer geometry clarification has no measured narrow-dialog layout evidence; source meaning is preserved without assuming nonblank pixels.')
   if key=='formats22_pdf_encrypted':
    extra.append('Technical encryption/protection construction is independently reviewed composition; terminology excerpts alone do not certify it.')
   if locale=='ca-ES-valencia':
    extra.append('General Catalan sources do not independently certify Valencian-specific usage; locale wording reviewed here as a model judgment.')
   entries.append({'locale':locale,'key':key,'source':inputs['source'][key]['text'],'candidate':candidate,'final':final,'decision':decision,'status':'accepted_model_review','reason':reasons[locale][i],'semantic_requirement':criteria[key],'confidence':confidence,'limits':['Not native-human certified; no installed-layout, shaping or speech acceptance.']+extra})
   checks[f'{locale}/{key}']=validate(final,inputs['source'][key]['text'],locale,key)
   counts[decision]+=1;loccounts[decision]+=1
  bylocale[locale]={'total':20,'unchanged':loccounts['unchanged'],'revised':loccounts['revised'],'held':0}
 sources=['inputs.json',f'candidate-{group}.json']+(['candidate-west-primary.json','candidate-west-encryption-primary.json','candidate-west-checks.json'] if group=='west' else ['candidate-indic-notes.json','indic-upstream-excerpts.json'])
 result={
  'reviewer':'Independent native agent review_six_page_locales, not the candidate authors; model review, not native-human certification',
  'scope':f'Complete 60-value P2 page-picker/PDF {group} independent review',
  'base_sha':sha,'base_tree':inputs['base_tree'],
  'method':'Read the complete candidates independently against the English source and real consumers, inspect current locale terminology and supplied primary excerpts, assess each whole value, preserve raw Android formatting, and make explicitly recorded repairs. No author self-review, old wording or imported term automatically confers acceptance.',
  'accepted':accepted,'entries':entries,
  'summary':{'total':sum(counts.values()),'unchanged':counts['unchanged'],'revised':counts['revised'],'held':0,'accepted':sum(counts.values()),'by_locale':bylocale},
  'source_context':{
    'ImportSelection':'kind/name/count arguments; one-based page field converted to zero-based source; current/total loading status; full source dimensions remain distinct from the at-most-384-pixel preview; out-of-memory conditional message.',
    'PdfCodec':'Nonempty <=512 MiB; 1..4096 page count; page-index bounds; page dimensions 1..500000 points; pixel crop strictly positive in both dimensions and within source; SecurityException distinct from invalid/IO; budget includes image/document/native work and is an estimate, not an allocator guarantee.',
    'LegacyImageCreditsActivity':'Previous/next labels reused for pages of bounded retained-credit text; no PDF qualification is appropriate.',
    'tests':'Read existing actual-consumer range/navigation/cancel, numeric-input, file-ownership, PDF failure-cause, crop/budget/144dpi, and retained-credit pagination tests. They were not run and their locale coverage does not certify these new translations.'
  },
  'inspected_repo_files':[{'path':p,'sha256':digest(repo/p)} for p in sourcefiles+list(inputs['paths'][l] for l in candidates)],
  'inspected_evidence':[{'path':p,'sha256':digest(out/p)} for p in sources],
  'upstream_evidence_limit':'Inspected supplied pinned upstream excerpts and notes, without independently refetching their remote contents. Their words inform term senses only; full final sentences are evaluated here separately.',
  'validation':{'checks_run':'Independent local Python review-artifact validation only; not Android build/runtime tests.','entry_count':len(checks),'all_final_formatting_checks_passed':True,'description_separator_codepoints':[92,110],'checks':checks},
  'limits':limits
 }
 (out/f'review-{group}.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(group,json.dumps(result['summary'],ensure_ascii=False))
