import base64,json,pathlib,re,sys
sys.path.insert(0,'tools')
from current_localization_contracts import current_display
w=pathlib.Path('/workspace/shared/anpaint-p2-west-six-evidence');p=json.load(open(w/'candidate.json'));rows=[]
cases={
'formats22_page_description':[['PDF','test %1$d · 東京.pdf',1],['TIFF','image.tiff',2],['PDF','',4096],['TIFF','red\n%3$d.tif',5]],
'formats22_page_range':[[1],[4096]],
'formats22_loading_page':[[1,1],[2,6],[4096,4096]],
'formats22_page_dimensions':[[1,1,1,1],[2,3,1024,768],[4096,4096,1000000,65535]],
'formats22_preview_unavailable':[[''],['त्रुटि · 오류 · ত্রুটি'],['first\nsecond'],['%1$s 100%']],
'formats22_pdf_page_count':[[1],[4096]],
}
b64=lambda x:base64.b64encode(x.encode()).decode()
for locale,path in p['paths'].items():
 for key,variants in cases.items():
  template=current_display(locale,key)
  for args in variants:
   def expected_slot(match):
    value=args[int(match[1])-1]
    return str(value)
   expected=re.sub(r'%([0-9]+)[$]([ds])',expected_slot,template)
   tokens=['d:'+str(x) if isinstance(x,int) else 's:'+b64(x) for x in args]
   rows.append('\t'.join([locale,key,b64(template),b64(expected),*tokens]))
assert len(rows)==108
(w/'format-cases.tsv').write_text('\n'.join(rows)+'\n')
print('108 temporary cases from final XML, with verified Latin numeric slots and literal string arguments')
