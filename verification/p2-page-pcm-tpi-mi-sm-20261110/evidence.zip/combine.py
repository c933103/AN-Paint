import json,pathlib,hashlib
w=pathlib.Path('/workspace/shared/anpaint-p2-remaining-evidence');a=json.load(open(w/'review-pcm-tpi.json'));b=json.load(open(w/'review-mi-sm.json'));out={'reviews':['review-pcm-tpi.json','review-mi-sm.json'],'accepted':{**a['accepted'],**b['accepted']},'summary':{}}
c={}
for name in ['candidate-pcm-tpi.json','candidate-mi-sm.json']:c.update(json.load(open(w/name))['translations'])
p=json.load(open(w/'inputs.json'));assert set(c)==set(p['paths']) and sum(map(len,c.values()))==80
n=rev=held=0
for tag,values in c.items():
 acc=out['accepted'][tag];assert set(acc)<=set(values)
 for k,v in acc.items():
  if v==values[k]:n+=1
  else:rev+=1
 held+=len(values)-len(acc)
out['summary']={'total_reviewed':80,'accepted_unchanged':n,'accepted_revised':rev,'held':held,'accepted_total':n+rev};out['accepted_map_sha256']=hashlib.sha256(json.dumps(out['accepted'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest();out['limits']='Independent full-value model review only; not native-human, installed-caption/layout/font/speech, device or release certification.';(w/'review.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');(w/'candidate.json').write_text(json.dumps({'translations':c},ensure_ascii=False,indent=2)+'\n');print(out['summary'])
