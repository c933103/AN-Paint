import json,re
from pathlib import Path
p=Path('/workspace/shared/anpaint-p2-remaining-evidence')
c=json.loads((p/'candidate-pcm-tpi.json').read_text())['translations']
s=json.loads((p/'inputs.json').read_text())['source']
reasons={
'select_page':'Imperative selects one page, not an entire document.',
'page_description':'Identifies format and filename, gives total count in a count label usable for 1 and arbitrary totals, and asks for one page for image editing. All three indexed slots and raw backslash+n separator retained.',
'page_number':'Unambiguous label for the one-based page-number field.',
'previous_page':'Previous-page accessible navigation label; no reversal of reading/image geometry.',
'next_page':'Next-page accessible navigation label; no reversal of reading/image geometry.',
'open_page':'Opens the selected page, matching the positive button.',
'page_preview':'Names a preview of the selected page, not a revision comparison or full import.',
'page_range':'Requests page number within inclusive bounds 1 and the integer maximum.',
'loading_page':'Distinguishes current page from total and indicates preview loading in progress; both integer slots retained.',
'page_dimensions':'Current page, total, width and height slots remain in order and are all integers. Multiplication sign and pixel unit retained.',
'preview_unavailable':'Reports preview unavailable and retains string slot for the actual reason.',
'preview_memory':'Insufficient memory is limited to this preview. Smaller dimensions are conditional on possibility, not promised for every page.',
'pdf_invalid':'Read failure, possible damage rather than certain corruption, and unsupported features on this Android version remain distinct.',
'pdf_encrypted':'Password requirement or unsupported encryption are alternatives. Unprotected copy must lack both password protection and encryption before import.',
'pdf_file_size':'Requires a nonempty file and an inclusive maximum of 512 MiB; neither units nor boundary changed.',
'pdf_page_count':'Requires at least 1 and at most the indexed integer limit, matching 1..MAX_PAGES.',
'pdf_page_index':'Selection is no longer valid, followed by selection from this document, not deletion or document replacement.',
'pdf_dimensions':'Invalid dimensions and dimensions too large for import remain alternatives.',
'pdf_crop':'Requires strictly positive width and height and containment of the entire rectangle within the selected page image, matching all six source checks.',
'pdf_memory':'Describes raster/image creation exceeding available image memory; no promise or instruction that downsizing can cure the document-memory floor.'}
revisions={
('pcm','formats22_pdf_invalid'):'Di app no fit read di PDF. Di file fit don damage, or e fit dey use features wey dis Android version no support.',
('pcm','formats22_pdf_crop'):'Di PDF crop must be rectangle wey im width and height greater than zero, and di whole rectangle must dey inside di picture of di page wey you choose.',
('pcm','formats22_pdf_memory'):'To turn dis PDF page into picture go pass di memory wey dey available for pictures.',
('tpi','formats22_page_range'):'Raitim namba bilong pes long 1 i go inap %1$d.',
('tpi','formats22_pdf_crop'):'Krop bilong PDF i mas wanpela rektengel i gat wit na hait i winim zero, na rektengel olgeta i mas stap insait long piksa bilong pes yu makim.',
('tpi','formats22_pdf_memory'):'Wok bilong mekim piksa bilong dispela pes PDF bai winim mak bilong memori i stap bilong ol piksa.'}
extra={
('pcm','formats22_pdf_invalid'):' Revised the first clause to state the app cannot read the PDF, avoiding an agentive reading of the PDF itself.',
('pcm','formats22_pdf_crop'):' Explicitly restored selected-page qualification.',
('tpi','formats22_pdf_crop'):' Explicitly restored selected-page qualification; wit/hait and rektengel match existing target technical register, not independent native endorsement.',
('tpi','formats22_page_range'):' Replaced potentially ambiguous between wording with inclusive 1-through-maximum phrasing.',
('pcm','formats22_pdf_memory'):' Removed unsupported smaller-dimensions instruction and made image memory scope explicit.',
('tpi','formats22_pdf_memory'):' Removed unsupported smaller-dimensions instruction and made available image memory scope explicit.'}
rows={}; accepted={}
for loc,vals in c.items():
 rows[loc]={};accepted[loc]={}
 for key,original in vals.items():
  decision='revised' if (loc,key) in revisions else 'accepted'
  final=revisions.get((loc,key),original)
  reason=reasons[key.removeprefix('formats22_')]+extra.get((loc,key),'')
  confidence='moderate-high' if loc=='pcm' else 'moderate'
  if (loc,key)==('tpi','formats22_pdf_encrypted'):
   decision='held';final=None;confidence='insufficient for publication'
   reason='The sentence preserves the apparent password/encryption distinction, but enkripsen is an authored, uncorroborated loan. The supplied primary tpi source supports paswot, not enkripsen. Searches for Tok Pisin enkripsen and Tok Pisin encryption returned no adequate Tok Pisin usage. I cannot independently qualify this complete technical sentence for publication; retain fallback until a competent target-language review or adequate source supports an exact rendering.'
  row={'original':original,'decision':decision,'reason':reason,'confidence':confidence,'limits':['Independent model linguistic/semantic review only; no native-human certification.','Existing catalogue consistency and primary component terms are not full-sentence endorsements.','No device rendering, layout, font, speech or release validation.']}
  if final is not None:
   row['final']=final;accepted[loc][key]=final
   assert re.findall(r'%\d+\$[sd]',final)==re.findall(r'%\d+\$[sd]',s[key]['text']),key
   if key=='formats22_page_description':
    assert '\\n' in final and '\n' not in final
  rows[loc][key]=row
out={'base':'fc682496bc91ca74eafd519428ca91d3b270027d','review_scope':'40 new complete page/PDF values; no old-value acceptance credit','source_checks':[
'Read AGENTS.md and TRANSLATING.md, actual ImportSelection.kt and PdfCodec.kt, English inputs and both existing target catalogues.',
'Independently parsed raw primary MediaWiki json, verified all cited component excerpts and SHA-256 hashes against primary-terms.json. No independent network refetch of those immutable blobs was necessary for this content check; the raw retrieved files were the source examined.',
'Primary pcm preview wording is web/revision context; not imported as image-preview wording. tpi pes and paswot have narrow corroboration only.',
'Examined exact one-based page bounds, 1..4096 count, nonempty <=512 MiB file bounds, positive dimensions, all crop boundaries and memory estimates including document-byte and reserve floors.',
'All 39 qualified complete values retain typed indexed format slots; descriptions preserve raw codepoints [92,110]. Counts read correctly at 1 and arbitrary totals. Latin script and proper names retained.'
], 'review':rows,'accepted':accepted,'summary':{'accepted_unchanged':33,'revised':6,'held':1,'qualified_total':39},'limitations':['Not native-human certification.','Does not reinstate any withdrawn historical acceptance or certify release/layout/device behavior.','Tok Pisin complex technical terminology remains a moderate-confidence model review, with encryption explicitly withheld.']}
(p/'review-pcm-tpi.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(out['summary'])
