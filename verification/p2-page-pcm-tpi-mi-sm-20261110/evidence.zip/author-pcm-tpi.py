import json,pathlib
w=pathlib.Path('/workspace/shared/anpaint-p2-remaining-evidence');p=json.load(open(w/'inputs.json'));keys=list(p['source']);sep=p['source']['formats22_page_description']['text'].split('%2$s')[1].split('Number')[0]
values={
'pcm':[
'Choose one page',
'%1$s · %2$s'+sep+'Number of pages: %3$d. Choose one page wey you wan edit as picture.',
'Page number',
'Previous page',
'Next page',
'Open page',
'Preview of di page wey you choose',
'Enter page number from 1 to %1$d.',
'Page %1$d out of %2$d · Preview dey load…',
'Page %1$d out of %2$d · %3$d × %4$d pixels',
'Preview no dey available: %1$s',
'Memory no enough for dis preview. When you open di page, di app go offer smaller dimensions if e fit.',
'Di PDF no fit read. Di file fit don damage, or e fit dey use features wey dis Android version no support.',
'Di PDF need password or e dey use encryption wey di app no support. Save copy wey no get password or encryption before you import am.',
'Di PDF file no suppose empty, and im size no suppose pass 512 MiB.',
'Di PDF must get from 1 to %1$d pages.',
'Di PDF page wey you choose no valid again. Choose one page from dis document.',
'Di PDF page dimensions no valid or dem too big to import.',
'Di PDF crop must be rectangle wey im width and height greater than zero, and di whole rectangle must dey inside di page picture.',
'To render dis PDF page go pass di memory limit. Choose smaller dimensions.'
],
'tpi':[
'Makim wanpela pes',
'%1$s · %2$s'+sep+'Namba bilong ol pes: %3$d. Makim wanpela pes long editim olsem piksa.',
'Namba bilong pes',
'Pes i kam paslain',
'Pes i kam bihain',
'Opim pes',
'Priviw bilong pes yu makim',
'Raitim namba bilong pes namel long 1 na %1$d.',
'Pes %1$d long olgeta %2$d · Priviw i lod yet…',
'Pes %1$d long olgeta %2$d · %3$d × %4$d piksel',
'Priviw i no stap: %1$s',
'I no gat inap memori bilong dispela priviw. Taim yu opim pes, app bai givim ol dimension i liklik moa sapos em inap.',
'I no inap ritim PDF. Ating fail i bagarap, o em i yusim ol samting dispela Android vesin i no sapotim.',
'PDF i nidim paswot o i yusim enkripsen app i no sapotim. Sevim wanpela kopi i no gat paswot o enkripsen pastaim, na bringim i kam insait.',
'PDF i mas wanpela fail i no stap nating, na sais bilong en i no ken winim 512 MiB.',
'PDF i mas i gat 1 i go inap %1$d pes.',
'Pes bilong PDF yu makim i no stret moa. Makim wanpela pes bilong dispela dokument.',
'Ol dimension bilong pes PDF i no stret o i bikpela tumas long bringim i kam insait.',
'Krop bilong PDF i mas wanpela rektengel i gat wit na hait i winim zero, na rektengel olgeta i mas stap insait long piksa bilong pes.',
'Wok bilong mekim piksa bilong dispela pes PDF bai winim mak bilong memori. Makim ol dimension i liklik moa.'
]}
assert all(len(v)==len(keys)==20 for v in values.values())
out={'translations':{l:dict(zip(keys,v)) for l,v in values.items()},'rationale':{
'pcm':{'confidence':'moderate-high, model-authored; not native-human certification','wording':'Nigerian Pidgin clause patterns and technical code-switching follow the existing catalogue. Uses picture, di/we(y), fit and no suppose. English technical loans page, preview, dimensions, memory and encryption are contextual choices, not upstream full-sentence quotations.','source':'primary-terms.json contains immutable MediaWiki pcm terms and exact limits. MediaWiki phonetic pej and Paswod support the concepts, while familiar page/password spellings preserve existing technical register.'},
'tpi':{'confidence':'moderate, model-authored; technical borrowing warrants reviewer attention','wording':'Tok Pisin forms follow existing piksa/fail/memori/dimension/priviw/rekten(g)el register. Pes and paswot corroborated by MediaWiki. Enkripsen is an authored technical borrowing, not independently sourced. Reviewer should hold encryption if this is insufficient. Geometry spells out positive width and height plus complete containment.','source':'primary-terms.json, immutable MediaWiki tpi. Web preview phrase is context-specific and not reused as image-preview wording.'}},'limits':['No old-value review credit','No installed-rendering, layout, speech, font, human-native or release acceptance']}
(w/'candidate-pcm-tpi.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('Authored 40 complete candidates; separator',list(map(ord,sep)))
