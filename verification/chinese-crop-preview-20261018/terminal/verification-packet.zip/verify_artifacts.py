"""Verify exact-source CI artifacts, including both regional crop-preview toolbar methods."""
from pathlib import Path
import hashlib
import io
import json
import re
import sys
import zipfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
HOSTED = ROOT / 'hosted'
SOURCE = ROOT / 'source'
OUT = ROOT / 'terminal-evidence'
OUT.mkdir(exist_ok=True)
read = lambda name: json.loads((ROOT / name).read_text())
publication = read('publication.json')
head, tree = publication['head'], publication['tree']
run, jobs, artifacts = read('terminal-run.json'), read('terminal-jobs.json'), read('artifacts.json')
review = read('final-review.json')
assert run['head_sha'] == head and run['status'] == 'completed' and run['conclusion'] == 'success'
assert len(jobs) == 6 and all(j['status'] == 'completed' and j['conclusion'] == 'success' for j in jobs)
assert publication['pr_checkout_tree'] == tree
for kind in ('code_review', 'security_review'):
    status = review['state'][kind]
    assert status['commit_sha'] == head and status['status'] == 'completed'
    assert status['has_any_findings'] is False and status['has_unresolved_findings'] is False
assert review['unresolved_threads'] == []


def archive(prefix, name):
    candidates = [a for a in artifacts if a['name'].startswith(prefix)]
    assert len(candidates) == 1, (prefix, candidates)
    artifact = candidates[0]
    data = (HOSTED / name).read_bytes()
    assert artifact['digest'] == 'sha256:' + hashlib.sha256(data).hexdigest()
    assert artifact['workflow_run']['id'] == run['id'] and artifact['workflow_run']['head_sha'] == head
    return artifact, zipfile.ZipFile(io.BytesIO(data))


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


build_artifact, build_zip = archive('apk-and-source-', 'apk-and-source.zip')
info = json.loads(build_zip.read('build/delivery/build-info.json'))
source_bytes = build_zip.read('build/delivery/AN-Paint-source.zip')
apk = build_zip.read('app/build/outputs/apk/debug/app-debug.apk')
assert info['commit'] == publication['pr_checkout'] and int(info['run_id']) == run['id']
assert hashlib.sha256(source_bytes).hexdigest() == info['source_sha256']
assert hashlib.sha256(apk).hexdigest() == info['apk_sha256']
with zipfile.ZipFile(io.BytesIO(apk)) as apk_zip:
    embedded = [n for n in apk_zip.namelist() if n.endswith('.zip') and 'source' in n.lower()]
    assert len(embedded) == 1 and apk_zip.read(embedded[0]) == source_bytes
missing, matched = [], 0
with zipfile.ZipFile(io.BytesIO(source_bytes)) as source_zip:
    for entry in read('remote-tree.json')['tree']:
        if entry['type'] != 'blob':
            continue
        name = 'AN-Paint/' + entry['path']
        if name not in source_zip.namelist():
            missing.append(entry['path'])
            continue
        data = source_zip.read(name)
        assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == entry['sha'], name
        assert ('100755' if (source_zip.getinfo(name).external_attr >> 16) & 0o100 else '100644') == entry['mode'], name
        assert (SOURCE / entry['path']).read_bytes() == data, name
        matched += 1
assert sorted(missing) == ['.gitignore', '.idea/codeStyles/Project.xml', 'colorpicker/.gitignore']
build = {'artifact': build_artifact, 'build_info': info, 'embedded_source_matches': True,
         'matched_source_files': matched, 'source_metadata_omissions': missing}
write('build-binding.json', build)

regression_artifact, regression_zip = archive('regression-', 'regression.zip')
counts = dict.fromkeys(('tests', 'failures', 'errors', 'skipped'), 0)
suites, related = [], {}
for name in regression_zip.namelist():
    if '/test-results/testDebugUnitTest/TEST-' not in name or not name.endswith('.xml'):
        continue
    root = ET.fromstring(regression_zip.read(name))
    cases = root.findall('testcase')
    assert len(cases) == int(root.attrib['tests'])
    for key in counts:
        counts[key] += int(root.attrib.get(key, 0))
    assert not any(case.find(key) is not None for case in cases for key in ('failure', 'error', 'skipped')), name
    suites.append(root.attrib['name'])
    classname = root.attrib['name'].split('.')[-1]
    if classname in ('ChineseCropPreviewTest', 'AssemblyModelTest', 'CropMovementTranslationTest'):
        source = (SOURCE / f'Paintroid/src/test/java/org/catrobat/paintroid/local/{classname}.kt').read_text()
        declared = set(re.findall(r'@Test(?:\s+@\w+(?:\([^)]*\))?)*\s+fun\s+(\w+)\(', source))
        methods = {case.attrib['name'] for case in cases}
        assert methods == declared and len(methods) == len(cases), (classname, methods, declared)
        related[classname] = {'source_methods': len(declared), 'passed_methods': sorted(methods)}
        (OUT / Path(name).name).write_bytes(regression_zip.read(name))
assert counts['tests'] > 0 and all(counts[key] == 0 for key in ('failures', 'errors', 'skipped'))
assert len(suites) == len(set(suites))
assert set(related) == {'ChineseCropPreviewTest', 'AssemblyModelTest', 'CropMovementTranslationTest'}
assert len(related['ChineseCropPreviewTest']['passed_methods']) == 3
python_log = regression_zip.read('build/reports/ci-phases/python.log').decode()
host_count = re.search(r'Ran (\d+) tests in [\d.]+s\n\nOK', python_log)
assert host_count
for mode in ('normal', 'optimized'):
    local_count = re.search(r'Ran (\d+) tests in [\d.]+s\n\nOK', (ROOT / f'evidence/host-{mode}.log').read_text())
    assert local_count and local_count[1] == host_count[1]
junit = {'artifact': regression_artifact, 'counts': counts, 'suite_count': len(suites),
         'source_bound_suites': related, 'hosted_python_tests': int(host_count[1])}
write('junit-receipt.json', junit)

exact_artifact, exact_zip = archive('exact-script-', 'exact-script.zip')
exact = json.loads(exact_zip.read(next(n for n in exact_zip.namelist() if n.endswith('summary.json'))))
assert exact['success'] and exact['tree'] == tree and exact['commit'] == publication['pr_checkout']
assert len(exact['probes']) == 9
for probe in exact['probes']:
    assert probe['exit_code'] == 0
    assert hashlib.sha256(exact_zip.read(next(n for n in exact_zip.namelist() if n.endswith(probe['name'] + '.log')))).hexdigest() == probe['log_sha256']
write('exact-script-summary.json', exact)

device_artifact, device_zip = archive('emulator-api-35-', 'combined.zip')
combined = ROOT / 'combined'
for name in device_zip.namelist():
    assert not Path(name).is_absolute() and '..' not in Path(name).parts
device_zip.extractall(combined)
sys.path.insert(0, str(SOURCE / 'tools'))
from app_instrumentation_matrix import verify_app_reports, read_app_reports
from run_android_instrumentation import declared_tests, source_tests_sha256
app_source = SOURCE / 'app/src/androidTest'
native_source = SOURCE / 'Paintroid/src/androidTest'
selected = declared_tests(app_source, sdk_level=35)
app = verify_app_reports(selected, 35, read_app_reports(combined, 35),
                         source_tests_sha256(app_source), declared_tests(app_source) - selected)
assert app['success'] and app['inventory_validated'] and app['completed_tests'] == len(selected)
native = json.loads((combined / 'Paintroid/androidTest-results/summary.json').read_text())
assert native['success'] and native['returncode'] == 0 and not native['timed_out']
assert not any(native[key] for key in ('missing', 'unexpected', 'errors'))
assert native['source_tests_sha256'] == source_tests_sha256(native_source)
native_cases = {(case['classname'], case['name']) for case in native['cases']}
assert native_cases == declared_tests(native_source, sdk_level=35)
assert len(native_cases) == len(native['cases']) and all(case['status'] == 'passed' for case in native['cases'])
identity = json.loads((combined / 'composed-device-identity.json').read_text())
assert identity['commit'] == info['commit'] and int(identity['run_id']) == run['id']
assert identity['apk_sha256'] == info['apk_sha256'] and identity['source_sha256'] == info['source_sha256']
assert identity['source_tests_sha256'] == source_tests_sha256(app_source)
assert identity['device_sdk'] == 35 and identity['build_variant'] == 'debug'
device = {'artifact': device_artifact, 'identity': identity, 'native_completed': len(native_cases),
          'app_completed': len(selected), 'app_inventory': app,
          'scope': 'Ordinary source-bound API35 union; no independent Chinese installed layout/glyph/TalkBack acceptance'}
write('device-receipt.json', device)
checks = {'source_commit': head, 'source_tree': tree, 'publication': publication, 'run': run, 'jobs': jobs,
          'review': review, 'junit': junit, 'build': build, 'device': device, 'exact_script_probes': len(exact['probes']),
          'local': {'focused_host_tests': 4, 'full_host_tests_per_mode': int(host_count[1]),
                    'jvm': 'Blocked before execution by uncached Gradle distribution and unreachable download network'}}
write('checks.json', checks)

manifest = []
with zipfile.ZipFile(OUT / 'verification-packet.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    def add(name, data):
        output.writestr(name, data)
        manifest.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    for name in ('publication.json', 'terminal-run.json', 'terminal-jobs.json', 'final-review.json', 'artifacts.json', 'verify_artifacts.py'):
        add(name, (ROOT / name).read_bytes())
    for name in regression_zip.namelist():
        if ('/test-results/testDebugUnitTest/TEST-' in name and name.endswith('.xml')) or '/ci-phases/' in name:
            add('regression/' + name, regression_zip.read(name))
    for name in device_zip.namelist():
        if name.endswith(('.json', '.xml')):
            add('combined-device/' + name, device_zip.read(name))
    for name in exact_zip.namelist():
        add('exact-script/' + name, exact_zip.read(name))
    output.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(OUT / 'verification-packet.zip') as output:
    for row in manifest:
        assert hashlib.sha256(output.read(row['path'])).hexdigest() == row['sha256']
print(json.dumps({'head': head, 'jobs': len(jobs), 'junit': counts, 'suites': len(suites),
                  'hosted_python': int(host_count[1]), 'source_files': matched, 'exact_probes': len(exact['probes']),
                  'native': len(native_cases), 'app': len(selected), 'code_and_security_exact': True,
                  'packet_bytes': (OUT / 'verification-packet.zip').stat().st_size}, indent=2))
