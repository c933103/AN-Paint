from pathlib import Path
import json,subprocess,xml.etree.ElementTree as ET,sys,hashlib,stat,re
O=Path(__file__).resolve().parent; W=O/'source';sys.path.insert(0,str(W/'tools'))
from test_crop_counterpart_guidance import require_complete, HELP
expected=json.loads((W/'Paintroid/src/test/resources/crop-counterparts/expected.json').read_text())['locales']['es-ES']
old=subprocess.check_output(['git','show','HEAD:Paintroid/src/main/res/values-b+es+ES/strings.xml'],cwd=W).decode();before=ET.fromstring(old);after=ET.parse(W/'Paintroid/src/main/res/values-b+es+ES/strings.xml').getroot()
try: require_complete(before,expected)
except ValueError as e: error=str(e)
else: raise AssertionError('Old value unexpectedly passed')
require_complete(after,expected)
for root in (before,after):root.find(f"./string[@name='{HELP}']").text='EXCLUDED_SINGLE_EDIT'
assert ET.tostring(before)==ET.tostring(after)
old_fixture=json.loads(subprocess.check_output(['git','show','HEAD:Paintroid/src/test/resources/crop-counterparts/expected.json'],cwd=W))
new_fixture=json.loads((W/'Paintroid/src/test/resources/crop-counterparts/expected.json').read_text())
old_fixture['locales']['es-ES']['help']=new_fixture['locales']['es-ES']['help'];assert old_fixture==new_fixture
source_text=(W/'Paintroid/src/main/res/values-b+es+ES/strings.xml').read_text()
pattern=rf'(<string name="{HELP}">)(.*?)(</string>)';om=re.search(pattern,old);nm=re.search(pattern,source_text)
assert old[:om.start(2)]+source_text[nm.start(2):nm.end(2)]+old[om.end(2):]==source_text
before_paragraphs=(O/'old-help.txt').read_text().strip().split('\n\n');after_paragraphs=(O/'new-help.txt').read_text().strip().split('\n\n')
assert len(before_paragraphs)==7 and len(after_paragraphs)==8
for old_index,new_index in ((0,0),(1,1),(3,4),(5,6),(6,7)):
 assert before_paragraphs[old_index]==after_paragraphs[new_index]
assert before_paragraphs[2].replace('La primera imagen empieza en el origen.','Al encajar, la primera imagen empieza en el origen.').replace('No se permiten solapamientos.','No se permiten solapamientos al encajar.')==after_paragraphs[2]
assert before_paragraphs[4].replace('Las imágenes siguientes ocupan el hueco y siguen colocadas.','Las demás imágenes siguen colocadas; las imágenes unidas pueden desplazarse para ocupar el hueco.')==after_paragraphs[5]
entries=json.loads((O/'base-tree.json').read_text())['tree'];changes=[]
for e in entries:
 if e['type']!='blob': continue
 p=W/e['path'];b=p.read_bytes();actual=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();mode='100755' if p.stat().st_mode&stat.S_IXUSR else '100644';assert mode==e['mode'],e['path']
 if actual!=e['sha']:changes.append({'path':e['path'],'mode':mode,'base_sha':e['sha'],'sha':actual})
assert len(changes)==5
receipt={'base':'ec4d74eb222c58d51e4a339e43ca83cc7aa16ec3','base_tree':'05f725b3a5c64acdace799cfb8cb5d5768ce8f63','production_scope':'One es-ES Help value only; every other production byte retained','paragraph_scope':'Five unchanged paragraphs plus three bounded corrections and the new Exact position paragraph','fixture_scope':'Only locales.es-ES.help changed; crop plural and other locale fixtures identical','base_blobs_verified':1209,'executable_modes':'All preserved','old_value_negative_control':error,'changes':changes}
(O/'scope-and-negative-control.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
