import json,re
from pathlib import Path
p=Path('/workspace/shared/anpaint-p2-asia-evidence')
a={
'formats22_select_page':'এখন পৃষ্ঠা বাছক',
'formats22_page_description':r'%1$s · %2$s\nপৃষ্ঠাৰ সংখ্যা: %3$d। ছবি হিচাপে সম্পাদনা কৰিবলৈ এখন পৃষ্ঠা বাছক।',
'formats22_page_number':'পৃষ্ঠাৰ নম্বৰ',
'formats22_previous_page':'আগৰ পৃষ্ঠা',
'formats22_next_page':'পৰৱৰ্তী পৃষ্ঠা',
'formats22_open_page':'পৃষ্ঠা খোলক',
'formats22_page_preview':'নিৰ্বাচিত পৃষ্ঠাৰ পূৰ্বদৰ্শন',
'formats22_page_range':'1ৰ পৰা %1$dলৈ এটা পৃষ্ঠাৰ নম্বৰ দিয়ক।',
'formats22_loading_page':'মুঠ %2$dখন পৃষ্ঠাৰ %1$d নম্বৰ পৃষ্ঠা · পূৰ্বদৰ্শন লোড হৈ আছে…',
'formats22_page_dimensions':'মুঠ %2$dখন পৃষ্ঠাৰ %1$d নম্বৰ পৃষ্ঠা · %3$d × %4$d পিক্সেল',
'formats22_preview_unavailable':'পূৰ্বদৰ্শন উপলব্ধ নহয়: %1$s',
'formats22_preview_memory':'এই পূৰ্বদৰ্শনৰ বাবে যথেষ্ট মেমৰি নাই। পৃষ্ঠাখন খুলিলে সম্ভৱ হ’লে সৰু মাত্ৰাৰ বিকল্প দিয়া হ’ব।',
'formats22_pdf_invalid':'PDF পঢ়িব পৰা নগ’ল। ফাইলটো ক্ষতিগ্ৰস্ত হ’ব পাৰে বা এই Android সংস্কৰণে সমৰ্থন নকৰা বৈশিষ্ট্য ব্যৱহাৰ কৰা হ’ব পাৰে।',
'formats22_pdf_encrypted':'PDF-ৰ বাবে পাছৱৰ্ড লাগে বা ই অসমৰ্থিত এনক্ৰিপশ্যন ব্যৱহাৰ কৰে। আমদানি কৰাৰ আগতে ইয়াৰ এটা সুৰক্ষাহীন প্ৰতিলিপি সংৰক্ষণ কৰক।',
'formats22_pdf_file_size':'PDF ফাইলটো খালী হ’ব নালাগিব আৰু ইয়াৰ আকাৰ 512 MiB-তকৈ ডাঙৰ হ’ব নালাগিব।',
'formats22_pdf_page_count':'PDF-ত 1ৰ পৰা %1$dখনলৈ পৃষ্ঠা থাকিব লাগিব।',
'formats22_pdf_page_index':'PDF পৃষ্ঠাৰ নিৰ্বাচন এতিয়া বৈধ নহয়। এই নথিৰ পৰা এখন পৃষ্ঠা বাছক।',
'formats22_pdf_dimensions':'PDF পৃষ্ঠাৰ মাত্ৰা অবৈধ বা আমদানি কৰিবলৈ অত্যধিক ডাঙৰ।',
'formats22_pdf_crop':'PDF-ৰ ক্ৰপ নিৰ্বাচিত পৃষ্ঠাৰ ভিতৰত থকা শূন্যতকৈ অধিক প্ৰস্থ আৰু উচ্চতাৰ এটা আয়তক্ষেত্ৰ হ’ব লাগিব।',
'formats22_pdf_memory':'PDF ৰেণ্ডাৰ কৰিবলৈ ছবিৰ বাবে উপলব্ধ মেমৰিৰ সীমাতকৈ অধিক মেমৰি লাগে।'
}
s={
'formats22_select_page':'පිටුවක් තෝරන්න',
'formats22_page_description':r'%1$s · %2$s\nපිටු ගණන: %3$d. රූපයක් ලෙස සංස්කරණය කිරීමට එක් පිටුවක් තෝරන්න.',
'formats22_page_number':'පිටු අංකය',
'formats22_previous_page':'පෙර පිටුව',
'formats22_next_page':'ඊළඟ පිටුව',
'formats22_open_page':'පිටුව විවෘත කරන්න',
'formats22_page_preview':'තෝරාගත් පිටුවේ පෙරදසුන',
'formats22_page_range':'1 සිට %1$d දක්වා පිටු අංකයක් ඇතුළත් කරන්න.',
'formats22_loading_page':'පිටු %2$d න් %1$d වන පිටුව · පෙරදසුන පූරණය වෙමින්…',
'formats22_page_dimensions':'පිටු %2$d න් %1$d වන පිටුව · පික්සල %3$d × %4$d',
'formats22_preview_unavailable':'පෙරදසුන ලබා ගත නොහැක: %1$s',
'formats22_preview_memory':'මෙම පෙරදසුන සඳහා ප්‍රමාණවත් මතකයක් නැත. පිටුව විවෘත කරන විට හැකි නම් කුඩා මාන තෝරා ගැනීමට ඉඩ ලැබේ.',
'formats22_pdf_invalid':'PDF කියවීමට නොහැකි විය. ගොනුව හානි වී හෝ මෙම Android අනුවාදය සහාය නොදක්වන විශේෂාංග භාවිත කරනවා විය හැක.',
'formats22_pdf_encrypted':'PDF සඳහා මුරපදයක් අවශ්‍ය වේ, නැතහොත් එය සහාය නොදක්වන සංකේතනයක් භාවිත කරයි. එය ආයාත කිරීමට පෙර ආරක්ෂාව ඉවත් කළ පිටපතක් සුරකින්න.',
'formats22_pdf_file_size':'PDF ගොනුව හිස් නොවිය යුතු අතර එහි ප්‍රමාණය 512 MiB ට වඩා වැඩි නොවිය යුතුය.',
'formats22_pdf_page_count':'PDF තුළ පිටු 1 සිට %1$d දක්වා තිබිය යුතුය.',
'formats22_pdf_page_index':'PDF පිටු තේරීම තවදුරටත් වලංගු නැත. මෙම ලේඛනයෙන් පිටුවක් තෝරන්න.',
'formats22_pdf_dimensions':'PDF පිටුවේ මාන වලංගු නැත, නැතහොත් ආයාත කිරීමට විශාල වැඩිය.',
'formats22_pdf_crop':'PDF කප්පාදුව තෝරාගත් පිටුව තුළ පිහිටි, පළල සහ උස ශුන්‍යයට වඩා වැඩි සෘජුකෝණාස්‍රයක් විය යුතුය.',
'formats22_pdf_memory':'PDF විදහා දැක්වීමට අවශ්‍ය මතකය රූප සඳහා පවතින මතක සීමාව ඉක්මවයි.'
}
(p/'candidate-indic.json').write_text(json.dumps({'as':a,'si':s},ensure_ascii=False,indent=2)+'\n')
common={
'select_page':'Imperative choose one page, generic for PDF/TIFF.',
'page_description':'Retains kind/name metadata, raw backslash-n, typed total count, and selection of one page for editing as an image rather than PDF editing.',
'page_number':'Numeric page-input accessibility label, not number of pages.',
'previous_page':'Generic previous-page navigation also used by legacy image-credit pagination.',
'next_page':'Generic next-page navigation also used by legacy image-credit pagination.',
'open_page':'Action opens selected page, not entire document or file.',
'page_preview':'Accessible description explicitly identifies selected page preview.',
'page_range':'Inclusive 1 through supplied total, matches UI validation rather than zero-based codec.',
'loading_page':'Reorders typed placeholders for idiomatic total/current construction; current is %1$d and total is %2$d. Preview loading remains ongoing.',
'page_dimensions':'Reorders typed total/current placeholders; width %3$d then height %4$d; multiplication sign and pixel unit retained.',
'preview_unavailable':'Failure remains preview-specific and includes supplied reason %1$s.',
'preview_memory':'Insufficient memory for preview; opening the page only offers smaller dimensions when possible, never promises a successful open.',
'pdf_invalid':'Unable to read plus two uncertain alternatives: damaged file or features unsupported by this Android version. Does not assert proven damage.',
'pdf_encrypted':'Password requirement OR unsupported encryption remains explicit. Save unprotected copy before import, no claim app can decrypt.',
'pdf_file_size':'Two independent requirements: nonempty AND not greater than 512 MiB; inclusive upper boundary and exact binary-unit symbol.',
'pdf_page_count':'Inclusive minimum 1 and typed maximum %1$d; codec limit is 4096, not hardcoded into resource.',
'pdf_page_index':'Selection no longer valid, action selects a page from this document; not a file corruption claim.',
'pdf_dimensions':'Invalid dimensions OR too large to import remains disjunctive.',
'pdf_crop':'Nonempty rectangle expressed explicitly as width and height greater than zero, wholly within selected page. Zero coordinates allowed.',
'pdf_memory':'Rendering exceeds available image-memory allocation limit; no storage/disk conflation or arbitrary fixed bound.'}
notes={'scope':'40 new candidate values only; no existing-string review credit. Author model assessment only; independent complete-value review required. No native-human, device layout, speech or whole-catalogue certification.', 'baseline':{'sha':'1290ee58e2d5a6f50a530e1d2331de57c3d382bb','tree':'e9eb525aa86e0ff5f49244cd6933a7e3ef32a42a'},'sources':[], 'consumer_review':{'files':['ImportSelection.kt','PdfCodec.kt','LegacyImageCreditsActivity.kt','PdfCodecTest.kt','JapanesePdfFailureTest.kt'],'findings':['Page UI 1..count maps to value-1 codec index.','Preview is bounded to 384 max dimension; memory error can still allow later import alternatives.','512*1024*1024 bytes inclusive; 1..4096 pages; PDF page width and height 1..500000 points.','Crop left/top nonnegative, right/bottom inside selected source page, width/height strictly positive.','Memory estimate includes output pixels, twice document bytes and 32 MiB reserve; not guaranteed physical allocation ceiling.','SecurityException maps to password-or-unsupported-encryption explanation; malformed and unsupported features remain uncertain alternatives.','Previous/next are shared with legacy credit text pages.'],'test_execution':'Read applicable existing tests only; no Android tests executed for this authoring-only task.'},'terminology_assessment':{'as':'Retains existing app পূৰ্বদৰ্শন (preview), মাত্ৰা (dimensions), ক্ৰপ, মেমৰি, আমদানি, and PDF raster term ৰেণ্ডাৰ. Mozilla gives both আগৰ and পূৰ্বৱৰ্তী; use shorter আগৰ for previous and explicit পৰৱৰ্তী for next. Mozilla damaged-file message mixes English file and asserts invalidity; do not reuse that complete sentence. পাছৱৰ্ড supported by Mozilla source. এনক্ৰিপশ্যন is technical transliteration; medium confidence requires reviewer attention.','si':'Retains recent app පෙරදසුන (preview), මාන (dimensions), මතක (memory), කප්පාදුව (crop), ආයාත (import), විදහා දැක්වීම (render). App has an older alternate preview spelling; do not edit it in this batch. Mozilla supports පිටුව, පිටු ගණන, මුරපදය and previous/next. Retain Latin PDF for consistency rather than copying Mozilla පීඩීඑෆ්. සංකේතනය is encryption in this password context, not generic file encoding.'},'values':{}}
for locale, values in [('as',a),('si',s)]:
 notes['values'][locale]={k:{'rationale':common[k.removeprefix('formats22_')], 'confidence':'medium' if any(t in k for t in ['encrypted','invalid','crop','memory']) else 'medium-high','review_status':'author candidate, awaiting independent review'} for k in values}
for locale,sha,path,terms in [('as','517c4862b524cb58fa3ab4be3391e1e00aa3023d','toolkit/toolkit/printing/printPreview.ftl',['পৃষ্ঠা','আগৰ পৃষ্ঠা']),('as','d9426fe4e73e66477b6d775400dd59986d403c13','toolkit/toolkit/pdfviewer/viewer.ftl',['পৰৱৰ্তী পৃষ্ঠা','পাছৱৰ্ড','ৰেণ্ডাৰ']),('si','42aa593682c32e206873d7742339f3a9104e68ad','toolkit/toolkit/printing/printPreview.ftl',['පෙර පිටුව','ඊළඟ පිටුව']),('si','d5a7b4272caa572fea32c2df0197becada928c0c','toolkit/toolkit/pdfviewer/viewer.ftl',['පිටු ගණන','මුරපදය','පූරණය'])]:
 notes['sources'].append({'locale':locale,'repository':'mozilla-l10n/firefox-l10n','path':locale+'/'+path,'retrieved_url':f'https://github.com/mozilla-l10n/firefox-l10n/blob/main/{locale}/{path}','blob_sha':sha,'pinned_blob_api':f'https://api.github.com/repos/mozilla-l10n/firefox-l10n/git/blobs/{sha}','selected_terms':terms,'limits':'Primary software localization terminology evidence, not a dictionary or native certification. Complete application messages independently composed. Mutable URL pinned by retrieved Git blob SHA.'})
(p/'candidate-indic-notes.json').write_text(json.dumps(notes,ensure_ascii=False,indent=2)+'\n')
src=json.loads((p/'inputs.json').read_text())
for locale, values in [('as',a),('si',s)]:
 assert set(values)==set(src['missing_keys'][locale])
 for k,v in values.items():
  x=src['source'][k]['text']
  assert sorted(re.findall(r'%\d+\$[sd]',v))==sorted(re.findall(r'%\d+\$[sd]',x)),k
  assert v.count('\\n')==x.count('\\n'),k
print('PASS: 40 keys; exact typed placeholder multisets and raw backslash-n preserved.')
