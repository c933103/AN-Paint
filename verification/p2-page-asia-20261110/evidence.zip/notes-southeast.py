import json,pathlib,hashlib,xml.etree.ElementTree as E
p=pathlib.Path('/workspace/shared/anpaint-p2-asia-evidence'); r=pathlib.Path('/workspace/shared/anpaint-p2-asia-20261110')
i=json.loads((p/'inputs.json').read_text()); c=json.loads((p/'candidate-southeast.json').read_text()); src=json.loads((p/'southeast-source-identities.json').read_text())
rationales=[
'Imperative choose/select one page. Applies to PDF and TIFF, so no PDF-only qualification.',
'Format then filename remain %1$s and %2$s, followed by literal Android backslash-n, total %3$d and instruction to select one page to edit as an image. Does not claim editable PDF text.',
'Accessible name of the one-based numeric page field, not page count.',
'Previous page in sequence, usable both for PDF/TIFF picker and paginated legacy credit text.',
'Next page in sequence, usable both for PDF/TIFF picker and paginated legacy credit text.',
'Open the chosen page; not whole-document import.',
'Accessible description of preview of the selected page, not a command to choose or preview all pages.',
'Explicit inclusive range from 1 through dynamic total %1$d. No zero-based internal index exposed.',
'Current page and total distinguished, with preview loading underway rather than page import completed.',
'Current page and total distinguished; width then height with multiplication symbol and pixel unit.',
'Preview is unavailable; typed %1$s retains diagnostic cause rather than replacing it with a generic error.',
'Insufficient memory for preview; opening offers smaller dimensions only if possible. No promised automatic resize or guaranteed success.',
'Unreadable PDF with uncertain alternatives: possible damaged file OR unsupported features in this Android version. Does not diagnose certain corruption.',
'Password requirement OR unsupported encryption remain distinct alternatives. Save an unprotected copy before import; no promise that entering a password here is supported.',
'File must not be empty AND must not exceed 512 MiB. Equality at 512 MiB remains permitted; unit is not MB.',
'Inclusive count from 1 through dynamic %1$d; no 0 pages and no hardcoded 4096 replacing the argument.',
'Selection is no longer valid, with instruction to select a page from this very document. Does not claim the file itself is malformed.',
'Invalid dimensions OR too large for import, preserving both failure possibilities.',
'Crop is a rectangle whose width and height exceed zero and which lies within the selected page. Explicit geometry avoids interpreting nonempty as requiring visible ink.',
'Rendering exceeds the available image-memory allowance, not free storage, file-size cap, or a monetary budget.'
]
terms={
'km':{'page':'ទំព័រ','preview':'ការមើលជាមុន','dimensions':'វិមាត្រ','crop':'ច្រឹប','memory':'អង្គចងចាំ','password':'ពាក្យសម្ងាត់','assessment':'MediaWiki corroborates page, previous/next, password and pixel vocabulary. Its preview verb is nominalized as ការមើលជាមុន for this image description. Existing crop and dimensions vocabulary retained after checking image geometry. No wiki import workflow copied.'},
'lo':{'page':'ໜ້າ','preview':'ຕົວຢ່າງ','dimensions':'ຂະໜາດ','crop':'ຕັດຂອບ','memory':'ໜ່ວຍຄວາມຈຳ','password':'ລະຫັດຜ່ານ','assessment':'MediaWiki corroborates previous/next page and password. Preview uses existing app noun rather than upstream verbal look-at-example. Pixel spelling follows retrieved source. Crop explicitly says right-angled quadrilateral, stronger than existing generic four-sided selection term.'},
'my':{'page':'စာမျက်နှာ','preview':'အစမ်းမြင်ကွင်း','dimensions':'အတိုင်းအတာများ','crop':'လှီးဖြတ်','memory':'မှတ်ဉာဏ်','password':'စကားဝှက်','assessment':'MediaWiki corroborates page and password. Existing app preview အစမ်းမြင်ကွင်း is more specifically a rendered preview than upstream နမူနာ (sample), so retained. Existing app pixel term retained rather than upstream English pixels. Page-of-total wording reorders positional arguments to total then selected page.'},
'jv':{'page':'kaca','preview':'pratinjau','dimensions':'ukuran','crop':'pangethokan','memory':'memori','password':'tembung sandi','assessment':'MediaWiki corroborates kaca, previous/next, tembung sandi and piksel. Existing app pratinjau retained instead of upstream pratuduh for cross-dialog consistency; this is a deliberate term choice, not approval of old strings. Existing app plain Latin spelling sadurunge/sabanjure follows its register rather than adding diacritics selectively. Rectangle uses existing app persegi panjang, not generic square.'}
}
notes={'scope':'80 newly authored absent values, 20 each in km/lo/my/jv. Authoring evidence only; independent complete-value review required. No prior-string review credit, native-human certification, device layout or speech certification.', 'base':{'live_sha':i['base_sha'],'verified_tree':i['base_tree'],'temporary_checkout_head':'befd3a6f80b60a52dd8df6711853bdaca050a4e8','head_note':'Temporary checkout commit identity differs, but HEAD tree was independently verified as identical to supplied live tree.'},'primary_sources':src,'source_limits':'Retrieved primary community-maintained software catalogues support terminology only, not correctness of complete new sentences. Default-branch responses preserved with exact Git blob SHA and original URL. Pinned Git blob API identities supplied. No upstream sentence copied as an approval authority.', 'consumer_checks':{'ImportSelection.kt':'Read entire consumer: kind/name/count args, PDF and TIFF pages, current page minus one on selection, typed formatting, conditional memory advice; controls and accessibility names.', 'PdfCodec.kt':'Read entire consumer: size 1..512*1024*1024 inclusive; count 1..4096; crop inside page with positive width/height; memory admission uses image pixels, twice document bytes, and native reserve. SecurityException maps to password/encryption alternatives.', 'LegacyImageCreditsActivity.kt':'Read entire consumer: same previous/next labels page through bounded credit text; keep them generic.', 'PdfCodecTest.kt':'Read relevant generated multipage, invalid-pages/crops, insufficient-budget, malformed/empty-file and uncertainty-preserving diagnostic checks. Tests inspected, not run.', 'OrdinaryPriorityFollowthroughTest.kt':'Inspected real picker assertions: complete localized description, controls/accessibility, out-of-range disables Open, count itself permitted.', 'LocaleNumberInputTest.kt':'Inspected actual page-field test rejecting fractional, negative, zero and out-of-range values.'},'terminology_assessment':terms,'values':{}}
for l,vals in c.items():
 existing=E.parse(r/i['paths'][l]).getroot(); existingkeys={x.get('name') for x in existing}
 assert not(set(vals)&existingkeys)
 notes['values'][l]={}
 for n,(k,v) in enumerate(vals.items()):
  notes['values'][l][k]={'rationale':rationales[n], 'confidence':'medium-high' if n<11 else 'medium','confidence_limit':'Machine-authored complete sentence; independent reviewer must assess idiom and technical meaning. No human native review.', 'primary_source':src[l]['git_blob_sha'],'terminology':terms[l]['assessment'] if n==0 else 'See locale terminology assessment; source supports terms, not this whole sentence.'}
  if l=='my' and n in (8,9): notes['values'][l][k]['rationale']+=' Uses %2$d အနက် %1$d, literally selected page out of total, with total first in natural Burmese order.'
 notes['values'][l]['formats22_pdf_crop']['rationale']+=' Explicit positive width and height paraphrases nonempty rather than adding a stricter content requirement.'
notes['checks']={'candidate_count':sum(map(len,c.values())),'only_absent':True,'typed_placeholder_multisets':'passed for all 80','raw_backslash_n_counts':'match source for all 80','repo_xml_edits':'none','runtime_tests':'not run; candidate JSON only','candidate_sha256':hashlib.sha256((p/'candidate-southeast.json').read_bytes()).hexdigest()}
(p/'candidate-southeast-notes.json').write_text(json.dumps(notes,ensure_ascii=False,indent=2)+'\n')
print(notes['checks'])
