import json,pathlib,re,hashlib,collections
p=pathlib.Path('/workspace/shared/anpaint-p2-asia-evidence')
i=json.loads((p/'inputs.json').read_text()); c={**json.loads((p/'candidate-indic.json').read_text()),**json.loads((p/'candidate-southeast.json').read_text())}
reasons={
'select_page':'A singular page-selection imperative, without incorrectly narrowing the PDF/TIFF chooser to PDF.',
'page_description':'Both metadata strings and total count retained; complete instruction selects one page for image editing, not editable PDF text. Literal Android newline retained.',
'page_number':'Labels the selected page number rather than the count of pages.',
'previous_page':'Correct backward page navigation; generic enough for legacy credit-text pages too.',
'next_page':'Correct forward page navigation; generic enough for legacy credit-text pages too.',
'open_page':'Opens a page, without promising to open/import the whole document.',
'page_preview':'Names the preview of the selected page, suitable as the ImageView accessible description.',
'page_range':'One-based inclusive range through the supplied total; typed maximum retained.',
'loading_page':'Current and total remain distinct and the preview operation remains ongoing, not successful import.',
'page_dimensions':'Current and total are distinct; width then height and pixel unit retained. Describes page dimensions, not a 384-pixel preview size.',
'preview_unavailable':'Failure concerns the preview and preserves the dynamic reason, not a categorical whole-document failure.',
'preview_memory':'Insufficient preview memory followed by smaller-dimension options only when possible; no unconditional recovery promise.',
'pdf_invalid':'Read failure plus possible file damage OR unsupported features in this Android version. Neither cause is asserted as established.',
'pdf_encrypted':'Password requirement OR unsupported encryption; instructs saving an unprotected copy before import, without implying the app can remove protection.',
'pdf_file_size':'Nonempty file AND size no greater than 512 MiB; equality is allowed and binary unit unchanged.',
'pdf_page_count':'At least one page and no more than the dynamic maximum; no zero-based count or hard-coded 4096.',
'pdf_page_index':'Selection is no longer valid; choose a page from this document. Does not say the document itself is invalid.',
'pdf_dimensions':'Page dimensions invalid OR too large for import; preserves the alternative causes.',
'pdf_crop':'Rectangle lies within the selected page and both width and height are strictly positive, equivalent to nonempty crop.',
'pdf_memory':'Rendering exceeds the memory allowance for images; does not conflate disk storage, whole-device RAM or a guaranteed native allocation ceiling.'}
locale_notes={
'as':'Assamese page/preview/dimension/crop terms match the inspected app context. Total-first page phrasing keeps the positional arguments meaningful. Technical encryption is transliterated; non-native assessment is medium confidence.',
'si':'Sinhala page, page-count and password terms are corroborated in the supplied viewer text. Newer app පෙරදසුන/මාන/කප්පාදුව terms retained. The final modal in the invalid-file sentence scopes over both possible causes.',
'km':'Khmer page, preview, password and pixel vocabulary agrees with inspected MediaWiki and app resources. Crop says rectangle, not generic quadrilateral; conditional preview option and both error alternatives are explicit.',
'lo':'Lao preview noun and dimensions/crop terms follow app context; MediaWiki corroborates page/password and candidate pixel spelling. The pixel spelling differs from older app strings but is a supported variant, not a semantic defect.',
'my':'Burmese preview noun follows app context rather than upstream sample. Total-first page wording preserves current/total roles. Loading wording describes opening the preview in progress, not completing document import.',
'jv':'Javanese plain Latin register and pratinjau follow app context; MediaWiki supports kaca, page navigation and tembung sandi. Two precision revisions distinguish editing as an image and explicitly name rectangle width.'}
revisions={('jv','formats22_page_description'):('%1$s · %2$s\\nCacah kaca: %3$d. Pilih siji kaca kanggo disunting minangka gambar.','Replace dadi (become) with minangka (as) to state the editing representation rather than suggest editing itself converts the page.'),('jv','formats22_pdf_crop'):('Area pangethokan PDF kudu awujud persegi panjang sing ambane lan dhuwure luwih saka nol lan ana ing njero kaca sing dipilih.','Use ambane (its width), parallel to dhuwure (its height), instead of bare amba (wide), making both positive dimensions explicit.')}
accepted={}; decisions={}
for l,vals in c.items():
 assert set(vals)==set(i['missing_keys'][l]);accepted[l]={};decisions[l]={}
 for k,v in vals.items():
  final,extra=revisions.get((l,k),(v,''));status='revised' if final!=v else 'accepted'
  assert sorted(re.findall(r'%\d+\$[sd]',final))==sorted(re.findall(r'%\d+\$[sd]',i['source'][k]['text']))
  assert final.count('\\n')==i['source'][k]['text'].count('\\n')
  accepted[l][k]=final
  decisions[l][k]={'original':v,'final':final,'status':status,'reason':reasons[k.removeprefix('formats22_')]+(' '+extra if extra else ''),'confidence':'medium (independent AI full-value review; non-native, not human-certified)'}
sourcechecks=[]
for l in ['km','lo','my','jv']:
 d=json.loads((p/f'source-mediawiki-{l}.json').read_text());b=d['content'].encode();actual=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert actual==d['sha']
 terms=json.loads(d['content']);sourcechecks.append({'locale':l,'blob':actual,'identity_verified':True,'terms_inspected':{k:terms.get(k) for k in ['mypage','prevpage','nextpage','preview','userlogin-yourpassword','file-info-size']},'limit':'Source terminology, not complete-sentence approval.'})
for l,sha in [('as','d9426fe4e73e66477b6d775400dd59986d403c13'),('si','d5a7b4272caa572fea32c2df0197becada928c0c')]:
 b=(p/f'primary-{l}-viewer.ftl').read_bytes();actual=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();sourcechecks.append({'locale':l,'claimed_blob':sha,'local_blob':actual,'identity_verified':actual==sha,'limit':'Inspected supplied viewer terminology, but saved local file does not hash to author recorded upstream Git blob. Await provenance reconciliation; no claim of independently verified immutable identity. Printing sources were not materialized/read by this reviewer.'})
r={'scope':'All 120 newly authored page/PDF values; independent reviewer separate from authors. No source XML edited. Existing strings used for terminology context only, without acceptance credit.','base_sha':i['base_sha'],'accepted':accepted,'decisions':decisions,'summary':{'candidates':120,'accepted_unchanged':118,'revised':2,'held':0,'accepted_final_values':120,'qualification':'AI semantic/terminology assessment only. Publication remains subject to parent integration and validation; upstream Indic source identity discrepancy is separately flagged.'},'locale_assessments':locale_notes,'source_verification':sourcechecks,'consumers_read':['ImportSelection.kt (entire)','PdfCodec.kt (entire)','LegacyImageCreditsActivity.kt (entire)'],'tests_inspected':['PdfCodecTest.kt: selected-page rasterization, crop/scaling, budget and malformed/empty rejection, invalid selection, uncertainty','JapanesePdfFailureTest.kt: complete error routing and uncertainty, encrypted versus empty-file messages','OrdinaryPriorityFollowthroughTest.kt: actual chooser description, labels, bounds and inclusive count','LocaleNumberInputTest.kt: actual chooser rejecting fractional, negative, zero and out-of-range input','ImportSelectionFlowTest.kt: page-index retention through assembly/crop','ImportSelectionTitleTest.kt: inspected but principally animation, not acceptance evidence for new page strings'],'verification':{'typed_placeholders':'All 120 checked against exact typed positional source placeholders, including reordered total/current.','raw_newline':'All six descriptions retain exactly one literal backslash-n; no physical newline substituted.','runtime':'No Android build/device/JVM test was executed by this reviewer. Inspection of test source is not a passing test run.'},'limits':['Independent AI review, not native-human linguistic validation.','No installed app layout, clipping, line breaking or accessibility speech validation.','No font/glyph/shaping coverage validation; script correctness at text review does not prove rendering.','No whole-catalogue, historical recheck, or release-completion claim.','Community software terminology references corroborate selected words only, not all composed sentences.','Indic local source hash discrepancy remains an evidence provenance limitation until reconciled.']}
(p/'review.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
print(r['summary'])
