import json,re,pathlib
p=pathlib.Path('/workspace/shared/anpaint-p2-asia-evidence')
i=json.loads((p/'inputs.json').read_text())
values={
'km':[
'ជ្រើសទំព័រមួយ',
r'%1$s · %2$s\nចំនួនទំព័រ៖ %3$d។ ជ្រើសទំព័រមួយដើម្បីកែសម្រួលជារូបភាព។',
'លេខទំព័រ','ទំព័រមុន','ទំព័របន្ទាប់','បើកទំព័រ','ការមើលជាមុននៃទំព័រដែលបានជ្រើស',
'បញ្ចូលលេខទំព័រពី 1 ដល់ %1$d។',
'ទំព័រ %1$d នៃ %2$d · កំពុងផ្ទុកការមើលជាមុន…',
'ទំព័រ %1$d នៃ %2$d · %3$d × %4$d ភីកសែល',
'មិនអាចមើលជាមុនបាន៖ %1$s',
'អង្គចងចាំមិនគ្រប់គ្រាន់សម្រាប់ការមើលជាមុននេះទេ។ ពេលបើកទំព័រ នឹងមានជម្រើសវិមាត្រតូចជាងនេះ ប្រសិនបើអាចធ្វើបាន។',
'មិនអាចអាន PDF បានទេ។ ឯកសារអាចខូច ឬប្រើមុខងារដែលកំណែ Android នេះមិនគាំទ្រ។',
'PDF ត្រូវការពាក្យសម្ងាត់ ឬប្រើការអ៊ិនគ្រីបដែលមិនគាំទ្រ។ រក្សាទុកច្បាប់ចម្លងដែលគ្មានការការពារ មុនពេលនាំចូល។',
'PDF ត្រូវតែជាឯកសារមិនទទេ និងមានទំហំមិនលើសពី 512 MiB។',
'PDF ត្រូវតែមានពី 1 ដល់ %1$d ទំព័រ។',
'ការជ្រើសទំព័រ PDF លែងមានសុពលភាពហើយ។ ជ្រើសទំព័រមួយពីឯកសារនេះ។',
'វិមាត្រទំព័រ PDF មិនត្រឹមត្រូវ ឬធំពេកសម្រាប់ការនាំចូល។',
'តំបន់ច្រឹប PDF ត្រូវតែជាចតុកោណកែងដែលមានទទឹងនិងកម្ពស់ធំជាងសូន្យ ហើយស្ថិតនៅក្នុងទំព័រដែលបានជ្រើស។',
'ការបង្ហាញ PDF ជារូបភាព ត្រូវការអង្គចងចាំលើសពីកម្រិតដែលមានសម្រាប់រូបភាព។'
],
'lo':[
'ເລືອກໜ້າໜຶ່ງ',
r'%1$s · %2$s\nຈຳນວນໜ້າ: %3$d. ເລືອກໜ້າໜຶ່ງເພື່ອແກ້ໄຂເປັນຮູບ.',
'ເລກໜ້າ','ໜ້າກ່ອນ','ໜ້າຕໍ່ໄປ','ເປີດໜ້າ','ຕົວຢ່າງຂອງໜ້າທີ່ເລືອກ',
'ປ້ອນເລກໜ້າຈາກ 1 ຫາ %1$d.',
'ໜ້າ %1$d ຈາກ %2$d · ກຳລັງໂຫຼດຕົວຢ່າງ…',
'ໜ້າ %1$d ຈາກ %2$d · %3$d × %4$d ປິກເຊລ',
'ບໍ່ສາມາດສະແດງຕົວຢ່າງ: %1$s',
'ໜ່ວຍຄວາມຈຳບໍ່ພຽງພໍສຳລັບຕົວຢ່າງນີ້. ເມື່ອເປີດໜ້າ ຈະມີຂະໜາດທີ່ນ້ອຍກວ່າໃຫ້ເລືອກ ຖ້າເປັນໄປໄດ້.',
'ບໍ່ສາມາດອ່ານ PDF. ໄຟລ໌ອາດເສຍຫາຍ ຫຼືໃຊ້ຄຸນສົມບັດທີ່ Android ລຸ້ນນີ້ບໍ່ຮອງຮັບ.',
'PDF ຕ້ອງການລະຫັດຜ່ານ ຫຼືໃຊ້ການເຂົ້າລະຫັດທີ່ບໍ່ຮອງຮັບ. ບັນທຶກສຳເນົາທີ່ບໍ່ມີການປ້ອງກັນກ່ອນນຳເຂົ້າ.',
'PDF ຕ້ອງເປັນໄຟລ໌ທີ່ບໍ່ວ່າງເປົ່າ ແລະມີຂະໜາດບໍ່ເກີນ 512 MiB.',
'PDF ຕ້ອງມີຈາກ 1 ຫາ %1$d ໜ້າ.',
'ການເລືອກໜ້າ PDF ບໍ່ຖືກຕ້ອງອີກຕໍ່ໄປ. ເລືອກໜ້າໜຶ່ງຈາກເອກະສານນີ້.',
'ຂະໜາດໜ້າ PDF ບໍ່ຖືກຕ້ອງ ຫຼືໃຫຍ່ເກີນໄປທີ່ຈະນຳເຂົ້າ.',
'ພື້ນທີ່ຕັດຂອບ PDF ຕ້ອງເປັນຮູບສີ່ລ່ຽມສາກທີ່ມີຄວາມກວ້າງແລະຄວາມສູງຫຼາຍກວ່າສູນ ແລະຢູ່ພາຍໃນໜ້າທີ່ເລືອກ.',
'ການສ້າງຮູບຈາກ PDF ໃຊ້ໜ່ວຍຄວາມຈຳເກີນຂີດຈຳກັດທີ່ມີໃຫ້ສຳລັບຮູບ.'
],
'my':[
'စာမျက်နှာတစ်ခု ရွေးပါ',
r'%1$s · %2$s\nစာမျက်နှာအရေအတွက်: %3$d။ ရုပ်ပုံအဖြစ် တည်းဖြတ်ရန် စာမျက်နှာတစ်ခုကို ရွေးပါ။',
'စာမျက်နှာနံပါတ်','ယခင်စာမျက်နှာ','နောက်စာမျက်နှာ','စာမျက်နှာဖွင့်ပါ','ရွေးထားသောစာမျက်နှာ၏ အစမ်းမြင်ကွင်း',
'1 မှ %1$d အထိ စာမျက်နှာနံပါတ်တစ်ခုကို ရိုက်ထည့်ပါ။',
'စာမျက်နှာ %2$d အနက် %1$d · အစမ်းမြင်ကွင်းကို ဖွင့်နေသည်…',
'စာမျက်နှာ %2$d အနက် %1$d · %3$d × %4$d ပစ်ဆယ်',
'အစမ်းမြင်ကွင်း မပြနိုင်ပါ: %1$s',
'ဤအစမ်းမြင်ကွင်းအတွက် မှတ်ဉာဏ်မလုံလောက်ပါ။ စာမျက်နှာကို ဖွင့်သည့်အခါ ဖြစ်နိုင်လျှင် ပိုသေးသော အတိုင်းအတာများကို ရွေးနိုင်ပါမည်။',
'PDF ကို ဖတ်၍မရပါ။ ဖိုင်ပျက်စီးနေနိုင်သည် သို့မဟုတ် ဤ Android ဗားရှင်းက မပံ့ပိုးသော လုပ်ဆောင်ချက်များကို သုံးထားနိုင်သည်။',
'PDF သည် စကားဝှက်လိုအပ်သည် သို့မဟုတ် မပံ့ပိုးသော ကုဒ်ဝှက်စနစ်ကို သုံးထားသည်။ မတင်သွင်းမီ အကာအကွယ်မပါသော မိတ္တူတစ်ခုကို သိမ်းဆည်းပါ။',
'PDF သည် ဖိုင်အလွတ်မဖြစ်ရဘဲ အရွယ်အစား 512 MiB ထက် မကြီးရပါ။',
'PDF တွင် စာမျက်နှာ 1 မှ %1$d အထိ ပါဝင်ရမည်။',
'PDF စာမျက်နှာရွေးချယ်မှုသည် ယခုအခါ မမှန်ကန်တော့ပါ။ ဤစာတမ်းမှ စာမျက်နှာတစ်ခုကို ရွေးပါ။',
'PDF စာမျက်နှာအတိုင်းအတာများ မမှန်ကန်ပါ သို့မဟုတ် တင်သွင်းရန် ကြီးလွန်းသည်။',
'PDF လှီးဖြတ်မည့်ဧရိယာသည် အကျယ်နှင့်အမြင့် သုညထက်ကြီးသော ထောင့်မှန်စတုဂံဖြစ်ရမည်ဖြစ်ပြီး ရွေးထားသောစာမျက်နှာအတွင်း ရှိရမည်။',
'PDF ကို ရုပ်ပုံအဖြစ် ဖော်ဆောင်ခြင်းသည် ရုပ်ပုံအတွက် အသုံးပြုနိုင်သော မှတ်ဉာဏ်ကန့်သတ်ချက်ကို ကျော်လွန်နေသည်။'
],
'jv':[
'Pilih kaca',
r'%1$s · %2$s\nCacah kaca: %3$d. Pilih siji kaca kanggo disunting dadi gambar.',
'Nomer kaca','Kaca sadurunge','Kaca sabanjure','Bukak kaca','Pratinjau kaca sing dipilih',
'Lebokna nomer kaca saka 1 nganti %1$d.',
'Kaca %1$d saka %2$d · Lagi ngemot pratinjau…',
'Kaca %1$d saka %2$d · %3$d × %4$d piksel',
'Pratinjau ora kasedhiya: %1$s',
'Memori ora cukup kanggo pratinjau iki. Nalika kaca dibukak, bakal ana pilihan ukuran sing luwih cilik yen bisa.',
'PDF ora bisa diwaca. Berkas bisa uga rusak utawa nganggo fitur sing ora didhukung versi Android iki.',
'PDF mbutuhake tembung sandi utawa nganggo enkripsi sing ora didhukung. Simpen salinan tanpa pangayoman sadurunge diimpor.',
'PDF kudu awujud berkas sing ora kosong lan ukurane ora luwih saka 512 MiB.',
'PDF kudu ngemot 1 nganti %1$d kaca.',
'Pilihan kaca PDF wis ora sah maneh. Pilih kaca saka dokumen iki.',
'Ukuran kaca PDF ora sah utawa kegedhen kanggo diimpor.',
'Area pangethokan PDF kudu awujud persegi panjang sing amba lan dhuwure luwih saka nol lan ana ing njero kaca sing dipilih.',
'Pangrenderan PDF ngluwihi wates memori sing kasedhiya kanggo gambar.'
]}
out={l:dict(zip(i['source'],v,strict=True)) for l,v in values.items()}
for l,d in out.items():
 for k,v in d.items():
  assert sorted(re.findall(r'%\d+\$[sd]',v))==sorted(re.findall(r'%\d+\$[sd]',i['source'][k]['text'])),(l,k)
  assert v.count('\\n')==i['source'][k]['text'].count('\\n'),(l,k)
(p/'candidate-southeast.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('Wrote 80 values; placeholder multisets and raw newline counts match.')
