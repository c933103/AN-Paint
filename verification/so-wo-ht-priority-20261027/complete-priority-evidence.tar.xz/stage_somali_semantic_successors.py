from pathlib import Path
import json,hashlib
B=Path(__file__).resolve().parent;p=B/'candidate-public/so-complete-author-packet.json';raw=p.read_bytes();rows={r['identity']:r for r in json.loads(raw)['rows']}
values={
'formats22_animation_message':'%1$s-kan waxa uu ka kooban yahay %2$s sawir oo isku xiga. AN Paint waxa uu tafatiraa sawirrada taagan, mana ilaaliyo dhaqdhaqaaqa.',
'formats22_animation_poster':'PNG-kan waxa uu leeyahay sawir caadi ah oo gooni ah. Sawirkaas ayaa la soo gelinayaa halkii laga soo gelin lahaa sawirrada isku xiga ee dhaqdhaqaaqa sameeya. Kaydintu waxay abuurtaa sawir taagan.',
'formats22_animation_still':'Kaliya sawirka koowaad ee taxanaha ayaa la soo gelinayaa. Kaydintu waxay abuurtaa sawir taagan.',
'formats22_animation_unknown':'%1$s-kan aad ayuu u murugsan yahay si loo xaqiijiyo inuu leeyahay sawirro badan oo isku xiga. AN Paint waxa uu furayaa kaliya sawir taagan, mana ilaalinayo wax dhaqdhaqaaq ah.',
'ui_there_is_not_enough_memory_for_this_operation':'Xusuus ku filan hawshan marka lagu sameeyo ballaca iyo joogga asalka ah ee sawirka, oo lagu cabbiray dhibco sawireed, ma jirto. Wax cabbir-beddel toos ah lama samayn.'}
out=[]
for k,v in values.items():
 r=rows['string/'+k]
 out.append({'locale':'so','identity':r['identity'],'previous_candidate':r['proposal'],'proposed_successor':v,'english':r['english'],'reason':'Use each image in a consecutive sequence for animation frames, not sequence-as-one-frame; express original resolution as original image width/height in pixels, preserving explicit no automatic resize.','submitted_packet_sha256':hashlib.sha256(raw).hexdigest(),'status':'author_proposed_independent_review_pending'})
(B/'author-successor-proposals-so-frames-resolution.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('5 whole-value successors staged; frozen packet untouched',hashlib.sha256(p.read_bytes()).hexdigest())
