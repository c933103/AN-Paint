from pathlib import Path
import json,hashlib,os,re,collections,copy,sys,xml.etree.ElementTree as E
P=Path(__file__).resolve().parents[1];C=P/'candidate-public';R=P/'independent-review';S=P.parent/'ha-ig-ln-p0-p1-20261027/source'
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
hashes={'so':'9796f7ee7dea5df854263ccde34235a264ba6f39b2d2cffa425200964b9c20e0','wo':'ef241862a425399649fffab6ce4eefdaf42d73ac9ab4d0d0ee170d773e33e004','ht':'5aa04c61e1fcf56dbecee28822d1f941c7f715286a1eb0978f2b68d321040857'}
tree=load(S.parent/'source-remote-tree.json');assert tree['sha']=='8ffc6e1b1692f882843a76bbf42bf5a3adb3267c';entries={r['path']:r for r in tree['tree'] if r['type']=='blob'}
for path,row in entries.items():
 raw=(S/path).read_bytes();assert blob(raw)==row['sha'],path
 assert ('100755' if os.stat(S/path).st_mode&0o111 else '100644')==row['mode'],path
bindings=load(C/'source-bindings.json')
for row in bindings['bindings']:
 raw=(S/row['path']).read_bytes();assert blob(raw)==row['git_blob_sha1'] and hashlib.sha256(raw).hexdigest()==row['sha256']
def obj(e):
 d={'value':e.text if e.tag=='string' else {x.get('quantity'):x.text for x in e},'attributes':dict(e.attrib)}
 if e.tag!='string':d['children_attributes']={x.get('quantity'):dict(x.attrib) for x in e}
 return d
EN={e.tag+'/'+e.get('name'):obj(e) for e in E.parse(S/'Paintroid/src/main/res/values/strings.xml').getroot()}
files=['author-successor-proposals-credits-compression.json','author-successor-proposals-so-frames-resolution.json','author-successor-proposals-so-output-resolution.json','author-successor-proposals-so-threshold-hypothetical.json','author-successor-proposals-so-companions.json']
successors={}
for fn in files:
 for row in load(P/fn):successors.setdefault((row['locale'],row['identity']),[]).append(row)
holdfile=P/'author-additional-absent-holds.json';additional={(r['locale'],r['identity']):r for r in load(holdfile)}
sys.path.insert(0,str(S/'tools'));import translation_catalogues as tc
from test_slovak_slovenian_catalan_priority_wording import token_contract

def encode(v):
 if isinstance(v,dict):return {k:encode(s) for k,s in v.items()}
 return '"'+v.replace('"','\\"')+'"'
def display(v):
 if isinstance(v,dict):return {k:display(s) for k,s in v.items()}
 assert v.startswith('"') and v.endswith('"')
 return re.sub(r'\\(.)',lambda m:{'n':'\n','t':'\t','r':'\r'}.get(m[1],m[1]),v[1:-1])
summary={'source_commit':bindings['source_commit'],'source_tree':tree['sha'],'source_blobs_and_modes_verified':len(entries),'source_bound_files':len(bindings['bindings']),'locales':{},'source_or_author_candidates_mutated':False};maps={};windows=set();used=set()
for tag in hashes:
 path=C/f'{tag}-complete-author-packet.json';assert sha(path)==hashes[tag];D=load(path);depfile=C/f'{tag}-adjacent-dependencies.json';dep=load(depfile)['rows'];rows=D['rows'];assert len(rows)==341 and len(dep)==15
 assert collections.Counter(r['tier'] for r in rows)=={'P0':92,'P1':249};assert len({r['identity'] for r in rows+dep})==356
 assert len(E.parse(S/D['catalogue_path']).getroot())==0
 expectedkeys={k for t in load(S/'translations/string-importance.json')['tiers'] if t['id'] in ('P0','P1') for k in t['keys']};assert {r['identity'] for r in rows}==expectedkeys
 reviewed=[];adj=[];edits={};holds=[];limited=[];values={};displays={}
 for r in rows+dep:
  ident=r['identity'];kind,key=ident.split('/');en={k:v for k,v in r['english'].items() if k!='value_json_sha256'}
  if kind=='plurals':assert en=={k:v for k,v in EN[ident].items() if k!='children_attributes'};en=copy.deepcopy(EN[ident])
  assert en==EN[ident] and r['current'] is None,(tag,ident)
  for c in r['direct_consumers']:
   lines=(S/c['path']).read_text().splitlines();a=c['start_line'];b=c['end_line'];assert '\n'.join(lines[a-1:b])==c['context'],(tag,ident,c['path'])
   assert re.search(r'R\.'+kind+r'\.'+re.escape(key)+r'\b',lines[c['line']-1]),(ident,c['path'],'non-exact consumer')
   windows.add((c['path'],c['line']))
  proposal=r.get('proposal');original=proposal;reasons=[]
  for successor in successors.get((tag,ident),[]):
   assert successor['previous_candidate']==original,(tag,ident,'original proposal')
   if 'supersedes_author_proposal' in successor:assert successor['supersedes_author_proposal']==proposal
   else:assert proposal==original
   if 'english' in successor:assert {k:v for k,v in successor['english'].items() if k!='value_json_sha256'}=={k:v for k,v in en.items() if k!='children_attributes'}
   proposal=successor['proposed_successor'];reasons.append(successor['reason']);used.add((tag,ident))
  hold=additional.get((tag,ident))
  if hold:
   assert hold['previous_candidate']==original and hold['proposed_disposition']=='hold_absent';proposal=None;reasons.append(hold['reason'])
  if proposal is None:
   decision='hold_absent';value=None;holds.append(ident)
   reason=' '.join(reasons) or r.get('hold_reason','Original exact context/layout hold, no insertion or acceptance credit.')
  else:
   value=encode(proposal);attrs=en['attributes']
   for source,target in ([(en['value'],value)] if kind=='string' else [(en['value'].get(q,en['value']['other']),v) for q,v in value.items()]):
    assert token_contract(source)==token_contract(target),(tag,ident,'format tokens')
    assert re.findall(r'\\+n',source)==re.findall(r'\\+n',target),(tag,ident,'newlines')
    assert not tc.android_string_errors(target),(tag,ident,tc.android_string_errors(target))
    assert not tc.format_string_errors(target,attrs.get('formatted')!='false'),(tag,ident,'Android format')
   lim=not r['direct_consumers'] or ident in {'string/language20_current','string/language20_settings','string/ui_menu_help'}
   decision='accept_new_wording_or_route_limited' if lim else 'accept_new'
   if lim:limited.append(ident)
   reason=' '.join(reasons) or 'Full English and target independently read for meaning, action/failure polarity, qualifiers, parameters and actual caller context. Not a presence/token-only acceptance.'
   values[key]=value;displays[key]=display(value)
   edits[key]={'identity':ident,'type':kind,'tier':r['tier'],'source':en,'previous_target':None,'reviewed_value':value,'reviewed_attributes':attrs,'decision':decision,'rationale':reason,'display':displays[key]}
   if kind=='plurals':edits[key]['reviewed_children_attributes']={q:{'quantity':q} for q in value}
  out=dict(r,source=en,previous_target=None,reviewed_value=value,reviewed_attributes=en['attributes'],decision=decision,rationale=reason,new_pair_credit=proposal is not None,confidence='Bounded independent model wording/static actual-consumer review; no native-human or installed layout/TalkBack certification.')
  if kind=='plurals' and value is not None:out['reviewed_children_attributes']={q:{'quantity':q} for q in value}
  (reviewed if r['tier'] in ('P0','P1') else adj).append(out)
 assert len(reviewed)==341 and len(adj)==15
 ledger={'source_commit':D['source_commit'],'source_tree':D['source_tree'],'locale':tag,'catalogue_path':D['catalogue_path'],'scope':'All92 P0+249 P1 and15 unique atomic companions completely reviewed. Original empty catalogue confers no prior acceptance.','rows':reviewed,'dependencies':adj,'accepted_resource_text_values':values,'accepted_display_values':displays,'integration_values':edits,'held_priority_identities':holds,'wording_only_or_route_limited_identities':limited,'original_packet_sha256':sha(path),'original_dependencies_sha256':sha(depfile),'successor_packet_hashes':{fn:sha(P/fn) for fn in files},'additional_holds_sha256':sha(holdfile),'source_binding_sha256':sha(C/'source-bindings.json'),'plural_reference':'https://raw.githubusercontent.com/unicode-org/cldr/release-48/common/supplemental/plurals.xml','plural_decision':'SO cardinal one at1 with counted sawir in both quantities; WO other-only; HT no specific CLDR rule, root other-only with invariant imaj. No French-rule inference. Android quantity behavior awaits runtime tests.','limits':'Not native-human or installed/runtime/layout certification. Exact Help/callback/archive restrictions unchanged; all holds remain explicit English fallbacks.'}
 f=R/f'{tag}-complete-review.json';f.write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n');maps[tag]=edits
 summary['locales'][tag]={'P0':92,'P1':249,'accepted_priority':341-len(holds),'held_priority':len(holds),'accepted_companions':15,'typed_additions':len(edits),'context_limited':len(limited),'ledger_sha256':sha(f),'counts':dict(collections.Counter(r['decision'] for r in reviewed))}
assert used==set(successors)
assert {tag:len(m) for tag,m in maps.items()}=={'so':344,'wo':343,'ht':345}
summary.update(all_priority_rows=1023,unique_companions=45,typed_additions=sum(map(len,maps.values())),unique_actual_caller_windows=len(windows),accepted_successor_identities=len(used),successor_steps=sum(map(len,successors.values())))
(R/'so-wo-ht-accepted-edit-maps.json').write_text(json.dumps(maps,ensure_ascii=False,indent=2)+'\n');(R/'complete-review-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
