from pathlib import Path
import json,hashlib,os,sys,copy,unittest,xml.etree.ElementTree as E
P=Path(__file__).resolve().parents[1];R=P/'independent-review';S=P/'source';B=P.parent/'yo-zu-xh-p0-p1-20261027/source'
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
tree=json.loads((P/'integration-base-tree.json').read_text());base={e['path']:e for e in tree['tree']if e['type']=='blob'}
assert tree['sha']=='28ada9cbc9cf3c7509dbed764ebb7e245e064b8f'
for p,e in base.items():assert blob((B/p).read_bytes())==e['sha'] and ('100755'if os.access(B/p,os.X_OK)else'100644')==e['mode'],p
manifest=json.loads((P/'source-delta.json').read_text());changes={r['path']:r for r in manifest['changed_paths']};paths=set(base)|set(changes)
for p in paths:
 e=changes.get(p,base.get(p));assert blob((S/p).read_bytes())==e['sha'],p
 assert ('100755'if os.access(S/p,os.X_OK)else'100644')==e['mode'],p
assert {p for p in base if (B/p).read_bytes()!=(S/p).read_bytes()}|{p for p in paths if p not in base}==set(changes)
sys.path.insert(0,str(S/'tools'))
import test_somali_wolof_haitian_creole_priority_wording as t
import somali_wolof_haitian_creole_priority_expectations as expectations
from current_localization_contracts import fixture
from language_option_additions import SECOND_ADDITIONS_PATH
f=fixture(t.NAME);maps=json.loads((R/'so-wo-ht-accepted-edit-maps.json').read_text());count=0;rejected=0;contexts=set()
roots={};english=E.parse(S/'Paintroid/src/main/res/values/strings.xml').getroot()
def resource(n):return {'type':n.tag,'target':n.text if n.tag=='string'else {c.get('quantity'):c.text for c in n},'attributes':dict(n.attrib)}
def reject(fn):
 global rejected
 try:fn()
 except (ValueError,KeyError):rejected+=1;return
 raise AssertionError('independent mutation accepted')
for tag in ('so','wo','ht'):
 d=json.loads((R/f'{tag}-complete-review.json').read_text());loc=f['locales'][tag];path=d['catalogue_path'];old={n.get('name'):resource(n)for n in E.parse(B/path).getroot()};assert not old
 root=E.parse(S/path).getroot();roots[tag]=root;new={n.get('name'):resource(n)for n in root};allrows=d['rows']+d['dependencies'];keys={r['identity'].split('/',1)[1]for r in allrows}
 accepted={r['identity'].split('/',1)[1]:r['reviewed_value']for r in allrows if r['decision'].startswith('accept_')}
 assert loc['accepted']==accepted and set(loc['changed'])==set(maps[tag])==set(accepted)
 assert loc['previous_targets']=={k:None for k in accepted}
 assert loc['unchanged_accepted']==[] and loc['predecessors']=={} and loc['outside_review']=={} and loc['held_present']=={}
 assert set(loc['held_absent'])=={r['identity'].split('/',1)[1]for r in d['rows']if r['decision']=='hold_absent'}
 assert set(loc['wording_only'])==set(d['wording_only_or_route_limited_identities'])
 assert loc['priority_status']=={r['identity']:r['decision']for r in d['rows']}
 for row in allrows:
  key=row['identity'].split('/',1)[1];typ=row['identity'].split('/',1)[0];src=row['source']
  assert f['sources'][key]=={'type':typ,'source':src['value'],'attributes':src['attributes']}
  actualsource=english.find(f"./{typ}[@name='{key}']");assert resource(actualsource)=={'type':typ,'target':src['value'],'attributes':src['attributes']}
  if typ=='plurals':assert {c.get('quantity'):dict(c.attrib)for c in actualsource}==src['children_attributes']
  for w in row['direct_consumers']:
   lines=(S/w['path']).read_text().splitlines();assert '\n'.join(lines[w['start_line']-1:w['end_line']])==w['context'];contexts.add((w['path'],w['start_line'],w['end_line']))
  if row['decision']=='hold_absent':assert key not in new;continue
  assert new[key]=={'type':typ,'target':row['reviewed_value'],'attributes':row['reviewed_attributes']}
  if typ=='plurals':assert {c.get('quantity'):dict(c.attrib)for c in root.find(f"./plurals[@name='{key}']")}==row['reviewed_children_attributes']
  for mode in ('value','missing','attrs'):
   bad=copy.deepcopy(root);bn=bad.find(f"./{typ}[@name='{key}']")
   if mode=='missing':bad.remove(bn)
   elif mode=='attrs':bn.set('unreviewed','true')
   elif typ=='string':bn.text+='forged'
   else:bn[0].text+='forged'
   reject(lambda:t.require_complete(bad,key,f['sources'][key],row['reviewed_value'],row['reviewed_attributes']))
  count+=1
 assert set(new)==set(maps[tag]);t.require_shape(f)
 oldoption=next(r for r in json.loads(SECOND_ADDITIONS_PATH.read_text())['languages']if r['tag']==tag)
 expectations.require_priority_option_successor(oldoption,E.tostring(root,encoding='unicode'))
 for field in oldoption:
  bad=copy.deepcopy(oldoption);bad[field]='forged';reject(lambda:expectations.require_priority_option_successor(bad,E.tostring(root,encoding='unicode')))
 for mode in ('root-attrs','root-text','resource-tail','plural-text','plural-tail','duplicate','extra','missing'):
  bad=copy.deepcopy(root)
  if mode=='root-attrs':bad.set('forged','true')
  elif mode=='root-text':bad.text='forged'
  elif mode=='resource-tail':bad[0].tail='forged'
  elif mode=='plural-text':bad.find('./plurals').text='forged'
  elif mode=='plural-tail':bad.find('./plurals/item').tail='forged'
  elif mode=='duplicate':bad.append(copy.deepcopy(bad[0]))
  elif mode=='extra':E.SubElement(bad,'string',name='unreviewed').text='forged'
  else:bad.remove(bad[0])
  reject(lambda:expectations.require_priority_option_successor(oldoption,E.tostring(bad,encoding='unicode')))
history=[p for p in base if p.startswith('tools/fixtures/')or p=='Paintroid/src/test/resources/tagged-colour/expected.json'];assert all((B/p).read_bytes()==(S/p).read_bytes()for p in history)
# Preserve every existing shared JVM assertion except its explicit final fallback-count successor.
jvm='Paintroid/src/test/java/org/catrobat/paintroid/local/TaggedColourImportTest.kt';old=(B/jvm).read_text();new=(S/jvm).read_text();assertions=[l.strip()for l in old.splitlines()if 'assert' in l and 'assertEquals(74, fallbacks)'not in l];assert all(new.count(l)>=old.count(l)for l in assertions)
names=['test_somali_wolof_haitian_creole_priority_wording','test_memory_warning_source_review','test_memory_warning_successors','test_current_localization_contracts','test_language_option_additions_second']
extra=S/'tools/test_somali_wolof_haitian_creole_family_additions.py'
if extra.exists():names.append(extra.stem)
suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(n)for n in names);result=unittest.TextTestRunner(verbosity=1).run(suite);assert result.wasSuccessful()
receipt={'result':'PASS','integration_base_commit':manifest['source_commit'],'integration_base_tree':tree['sha'],'linguistic_source_commit':d['source_commit'],'extra_linguistic_credit_from_rebind':0,'all_base_blobs_modes_verified':len(base),'all_current_blobs_modes_verified':len(paths),'all_priority_rows':1023,'adjacent_companions':45,'exact_typed_additions':count,'held_absent':36,'unique_actual_caller_windows':len(contexts),'historical_fixtures_unchanged':len(history),'independent_negative_probes_rejected':rejected,'focused_tests_passed':result.testsRun,'shared_assertion_lines_preserved':len(assertions),'jvm_review':'15 complete consumer methods static reviewed by exact comparison to fully read D analogue, with SO one1/WOother/HTother and no alias; AppLanguage12 explicit output successors read. No local JVM/device execution.','final_files':{p:hashlib.sha256((S/p).read_bytes()).hexdigest()for p in changes},'remote_mutation':False}
(R/'integration-exact-review.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
