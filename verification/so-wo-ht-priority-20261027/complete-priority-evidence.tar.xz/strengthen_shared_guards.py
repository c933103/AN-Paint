"""Stage exact shared-family guard strengthening; do not edit the running test source."""
from pathlib import Path
import json,hashlib
B=Path(__file__).resolve().parent;S=B/'source';O=B/'strengthening-staged';O.mkdir(exist_ok=True)
def put(path,text):p=O/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
p='tools/somali_wolof_haitian_creole_priority_expectations.py';s=(S/p).read_text();data=json.loads((S/'tools/fixtures/current_localization/somali_wolof_haitian_creole_priority_wording.json').read_text());digest=hashlib.sha256(json.dumps(data,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
a=s.index('def current_row(');b=s.index('\ndef _display(',a)
block='''def require_fixture_binding(data):
    import hashlib,json
    digest=hashlib.sha256(json.dumps(data,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    if digest!='CANONICAL_DIGEST':raise ValueError('Complete reviewed trio fixture binding differs')
    return data


def _bound_row(data,tag,key):
    if tag not in TAGS:raise ValueError('Outside exact reviewed locale set')
    locale=data['locales'][tag];source=data['sources'][key]
    if key not in locale['accepted']:raise ValueError('No accepted complete value')
    if key not in locale['previous_targets'] or locale['previous_targets'][key] is not None or key in locale['predecessors']:
        raise ValueError('Every exact addition needs an explicit null predecessor and no prior attributes')
    return {'source':source['source'],'source_attributes':source['attributes'],'target':locale['accepted'][key],
            'attributes':locale['target_attribute_exceptions'].get(key,{'name':key}),
            'previous_target':locale['previous_targets'][key],'previous_attributes':None,
            'changed':key in locale['changed'],'type':source['type']}


def current_row(tag,key):
    return _bound_row(require_fixture_binding(fixture(NAME)),tag,key)


def display_row(row):
    value=row['target']
    if isinstance(value,dict):return {quantity:_display(text) for quantity,text in value.items()}
    if value.startswith('@string/'):raise ValueError('No aliases in exact SO/WO/HT additions')
    return _display(value)


def display(tag,key):
    return display_row(current_row(tag,key))


def require_addition(tag,key,english,historical_value=None,already_present=False,row=None):
    allowed=MEMORY_ADDITIONS|SVG_ADDITIONS|{(tag,'save20_unsupported_image_colour')for tag in TAGS}
    if (tag,key) not in allowed:raise ValueError('Outside exact fifteen family additions')
    if row is None:row=current_row(tag,key)
    bound=_bound_row(require_fixture_binding(fixture(NAME)),tag,key)
    if row!=bound:raise ValueError('Complete current row differs from exact reviewed binding')
    if (historical_value is not None or already_present or row['previous_target'] is not None or row['previous_attributes'] is not None
            or not row['changed'] or row['type']!='string' or row['source']!=english
            or row['source_attributes']!={'name':key} or row['attributes']!={'name':key}
            or not isinstance(row['target'],str) or not row['target'] or row['target'].startswith('@')):
        raise ValueError('Exact family source/type/attributes/history/addition differs: '+tag+'/'+key)
    return row['target']

'''.replace('CANONICAL_DIGEST',digest)
s=s[:a]+block+s[b:];put(p,s)
p='tools/memory_warning_source_review.py';s=(S/p).read_text();s=s.replace('current_row as so_wo_ht_row','current_row as so_wo_ht_row, require_addition as require_so_wo_ht_addition')
a=s.index('    if (tag,key) in SO_WO_HT_ADDITIONS:');b=s.index('    if (tag,key) in NE_PA_ADDITIONS:',a)
s=s[:a]+'''    if (tag,key) in SO_WO_HT_ADDITIONS:
        queue=review_record()
        old=next(o for o in queue['options'] if o['tag']==tag)['terms'][key]['value']
        row=so_wo_ht_row(tag,key)
        return require_so_wo_ht_addition(tag,key,queue['keys'][key]['corrected_english'],
            historical_value=historical_value,already_present=old is not None,row=row)
'''+s[b:];put(p,s)
p='tools/test_current_localization_contracts.py';s=(S/p).read_text();s=s.replace('display as so_wo_ht_display','display as so_wo_ht_display, require_addition as require_so_wo_ht_addition, display_row as so_wo_ht_display_row')
a=s.index('        for tag in sorted(SO_WO_HT_TAGS):');b=s.index('    return require_wording_shape',a)
s=s[:a]+'''        for tag in sorted(SO_WO_HT_TAGS):
            for key in EXPECTED_KEYS[name]:
                row=so_wo_ht_row(tag,key)
                data['values'][key][tag]=require_so_wo_ht_addition(tag,key,data['values'][key]['default'],
                    already_present=tag in data['values'][key],row=row)
            data['additional_reviewed_tags'].append(tag)
            data['additional_locale_review_status'][tag]='independent_model_static_priority_review; no native-human or runtime/layout certification'
'''+s[b:]
a=s.index('\n    for tag in sorted(SO_WO_HT_TAGS):',s.index('def current_tagged_colour_data'))+1;b=s.index('    return data',a)
s=s[:a]+'''    for tag in sorted(SO_WO_HT_TAGS):
        row=so_wo_ht_row(tag,TAGGED_COLOUR_KEY)
        source=ET.parse(catalogues.RES/'values/strings.xml').find("./string[@name='"+TAGGED_COLOUR_KEY+"']")
        if source.attrib!={'name':TAGGED_COLOUR_KEY}:raise ValueError('Actual tagged colour source attributes differ')
        require_so_wo_ht_addition(tag,TAGGED_COLOUR_KEY,source.text,already_present=tag in data,row=row)
        data[tag]=so_wo_ht_display_row(row)
'''+s[b:];put(p,s)
print('Staged three strict shared helper/adapters; source unchanged.')
