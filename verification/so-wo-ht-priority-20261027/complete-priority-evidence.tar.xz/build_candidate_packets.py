from pathlib import Path
import hashlib,json,re,shutil,sys
B=Path(__file__).resolve().parent
for loc in sys.argv[1:] or ('so','wo','ht'):
 p=json.loads((B/f'candidate-public/{loc}-complete-inventory.json').read_text());m={}
 for tier in ('p0','p1'):
  path=B/f'{loc}-{tier}-proposals.tsv'
  if path.exists():
   for line in path.read_text().splitlines():
    k,v=line.split('\t',1);assert k not in m;m[k]=v
 seen=set()
 for r in p['rows']:
  k=r['identity'][7:]
  if k not in m:continue
  seen.add(k);assert r['author_disposition']!='hold-absent',k
  token=lambda x:sorted(re.findall(r'%(?:\d+\$)?[.\d]*[sdf]',x))
  assert token(r['english']['value'])==token(m[k]),k
  r.update(proposal=m[k],proposal_sha256=hashlib.sha256(m[k].encode()).hexdigest(),candidate_phase='Complete submitted value within full P0+P1 assignment; absent submissions remain explicitly pending.')
 assert seen==set(m)
 p['candidate_scope']={'complete_submitted_values':len(m),'P0_submitted':sum(r['tier']=='P0' and 'proposal'in r for r in p['rows']),'P1_submitted':sum(r['tier']=='P1' and 'proposal'in r for r in p['rows']),'remaining_unheld_pending':sum('proposal' not in r and r['author_disposition']!='hold-absent' for r in p['rows']),'limits':'Independent review required before integration. Existing quote wrappers and aliases preserved when retaining values. No runtime/native-human acceptance.'}
 (B/f'candidate-public/{loc}-complete-author-packet.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n');print(loc,p['candidate_scope'])
