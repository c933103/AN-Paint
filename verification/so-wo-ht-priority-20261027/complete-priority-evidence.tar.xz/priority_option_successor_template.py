# Three finite successors to existing options, never additions to the picker.
SO_WO_HT_OPTION_TAGS=TAGS
PRIORITY_OPTION_STATUS='partial-priority-reviewed'
FIXTURE_SHA256='FIXTURE_DIGEST_PLACEHOLDER'

def require_priority_option_successor(historical_row,xml):
    import hashlib,json
    from pathlib import Path
    import xml.etree.ElementTree as ET
    from language_option_additions import SECOND_ADDITIONS_PATH, require_untranslated_option
    root_path=Path(__file__).resolve().parents[1]
    tag=historical_row.get('tag')
    if tag not in SO_WO_HT_OPTION_TAGS:raise ValueError('Outside exact Somali/Wolof/Haitian Creole option successors')
    historical=next(r for r in json.loads(SECOND_ADDITIONS_PATH.read_text())['languages'] if r['tag']==tag)
    if historical_row!=historical:raise ValueError('Original complete option row differs')
    require_untranslated_option(historical_row,'<resources/>')
    raw=(root_path/'tools/fixtures/current_localization'/NAME).read_bytes()
    if hashlib.sha256(raw).hexdigest()!=FIXTURE_SHA256:raise ValueError('Complete reviewed trio fixture differs')
    data=json.loads(raw);locale=data['locales'][tag];accepted=locale['accepted'];count={'so':344,'wo':343,'ht':345}[tag]
    if locale['catalogue_path']!=historical['catalogue'] or len(accepted)!=count or locale['outside_review'] or locale['held_present'] or locale['predecessors'] or locale['unchanged_accepted']:
        raise ValueError('Exact empty predecessor successor scope differs')
    if len(locale['changed'])!=count or set(locale['changed'])!=set(accepted) or locale['previous_targets']!={key:None for key in accepted}:
        raise ValueError('Exact additions must bind every explicit null predecessor')
    root=ET.fromstring(xml)
    if root.tag!='resources' or root.attrib or (root.text or '').strip() or (root.tail or '').strip():raise ValueError('Malformed current catalogue')
    if len(root)!=count or {n.tag+'/'+n.get('name','')for n in root}!=set(locale['catalogue_identities']):raise ValueError('Exact accepted typed identity set differs')
    english={node.get('name'):node for node in ET.parse(root_path/'Paintroid/src/main/res/values/strings.xml').getroot()}
    for node in root:
        key=node.get('name');expected=accepted[key];source=data['sources'][key];original=english[key]
        source_value={n.get('quantity'):n.text for n in original} if original.tag=='plurals' else original.text
        if source!={'type':original.tag,'source':source_value,'attributes':original.attrib}:raise ValueError('Complete English source binding differs')
        if node.tag!=source['type'] or node.attrib!=locale['target_attribute_exceptions'].get(key,{'name':key}):raise ValueError('Exact target type or attributes differ')
        if (node.tail or '').strip():raise ValueError('Unexpected resource tail')
        if node.tag=='string':
            if list(node) or node.text!=expected:raise ValueError('Exact accepted string differs')
        elif node.tag=='plurals':
            if ((node.text or '').strip() or len(node)!=len(expected)
                    or any(n.tag!='item' or set(n.attrib)!={'quantity'} or list(n) or (n.tail or '').strip()for n in node)
                    or {n.get('quantity'):n.text for n in node}!=expected):raise ValueError('Exact complete plural differs')
        else:raise ValueError('Unexpected resource type')
    return root
