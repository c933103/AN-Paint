"""Rebind exact immutable full reviews and final typed maps to the published PR198 parent."""
from pathlib import Path
import json,hashlib,shutil,xml.etree.ElementTree as E
B=Path(__file__).resolve().parent;P=B.parent/'yo-zu-xh-p0-p1-20261027';S=B/'source';base=json.loads((P/'source-remote-tree.json').read_text());assert base['sha']=='28ada9cbc9cf3c7509dbed764ebb7e245e064b8f'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
mp=B/'independent-review/so-wo-ht-accepted-edit-maps.json';assert sha(mp)=='6966e1ef9cc35d5deef0b6535018f5a8c45228d4ff95b7eecc9b75f08f7f4baf';maps=json.loads(mp.read_text());summary=json.loads((B/'independent-review/complete-review-summary.json').read_text())
reviews={loc:json.loads((B/f'independent-review/{loc}-complete-review.json').read_text())for loc in ('so','wo','ht')}
for loc,r in reviews.items():
 assert sha(B/f'independent-review/{loc}-complete-review.json')==summary['locales'][loc]['ledger_sha256']
 assert sha(B/f'candidate-public/{loc}-complete-author-packet.json')==r['original_packet_sha256']
 assert sha(B/f'candidate-public/{loc}-adjacent-dependencies.json')==r['original_dependencies_sha256']
 assert sha(B/'author-additional-absent-holds.json')==r['additional_holds_sha256']
 for path,digest in r['successor_packet_hashes'].items():assert sha(B/path)==digest,path
 assert len(r['rows'])==341 and len(r['dependencies'])==15
 assert all(x['decision'].startswith('accept')or x['decision']=='hold_absent' for x in r['rows']+r['dependencies'])
 assert maps[loc]==r['integration_values'] and len(maps[loc])==dict(so=344,wo=343,ht=345)[loc]
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
for row in base['tree']:
 if row['type']!='blob':continue
 p=P/'source'/row['path'];assert blob(p.read_bytes())==row['sha'],row['path'];assert ('100755'if p.stat().st_mode&0o111 else'100644')==row['mode'];q=S/row['path'];q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
(B/'integration-base-tree.json').write_text(json.dumps(base,indent=2)+'\n')
eng={e.get('name'):e for e in E.parse(S/'Paintroid/src/main/res/values/strings.xml').getroot()}
def val(e):
 out={'value':{c.get('quantity'):c.text for c in e} if e.tag=='plurals' else e.text,'attributes':e.attrib}
 if e.tag=='plurals':out['children_attributes']={c.get('quantity'):c.attrib for c in e}
 return out
results=[];allcontexts=set()
for loc,r in reviews.items():
 cur={e.get('name'):e for e in E.parse(S/r['catalogue_path']).getroot()};assert not cur;accepted={};holds=[];contexts=set()
 for row in r['rows']+r['dependencies']:
  k=row['identity'].split('/',1)[1];ev=val(eng[k]);assert ev==row['source'];assert ev['value']==row['english']['value']and ev['attributes']==row['english']['attributes'];assert row['current']is None
  for w in row['direct_consumers']:
   lines=(S/w['path']).read_text().splitlines();assert '\n'.join(lines[w['start_line']-1:w['end_line']])==w['context'];contexts.add((w['path'],w['start_line'],w['end_line']))
  if row['decision'].startswith('accept'):
   assert 'previous_target'in maps[loc][k]and maps[loc][k]['previous_target']is None
   assert row['reviewed_value']==maps[loc][k]['reviewed_value']and row['reviewed_attributes']==maps[loc][k]['reviewed_attributes']
   accepted[k]=row['reviewed_value']
  else:assert row['decision']=='hold_absent'and k not in maps[loc];holds.append(k)
 assert accepted==r['accepted_resource_text_values']and {'string/'+k for k in holds}==set(r['held_priority_identities']);allcontexts|=contexts
 out={'locale':loc,'catalogue_path':r['catalogue_path'],'rows':r['rows'],'dependencies':r['dependencies'],'accepted_resource_text_values':accepted,'integration_values':maps[loc],'held_absent':sorted(holds),'held_present':{},'wording_only_or_route_limited_identities':r['wording_only_or_route_limited_identities'],'provenance':{'independent_receipt_sha256':sha(B/f'independent-review/{loc}-complete-review.json'),'accepted_maps_sha256':sha(mp),'original_source':r['source_commit'],'integration_source':'b225631aa4609d9d0c64513982f56cb39d864125','additional_linguistic_credit_from_rebind':0}}
 (B/f'independent-review/{loc}-integration-ledger.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');results.append({'locale':loc,'accepted':len(accepted),'typed_edits':len(maps[loc]),'retained_accepted':0,'held_absent':holds,'exact_caller_windows':len(contexts)})
assert len(allcontexts)==414
(B/'integration-parent-rebind-author.json').write_text(json.dumps({'locales':results,'unique_caller_windows':len(allcontexts)},ensure_ascii=False,indent=2)+'\n');print(results)
