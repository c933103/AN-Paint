"""Install finite tests only after the exact independently reviewed fixture exists."""
from pathlib import Path
import hashlib,json,re
B=Path(__file__).resolve().parent;Y=B.parent/'yo-zu-xh-p0-p1-20261027';S=B/'source'
name='somali_wolof_haitian_creole_priority_wording.json'
d=json.loads((S/'tools/fixtures/current_localization'/name).read_text())
assert set(d['locales'])=={'so','wo','ht'}
for tag,locale in d['locales'].items():
 r=json.loads((B/f'independent-review/{tag}-complete-review.json').read_text())
 assert hashlib.sha256((B/f'candidate-public/{tag}-complete-author-packet.json').read_bytes()).hexdigest()==r['original_packet_sha256']
 assert len(locale['accepted'])==dict(so=344,wo=343,ht=345)[tag] and len(locale['changed'])==dict(so=344,wo=343,ht=345)[tag] and not locale['held_present']

s=(B/'priority_expectations_template.py').read_text()+'\n'+(B/'priority_option_successor_template.py').read_text().replace('FIXTURE_DIGEST_PLACEHOLDER',hashlib.sha256((S/'tools/fixtures/current_localization'/name).read_bytes()).hexdigest())
(S/'tools/somali_wolof_haitian_creole_priority_expectations.py').write_text(s)
(S/'Paintroid/src/test/java/org/catrobat/paintroid/local/SomaliWolofHaitianCreolePriorityWordingTest.kt').write_text((B/'PriorityWordingTest.template.kt').read_text())

p=S/'tools/test_language_option_additions_second.py';s=p.read_text()
assert 'SO_WO_HT_OPTION_TAGS' not in s
s=s.replace('from assamese_khmer_lao_priority_expectations import', 'from somali_wolof_haitian_creole_priority_expectations import SO_WO_HT_OPTION_TAGS, PRIORITY_OPTION_STATUS as SO_WO_HT_OPTION_STATUS, require_priority_option_successor as require_so_wo_ht_option_successor\nfrom assamese_khmer_lao_priority_expectations import')
s=s.replace("ASSAMESE_OPTION_STATUS if tag=='as' else 'not-started'","SO_WO_HT_OPTION_STATUS if tag in SO_WO_HT_OPTION_TAGS else ASSAMESE_OPTION_STATUS if tag=='as' else 'not-started'")
anchor="            if row['tag']=='as':"
new='''            if row['tag'] in SO_WO_HT_OPTION_TAGS:
                tag=row['tag'];root=require_so_wo_ht_option_successor(row,path.read_text())
                self.assertEqual([],catalogues.validate_catalogue(tag))
                missing_strings=strings-{n.get('name')for n in root if n.tag=='string'}
                missing_plurals=plurals-{n.get('name')for n in root if n.tag=='plurals'}
                self.assertTrue(missing_strings);self.assertFalse(missing_plurals)
                self.assertEqual([f"{tag}: missing {len(missing_strings)} strings: {', '.join(sorted(missing_strings)[:20])}"],catalogues.validate_catalogue(tag,require_complete=True))
                continue
'''
assert anchor in s;s=s.replace(anchor,new+anchor,1)
t=(Y/'source/tools/test_language_option_additions.py').read_text()
start=t.index('    def test_only_exact_full_priority_values_supersede_two_remaining_original_empty_options')
end=t.index("if __name__ == '__main__':",start)
block=t[start:end].replace('two_remaining_original_empty_options','three_existing_second_batch_options').replace('ADDITIONS_PATH','SECOND_ADDITIONS_PATH').replace('YO_ZU_OPTION_TAGS','SO_WO_HT_OPTION_TAGS').replace('require_yo_zu_option_successor','require_so_wo_ht_option_successor')
# Keep every original five-field empty-row guard sensitive, including plural count.
block=block.replace("('source_strings_present',346)","('source_strings_present',346),('source_plurals_present',1)")
block=block.replace("('missing','extra','attribute')","('missing','extra','attribute','tail','plural-text','plural-tail')").replace("                else:bad[0].set('formatted','false')","                elif mode=='tail':bad[0].tail='unreviewed text'\n                elif mode=='plural-text':bad.find('./plurals').text='unreviewed text'\n                elif mode=='plural-tail':bad.find('./plurals')[0].tail='unreviewed text'\n                else:bad[0].set('formatted','false')")
assert "if __name__ == '__main__':" in s;s=s.replace("if __name__ == '__main__':",block+"if __name__ == '__main__':",1);p.write_text(s)

p=S/'translations/language-options.json';options=json.loads(p.read_text())
for row in options['options']:
 if row['tag'] in ('so','wo','ht'):
  assert row['translation_status']=='not-started';row['translation_status']='partial-priority-reviewed'
p.write_text(json.dumps(options,ensure_ascii=False,indent=2)+'\n')

def display(value):
 if value.startswith('"') and value.endswith('"'):value=value[1:-1]
 return re.sub(r'\\(.)',lambda m:{'n':'\n','t':'\t','r':'\r'}.get(m[1],m[1]),value)
p=S/'Paintroid/src/test/java/org/catrobat/paintroid/local/AppLanguageTest.kt';s=p.read_text()
start=s.index('fun furtherOptionsIncludingPrincipalVarietiesKeepTheirExactIdentityAndFallback')
part=s[start:]
anchor='''            } else {
                assertEquals("File",wrapped.getString(R.string.ui_menu_file))'''
assert anchor in part
new=''
for tag in ('so','wo','ht'):
 new+='            } else if (tag == "'+tag+'") {\n'
 for key in ['ui_menu_file','ui_brush','ui_save','language20_translation_note']:
  value=display(d['locales'][tag]['accepted'][key])
  new+='                assertEquals('+json.dumps(value,ensure_ascii=False).replace('$','\\$')+',wrapped.getString(R.string.'+key+'))\n'
part=part.replace(anchor,new+anchor,1).replace('the other 20 options retain English fallback','the other 17 options retain English fallback')
s=s[:start]+part;p.write_text(s)
print('Prepared finite SO/WO/HT tests and three existing-option successors; original frozen fixtures unchanged.')
