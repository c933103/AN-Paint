from pathlib import Path
import json,hashlib
B=Path(__file__).resolve().parent
v={
'so':{
'gallery_credit_could_not_save':'Macluumaadka abuurayaasha sawirka, ilaha iyo ruqsadaha lama kaydin karin ama dib looma soo celin karin. Macluumaadkii hore loo kaydiyey waa la hayey. Mar kale isku day.',
'gallery_credit_too_large':'Macluumaadkan abuurayaasha sawirka, ilaha iyo ruqsadaha waxa uu sawirka ka dhigayaa mid aad u weyn oo aan dib loo soo celin karin. Sawirkaagii iyo macluumaadkii hore waa la hayey.',
'legacy_credits_unreadable':'Qaar ka mid ah macluumaadkii la kaydiyey ee abuurayaasha sawirrada, ilaha iyo ruqsadaha lama akhrin karin. Nuqulladoodii kaydsanaa waa la hayey.'},
'wo':{
'gallery_credit_could_not_save':'Mëneesul woon a denc walla delloo xibaar yi jëm ci soskat nataal bi, cosaanam ak lisansam. Xibaar yi ñu dencoon ba noppi dañu leen a tëye. Jéemaatal.',
'gallery_credit_too_large':'Xibaar yii jëm ci soskat nataal bi, cosaanam ak lisansam dinañu tax dessin bi réy lool ba mëneesul koo delloo. Sa dessin ak sa xibaar yu jiitu dañu leen a tëye.',
'legacy_credits_unreadable':'Kenn mënu woon a jàng yenn xibaar yi ñu dencoon te jëm ci soskati nataal yi, seen cosaan ak seen lisans. Duppi yi ñu dencoon dañu leen a tëye.',
'ui_save_explanation23':'Tànnal anamu nataal ak jekkali kompresyoŋ bi. Denc dina jëfandikoowaat turu dencukaay, barab, anam ak jekkali yii.'},
'ht':{
'gallery_credit_could_not_save':'Enfòmasyon sou otè imaj la, sous li ak lisans li pa t ka anrejistre oswa retabli. Enfòmasyon ki te deja anrejistre yo konsève. Eseye ankò.',
'gallery_credit_too_large':'Enfòmasyon sou otè imaj sa a, sous li ak lisans li ta fè desen an twò gwo pou retabli. Desen ak enfòmasyon anvan yo konsève.',
'legacy_credits_unreadable':'Kèk enfòmasyon ki te anrejistre sou otè imaj yo, sous yo ak lisans yo pa t ka li. Kopi ki te estoke yo konsève.'}}
rows=[]
for l,values in v.items():
 old=dict(line.split('\t',1)for line in (B/f'{l}-p0-proposals.tsv').read_text().splitlines())
 for k,new in values.items():rows.append({'locale':l,'identity':'string/'+k,'previous_candidate':old[k],'proposed_successor':new,'reason':'Explicit credit schema author/source/licence coverage'if k!='ui_save_explanation23'else'Use explicit compression technical term, not hiding/storage wording','status':'author_proposed_independent_review_pending'})
(B/'author-successor-proposals-credits-compression.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print(len(rows),'full successors staged without changing submitted packets')
