from pathlib import Path
B=Path(__file__).resolve().parent;S=B/'source';O=B/'strengthening-staged'
p='Paintroid/src/test/java/org/catrobat/paintroid/local/TaggedColourImportTest.kt';s=(S/p).read_text()
a=s.index('        val soWoHtPriority=');b=s.index('        assertEquals(99, expected.length())',a)
s=s[:a]+'        addSoWoHt(expected,soWoHtExpectations())\n'+s[b:]
anchor='    @Test fun everyOfferedLanguageResolvesItsScopedMessageOrExplicitEnglishFallback() {'
block=r'''    private fun soWoHtExpectations() = JSONObject(File("../tools/fixtures/current_localization/somali_wolof_haitian_creole_priority_wording.json").readText())

    private fun addSoWoHt(expected: JSONObject,reviewed: JSONObject) {
        val key="save20_unsupported_image_colour"
        val source=reviewed.getJSONObject("sources").getJSONObject(key)
        assertEquals("string",source.getString("type"));assertEquals(neutral,source.getString("source"))
        assertEquals(setOf("name"),source.getJSONObject("attributes").keys().asSequence().toSet())
        assertEquals(key,source.getJSONObject("attributes").getString("name"))
        val canonical=soWoHtExpectations().getJSONObject("locales")
        for(tag in listOf("so","wo","ht")) {
            assertFalse("Already present predecessor $tag",expected.has(tag))
            val row=reviewed.getJSONObject("locales").getJSONObject(tag)
            assertFalse("Historical resource must be absent $tag",row.getJSONObject("predecessors").has(key))
            assertTrue("Explicit previous-target key required $tag",row.getJSONObject("previous_targets").has(key))
            assertTrue("Explicit null predecessor required $tag",row.getJSONObject("previous_targets").isNull(key))
            assertTrue("Must be an explicit changed value $tag",(0 until row.getJSONArray("changed").length()).any {
                row.getJSONArray("changed").getString(it)==key })
            assertFalse("Exact name-only target attributes $tag",row.getJSONObject("target_attribute_exceptions").has(key))
            val raw=row.getJSONObject("accepted").getString(key)
            assertTrue(raw.isNotEmpty());assertFalse(raw.startsWith("@"))
            assertEquals("Exact complete raw target $tag",canonical.getJSONObject(tag).getJSONObject("accepted").getString(key),raw)
            val display=Regex("""\\(.)""").replace(raw.removeSurrounding("\"")) { token ->
                when(token.groupValues[1]) { "n"->"\n"; "t"->"\t"; "r"->"\r"; else->token.groupValues[1] }
            }
            expected.put(tag,display)
        }
    }

    @Test fun finiteSoWoHtAdditionRejectsSourceAttributesHistoryAndTargetCorruption() {
        val key="save20_unsupported_image_colour"
        for(tag in listOf("so","wo","ht")) for(mutation in listOf("source","sourceAttributes","sourceType","previous","missingNull","nonNull","attributes","changed","empty","target","alias","alreadyPresent")) {
            val data=soWoHtExpectations();val expected=JSONObject()
            val source=data.getJSONObject("sources").getJSONObject(key)
            val row=data.getJSONObject("locales").getJSONObject(tag)
            when(mutation) {
                "source" -> source.put("source","forged")
                "sourceAttributes" -> source.getJSONObject("attributes").put("formatted","false")
                "sourceType" -> source.put("type","plurals")
                "previous" -> row.getJSONObject("predecessors").put(key,"forged")
                "missingNull" -> row.getJSONObject("previous_targets").remove(key)
                "nonNull" -> row.getJSONObject("previous_targets").put(key,"forged")
                "attributes" -> row.getJSONObject("target_attribute_exceptions").put(key,JSONObject().put("name",key).put("formatted","false"))
                "changed" -> row.put("changed",org.json.JSONArray())
                "empty" -> row.getJSONObject("accepted").put(key,"")
                "target" -> row.getJSONObject("accepted").put(key,"forged")
                "alias" -> row.getJSONObject("accepted").put(key,"@string/ui_save")
                "alreadyPresent" -> expected.put(tag,"forged")
            }
            assertThrows("$tag/$mutation",AssertionError::class.java) { addSoWoHt(expected,data) }
        }
    }

'''
assert anchor in s;s=s.replace(anchor,block+anchor,1);q=O/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(s)
p='Paintroid/src/test/java/org/catrobat/paintroid/local/SomaliWolofHaitianCreolePriorityWordingTest.kt';s=(S/p).read_text();anchor='''        run {
            assertEquals("Foreground''';a=s.index(anchor)
block='''        val english=activity.createConfigurationContext(android.content.res.Configuration(activity.resources.configuration).apply {
            setLocale(Locale.US)
        }).resources
        val held=locale.getJSONArray("held_absent")
        assertEquals(mapOf("so" to 12,"wo" to 13,"ht" to 11).getValue(tag),held.length())
        for(index in 0 until held.length()) {
            val key=held.getString(index);val id=activity.resources.getIdentifier(key,"string",activity.packageName)
            assertNotEquals("$tag held/$key",0,id)
            assertEquals("$tag held/$key",english.getString(id),activity.getString(id))
        }
''';s=s[:a]+block+s[a:]
anchor='''            check(3);root.findViewWithTag<View>("crop_none").performClick();check(0)'''
block='''            for(count in listOf(21,21001)) {
                val pattern=decoded(values.getString("other"))
                assertEquals(String.format(Locale.forLanguageTag(tag),pattern,24,16,count),
                    uiQuantity(activity.resources,R.plurals.ui_crop_preview_images,count,24,16,count))
            }
''';assert anchor in s;s=s.replace(anchor,block+anchor,1);q=O/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(s)
print('Staged finite JVM helper with 36 negative cases, all 36 exact English fallbacks and counts21/21001; original14 consumer methods retained.')
