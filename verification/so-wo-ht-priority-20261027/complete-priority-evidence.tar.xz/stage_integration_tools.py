"""Prepare strict integration tooling only; execution still requires three exact independent receipts."""
from pathlib import Path
B=Path(__file__).resolve().parent;Y=B.parent/'yo-zu-xh-p0-p1-20261027'
def adapt(s):
 for a,b in [('yoruba_zulu_xhosa','somali_wolof_haitian_creole'),('YorubaZuluXhosa','SomaliWolofHaitianCreole'),('Yoruba/Zulu/Xhosa','Somali/Wolof/Haitian Creole'),('YO_ZU_XH','SO_WO_HT'),('yo_zu_xh','so_wo_ht'),("('yo','zu','xh')","('so','wo','ht')"),("{'yo','zu','xh'}","{'so','wo','ht'}"),('listOf("yo","zu","xh")','listOf("so","wo","ht")'),('HA/IG/LN','SO/WO/HT')]:s=s.replace(a,b)
 return s
s=adapt((Y/'integrate_priority.py').read_text()).replace('ten exact absent holds per language, four inherited Xhosa terminology holds without acceptance credit, and fifteen','ten exact absent holds per language and fifteen').replace("(342 if loc=='xh' else 346)",'346')
(B/'integrate_priority.py').write_text(s)
s=adapt((Y/'priority_host_test_template.py').read_text()).replace("tag in ('zu','xh')","tag=='so'")
(B/'priority_host_test_template.py').write_text(s)
(B/'prepare_host_tests.py').write_text(adapt((Y/'prepare_host_tests.py').read_text()))
s=adapt((Y/'apply_shared_guard_additions.py').read_text())
s=s.replace('import HA_IG_LN_ADDITIONS,','import YO_ZU_XH_ADDITIONS,').replace('SO_WO_HT_ADDITIONS, HA_IG_LN_ADDITIONS,','SO_WO_HT_ADDITIONS, YO_ZU_XH_ADDITIONS,')
s=s.replace('ha_ig_ln_display','yo_zu_xh_display').replace('Hausa/Igbo/Lingala value','Yoruba/Zulu/Xhosa value').replace('val yoZuXhPriority','val soWoHtPriority').replace('yoZuXhPriority.getJSONObject','soWoHtPriority.getJSONObject')
s=s.replace('assertEquals(96, expected.length())','assertEquals(99, expected.length())').replace('assertEquals(93, expected.length())','assertEquals(96, expected.length())')
s=s.replace('assertEquals(74, fallbacks) // 171 offered - 96 exact current values - 1 inherited.','assertEquals(71, fallbacks) // 171 offered - 99 exact current values - 1 inherited.').replace('assertEquals(77, fallbacks) // 171 offered - 93 exact current values - 1 inherited.','assertEquals(74, fallbacks) // 171 offered - 96 exact current values - 1 inherited.')
s=s.replace('Applied exact finite JV/SU/KY additions','Applied exact finite SO/WO/HT additions')
(B/'apply_shared_guard_additions.py').write_text(s)
# Templates are temporary authoring aids, not files in the application tree.
s=adapt((Y/'source/tools/yoruba_zulu_xhosa_priority_expectations.py').read_text().split('# Two exact empty-option successors')[0])
(B/'priority_expectations_template.py').write_text(s)
s=adapt((Y/'source/Paintroid/src/test/java/org/catrobat/paintroid/local/YorubaZuluXhosaPriorityWordingTest.kt').read_text())
s=s.replace('(tag=="xh" && count==1) || (tag=="zu" && count in 0..1)','tag=="so" && count==1').replace('// CLDR: Xhosa one=1; Zulu one=0/1; Yoruba only other.','// Somali one=1; Wolof other-only. Haitian Creole uses an invariant noun and explicit other fallback; no French-rule inference.')
(B/'PriorityWordingTest.template.kt').write_text(s)
