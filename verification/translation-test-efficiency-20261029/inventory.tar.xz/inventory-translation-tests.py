"""One-time read-only source/artifact inventory. Not an application test."""
import ast,collections,hashlib,json,pathlib,re,subprocess,zipfile,xml.etree.ElementTree as E
P=pathlib.Path(__file__).resolve().parent;REPO=P.parent/'repo'; BASE='b05a4463e03683f92c2b3ebe21905e0420362a42';REFS={'b05a':BASE,'226':'d8f1840ac60ec9c2134f6a01439fac35433d349c','227':'68c7d1c2e1ceaa316cd138ac2ddf3247691ae245'}
def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args],text=True)
def paths(ref):return git('ls-tree','-r','--name-only',ref).splitlines()
def source(ref,p):return git('show',ref+':'+p)
# Explicit operational categories, not a claim every test using R.string is translation-specific.
FOCUS=re.compile(r'priority|wording|translation|localiz|language|locale|normalization_scope|assembly_help|assembly_.*_help|manual_save_export|font_disclosures|picker_fallback|source_text_resources|hakka_context|help_save_export|help_commons_provider|save_export_help|crop_counterpart_guidance|crop_movement|crop_followon')
JFOCUS=re.compile(r'Priority|Wording|Translation|Locale|Language|Localized|AssemblyHelp|CropCounterpart|CropMovement|TiffDescription|ProtectedDraftWarning|TaggedColour|UiDirection|UiTypography|NumericDisplay|FrenchCursorGuidance|FrenchToolCategory|JapaneseActiveGuidance|JapanesePdfFailure|HungarianAttribution|NynorskRemainingP0|SlovakSlovenianP0|DanishNorwegianP0|CroatianBosnianP0|SerbianP0|ImageDisplayLocale')
rows=[];texts={}
for p in paths(BASE):
 if p.startswith('tools/') and p.count('/')==1 and p.endswith('.py'):
  s=source(BASE,p);texts[p]=s;tree=ast.parse(s);methods=[n.name for cls in ast.walk(tree) if isinstance(cls,ast.ClassDef) for n in cls.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_')]
  category='test' if pathlib.Path(p).name.startswith('test_') else 'helper'
  rows.append({'path':p,'kind':'python_'+category,'lines':len(s.splitlines()),'test_methods':len(methods),'method_names':methods,'translation_focus':bool(FOCUS.search(p)),'priority_slice':'priority' in p or 'wording' in p,'fixture_reference':'current_localization' in s})
 elif p.startswith('Paintroid/src/test/') and p.endswith(('.kt','.java')):
  s=source(BASE,p);texts[p]=s
  # Remove literal strings/comments before counting test annotations.
  clean=re.sub(r'"""[\s\S]*?"""|"(?:\\.|[^"\\])*"|/\*[\s\S]*?\*/|//[^\n]*','',s)
  methods=len(re.findall(r'@Test\b',clean))
  rows.append({'path':p,'kind':'jvm_test' if methods else 'jvm_helper','lines':len(s.splitlines()),'test_methods':methods,'translation_focus':bool(JFOCUS.search(p)),'priority_slice':bool(re.search(r'Priority|Wording',p)),'fixture_reference':'current_localization' in s})
 elif p.startswith('tools/fixtures/current_localization/'):
  s=source(BASE,p);rows.append({'path':p,'kind':'localization_fixture','bytes':len(s.encode()),'lines':len(s.splitlines())})
summary={}
for k in sorted(set(r['kind'] for r in rows)):
 r=[x for x in rows if x['kind']==k];summary[k]={'files':len(r),'lines':sum(x.get('lines',0) for x in r),'literal_test_methods':sum(x.get('test_methods',0) for x in r)}
 for label in ['translation_focus','priority_slice','fixture_reference']:
  a=[x for x in r if x.get(label)];summary[k][label]={'files':len(a),'literal_test_methods':sum(x.get('test_methods',0) for x in a),'lines':sum(x.get('lines',0) for x in a)}
# Function shapes: remove docstrings and replace ONLY family-specific literal metadata.
class Normalize(ast.NodeTransformer):
 def visit_Constant(self,n):
  if isinstance(n.value,str) and (re.fullmatch('[0-9a-f]{64}',n.value) or 'priority_wording' in n.value or 'priority_followthrough' in n.value or 'indonesian_crop_followthrough' in n.value):return ast.copy_location(ast.Constant('<fixture-or-digest>'),n)
  return n
functions=collections.defaultdict(list)
for p,s in texts.items():
 if not p.endswith('.py') or pathlib.Path(p).name.startswith('test_'):continue
 for n in ast.parse(s).body:
  if not isinstance(n,ast.FunctionDef):continue
  if n.body and isinstance(n.body[0],ast.Expr) and isinstance(n.body[0].value,ast.Constant) and isinstance(n.body[0].value.value,str):n.body=n.body[1:]
  normalized=ast.dump(Normalize().visit(n),include_attributes=False)
  if len(normalized)<200:continue
  functions[hashlib.sha256(normalized.encode()).hexdigest()].append({'path':p,'function':n.name,'line':n.lineno,'end_line':n.end_lineno})
clones=[v for v in functions.values() if len(v)>1];clones.sort(key=lambda a:(len(a),a[0]['end_line']-a[0]['line']),reverse=True)
artifact=pathlib.Path('/workspace/scratch/bbca2890f602/easteurope-ordinary-evidence/b05a-postmerge/regression.zip');z=zipfile.ZipFile(artifact);timings=[]
for n in z.namelist():
 if '/test-results/' not in n or not n.endswith('.xml'):continue
 r=E.fromstring(z.read(n));name=r.attrib['name'];timings.append({'class':name,'tests':int(r.attrib['tests']),'seconds':float(r.attrib['time']),'translation_focus':bool(JFOCUS.search(name)),'priority_slice':bool(re.search(r'Priority|Wording',name)),'cases':[{'name':c.attrib['name'],'seconds':float(c.attrib['time'])} for c in r.findall('testcase')]})
timing_summary={k:{'classes':len(a),'cases':sum(r['tests'] for r in a),'suite_seconds_sum':round(sum(r['seconds'] for r in a),3)} for k,a in [('all',timings),('translation_focus',[r for r in timings if r['translation_focus']]),('priority_slice',[r for r in timings if r['priority_slice']])]}
deltas={}
for label,ref in REFS.items():
 if label=='b05a':continue
 raw=git('diff','--numstat',BASE,ref);stats=[]
 for line in raw.splitlines():
  add,delete,p=line.split('\t');entry={'path':p,'added_lines':int(add),'deleted_lines':int(delete)}
  if p.endswith('.py'):
   t=ast.parse(source(ref,p));entry['literal_test_methods']=sum(isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_') for c in ast.walk(t) if isinstance(c,ast.ClassDef) for n in c.body)
  elif p.endswith('.kt'):
   s=source(ref,p);entry['literal_test_methods']=len(re.findall(r'@Test\b',re.sub(r'"""[\s\S]*?"""|"(?:\\.|[^"\\])*"|/\*[\s\S]*?\*/|//[^\n]*','',s)))
  stats.append(entry)
 deltas[label]={'head':ref,'files':stats,'added_lines':sum(x['added_lines'] for x in stats),'deleted_lines':sum(x['deleted_lines'] for x in stats)}
result={'base':BASE,'base_tree':git('rev-parse',BASE+'^{tree}').strip(),'method':'Read-only Git blobs; Python AST literal class test_ methods; JVM @Test after stripping literals/comments. Focus categories are explicit filename rules, not exhaustive semantic classification; rows preserve inspectable membership. Executed counts/times are separate actual b05a regression XML, not inferred from source.','focus_patterns':{'python':FOCUS.pattern,'jvm':JFOCUS.pattern},'summary':summary,'rows':rows,'duplicate_function_groups':clones,'baseline_jvm_artifact':{'run':40836724809,'artifact':12882793690,'sha256':hashlib.sha256(artifact.read_bytes()).hexdigest(),'classification':'Successful regression only; whole natural attempt1 failed device collection'},'timing_summary':timing_summary,'jvm_timings':timings,'deltas':deltas}
(P/'translation-test-inventory.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'summary':summary,'timing_summary':timing_summary,'clone_groups':len(clones),'top_clone_groups':clones[:8],'deltas':deltas},indent=2))
