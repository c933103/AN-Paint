# Proposed batch: sixteen Assembly Help modules

No edit or new test run is made by this proposal. Base is the current reviewed shared-core source, bb0ded75b3b88f961665cfa40bec12e4fa32a080 (tree 1bc12faf15de145ac9148ff439d7060156430baf), on actual develop 2cb90dbd.

## Scope and expected reduction

The existing sixteen modules contain 2,836 source lines and 129 test methods. Five methods are exact AST clones in every module; their bodies/decorators occupy 768 lines. Move only their repeated mechanism into one Assembly-Help-specific support module and keep thin, same-named wrappers in each existing test class. Estimated net reduction: about 550 lines (roughly 19% of this family), subject to final diff. This is maintenance reduction, not measured runtime savings or project-wide completion.

| Existing method | Explicit runtime dependencies |
| --- | --- |
| setUpClass | cls, FIXTURE, RESOURCE, require_fixture |
| reject_value | self, value, KEY, require_complete |
| test_exact_complete_eight_paragraph_value | self, ROOT, KEY, require_complete |
| test_oracle_rejects_each_paragraph_omission_duplication_and_reorder | self |
| test_oracle_rejects_resource_structure_changes | self, KEY, require_complete |

The support module imports only json, ElementTree and deepcopy. Each wrapper passes current module values/callables at invocation; no captured fixture path, hidden cache, class-generation or inherited test discovery. Existing class/module/method identities remain explicit and unchanged. ElementTree/deepcopy have no uses outside these five methods in any of the sixteen modules, allowing their duplicate imports to disappear.

## Contracts that remain local and unchanged

- All accepted full-text fixture bytes, locale/directory/key constants, require_fixture/require_complete functions and exact error messages.
- Caption sets and actual route quotation/separator tests: six distinct method variants.
- Sentence segmentation, sentence counts and omission/duplication rules: four distinct variants.
- All exact semantic corruption literals, Unicode/escape/placeholder mutations, conditional-clause relocations and negative no-op assertions.
- Fixture identity/malformed-paragraph controls, including differing wrong-locale examples.
- Vietnamese prior-seven-paragraph rejection; Jyutping/Simplified-Chinese extra relocation/count checks and retained historical corruption values.
- All 129 current test identities and assertion scopes; production resources, JVM consumers, CI and timeouts.

Modules: Brazilian Portuguese, Cantonese, Classical Chinese, Dutch, Jyutping, Latvian, Lithuanian, Malay, Mongolian Cyrillic, Russian, Simplified Chinese, Swahili, Taiwanese Han, Taiwanese POJ, Turkish and Vietnamese.

## Proposed execution boundary

After parent review, implement all sixteen modules in one batch. Compare every retained function body/constant and existing discovered identity, run the existing family checks in normal and optimized modes, and provide the compact incremental diff. No new test suite, generic registry, permanent source reconstruction, added workflow or duplicate full local cycle. Keep the ongoing #228 head/checks as their own historical evidence; root decides publication/integration of the batch after reviewing it.
