# Proposed next batch: eight priority-cohort validators

Read-only assessment of the already-identified family at merged #228 tree 0926f300; no source edit/test run is made by this proposal.

The eight helpers total 744 lines. Their five exact common functions occupy 392 lines: require_fixture_binding, bound_fixture, require_resource_shape, require_edited_resource and require_catalogue. A plain family-specific common module (estimated 78 lines), five same-name wrappers per cohort (80 lines total), and removing redundant imports would reduce the family by about 240 lines (~32%). This is a maintenance estimate, not measured runtime savings.

- require_fixture_binding: pass tag, data, current TAGS and FIXTURE_DIGESTS; preserve canonical complete JSON serialization/digest/error behavior.
- bound_fixture: pass tag, current TAGS/FAMILY, current fixture loader and local binding validator. Preserve per-call loading and duplicate-key rejection; no captured path/digest/cache.
- require_resource_shape: stateless element/kind/expected checker, preserving all exact resource attributes, text, children, tails and plural quantity checks.
- require_edited_resource and require_catalogue: pass current local bound_fixture, require_fixture_binding and require_resource_shape callables. Preserve optional supplied-data validation, complete catalogue identity set and original/unrelated resource checks.

Shared imports are hashlib/json. The Sanskrit module retains its own hashlib/json for its separate original-option-row guard. All eight current helpers have no local cache/decorators. No shared factory, registry, inheritance, dynamic test generation or schema adaptation is proposed.

Keep unchanged every cohort constant/digest and all 24 fixtures; all six distinct require_shared_row variants; exact source/predecessor/display/absence rules; Uzbek/Tatar script successors; Tibetan sampled-warning successor; Sanskrit original-row/empty-catalogue successor; and the four existing Android-decoding helpers. This family uses quantity-keyed plural fixtures and whole-catalogue validation and must not be forced into #228's ordered finite-value core.

Existing direct cohort packages contain 134 test methods. After approval, use those existing tests and affected existing memory/source/routing/option-consumer checks in normal/optimized modes, with no new suite or duplicate whole-project local cycle. Verify exact retained bodies/constants/fixture bytes and discovered identities before final diff review/publication.

Cohorts: Basque/Frisian/Uzbek; Cebuano/Low German/Kashubian; Chhattisgarhi/Yiddish/Hong Kong; Kazakh/Tajik/Pashto; Sindhi/Nigerian Pidgin/Tok Pisin; Sorani/Uyghur/Tatar; Tibetan/Dzongkha/Valencian; Walloon/Northern Sami/Sanskrit. All eight are one batch, not one PR per language. Broader project duplication remains open.
