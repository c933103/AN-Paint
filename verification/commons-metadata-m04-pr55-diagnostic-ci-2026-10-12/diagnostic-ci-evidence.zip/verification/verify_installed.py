if not __debug__:
 raise RuntimeError('Acceptance verification requires ordinary Python; optimized mode is rejected')
import argparse,hashlib,json,sys,math
from pathlib import Path
import xml.etree.ElementTree as E
p=argparse.ArgumentParser();p.add_argument('root',type=Path);a=p.parse_args();R=Path(__file__).parent;(R/'candidate-installed-verification.json').unlink(missing_ok=True);checkout=Path('/workspace/shared/anpaint-pr55-landscape-diagnostic-20261012');sys.path.insert(0,str(checkout/'tools'))
from run_android_instrumentation import declared_tests,source_tests_sha256,parse_protocol
from app_instrumentation_matrix import read_app_reports,report_paths,app_partition,verify_app_reports
source=checkout/'app/src/androidTest';expected=declared_tests(source,sdk_level=35);suppressed=declared_tests(source)-expected;digest=source_tests_sha256(source);reports=read_app_reports(a.root,35);union=verify_app_reports(expected,35,reports,digest,suppressed);parts=app_partition(expected,35);paths=report_paths(a.root,35)
ns=checkout/'Paintroid/src/androidTest';parts['native']=declared_tests(ns,sdk_level=35);paths['native']=a.root/'Paintroid/androidTest-results/summary.json';reports['native']=json.loads(paths['native'].read_text());native=reports['native'];assert native['source_tests_sha256']==source_tests_sha256(ns);assert native['device_sdk']==35 and native['timeout_seconds']==180;assert native['sdk_suppressed_tests']==[] and native['excluded_classes']==[] and native['included_tests']==[] and native['leave_target_running'] is False
plain=lambda v:json.loads(json.dumps(v));facts={}
for phase,path in paths.items():
 report=reports[phase];raw=path.with_name('instrumentation.log');parsed=parse_protocol(raw.read_text(),parts[phase],returncode=report['returncode'],timed_out=report['timed_out']);assert parsed['success'],(phase,parsed['errors'])
 for k,v in parsed.items():assert plain(v)==report[k],(phase,k)
 xml=list(path.parent.glob('TEST-*.xml'));assert len(xml)==1;root=E.parse(xml[0]).getroot();assert root.tag=='testsuite';cases=root.findall('testcase');assert len(cases)==len(root.findall('.//testcase'));assert int(root.attrib['tests'])==len(cases);assert all(int(root.attrib[k])==0 for k in ['errors','failures','skipped']);ids=[(c.attrib['classname'],c.attrib['name']) for c in cases];assert len(ids)==len(set(ids));assert set(ids)==parts[phase];assert not any(root.findall('.//'+t) for t in ['failure','error','skipped']);elapsed=report['elapsed_seconds'];assert type(elapsed) in (int,float) and math.isfinite(elapsed) and 0<=elapsed<=report['timeout_seconds']
 facts[phase]=dict(completed=len(ids),elapsed_seconds=report['elapsed_seconds'],timeout_seconds=report['timeout_seconds'],protocol_sha256=hashlib.sha256(raw.read_bytes()).hexdigest(),xml_sha256=hashlib.sha256(xml[0].read_bytes()).hexdigest())
assert sum(x['completed'] for x in facts.values())==104
for name in ['app/coverage.json','app/ordinary-gallery-coverage.json','app/vertical-coverage.json','app/accepted-credit-restart/coverage.json']:assert json.loads((a.root/name).read_text())==plain(union),name
out=dict(success=True,head='dc46abc2add7984358565a88fe65c5278212dcf6',ci_merge='56e7891852a2da201bf10ad99c486e659da2e6c5',tree='4ff7f479ffc73964fa8756b6c7e3202f624ad0f1',run_id=38244193872,exact_total=104,app_union=union,phases=facts,source_tests_sha256=digest,native_source_tests_sha256=source_tests_sha256(ns),scope='Original raw protocol, XML and source-digest-bound phase union. Screenshots, export manifests and build identity are separate gates.')
(R/'candidate-installed-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(success=True,total=104,phases={k:v['completed'] for k,v in facts.items()})))
