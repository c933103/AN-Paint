import hashlib, io, json, subprocess, sys, zipfile
from pathlib import Path

archive=Path(sys.argv[1]); checkout=Path(sys.argv[2]); output=Path(sys.argv[3])
expected_tree='4ff7f479ffc73964fa8756b6c7e3202f624ad0f1'
expected_merge='56e7891852a2da201bf10ad99c486e659da2e6c5'
expected_zip_sha='5082b9388879172277297b81524fab20642550114d0fa181d2162e46d466be04'
def sha(b): return hashlib.sha256(b).hexdigest()
def blob(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
assert sha(archive.read_bytes())==expected_zip_sha
with zipfile.ZipFile(archive) as outer:
    names=outer.namelist()
    def one(suffix):
        matches=[n for n in names if n.endswith(suffix)]
        assert len(matches)==1, (suffix,matches)
        return outer.read(matches[0])
    info=json.loads(one('/build-info.json'))
    apk=one('/app-debug.apk'); source=one('/AN-Paint-source.zip')
    assert info['commit']==expected_merge and str(info['run_id'])=='38244193872'
    assert info['build_variant']=='debug'
    assert info['apk_sha256']==sha(apk) and info['source_sha256']==sha(source)
    with zipfile.ZipFile(io.BytesIO(apk)) as az:
        assert az.read('assets/local-source/AN-Paint-source.zip')==source
        font=az.read('assets/fonts/anpaintnomui.ttf')
        assert sha(font)=='6b70d3c5c146c9d11503e5dff7ade5e7ccb3ae5a70c511f71902d4a75f7a3006'
        inv=az.read('assets/fonts/inventory.json')
        assert inv==(checkout/'Paintroid/src/main/assets/fonts/inventory.json').read_bytes()
        checked_assets=[]
        for local in (checkout/'Paintroid/src/main/assets/fonts').rglob('*'):
            if not local.is_file(): continue
            member='assets/fonts/'+str(local.relative_to(checkout/'Paintroid/src/main/assets/fonts'))
            assert az.read(member)==local.read_bytes(), member
            checked_assets.append(member)
        font_info={'sha256':sha(font),'bytes':len(font),'inventory_sha256':sha(inv),'all_font_directory_assets_identical':checked_assets}
    raw=subprocess.check_output(['git','ls-tree','-rz','--full-tree',expected_tree],cwd=checkout)
    tracked={}
    for item in raw.split(b'\0'):
        if not item:continue
        meta,path=item.split(b'\t',1); mode,kind,digest=meta.decode().split()
        assert kind=='blob'
        tracked[path.decode()]=(mode,digest)
    def excluded(path):
        p=Path(path)
        # Existing bundle excludes .idea explicitly; Gradle FileTree applies Ant's
        # documented .gitignore defaults. Pin the exact three tracked omissions.
        # https://docs.gradle.org/current/userguide/working_with_files.html
        # https://ant.apache.org/manual/dirtasks.html#defaultexcludes
        return path in {'.gitignore','colorpicker/.gitignore','.idea/codeStyles/Project.xml'}
    checked=[]; omitted=[]; bad=[]; extras=[]
    with zipfile.ZipFile(io.BytesIO(source)) as sz:
        entries={n:sz.read(n) for n in sz.namelist() if not n.endswith('/')}
        assert len(entries)==len([n for n in sz.namelist() if not n.endswith('/')]),'Duplicate ZIP entries'
        for p,(mode,digest) in tracked.items():
            if excluded(p): omitted.append(p); continue
            n='AN-Paint/'+p
            if n not in entries:bad.append({'missing':p});continue
            observed=blob(entries[n])
            if observed!=digest:bad.append({'path':p,'expected':digest,'actual':observed})
            checked.append(p)
        for n in entries:
            p=n.removeprefix('AN-Paint/')
            if p not in tracked and not any(p.startswith('Paintroid/build/'+codec+'/') for codec in ('jxl-source','webp-source','heif-source','tiff-source')):extras.append(p)
        assert not bad, bad
        assert not extras, extras
    output.mkdir(parents=True,exist_ok=True)
    (output/'app-debug.apk').write_bytes(apk)
    (output/'AN-Paint-source.zip').write_bytes(source)
    (output/'build-info.json').write_text(json.dumps(info,indent=2)+'\n')
    result={'run':38244193872,'tested_commit':expected_merge,'tested_tree':expected_tree,'artifact_sha256':expected_zip_sha,'build_info':info,'packaged_font':font_info,'tracked_source_checked':len(checked),'tracked_excluded_by_bundle':omitted,'mismatches':bad,'unexpected_extra_paths':extras,'embedded_source_identical':True}
    (output/'source-binding-audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
