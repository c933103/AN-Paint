from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parent
reg=R/'regression'
review=Path('/workspace/shared/anpaint-pr55-diagnostic-artifact-review-20261012')
files={}
def add(prefix, root, paths):
    for p in paths:
        if p.is_file():
            key=prefix+'/'+p.relative_to(root).as_posix()
            assert key not in files,key
            files[key]=p
for directory,prefix in [('commons-metadata-m04','m04-renders'),('commons-metadata-m04-diagnostic','m04-diagnostic')]:
    d=reg/'Paintroid/build/reports'/directory
    add(prefix,d,d.rglob('*'))
add('junit',reg,reg.rglob('TEST-*.xml'))
d=reg/'build/reports/ci-phases';add('ci-phases',d,d.iterdir())
d=R/'exact-script';add('exact-script',d,d.iterdir())
d=R/'api35'
add('api35',d,(p for p in d.rglob('*') if p.is_file() and (p.name.startswith('TEST-') and p.suffix=='.xml' or p.name in ['instrumentation.log','summary.json','coverage.json','ordinary-gallery-coverage.json','vertical-coverage.json'])))
for item in json.loads((review/'DELIVERY-FILES.json').read_text())['files']:
    p=review/item['path'];data=p.read_bytes();assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'];add('independent-review',review,[p])
add('independent-review',review,[review/'DELIVERY-FILES.json'])
add('apk-source',R/'apk-audit',[R/'apk-audit'/n for n in ['build-info.json','source-binding-audit.json']])
add('verification',R,[R/n for n in ['diagnostic-ci-metadata.json','candidate-installed-verification.json','verify_installed.py','audit_apk_source.py','preserve_diagnostic_evidence.py']])
manifest=[]
z=R/'diagnostic-ci-evidence.zip'
with zipfile.ZipFile(z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as f:
    for name,p in sorted(files.items()):
        data=p.read_bytes();manifest.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
        info=zipfile.ZipInfo(name,date_time=(2026,10,12,12,2,48));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
        f.writestr(info,data)
data=z.read_bytes();blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
receipt=dict(source_head='dc46abc2add7984358565a88fe65c5278212dcf6',source_tree='4ff7f479ffc73964fa8756b6c7e3202f624ad0f1',ci_merge='56e7891852a2da201bf10ad99c486e659da2e6c5',run_id=38244193872,status='failure-retained',jvm=dict(total=890,passed=889,failed=1),successful_render_pairs=111,expected_success_pairs=112,diagnostic_profiles=28,api35_installed=104,archive=dict(path=z.name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),git_blob=blob,entries=len(manifest)),independent_review_manifest_sha256=hashlib.sha256((review/'DELIVERY-FILES.json').read_bytes()).hexdigest())
(R/'diagnostic-ci-evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(R/'diagnostic-ci-evidence-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
