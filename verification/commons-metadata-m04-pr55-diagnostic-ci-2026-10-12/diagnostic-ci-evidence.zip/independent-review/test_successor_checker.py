"""Synthetic checker-only tests, never hosted app evidence."""
import tempfile,pathlib,unittest
from PIL import Image
from audit_successor_artifacts import ink_metrics,junit_audit,render_audit
class CheckerTest(unittest.TestCase):
    def test_recompute_actual_ink_and_detect_corruption(self):
        im=Image.new('RGBA',(164,84));im.putpixel((35,34),(1,2,3,255));im.putpixel((30,34),(1,2,3,128))
        data={'layout_width':100,'layout_height':20,'expanded_layout_margin_px':32,'expanded_canvas_edge_touch':dict(left=False,right=False,top=False,bottom=False),'lines':[dict(line=0,top=0,bottom=20,ink_left=-2,ink_right_exclusive=4,ink_pixels_outside_layout=1)]}
        edges,lines=ink_metrics(im,data);self.assertEqual(1,lines[0]['ink_pixels_outside_layout'])
        data['lines'][0]['ink_pixels_outside_layout']=0
        with self.assertRaises(ValueError):ink_metrics(im,data)
    def test_finite_canvas_edge_contact_is_checked(self):
        im=Image.new('RGBA',(164,84));im.putpixel((0,0),(0,0,0,255))
        data={'layout_width':100,'layout_height':20,'expanded_layout_margin_px':32,'expanded_canvas_edge_touch':dict(left=True,right=False,top=True,bottom=False),'lines':[dict(line=0,top=0,bottom=20,ink_left=None,ink_right_exclusive=None,ink_pixels_outside_layout=0)]}
        edges,_=ink_metrics(im,data);self.assertTrue(edges['left']);self.assertTrue(edges['top'])
        data['expanded_canvas_edge_touch']['left']=False
        with self.assertRaises(ValueError):ink_metrics(im,data)
    def test_sdk_suffix_and_failures_are_retained(self):
        with tempfile.TemporaryDirectory() as td:
            root=pathlib.Path(td);(root/'TEST-C.xml').write_text('<testsuite tests="2" failures="1" errors="0" skipped="0"><testcase classname="C" name="x"/><testcase classname="C" name="x[30]"><failure>synthetic</failure></testcase></testsuite>')
            result=junit_audit(root,[['C','x'],['C','x[30]']]);self.assertEqual('FAIL',result['status']);self.assertEqual([],result['missing']);self.assertEqual('x[30]',result['failures_and_errors'][0]['name'])
if __name__=='__main__':unittest.main(verbosity=2)
