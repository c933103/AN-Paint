# Independent PR55 diagnostic-artifact review

## Result

**JVM acceptance FAIL. Diagnostic evidence is complete and consistent. No visible clipping was demonstrated in the failing Ainu capture.** Do not relax the existing threshold or infer a production repair from this report.

Exact source/run binding, independently audited downloaded bytes:

- PR55 head: `dc46abc2add7984358565a88fe65c5278212dcf6`
- Tested synthetic merge: `56e7891852a2da201bf10ad99c486e659da2e6c5`
- Tree: `4ff7f479ffc73964fa8756b6c7e3202f624ad0f1`, 1,975 leaves
- Run: 38244193872, parent-verified source/merge relationship
- Regression artifact: 11746210615, SHA256 `eb01c308d55b0fde0da6375b7b3d774c8436f9b1b50137378c823b08f2f0e431`
- APK/source artifact: 11745795336, SHA256 `5082b9388879172277297b81524fab20642550114d0fa181d2162e46d466be04`

The old d802 first-run source, checks and artifacts were not modified or rebound.

## Exact JVM and render outcomes

All **890 expected class/method identities** ran, including exact SDK suffixes. **889 passed; one failed.** No skipped, missing, extra, duplicate, malformed or count-mismatched identity. Failure is still `CommonsMetadataQueryFailureFlowTest.shortLandscapeM04RetainsFullAccessibleTextAtNormalScale`.

All **28 normal-landscape diagnostic profiles** completed. Only **ain-Kana, copy, 640x320 DP, font 1.0** failed the original horizontal guard. There are **111/112 successful-render PNG/JSON pairs**; the single absent pair is that failed profile. Its separately labelled pre-check root, expanded raster and JSON are present, so no failed image is misrepresented as a passing capture.

All 2,210 extracted regression files match the digest-verified ZIP exactly. Success JSON matches exact message, Unicode controls, dimensions and new scroll schema. Diagnostic integrity PASS: independent recomputation from actual PNG alpha pixels agrees with every recorded line ink bound, outside-layout count and finite-canvas edge flag. Every original-guard boolean agrees with the unchanged formula. No expanded raster touches its outer canvas edge.

## Failing Ainu geometry: advance versus ink

Line 0:

- Layout/content width: 1,232 px
- Left advance: 0; right/max advance: 1,233.043 px
- Original permitted right bound: width+1 = 1,233 px
- Violation beyond that bound: approximately **0.043 px**
- Actual painted x range: **3 through 1,231 inclusive**, right-exclusive 1,232
- Actual ink pixels outside the layout: **0**

Line 1 also has no outside ink. Both lines have zero ellipsis. All 63 UTF-16 units remain laid out; full text matches the accessibility text. View/content height is sufficient, and the retained visible bounds include the full status view.

I inspected the actual failing root and expanded PNGs, plus a derived white-background view for contrast. The full two-line status is visible without an apparent lost glyph edge. A pixel comparison of the root's 1,232×82 content crop and the same expanded layout composited onto the actual background found a maximum difference of one color-channel level, with no pixel differing by more than one. This is a measured comparison, not a changed acceptance tolerance.

**Bounded inference:** this capture demonstrates a logical advance-width guard violation without corresponding out-of-layout painted ink. It does not establish why Android's line breaking and advance measurement differ, prove the oracle is universally invalid, or establish cross-device behavior. The original guard remains failed. No production, language or threshold change was made or recommended solely to make the job green.

For completeness, the two vertical emoji diagnostic profiles each contain one alpha pixel outside their logical layout width. They are not the failed profile, and the horizontal guard does not apply to their vertical route. Their presence is retained in the full measurements rather than generalized into an all-profiles zero-overflow claim. No new defect conclusion is drawn from that observation.

Actual failing image paths within the regression artifact:

- `Paintroid/build/reports/commons-metadata-m04-diagnostic/api35-ain-Kana-640x320-font1.0-copy-before-checks.png`
- `Paintroid/build/reports/commons-metadata-m04-diagnostic/api35-ain-Kana-640x320-font1.0-copy-before-checks-expanded-layout.png`

## Corrected vertical capture evidence

I inspected new enlarged Manchu and Mongolian success PNGs. They now show the left reading-start columns, and success JSON records scrollX=0. The source-bound JVM run passed the completed-reading-start assertions while retaining endpoint reachability checks. Only these sampled images, the failing raw pair and derived white view were directly inspected; no all 111-image visual acceptance is claimed.

## Unaffected checks

- PASS: actual Python 666 methods (194.696s), native build and lint phase receipts, all exit 0. JVM exit 1, 890 cases/one failure, 8m 19s. See `phase-results.json`.
- PASS: successor APK/build-info/source hashes, exact embedded source ZIP and all 1,972 included tracked blobs against immutable 4ff7 tree. Exactly the existing three source-bundle omissions; extras confined to the four existing native-source roots. All14 font-directory assets match source byte-for-byte, including M04 font SHA256 `6b70d3c5c146c9d11503e5dff7ade5e7ccb3ae5a70c511f71902d4a75f7a3006`.
- PASS: actual compiled M04 resource table contains exact default + 59 values plus generated mixed-script Korean alias, 61 configurations. Manchu U+180E positions 7/18/27 and Mongolian U+202F positions 7/17/30 are retained. No translation re-review.
- PASS: seven new exact-script probe logs, commands, outcomes/order, up-to-date and changed/restored XML hashes, wrapper/build hashes and source binding. Parent verified the exact-script ZIP digest; reviewer independently audited extracted receipt bytes and source.
- PASS: three synthetic successor-checker helper tests; these are checker tests, not application evidence.

## Tools and reproduction

`audit_successor_artifacts.py` requires the exact published head/merge/tree/run and digest receipt in `actual-binding.json`. It checks actual archive/extracted bytes, exact 890 identities, success schema, all 28 diagnostic profiles and alpha-pixel metrics. Its automated result does not substitute for pixel inspection or installed-device acceptance.

```sh
python3 audit_successor_artifacts.py --repo CHECKOUT --artifact REGRESSION.zip --extracted EXTRACTED --binding actual-binding.json --output successor-result.json
python3 make_ain_kana_forensic.py --diagnostics EXTRACTED/Paintroid/build/reports/commons-metadata-m04-diagnostic --output OUTPUT
python3 -m unittest -v test_successor_checker
```

Delivery/probe/compiled-resource scripts and full JSON results are included. `DELIVERY-FILES.json` excludes materialized APK/SDK binaries and caches. The white forensic PNG is explicitly derived; raw source PNG hashes are preserved.

## Remaining gates

The JVM result is not accepted, and a 112/112 successful-render claim is unavailable. Any next change requires a justified decision about the observed advance/ink discrepancy, preservation of historical failed evidence and a fresh exact-source run. Installed rendering, all-script shaping, signature/alignment/ABI/upgrade packaging and full release readiness were not assessed here. This report establishes no merge or release readiness.
