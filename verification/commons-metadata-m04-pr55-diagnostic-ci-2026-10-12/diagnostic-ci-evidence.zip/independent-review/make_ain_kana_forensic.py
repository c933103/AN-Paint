#!/usr/bin/env python3
"""Derived forensic visualization of retained pixels; never modifies raw evidence."""
import argparse,json,hashlib,pathlib
from PIL import Image

def main():
    p=argparse.ArgumentParser();p.add_argument('--diagnostics',type=pathlib.Path,required=True);p.add_argument('--output',type=pathlib.Path,required=True);a=p.parse_args()
    stem='api35-ain-Kana-640x320-font1.0-copy-before-checks';base=a.diagnostics;out=a.output;out.mkdir(parents=True,exist_ok=True)
    data=json.loads((base/(stem+'.json')).read_text());root=Image.open(base/(stem+'.png')).convert('RGBA');ink=Image.open(base/(stem+'-expanded-layout.png')).convert('RGBA')
    (out/'forensic').mkdir(exist_ok=True);white=Image.alpha_composite(Image.new('RGBA',ink.size,'white'),ink);white.save(out/'forensic/ain-kana-expanded-on-white.png')
    m=data['expanded_layout_margin_px'];w,h=data['layout_width'],data['layout_height'];x=data['window_x']+data['padding_left'];y=data['window_y']+data['padding_top']
    native=root.crop((x,y,x+w,y+h));background=root.getpixel((0,y));composed=Image.alpha_composite(Image.new('RGBA',(w,h),background),ink.crop((m,m,m+w,m+h)))
    deltas=[max(abs(a-b) for a,b in zip(native.getpixel((ix,iy)),composed.getpixel((ix,iy)))) for iy in range(h) for ix in range(w)]
    sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
    record={'root_png_sha256':sha(base/(stem+'.png')),'expanded_png_sha256':sha(base/(stem+'-expanded-layout.png')),'json_sha256':sha(base/(stem+'.json')),'native_status_content_crop_xywh':[x,y,w,h],'background_rgba':list(background),'compared_pixels':len(deltas),'pixels_with_any_channel_difference':sum(d>0 for d in deltas),'pixels_with_channel_difference_above_one':sum(d>1 for d in deltas),'maximum_channel_difference':max(deltas),'derived_white_background_image':'forensic/ain-kana-expanded-on-white.png','derived_image_sha256':sha(out/'forensic/ain-kana-expanded-on-white.png'),'limit':'Derived visualization composites original transparent pixels on white; raw files are unchanged. Crop comparison uses recorded layout placement and root background, not a new Android run or a changed acceptance threshold.'}
    (out/'ain-kana-pixel-comparison.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
if __name__=='__main__':main()
