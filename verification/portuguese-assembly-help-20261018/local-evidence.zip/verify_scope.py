from pathlib import Path
import json,subprocess,xml.etree.ElementTree as ET,sys,hashlib,stat,re
O=Path(__file__).resolve().parent; W=O/'source';sys.path.insert(0,str(W/'tools'))
from test_crop_counterpart_guidance import require_complete, HELP
base=json.loads((O/'base-tree.json').read_text());eng=json.loads((O/'english-tree-verified.json').read_text())
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
expected=json.loads((W/'Paintroid/src/test/resources/crop-counterparts/expected.json').read_text())['locales']['pt-PT']
path='Paintroid/src/main/res/values-b+pt+PT/strings.xml'
old=subprocess.check_output(['git','show','HEAD:'+path],cwd=W).decode();before=ET.fromstring(old);after=ET.parse(W/path).getroot()
try: require_complete(before,expected)
except ValueError as e: error=str(e)
else: raise AssertionError('Old value unexpectedly passed')
require_complete(after,expected)
for root in (before,after):root.find(f"./string[@name='{HELP}']").text='EXCLUDED_SINGLE_EDIT'
assert ET.tostring(before)==ET.tostring(after)
old_fixture=json.loads(subprocess.check_output(['git','show','HEAD:Paintroid/src/test/resources/crop-counterparts/expected.json'],cwd=W));new_fixture=json.loads((W/'Paintroid/src/test/resources/crop-counterparts/expected.json').read_text())
old_fixture['locales']['pt-PT']['help']=new_fixture['locales']['pt-PT']['help'];assert old_fixture==new_fixture
source_text=(W/path).read_text();pattern=rf'(<string name="{HELP}">)(.*?)(</string>)';om=re.search(pattern,old);nm=re.search(pattern,source_text)
assert old[:om.start(2)]+source_text[nm.start(2):nm.end(2)]+old[om.end(2):]==source_text
before_paragraphs=(O/'old-help.txt').read_text().strip().split('\n\n');after_paragraphs=(O/'new-help.txt').read_text().strip().split('\n\n')
assert len(before_paragraphs)==7 and len(after_paragraphs)==8
for oi,ni in ((0,0),(1,1),(3,4),(5,6),(6,7)):assert before_paragraphs[oi]==after_paragraphs[ni]
assert before_paragraphs[2].replace('A primeira imagem começa na origem.','Ao encaixar, a primeira imagem começa na origem.').replace('As sobreposições são rejeitadas.','As sobreposições são rejeitadas ao encaixar.')==after_paragraphs[2]
assert before_paragraphs[4].replace('As imagens seguintes preenchem o espaço e continuam colocadas.','As outras imagens continuam colocadas; as imagens ligadas podem deslocar-se para preencher o espaço.')==after_paragraphs[5]
changes=[]
for e in base['tree']:
 if e['type']!='blob':continue
 p=W/e['path'];b=p.read_bytes();actual=blob(b);mode='100755' if p.stat().st_mode&stat.S_IXUSR else '100644';assert mode==e['mode'],e['path']
 if actual!=e['sha']:changes.append({'path':e['path'],'mode':mode,'base_sha':e['sha'],'sha':actual})
assert len(changes)==5
receipt={'base':base['sha'],'base_tree':'38f4130f0452db1fab1477d0362cee0304d2fced','production_scope':'One pt-PT Help value only; every other production byte retained','paragraph_scope':'Five unchanged paragraphs plus three bounded corrections and the new Exact position paragraph','fixture_scope':'Only locales.pt-PT.help changed; crop plural and other locale fixtures identical','base_blobs_verified':1209,'executable_modes':'All preserved','old_value_negative_control':error,'changes':changes}
(O/'scope-and-negative-control.json').write_text(json.dumps(receipt,indent=2)+'\n')
bindings=[]
for name in ['AssemblyActivity.kt','AssemblyPlacementDialog.kt','ImageAssembly.kt']:
 p='Paintroid/src/main/java/org/catrobat/paintroid/classic/'+name;a=next(e['sha'] for e in base['tree'] if e['path']==p);b=next(e['sha'] for e in eng['tree'] if e['path']==p);assert a==b==blob((W/p).read_bytes());bindings.append({'path':p,'currentBlob':a,'englishReferenceBlob':b,'identical':True})
ref_blob=next(e['sha'] for e in eng['tree'] if e['path']=='Paintroid/src/main/res/values/strings.xml');assert ref_blob==blob((O/'source-reference-en.xml').read_bytes())
(O/'source-bindings.json').write_text(json.dumps({'base':base['sha'],'corrected_english_reference':eng['sha'],'reference_resource_blob':ref_blob,'consumers':bindings},indent=2)+'\n')
print(json.dumps(receipt,indent=2))
