# Independent review: European Portuguese assembly Help

## Verdict

**Accept the proposed value without required replacements.** All eight paragraphs were reviewed for meaning, European Portuguese wording, terminology, current resource labels, and source consumers. The four intended changes faithfully express the corrected English reference and do not weaken the existing crop, displayed-dimensions, output-memory, persistence, or attribution guidance.

This is an independent model linguistic review with source inspection. It is **not** native-speaker sign-off, an installed-app review, a rendering/accessibility test, or approval of the whole Portuguese catalogue. No production source was edited or published by this reviewer.

## Reviewed material and scope

- Project: c933103/AN-Paint, PR #75 Portuguese continuation.
- Proposed text: `new-help.txt`, SHA-256 `11d124d27cec513f2796b9f27004884fd28ad1c945495c57a7863cc37742a1cf` (UTF-8 file including final newline).
- Previous text: `old-help.txt`.
- Reference: `source-help-en.txt` and `source-reference-en.xml`, supplied corrected PR #122 English reference at `0d56dd970c22398f7fa032d1baee4a1b74c83f2b`.
- Source material: supplied develop snapshot identified as `3a88bfea`; reviewed the assembly activity, position dialog, model, crop dialog, normalization dialog, canvas, and relevant main-editor import/menu consumers.
- Locale checked: `Paintroid/src/main/res/values-b+pt+PT/strings.xml`, specifically European Portuguese. The separate `values-pt-rBR` catalogue is not the acceptance target.
- Resource: `ui_add_up_to_20_images_with_android_s`, consumed by `AssemblyActivity.showHelp()` (line 347).

All source paths below are relative to `Paintroid/src/main/java/org/catrobat/paintroid/classic/`, unless a resource path is explicitly given.

## Paragraph-by-paragraph review

### 1. Adding images, thumbnail tray, dimensions and sorting

Starts: “Adicione até 20 imagens com o seletor de ficheiros do Android.”

**Accept unchanged.** The 20-image limit, Android file picker, thumbnails, file names, dimensions after both crop and any width/height normalization, optional modification dates, and sorting without rearrangement are all retained. The long list remains understandable: “dimensões das imagens resultantes do recorte e de eventuais ajustes” correctly covers both transformations, rather than describing original dimensions or crop dimensions alone. “Ficheiros,” “seletor,” and the impersonal imperative register fit pt-PT. “Datas de modificação” is acceptable for the displayed date/time metadata and does not imply that a missing provider timestamp is invented.

Source check: `AssemblyActivity.kt:135–157` renders `placedSize`, names and optional formatted timestamps; `185–188, 207–215, 217–219` cover picker, metadata and the input limit. `ImageAssembly.kt:24–32, 56, 67–85` cover crop-plus-normalization dimensions, sorting as a returned list, and the 20-image cap.

No replacement required.

### 2. Selecting and cropping images

Starts: “Toque numa miniatura para a selecionar.”

**Accept unchanged.** The paragraph distinguishes single-image crop from selected-image batch crop, pixel and percentage margins, drag handles and numeric input, reset to original edges, and nondestructive/undoable edits. “Numa,” “para a selecionar,” “píxeis,” “percentagem,” and “introduza” are appropriate pt-PT forms. “Alças de recorte” is understandable technical wording; changing that inherited terminology is not necessary for this bounded correction. “Restaura as margens originais” conveys reset of the crop to the original image boundaries.

Actual labels match exactly: “Recortar imagem,” “Recorte em lote,” and “Repor recorte.” The actual reset label should remain “Repor recorte,” rather than being replaced with a regional or stylistic synonym.

Source check: `AssemblyActivity.kt:96, 143, 277–280`; `ImageCropDialog.kt:58, 69–108, 125–148`; `ImageAssembly.kt:39–49, 154–159, 233–238`. Batch selection is available within the crop dialog; the Help does not claim that every loaded image must be cropped.

No replacement required.

### 3. Snapping, previews, alignment, origin and overlap rejection

Starts: “Mantenha uma miniatura premida…”

**Accept the proposed changes.** The hold/drag/drop sequence, translucent snap preview, right attachment aligned at the top, bottom attachment aligned on the left, and thumbnail-then-“+” alternative are preserved. “Premida,” “largue-a,” “pré-visualização,” “encaixe,” and “ligadas” are clear and consistent with the surrounding pt-PT text.

“Ao encaixar, a primeira imagem começa na origem” correctly limits the origin statement to snapping. “As sobreposições são rejeitadas ao encaixar” likewise limits overlap rejection to snapping, so the new exact-position paragraph can truthfully allow overlap. Neither sentence incorrectly applies the snap constraints to every placement method. The intervening “podem deslocar-se” correctly expresses the conditional movement of attached images after their parent is cropped.

Source check: `AssemblyActivity.kt:143–149`; `AssemblyCanvas.kt:104–112, 118–129, 149–174`; `ImageAssembly.kt:160–162, 180–189, 197–231`. The model resolves right/bottom attachment alignment, starts an empty snapped assembly at (0,0), and separately validates snapped overlap.

No replacement required.

### 4. Exact position

Full proposed paragraph:

> Selecione uma imagem e use «Posição exata» para definir as coordenadas X/Y do seu canto superior esquerdo em números inteiros de píxeis, a partir de zero. As outras imagens mantêm as suas posições e são permitidas sobreposições.

**Accept as written.** It contains every required fact: image selection; the real action label; X/Y coordinates; the selected image’s top-left corner; whole-pixel, zero-based coordinates; unchanged positions for the other images; and permitted overlaps. “A partir de zero” correctly expresses nonnegative values in this context; it does not require placing the image at zero. “Em números inteiros de píxeis” is clear and consistent with the existing detailed position Help. “As suas posições” has an unambiguous antecedent in “As outras imagens.”

The actual toolbar and dialog label is **“Posição exata.”** The real validation message is **“X e Y têm de ser números inteiros entre 0 e 2147483647.”** The paragraph agrees with that validation without unnecessarily reproducing an implementation limit in the short overview. It does not promise that every pair up to that maximum can accommodate an image: the model additionally bounds the image’s right and bottom edges.

Source check: `AssemblyActivity.kt:87, 272–275`; `AssemblyPlacementDialog.kt:17–35, 64–65`; `ImageAssembly.kt:164–178, 203–215`. Exact placement detaches the selected image from snapping and freezes directly attached children at their old coordinates, preserving the positions of the remaining branches as well. Overlap is allowed for absolute placement.

No replacement required. No need to add stacking order, canvas expansion, or the full coordinate validation text to this paragraph to satisfy the corrected English overview.

### 5. Common width/height and restoring sizes

Starts: “«Mesma largura» e «Mesma altura»…”

**Accept unchanged.** The paragraph correctly describes a shared target dimension with each image’s own proportions preserved. It retains pixel/percentage entry, the smallest/largest presets, and removal of normalization without discarding crops. “Dimensão comum,” “preservando a proporção de cada uma,” and “mantém os recortes” are accurate and readable. “Normalização” is a suitable consistent technical term in this context.

All quoted labels match the pt-PT resources: “Mesma largura,” “Mesma altura,” “Menor,” “Maior,” and “Restaurar tamanhos originais.” The latter is the real action label even though the explanatory sentence correctly clarifies that crops remain.

Source check: `AssemblyActivity.kt:97–98, 268–270`; `NormalizeImagesDialog.kt:19–32, 50–70, 79–81`; `ImageAssembly.kt:24–32, 123–124`.

No replacement required.

### 6. Unplace/remove, undo/redo, rearrangement and view controls

Starts: “«Retirar» devolve apenas a imagem selecionada ao tabuleiro.”

**Accept the proposed change.** “As outras imagens continuam colocadas; as imagens ligadas podem deslocar-se para preencher o espaço” correctly separates retained placement from possible movement. It avoids the former blanket claim that following images always close the gap. The semicolon joins two complementary facts clearly, and “podem” preserves the important conditional meaning. “Retirar” versus “Remover” remains distinct: the former removes the selected placement, the latter removes that input from the assembly.

Undo/redo, dragging a placed image, panning in empty space, pinch zoom in both directions, and fitting the entire assembly without changing output dimensions remain covered. “Para a reorganizar,” “desloca a vista,” and “ampliar ou reduzir” are fluent pt-PT instructional phrasing. The quoted action names match the resources, including “Desfazer,” “Refazer” and “Mostrar tudo.”

Source check: `AssemblyActivity.kt:79–80, 99–101`; `ImageAssembly.kt:88–122, 237–238`. Unplacing an explicitly positioned image preserves attached branches at their old positions, while removing a snapped node may promote/reflow its branches. The qualified sentence covers both. `AssemblyCanvas.kt:29–32, 48–55, 149–174` confirms viewport-only zoom/pan/fit and drag placement.

No replacement required.

### 7. PNG output, editor transfer, memory, originals and persistence

Starts: “«Guardar PNG» guarda diretamente a imagem montada.”

**Accept unchanged.** Both real output labels are preserved. The text keeps the undoable replacement behavior when transferring to the main editor; the conditional smaller-output option; the special memory-warning path when even minimal output cannot fit; unchanged original files; and local reopening of the assembly. These qualifications must not be removed while editing the placement guidance.

“Guardar,” “mais pequena,” “aplicação,” “ficheiros,” and “quando regressar” are consistent pt-PT choices. “Se essa opção estiver disponível” prevents a false promise of a size chooser, and “em vez de um seletor de tamanho” accurately explains the source-memory-floor case. “Diretamente” distinguishes exporting from first transferring to the editor; it does not require bypassing Android’s destination picker.

Source check: `AssemblyActivity.kt:283–317, 319–343` selects normal output, a smaller-output dialog, or the memory-floor warning. `ClassicPaintActivity.kt:1235–1239, 1321–1324` imports an assembly result with `asEdit = true` for replacement. `ImageAssembly.kt:54–65, 233–268` stores project metadata and restores it on reopening; crop/placement changes do not overwrite original image files.

No replacement required.

### 8. Attribution and licence-panel location

Starts: “Este modo usa os mesmos créditos Catrobat/AGPL…”

**Accept unchanged.** The statement and panel path faithfully preserve the reference. “Créditos… de recursos” is understandable in the application’s existing attribution vocabulary. The actual labels “Ficheiro” and “Sobre, licenças e créditos” agree with the quoted path. The wording points to the existing shared notices; it does not introduce a new licence claim for user-imported images.

Source check: pt-PT `ui_menu_file` and `ui_about_credits23`; `ClassicPaintActivity.kt:827–836, 868–882`; `LegalInfo.kt:31–50`.

No replacement required.

## Exact edit accounting

The reviewed proposal makes only these four intended semantic edits to the previous value:

1. “A primeira imagem começa na origem.” → “Ao encaixar, a primeira imagem começa na origem.”
2. “As sobreposições são rejeitadas.” → “As sobreposições são rejeitadas ao encaixar.”
3. Insert the complete Exact position paragraph quoted in paragraph 4.
4. “As imagens seguintes preenchem o espaço e continuam colocadas.” → “As outras imagens continuam colocadas; as imagens ligadas podem deslocar-se para preencher o espaço.”

**Required additional replacements: none.** No optional stylistic rewrite is needed to accept this resource. Preserve the five other unchanged paragraphs and all remaining sentences in the two modified paragraphs.

## Verification limits

This conclusion applies only to this exact proposed Help value and the inspected source semantics/labels. It does not establish that an APK compiles, the resource is selected at runtime on a device, the Help fits the installed dialog, every glyph renders correctly, or the wider PR/catalogue is linguistically complete.

