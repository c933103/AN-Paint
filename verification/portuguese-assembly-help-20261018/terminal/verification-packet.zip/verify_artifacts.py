from pathlib import Path
import json,zipfile,hashlib,io,re,sys,xml.etree.ElementTree as ET
O=Path(__file__).resolve().parent;H=O/'hosted';H.mkdir(exist_ok=True)
PUB=json.loads((O/'publication.json').read_text());HEAD=PUB['head'];TREE=PUB['tree'];RUN=PUB['run_id']
ART=json.loads((O/'artifacts.json').read_text())
def artifact(prefix,filename):
 a=next(x for x in ART if x['name'].startswith(prefix));p=H/filename;digest=hashlib.sha256(p.read_bytes()).hexdigest()
 assert a['digest']=='sha256:'+digest
 assert a['workflow_run']['id']==RUN and a['workflow_run']['head_sha']==HEAD
 return a,zipfile.ZipFile(p),digest
def write(name,r):
 (H/name).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
kind=sys.argv[1]
if kind=='regression':
 a,z,digest=artifact('regression-','regression.zip');counts={k:0 for k in ('tests','failures','errors','skipped')};suites=[];affected=[]
 for n in z.namelist():
  if '/test-results/testDebugUnitTest/TEST-'not in n or not n.endswith('.xml'):continue
  root=ET.fromstring(z.read(n));assert root.tag=='testsuite';cases=root.findall('testcase');assert len(cases)==int(root.attrib['tests'])
  for k in counts:counts[k]+=int(root.attrib.get(k,0))
  assert not any(c.find(k)is not None for c in cases for k in ('failure','error','skipped')),n
  suites.append({'name':root.attrib['name'],'tests':len(cases)})
  if n.endswith('TEST-org.catrobat.paintroid.local.CropCounterpartGuidanceTest.xml'):
   (H/Path(n).name).write_bytes(z.read(n));affected=[{'name':c.attrib['name'],'seconds':float(c.attrib['time'])}for c in cases]
 source=(O/'source/Paintroid/src/test/java/org/catrobat/paintroid/local/CropCounterpartGuidanceTest.kt').read_text();expected=set(re.findall(r'@Test\s+fun\s+(\w+)\(',source))
 assert {c['name']for c in affected}==expected and counts['tests']>0 and all(counts[k]==0 for k in ('failures','errors','skipped'))
 write('junit-receipt.json',{'source_commit':HEAD,'source_tree':TREE,'artifact_id':a['id'],'artifact_name':a['name'],'artifact_sha256':digest,'run_id':RUN,'junit':counts,'suite_count':len(suites),'affected_source_methods':len(expected),'affected_methods':affected})
elif kind=='build':
 a,z,digest=artifact('apk-and-source-','apk-and-source.zip');info=json.loads(z.read('build/delivery/build-info.json'));apk=z.read('app/build/outputs/apk/debug/app-debug.apk');src=z.read('build/delivery/AN-Paint-source.zip');binding=json.loads((O/'ci-checkout-binding.json').read_text())
 assert info['commit']==binding['pr_checkout'] and int(info['run_id'])==RUN
 assert hashlib.sha256(apk).hexdigest()==info['apk_sha256'] and hashlib.sha256(src).hexdigest()==info['source_sha256']
 with zipfile.ZipFile(io.BytesIO(apk)) as az:
  candidates=[n for n in az.namelist()if n.endswith('.zip') and 'source' in n.lower()];assert len(candidates)==1,candidates;assert az.read(candidates[0])==src
 tree=json.loads((O/'remote-tree.json').read_text());entries=[e for e in tree['tree']if e['type']=='blob'];matched=[];missing=[]
 with zipfile.ZipFile(io.BytesIO(src)) as sz:
  for e in entries:
   name='AN-Paint/'+e['path']
   if name not in sz.namelist():missing.append(e['path']);continue
   b=sz.read(name);assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==e['sha'],e['path']
   assert ('100755' if (sz.getinfo(name).external_attr>>16)&0o100 else '100644')==e['mode'],e['path'];matched.append(e['path'])
 assert sorted(missing)==['.gitignore','.idea/codeStyles/Project.xml','colorpicker/.gitignore']
 write('build-info.json',info);write('build-binding.json',{'commit':info['commit'],'run_id':RUN,'artifact_id':a['id'],'artifact_sha256':digest,'apk_sha256':info['apk_sha256'],'source_sha256':info['source_sha256'],'hashes_match_build_info':True,'embedded_source_matches_corresponding_archive':True,'reviewed_tree':tree['sha'],'signing':info['signing'],'tracked_source_files_examined':len(entries),'matched_payload_files':len(matched),'archive_omissions':missing,'scope':'Exact source/payload binding only; CI debug key, no upgrade-signature or installed Portuguese acceptance.'})
elif kind=='exact':
 a,z,digest=artifact('exact-script-','exact-script.zip');name=next(n for n in z.namelist()if n.endswith('summary.json'));r=json.loads(z.read(name));binding=json.loads((O/'ci-checkout-binding.json').read_text())
 assert r['success'] and r['tree']==TREE and r['commit']==binding['pr_checkout'] and len(r['probes'])==9
 for p in r['probes']:
  assert p['exit_code']==0
  n=next(n for n in z.namelist() if n.endswith(p['name']+'.log'));assert hashlib.sha256(z.read(n)).hexdigest()==p['log_sha256']
 write('exact-script-summary.json',r)
elif kind=='device':
 a,z,digest=artifact('emulator-api-35-','combined.zip');R=O/'combined-extracted'
 for n in z.namelist():
  p=Path(n);assert not p.is_absolute() and '..'not in p.parts
 z.extractall(R);sys.path.insert(0,str(O/'source/tools'))
 from app_instrumentation_matrix import verify_app_reports,read_app_reports
 from run_android_instrumentation import declared_tests,source_tests_sha256
 appsource=O/'source/app/src/androidTest';native=O/'source/Paintroid/src/androidTest';selected=declared_tests(appsource,sdk_level=35)
 app=verify_app_reports(selected,35,read_app_reports(R,35),source_tests_sha256(appsource),declared_tests(appsource)-selected)
 assert app['success'] and app['inventory_validated'] and app['completed_tests']==len(selected)
 n=json.loads((R/'Paintroid/androidTest-results/summary.json').read_text());assert n['success'] and n['returncode']==0 and not n['timed_out'] and not any(n[k]for k in ('missing','unexpected','errors'));assert n['source_tests_sha256']==source_tests_sha256(native)
 cases={(t['classname'],t['name'])for t in n['cases']};assert cases==declared_tests(native,sdk_level=35);assert all(t['status']=='passed'for t in n['cases']) and len(cases)==len(n['cases'])
 identity=json.loads((R/'composed-device-identity.json').read_text());build=json.loads((H/'build-binding.json').read_text());assert identity['commit']==build['commit'] and int(identity['run_id'])==RUN;assert identity['apk_sha256']==build['apk_sha256'] and identity['source_sha256']==build['source_sha256'] and identity['source_tests_sha256']==source_tests_sha256(appsource);assert identity['device_sdk']==35 and identity['build_variant']=='debug'
 reports=[]
 for p in sorted(R.rglob('summary.json')):
  if 'androidTest-results'not in p.parts and 'accepted-credit-restart'not in p.parts:continue
  r=json.loads(p.read_text());assert r['success'] and not r['timed_out'] and not any(r[k]for k in ('missing','unexpected','errors'));reports.append({'path':str(p.relative_to(R)),'expected':r['expected_tests'],'completed':r['completed_tests'],'seconds':r['elapsed_seconds']})
 write('app-inventory-reverified.json',app);write('device-receipt.json',{'commit':identity['commit'],'run_id':RUN,'attempt':identity['composed_in_run_attempt'],'artifact_id':a['id'],'artifact_sha256':digest,'identity':identity,'reports':reports,'native_completed':len(cases),'app_completed':len(selected),'source_bound_app_inventory_reverified':True,'capture_review':'Not independently revalidated in this bounded Help correction; ordinary hosted gates retained unchanged.','limits':['No independent visual acceptance of ordinary-language captures','No installed Portuguese or TalkBack acceptance']})
else:raise ValueError(kind)
