#!/usr/bin/env bash
set -euo pipefail
O="$(cd "$(dirname "$0")" && pwd)"
W="$O/../source"
R="$O/combined-extracted"
mkdir -p "$O/reverified"
python3 "$W/tools/dialog_evidence_transport.py" "$R/dialog-export" --dialog-summary "$R/app-dialog/androidTest-results/summary.json" --output "$O/reverified/dialog" --receipt "$O/hosted/dialog-reverified.json" > "$O/hosted/dialog-reverified.log" 2>&1
python3 "$W/tools/vertical_evidence_transport.py" "$R/vertical-locale-export" --output "$O/reverified/vertical" --receipt "$O/hosted/vertical-reverified.json" --sdk 35 > "$O/hosted/vertical-reverified.log" 2>&1
python3 "$W/tools/vertical_locale_matrix.py" verify-screenshots "$O/reverified/vertical" --output "$O/hosted/vertical-screenshots-reverified.json" > "$O/hosted/vertical-screenshots-reverified.log" 2>&1
