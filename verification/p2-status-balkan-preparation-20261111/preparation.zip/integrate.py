import copy,hashlib,json,pathlib,re,subprocess,sys,unicodedata
import xml.etree.ElementTree as E
sys.path.insert(0,'tools');import translation_catalogues as c
w=pathlib.Path('/workspace/shared/anpaint-p2-status-balkan-evidence');p=json.load(open(w/'inputs.json'));r=json.load(open(w/'review.json'));values=r['final_accepted_map']
assert subprocess.check_output(['git','status','--porcelain'],text=True)==''
assert subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip()==p['base_tree']
source={n.get('name'):n for n in E.parse(c.RES/'values/strings.xml').getroot()}
tiers={k:t['id'] for t in json.load(open('translations/string-importance.json'))['tiers'] for k in t['keys']}
plan=json.load(open(w/'held-blob-plan.json'));blobs=json.load(open(w/'held-blobs.json'))
for sha,txt in blobs.items():
 raw=txt.encode();assert hashlib.sha1(f'blob {len(raw)}\0'.encode()+raw).hexdigest()==sha
 keys={n.get('name') for n in E.fromstring(txt)}
 for pair in plan[sha]:
  tag=next(t for t,path in p['paths'].items() if path==pair['path']);assert not keys&set(p['missing_keys'][tag])
def node(n):
 n=copy.deepcopy(n);n.tail=None;return E.tostring(n,encoding='unicode')
summary={}
for tag,accepted in values.items():
 path=pathlib.Path(p['paths'][tag]);assert path==c.catalogue_paths()[tag].relative_to(c.ROOT)
 assert set(accepted)<=set(p['missing_keys'][tag]);old=path.read_text();before=E.fromstring(old);oldnodes={n.get('name'):node(n) for n in before}
 additions=[]
 for k,v in accepted.items():
  assert k not in oldnodes;assert tiers['string/'+k]=='P2'
  assert p['source'][k]=={'text':source[k].text,'attributes':source[k].attrib}
  assert v and v==unicodedata.normalize('NFC',v) and not any(unicodedata.category(x).startswith('C') for x in v)
  assert c.placeholders(v)==c.placeholders(source[k].text)
  assert not c.android_string_errors(v) and not c.format_string_errors(v,source[k].get('formatted')!='false')
  assert any(re.search(r'R\.string\.'+re.escape(k)+r'\b',f.read_text()) for f in pathlib.Path('Paintroid/src/main/java').rglob('*.kt'))
  n=E.Element('string',source[k].attrib);n.text=v;additions.append('    '+E.tostring(n,encoding='unicode')+'\n')
 final=old.replace('</resources>',''.join(additions)+'</resources>');after=E.fromstring(final);nodes={n.get('name'):n for n in after}
 assert len(nodes)==len(after)==len(before)+len(accepted)
 assert all(node(nodes[k])==v for k,v in oldnodes.items())
 assert all(nodes[k].text==v and nodes[k].attrib==source[k].attrib for k,v in accepted.items())
 path.write_text(final)
 summary[tag]={'path':str(path),'old_nodes_preserved':len(before),'new_values':len(accepted),'blob':subprocess.check_output(['git','hash-object',str(path)],text=True).strip()}
summary['accepted_map_sha256']=hashlib.sha256(json.dumps(values,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest();summary['total_new_values']=sum(map(len,values.values()))
(w/'integration.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False,indent=2))
