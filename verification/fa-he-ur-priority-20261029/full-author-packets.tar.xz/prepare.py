from pathlib import Path
import json,hashlib,re,subprocess,xml.etree.ElementTree as E
P=Path(__file__).parent;R=P/'repo';out=P/'packets';out.mkdir(exist_ok=True)
head=subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip();tree=subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD^{tree}'],text=True).strip()
def nodes(p):return {n.tag+'/'+n.get('name'):n for n in E.parse(p).getroot() if n.get('name')}
def val(n):return None if n is None else {'attributes':dict(n.attrib),'value':n.text if n.tag=='string' else {c.get('quantity'):c.text for c in n}}
en=nodes(R/'Paintroid/src/main/res/values/strings.xml');tiers=json.loads((R/'translations/string-importance.json').read_text())['tiers'];prio={k:t['id'] for t in tiers if t['id'] in ['P0','P1']for k in t['keys']}
files={str(p.relative_to(R)):p.read_text().splitlines()for p in (R/'Paintroid/src/main').rglob('*') if p.suffix in ('.kt','.java','.xml') and ('/res/values' not in str(p))}
cons={};pattern=re.compile(r'(?:R\.(string|plurals)\.|@(string|plurals)/)([A-Za-z0-9_]+)')
for path,lines in files.items():
 for i,line in enumerate(lines):
  for m in pattern.finditer(line):
   k=(m[1] or m[2])+'/'+m[3];a=max(0,i-6);b=min(len(lines),i+7)
   cons.setdefault(k,[]).append({'path':path,'line':i+1,'start_line':a+1,'end_line':b,'text':'\n'.join(lines[a:b])})
companions=['ui_top','ui_width_in','ui_height_in','ui_trim_in_pixels','ui_trim_in_percent','formats22_at_least_frames','ui_save','ui_cancel','ui_apply','ui_brush','ui_eraser','ui_watercolor','ui_eyedropper','ui_copy','ui_done','ui_new_image','ui_pixel','ui_percent']
extra={k for k in en if k.split('/')[1]in companions or k=='plurals/ui_crop_preview_images'}-set(prio)
for tag,folder in [('fa','values-fa'),('he','values-iw'),('ur','values-ur')]:
 path=f'Paintroid/src/main/res/{folder}/strings.xml';current=nodes(R/path)
 def row(k,t):return {'identity':k,'tier':t,'english':val(en[k]),'current':val(current.get(k)),'direct_consumers':cons.get(k,[]),'candidate':None,'decision':'unreviewed','prior_acceptance':None}
 d={'source_commit':head,'source_tree':tree,'locale':tag,'catalogue_path':path,'catalogue_sha256':hashlib.sha256((R/path).read_bytes()).hexdigest(),'limits':['Author source packet only, no linguistic acceptance yet. All material wording needs independent review.','No native-human, installed UI, TalkBack or whole-language certification.','No matching full fa/he/ur receipt in 60354 index; narrower outside-priority receipts remain separate.'],'priority_rows':[row(k,t)for k,t in prio.items()],'companions':[row(k,'P2-companion')for k in sorted(extra)]}
 (out/f'{tag}-complete-packet.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 print(tag,len(d['priority_rows']),len(d['companions']),sum(x['current']is not None for x in d['priority_rows']),sum(bool(x['direct_consumers'])for x in d['priority_rows']),d['catalogue_sha256'])
(out/'source-consumers.json').write_text(json.dumps(cons,ensure_ascii=False,indent=2)+'\n')
with (P/'source-priority.tsv').open('w')as f:
 for i,(k,t)in enumerate(prio.items()): f.write(f'{i}\t{t}\t{k}\t{json.dumps(val(en[k])["value"],ensure_ascii=False)}\n')
