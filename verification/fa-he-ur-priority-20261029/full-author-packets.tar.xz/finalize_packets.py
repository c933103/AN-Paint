from pathlib import Path
import json,re,hashlib,xml.etree.ElementTree as E
P=Path(__file__).parent;R=P/'repo';C=json.loads((P/'companions.json').read_text());cons=json.loads((P/'packets/source-consumers.json').read_text())
def ns(path):return {n.tag+'/'+n.get('name'):n for n in E.parse(path).getroot() if n.get('name')}
def value(n):return None if n is None else {'attributes':dict(n.attrib),'value':n.text if n.tag=='string'else{c.get('quantity'):c.text for c in n}}
def raw(v):return {k:raw(x)for k,x in v.items()}if isinstance(v,dict)else '"'+v.replace('\n','\\n').replace('"','\\"')+'"'
ph=re.compile(r'%(?:\d+\$)?[-#+ 0,(]*\d*(?:\.\d+)?[a-zA-Z%]')
def signature(s):return sorted(ph.findall(s))
en=ns(R/'Paintroid/src/main/res/values/strings.xml');holds={6,68,69,70,71,207,235,263};summary={}
for tag in ['fa','he','ur']:
 f=P/'packets'/f'{tag}-complete-packet.json';d=json.loads(f.read_text());rows=d['priority_rows'];current=ns(R/d['catalogue_path']);cs={}
 for l in (P/f'{tag}-candidates.tsv').read_text().splitlines():
  i,v=l.split('\t',1);i=int(i);assert i not in cs,(tag,i);cs[i]=v
 for i,r in enumerate(rows):
  if i in holds:
   r.update(candidate=None,decision='hold-present-unchanged'if r['current']else'hold-absent',rationale='No direct production consumer found; operational state/composition or referent is not established. Preserve existing raw text or fallback.');continue
  r['candidate']=raw(cs[i])if i in cs else r['current']['value']
  assert signature(r['candidate'])==signature(r['english']['value']),(tag,i,signature(r['candidate']),signature(r['english']['value']))
  r['decision']='author-proposal-awaiting-independent-review'if i in cs else'author-retain-awaiting-independent-review'
  r['review_limit']='Direct static consumer'if r['direct_consumers']else'Wording only; no direct consumer found, not runtime acceptance'
  r['candidate_attributes']=r['current']['attributes']if r['current']else r['english']['attributes']
 d['companions']=[]
 for key,v in C[tag].items():
  identity=('plurals/'if isinstance(v,dict)else'string/')+key;n=en[identity];r={'identity':identity,'tier':'P2-companion','english':value(n),'current':value(current.get(identity)),'candidate':raw(v),'candidate_attributes':n.attrib,'direct_consumers':cons.get(identity,[]),'decision':'author-proposal-awaiting-independent-review','rationale':'Finite dependency for complete dimension/crop, GIF/dither/lossless, frame lower-bound or nested memory composition.'}
  for s in (r['candidate'].values()if isinstance(v,dict)else[r['candidate']]):assert signature(s)==signature(next(iter(r['english']['value'].values()))if isinstance(v,dict)else r['english']['value']),(tag,key)
  d['companions'].append(r)
 d['status']='Full author candidate inventory; independent linguistic and complete consumer review pending. Unapplied.'
 d['base_movement']='Pinned246f is preceding verified develop, not current develop. Parent reports72f987 adds only instrumentation+host guard. Rebind to final combined integration source before production application.'
 d['prior_receipt_reconciliation']='No full fa/he/ur receipts in8a960dea60354 index. Zero accepted priority entries mapped there. Historical Hebrew one outside-priority receipt remains separate; no reset/withdrawn or partial receipt promoted.'
 f.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
 summary[tag]={'priority':len(rows),'companions':len(d['companions']),'proposals':sum(r['decision'].startswith('author-proposal')for r in rows),'retained_for_review':sum(r['decision'].startswith('author-retain')for r in rows),'holds':[r['identity']for r in rows if r['decision'].startswith('hold')],'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
(P/'packets/summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False,indent=2))
