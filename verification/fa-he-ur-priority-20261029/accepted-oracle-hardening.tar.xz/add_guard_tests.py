from pathlib import Path
r=Path('/workspace/scratch/bbca2890f602/nordic-fa-he-ur-bound');p=r/'tools/test_persian_hebrew_urdu_priority_wording.py';s=p.read_text().replace('NAME,TAGS,current_row','NAME,TAGS,require_reviewed_fixture,reviewed_fixture,validated_fixture_text,current_row').replace('cls.data=fixture(NAME);','cls.data=require_reviewed_fixture(fixture(NAME));');point="if __name__=='__main__':unittest.main()";s=s.replace(point,'''    def test_coordinated_targets_xml_display_and_metadata_cannot_replace_accepted_values(self):
        import persian_hebrew_urdu_priority_expectations as current
        for tag,locale in self.data['locales'].items():
            for key in locale['accepted']:
                bad=deepcopy(self.data);bad['locales'][tag]['accepted'][key]+=' forged'
                # Matching altered XML is insufficient: independent accepted row refuses it.
                with self.subTest(tag=tag,key=key),patch.object(current,'fixture',return_value=bad),self.assertRaises(ValueError):current.current_row(tag,key)
            for field in ('predecessors','changed','held_absent','held_present','target_attribute_exceptions','priority_dispositions','preserved_unreviewed','review_receipt_sha256'):
                bad=deepcopy(self.data);del bad['locales'][tag][field]
                with self.subTest(tag=tag,field=field),self.assertRaises(ValueError):require_reviewed_fixture(bad)
            bad=deepcopy(self.data);del bad['locales'][tag]['predecessors']['string/ui_apply']
            with self.assertRaises(ValueError):require_reviewed_fixture(bad)
            bad=deepcopy(self.data);bad['locales'][tag]['display']={'save20_unsupported_image_colour':'forged'}
            with self.assertRaises(ValueError):require_reviewed_fixture(bad)
        raw=(cat.ROOT/'tools/fixtures/current_localization'/NAME).read_text()
        self.assertEqual(self.data,validated_fixture_text(raw))
        for corrupted in (raw+' ',raw.replace('sRGB','forgedRGB',1)):
            with self.assertRaises(ValueError):validated_fixture_text(corrupted)
        copy=reviewed_fixture();copy['locales']['fa']['accepted']['ui_apply']='forged'
        self.assertNotEqual(copy,reviewed_fixture())
'''+point);p.write_text(s)
p=r/'Paintroid/src/test/java/org/catrobat/paintroid/local/PersianHebrewUrduPriorityWordingTest.kt';s=p.read_text();i=s.rfind('\n}');s=s[:i]+'''
    @Test fun finiteAcceptedFixtureRejectsCoordinatedTargetsMetadataAndMissingPredecessors() {
        val helper=PersianHebrewUrduPriorityExpectations
        for(tag in listOf("fa","he","ur")) {
            for(mutation in listOf("target","display","attributes","receipt","held","previous")) {
                val bad=helper.fixture();val locale=bad.getJSONObject("locales").getJSONObject(tag)
                when(mutation) {
                    "target" -> locale.getJSONObject("accepted").put("save20_unsupported_image_colour","Forged sRGB PNG")
                    "display" -> locale.put("display",JSONObject().put("save20_unsupported_image_colour","Forged sRGB PNG"))
                    "attributes" -> locale.getJSONObject("target_attribute_exceptions").put("save20_unsupported_image_colour",JSONObject().put("name","wrong"))
                    "receipt" -> locale.put("review_receipt_sha256","forged")
                    "held" -> locale.remove("held_absent")
                    "previous" -> locale.getJSONObject("predecessors").remove("string/ui_apply")
                }
                val expected=JSONObject()
                assertThrows("$tag/$mutation",AssertionError::class.java) {helper.addTagged(expected,bad)}
                assertEquals(0,expected.length())
            }
        }
        val expected=JSONObject();helper.addTagged(expected,helper.fixture())
        assertEquals(setOf("fa","he","ur"),expected.keys().asSequence().toSet())
        assertThrows(AssertionError::class.java) {helper.addTagged(expected,helper.fixture())}
    }
'''+s[i:];p.write_text(s)
