from pathlib import Path
r=Path('/workspace/scratch/bbca2890f602/nordic-fa-he-ur-bound');p=r/'tools/persian_hebrew_urdu_priority_expectations.py';s=p.read_text();needle="TAGS=frozenset({'fa','he','ur'})";s=s.replace(needle,'''# Only the finite independently accepted wording fixture, not source files or trees.
FIXTURE_SHA256='1a6c04bd3d34965bb6aa12de7924d308bfdebcc80e5dd81032a8569f707839ac'
def validated_fixture_text(text):
    import hashlib,json
    if hashlib.sha256(text.encode('utf-8')).hexdigest()!=FIXTURE_SHA256:
        raise ValueError('Complete finite accepted FA/HE/UR fixture differs')
    return json.loads(text)
from functools import lru_cache
@lru_cache(maxsize=1)
def _baseline():
    from pathlib import Path
    return validated_fixture_text((Path(__file__).resolve().parent/'fixtures/current_localization'/NAME).read_text())
def require_reviewed_fixture(data):
    if data!=_baseline():raise ValueError('Accepted complete values or metadata differ')
    return data
def reviewed_fixture():
    return deepcopy(_baseline())
'''+needle);s=s.replace("d=fixture(NAME);loc=","d=require_reviewed_fixture(fixture(NAME));loc=");s=s.replace("l=fixture(NAME)['locales'][tag]","l=require_reviewed_fixture(fixture(NAME))['locales'][tag]");p.write_text(s)
peer=Path('/workspace/scratch/bbca2890f602/seasia-si-my-za-20261029/Paintroid/src/test/java/org/catrobat/paintroid/local/SinhalaBurmeseZhuangPriorityExpectations.kt').read_text();s=peer.replace('SinhalaBurmeseZhuang','PersianHebrewUrdu').replace('sinhala_burmese_zhuang','persian_hebrew_urdu').replace('92c0f8eadd3374f82d8761fce44cff52bdd889f22d7cf7453f7172da20960388','1a6c04bd3d34965bb6aa12de7924d308bfdebcc80e5dd81032a8569f707839ac').replace('SI/MY replacement and bounded ZA','FA/HE/UR').replace('listOf("si","my")','listOf("fa","he","ur")').replace('getJSONObject(key)\n        assertEquals','getJSONObject("string/$key")\n        assertEquals').replace('source.getString("value")','source.getString("source")').replace('assertTrue(locale.getJSONObject("predecessors").isNull(key))','assertFalse(locale.getJSONObject("predecessors").has("string/$key"))')
s=s.replace('''            assertEquals(setOf("name"),locale.getJSONObject("attributes").getJSONObject(key).keys().asSequence().toSet())
            assertEquals(key,locale.getJSONObject("attributes").getJSONObject(key).getString("name"))''','''            assertFalse(locale.getJSONObject("target_attribute_exceptions").has(key))''')
(r/'Paintroid/src/test/java/org/catrobat/paintroid/local/PersianHebrewUrduPriorityExpectations.kt').write_text(s)
p=r/'Paintroid/src/test/java/org/catrobat/paintroid/local/PersianHebrewUrduPriorityWordingTest.kt';s=p.read_text().replace('JSONObject(File("../tools/fixtures/current_localization/persian_hebrew_urdu_priority_wording.json").readText()).getJSONObject("locales")','PersianHebrewUrduPriorityExpectations.fixture().getJSONObject("locales")');p.write_text(s)
p=r/'Paintroid/src/test/java/org/catrobat/paintroid/local/TaggedColourImportTest.kt';s=p.read_text();a=s.index('        val rtlPriority=JSONObject(');b=s.index('        assertEquals(exactScriptStageTags + combinedAddedTags + setOf("fa","he","ur")',a);s=s[:a]+'''        PersianHebrewUrduPriorityExpectations.addTagged(expected,PersianHebrewUrduPriorityExpectations.fixture())
'''+s[b:];p.write_text(s)
