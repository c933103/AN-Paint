from pathlib import Path
r=Path('/workspace/scratch/bbca2890f602/nordic-fa-he-ur-bound');p=r/'tools/test_current_localization_contracts.py';s=p.read_text().replace("TAGGED_COLOUR_INHERITED_CATALOGUES = {'ca-ES-valencia': 'ca'}","TAGGED_COLOUR_INHERITED_CATALOGUES = {'ca-ES-valencia': 'ca', 'fa-IR': 'fa'}")
s=s.replace('''    data = tagged_colour_expectations(data)
    if not (set(TAGGED_COLOUR_INHERITED_CATALOGUES) |''','''    data = tagged_colour_expectations(data)
    if TAGGED_COLOUR_INHERITED_CATALOGUES != {'ca-ES-valencia':'ca', 'fa-IR':'fa'}:
        raise ValueError('Finite tagged-colour parent mapping differs')
    if not (set(TAGGED_COLOUR_INHERITED_CATALOGUES) |''')
s=s.replace("self.assertEqual({'ca-ES-valencia': 'ca'}, TAGGED_COLOUR_INHERITED_CATALOGUES)","self.assertEqual({'ca-ES-valencia': 'ca', 'fa-IR': 'fa'}, TAGGED_COLOUR_INHERITED_CATALOGUES)")
# Direct missing count remains20; English-only count excludes one actual parent.
lines=s.splitlines()
for i,line in enumerate(lines):
 if 'self.assertEqual(94-len('in line and 'set(TAGGED_COLOUR_INHERITED_CATALOGUES)-BO_DZ_VAL_TAGS' in line:lines[i]=line.replace('self.assertEqual(94-len(','self.assertEqual(93-len(',1)
s='\n'.join(lines)+'\n'
needle='    def test_explicit_scope_and_open_fallbacks_match_current_picker(self):'
s=s.replace(needle,'''    def test_persian_regional_inheritance_is_not_direct_or_english_acceptance(self):
        from unittest.mock import patch
        data=current_tagged_colour_data()
        strings={tag:catalogues.read_strings(path) for tag,path in paths().items()}
        offered=set(catalogues.offered_tags());english=strings['default'][TAGGED_COLOUR_KEY]
        self.assertNotIn('fa-IR',data);self.assertNotIn(TAGGED_COLOUR_KEY,strings['fa-IR'])
        self.assertEqual(fa_he_ur_display('fa',TAGGED_COLOUR_KEY),data['fa'])
        require_tagged_colour_resolution(data,strings,offered,english)
        for override in (strings['fa'][TAGGED_COLOUR_KEY],english,'invented direct acceptance'):
            changed={**strings,'fa-IR':{**strings['fa-IR'],TAGGED_COLOUR_KEY:override}}
            with self.assertRaises(ValueError):require_tagged_colour_resolution(data,changed,offered,english)
        with self.assertRaises(ValueError):require_tagged_colour_resolution({**data,'fa-IR':data['fa']},strings,offered,english)
        for parent in ('he','ur','missing'):
            with patch.dict(TAGGED_COLOUR_INHERITED_CATALOGUES,{'fa-IR':parent}),self.assertRaises(ValueError):
                require_tagged_colour_resolution(data,strings,offered,english)
        for missing in ('fa','fa-IR'):
            with self.assertRaises(ValueError):require_tagged_colour_resolution(data,strings,offered-{missing},english)

'''+needle);p.write_text(s)
p=r/'Paintroid/src/test/java/org/catrobat/paintroid/local/TaggedColourImportTest.kt';s=p.read_text().replace('val inheritedCatalogues = historicalInheritedCatalogues.filterKeys { it != "ca-ES-valencia" }','val inheritedCatalogues = historicalInheritedCatalogues.filterKeys { it != "ca-ES-valencia" } + mapOf("fa-IR" to "fa")\n        assertEquals(mapOf("fa-IR" to "fa"),inheritedCatalogues)')
s=s.replace('''        val expectedFallbacks = 171 - expected.length()
        assertEquals(20, expectedFallbacks)''','''        assertFalse(expected.has("fa-IR")) // no regional direct wording acceptance
        assertEquals(20, 171 - expected.length()) // direct absences include the parent-inherited option
        val expectedFallbacks = 171 - expected.length() - inheritedCatalogues.size
        assertEquals(19, expectedFallbacks)''').replace('assertEquals(0, inherited)','assertEquals(1, inherited)').replace('// 171 offered - 151 direct; no inherited catalogue.','// 171 offered - 151 direct - 1 explicitly parent-inherited.')
p.write_text(s)
