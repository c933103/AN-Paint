from pathlib import Path
import json,hashlib,xml.etree.ElementTree as E,re,copy
P=Path(__file__).parent;R=P/'repo';I=Path('/tmp/seasia-priority-20261029/peer-fa-he-ur');out=P/'accepted-integration';out.mkdir(exist_ok=True)
def ns(path):return {n.tag+'/'+n.get('name'):n for n in E.parse(path).getroot()if n.get('name')}
def val(n):return {'attributes':dict(n.attrib),'value':n.text if n.tag=='string'else{c.get('quantity'):c.text for c in n}}
en=ns(R/'Paintroid/src/main/res/values/strings.xml');fixture={'schema_version':1,'scope':'Independently reviewed FA HE UR complete priority values and16 finite companions; not whole-language/native-human acceptance.','sources':{},'locales':{}};summary={}
for tag in ['fa','he','ur']:
 d=json.loads((P/'packets'/f'{tag}-complete-packet.json').read_text());b=(I/f'{tag}-complete-independent-review.json').read_bytes();rev=json.loads(b);assert rev['packet_sha256']==hashlib.sha256((P/'packets'/f'{tag}-complete-packet.json').read_bytes()).hexdigest();assert len(rev['rows'])==357
 current=ns(R/d['catalogue_path']);submitted={r['identity']:r for r in d['priority_rows']+d['companions']}
 l={'path':d['catalogue_path'],'accepted':{},'plurals':{},'predecessors':{},'changed':[],'held_absent':[],'held_present':{},'target_attribute_exceptions':{},'priority_dispositions':{},'preserved_unreviewed':{},'review_receipt_sha256':hashlib.sha256(b).hexdigest()};scope=set();replacements={}
 for row in rev['rows']:
  k=row['identity'];typ,key=k.split('/');old=current.get(k);author=submitted[k]
  assert row['reviewed_source']==val(en[k]);assert row['reviewed_current']==(val(old)if old is not None else None);assert row['reviewed_proposed']==author['candidate'],(tag,k,'proposal')
  if row['tier'] in('P0','P1'):l['priority_dispositions'][key]={'tier':row['tier'],'status':row['decision'],'limit':row['confidence']}
  if row['decision']=='hold':
   if old is None:l['held_absent'].append(key)
   else:l['held_present'][key]=val(old)
   continue
  assert row['decision']in('accept','revise');target=row['accepted_or_replacement_value'];attrs=row['attributes'];scope.add(k)
  fixture['sources'][k]={'source':row['reviewed_source']['value'],'attributes':row['reviewed_source']['attributes'],'type':typ}
  if typ=='string':l['accepted'][key]=target
  else:l['plurals'][key]={'target':target,'attributes':attrs}
  if old is not None:l['predecessors'][k]={'target':val(old)['value'],'attributes':old.attrib}
  if attrs!={'name':key}:l['target_attribute_exceptions'][key]=attrs
  if old is None or val(old)!={'attributes':attrs,'value':target}:
   l['changed'].append(k);n=E.Element(typ,attrs)
   if typ=='string':n.text=target
   else:
    for q,s in target.items():E.SubElement(n,'item',{'quantity':q}).text=s
   E.indent(n,space='    ');replacements[k]=E.tostring(n,encoding='unicode')
 for k,n in current.items():
  if k not in scope:l['preserved_unreviewed'][k]={'target':val(n)['value'],'attributes':n.attrib}
 text=(R/d['catalogue_path']).read_text()
 for k,xml in replacements.items():
  typ,key=k.split('/');pattern=rf'<{typ}\b[^>]*\bname="{re.escape(key)}"[^>]*>.*?</{typ}>'
  if k in current:text,n=re.subn(pattern,lambda m:xml,text,flags=re.S);assert n==1,(tag,k,n)
  else:text=text.replace('</resources>','    '+xml.replace('\n','\n    ')+'\n</resources>')
 dest=out/d['catalogue_path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(text)
 after=ns(dest);assert set(after)==set(current)|scope
 for k in scope:
  key=k.split('/')[1];target=l['accepted'][key]if k.startswith('string/')else l['plurals'][key]['target'];assert val(after[k])['value']==target
 for k,v in l['preserved_unreviewed'].items():assert val(after[k])=={'value':v['target'],'attributes':v['attributes']}
 l['held_absent'].sort();fixture['locales'][tag]=l
 summary[tag]={'changes':len(l['changed']),'additions':sum(k not in current for k in l['changed']),'replacements':sum(k in current for k in l['changed']),'priority':len(l['priority_dispositions']),'companion':16,'holds':len(l['held_absent'])+len(l['held_present']),'source_production_unchanged':True}
(out/'persian_hebrew_urdu_priority_wording.json').write_text(json.dumps(fixture,ensure_ascii=False,indent=2)+'\n');(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
