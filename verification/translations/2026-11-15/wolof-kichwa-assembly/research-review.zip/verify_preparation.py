import pathlib,json,hashlib,subprocess
r=pathlib.Path(__file__).resolve().parent;c=r/'checkout';base=json.loads((r/'reconciliation.json').read_text())['base'];assert subprocess.check_output(['git','-C',str(c),'rev-parse','HEAD'],text=True).strip()==base
result={}
for file in ['wo-proposals.json','qug-proposals.json']:
 p=json.loads((r/file).read_text());assert p.get('source_commit',p.get('base'))==base
 hashes=dict(p.get('source_hashes',{})); checked=[];bounds=[]
 if 'catalogue_path' in p:hashes[p['catalogue_path']]=p['catalogue_sha256']
 if 'english_sha256' in p:hashes['Paintroid/src/main/res/values/strings.xml']=p['english_sha256']
 for v in p['proposals']:
  anchors=v.get('source_anchors',[])+v.get('canonical_anchors',[])+v.get('consumer_anchors',[])+v.get('producer_boundary_anchors',[])+([v['english_anchor']] if 'english_anchor' in v else [])
  for a in anchors:
   path=c/a['path'];lines=path.read_text().splitlines();start=a.get('line',(a.get('lines')or[None])[0]);end=(a.get('lines')or[start,start])[-1];assert 1<=start<=end<=len(lines);text='\n'.join(lines[start-1:end])
   if 'sha256'in a:assert hashes.setdefault(a['path'],a['sha256'])==a['sha256']
   if 'code'in a:assert text.strip()==a['code'].strip(),(file,v['key'],a)
   checked.append({'path':a['path'],'start':start,'end':end,'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
 for a in p.get('producer_boundaries',[]):
  path=c/a['path'];lines=path.read_text().splitlines();raw=a['lines'];ranges=[]
  if isinstance(raw,str):
   for part in raw.replace('–','-').replace('—','-').split(','):
    nums=[int(x.strip())for x in part.split('-')];assert len(nums)in[1,2];ranges.append((nums[0],nums[-1]))
  else:
   assert len(raw)==2;ranges=[tuple(raw)]
  snippets=[]
  for start,end in ranges:
   assert 1<=start<=end<=len(lines);snippets.append({'start':start,'end':end,'code':'\n'.join(lines[start-1:end])})
  bounds.append({**a,'verified_ranges':snippets,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
 for path,h in hashes.items():assert hashlib.sha256((c/path).read_bytes()).hexdigest()==h,(path,h)
 result[file]={'proposal_sha256':hashlib.sha256((r/file).read_bytes()).hexdigest(),'source_hashes_verified':hashes,'anchor_ranges_verified':len(checked),'anchor_records':checked,'producer_boundaries':bounds}
(r/'proposal-reconciliation.json').write_text(json.dumps({'base':base,'packets':result,'result':'pass'},ensure_ascii=False,indent=2)+'\n');print({f:{'hashes':len(v['source_hashes_verified']),'anchors':v['anchor_ranges_verified'],'producer_ranges':len(v['producer_boundaries'])}for f,v in result.items()})
