import pathlib,json,sys,subprocess,hashlib,unicodedata,xml.etree.ElementTree as ET,collections,re
from xml.sax.saxutils import escape,quoteattr
r=pathlib.Path(__file__).resolve().parent;c=r/'checkout';base=json.loads((r/'reconciliation.json').read_text())['base'];read=lambda f:json.loads((r/f).read_text())
assert subprocess.check_output(['git','-C',str(c),'rev-parse','HEAD'],text=True).strip()==base
assert not subprocess.check_output(['git','-C',str(c),'status','--porcelain'],text=True)
sys.path.insert(0,str(c/'tools'));import translation_catalogues as t,string_importance as si
pairs=read('review-pairs.json');props=[];reviews=[];anchors=consumers=0;review_hashes={}
for pf,rf in pairs:
 p=read(pf);v=read(rf);expected_hash=v.get('proposal_sha256',v.get('packet_sha256'));assert expected_hash and hashlib.sha256((r/pf).read_bytes()).hexdigest()==expected_hash
 ps=p.get('proposals',p.get('entries',p.get('corrections')));vs=v['reviews'];pm={(x['locale'],x['key']):x for x in ps};assert len(pm)==len(ps)==len(vs)
 for q in vs:
  x=dict(pm[q['locale'],q['key']]);x['value']=x.get('value',x.get('proposed_value'));x['operation']='replace' if x.get('old_value') is not None else 'add';x['source_anchors']=x.get('source_anchors',[])+([x['english_anchor']] if 'english_anchor' in x else [])+x.get('canonical_anchors',[])
  assert q['english']==x['english'] and q.get('proposed',q.get('proposed_value'))==x['value'];assert q['decision'] in ['accept','revise','defer','reject'];assert (q['final_value'] is None)==(q['decision'] in ['defer','reject'])
  aa=[]
  if x['operation']=='replace':
   cat=t.catalogue_paths()[x['locale']];assert t.read_strings(cat)[x['key']]==x['old_value']==q['old_value']
   x['source_anchors']=x['source_anchors']+[{'path':cat.relative_to(c).as_posix(),'key':x['key'],'value':x['old_value'],'line':next(i+1 for i,line in enumerate(cat.read_text().splitlines()) if f'name="{x["key"]}"' in line)}]
  for a in x['source_anchors']:
   a=dict(a);a['line']=a.get('line',(a.get('lines') or [None])[0]);path=c/a['path'];line=path.read_text().splitlines()[a['line']-1]
   if 'key' in a:
    current=t.read_strings(path)[a['key']];packet_value=a.get('value',current);quoted=current.startswith(chr(34)) and current.endswith(chr(34)) and current[1:-1]==packet_value;assert (packet_value==current or quoted) and a['key'] in line;a['packet_value']=packet_value;a['packet_display_form_without_enclosing_Android_quotes']=quoted;a['value']=current
   else:
    assert hashlib.sha256(path.read_bytes()).hexdigest()==p.get('source_hashes',{}).get(a['path'],a.get('sha256'));assert line.strip();a['code']=line.strip()
   aa.append(a);anchors+=1
  x['source_anchors']=aa;ca=[]
  for a in x['consumer_anchors']:
   a=dict(a);a['line']=a.get('line',(a.get('lines') or [None])[0]);code=a.get('code',a.get('text'));assert (c/a['path']).read_text().splitlines()[a['line']-1].strip()==code.strip();a['code']=code;ca.append(a);consumers+=1
  x['consumer_anchors']=ca;x['consumer_classification']='active' if ca else 'catalogue-only';props.append(x);reviews.append(q)
 review_hashes[rf]=hashlib.sha256((r/rf).read_bytes()).hexdigest()
assert len({(x['locale'],x['key']) for x in props})==len(props)
revised=[x for x in reviews if x['decision']=='revise']
if revised:
 assessments=read('revision-assessments.json')['assessments'];am={(x['locale'],x['key']):x for x in assessments if x['decision']=='agree'};assert len(am)==len(revised)
 for x in revised:assert am[x['locale'],x['key']]['final_value']==x['final_value']
accepted=[x for x in reviews if x['decision'] in ['accept','revise']];withheld=[x for x in reviews if x['decision'] in ['defer','reject']];pm={(x['locale'],x['key']):x for x in props}
default={n.get('name'):n for p in (t.RES/'values').glob('*.xml') for n in ET.parse(p).getroot() if n.tag=='string'};tiers={k:v['id'] for v in si.load_manifest()['tiers'] for k in v['keys']}
def sig(n):return n.tag,tuple(sorted(n.attrib.items())),n.text,tuple(sig(x) for x in n)
result={};planned={}
for locale in sorted({x['locale'] for x in accepted}):
 path=t.catalogue_paths()[locale];rel=path.relative_to(c).as_posix();before=subprocess.check_output(['git','-C',str(c),'show',f'{base}:{rel}']);assert path.read_bytes()==before;old=ET.fromstring(before);oldkeys={n.get('name') for n in old};rows=sorted((x for x in accepted if x['locale']==locale),key=lambda x:x['key']);lines=[];text=before.decode();changed=[]
 for x in rows:
  key=x['key'];value=x['final_value'];d=default[key];prop=pm[locale,key];assert x['english']==t.default_resources()[0][key]
  assert value==unicodedata.normalize('NFC',value) and t.placeholders(value)==t.placeholders(x['english']) and not t.android_string_errors(value) and not t.format_string_errors(value,formatted=d.get('formatted')!='false');assert value.count('\\n')==x['english'].count('\\n')
  if prop['operation']=='add':
   assert key not in oldkeys and tiers['string/'+key] in ['P2','P3'];attrs={k:v for k,v in d.attrib.items() if k!='translatable'};lines.append('    <string '+' '.join(k+'='+quoteattr(v) for k,v in attrs.items())+'>'+escape(value)+'</string>')
  else:
   assert key in oldkeys and t.read_strings(path)[key]==prop['old_value'];pattern=r'(<string\b[^>]*\bname="'+re.escape(key)+r'"[^>]*>).*?(</string>)';text,n=re.subn(pattern,lambda m:m[1]+escape(value)+m[2],text,flags=re.S);assert n==1;changed.append(key)
 assert text.count('</resources>')==1
 if lines:text=text.replace('</resources>','\n'+'\n'.join(lines)+'\n</resources>')
 new=ET.fromstring(text);assert len(new)==len(old)+len(lines)
 for i,node in enumerate(old):
  if node.get('name') in changed:
   assert node.tag==new[i].tag and node.attrib==new[i].attrib and new[i].text==next(x['final_value'] for x in rows if x['key']==node.get('name')) and len(new[i])==0
  else:assert sig(node)==sig(new[i])
 result[locale]={'path':rel,'added':len(lines),'corrected_existing':len(changed),'corrected_keys':changed,'old_elements':len(old),'old_elements_preserved':len(old)-len(changed),'total':len(new),'sha256':hashlib.sha256(text.encode()).hexdigest()}
 planned[path]=text
# Apply only after every locale has passed preflight, preserving the original clean base until then.
for path,text in planned.items():path.write_text(text)
active=sum(pm[x['locale'],x['key']]['consumer_classification']=='active' for x in accepted);added=[x for x in accepted if pm[x['locale'],x['key']]['operation']=='add'];repaired=[x for x in accepted if pm[x['locale'],x['key']]['operation']=='replace']
out={'base':base,'review_pairs':pairs,'source_anchors_revalidated_at_base':anchors,'consumer_anchors_revalidated':consumers,'proposed_unique_keys':len(props),'accepted':len(accepted),'accepted_unchanged_from_proposal':sum(x['decision']=='accept' for x in accepted),'revised':len(revised),'withheld':withheld,'new_values':len(added),'corrected_existing_values':len(repaired),'active_changed':active,'catalogue_only_changed':len(accepted)-active,'new_active':sum(pm[x['locale'],x['key']]['consumer_classification']=='active' for x in added),'new_catalogue_only':sum(pm[x['locale'],x['key']]['consumer_classification']!='active' for x in added),'resource_tiers_changed':dict(collections.Counter(tiers['string/'+x['key']] for x in accepted)),'applied':result,'review_file_sha256':review_hashes,'limits':['Original proposal/review files remain unchanged. Raw canonical anchor and display-quote representations are recorded separately.','Individual deferrals remain excluded; inventory gaps are not whole-value linguistic findings or a language-wide hold.','Model/source review is not native-human, whole-language or exhaustive installed-layout/TalkBack acceptance.','All existing holds, #422 approval operation, #330 and Work-side tasks remain untouched.']}
for name,data in [('normalized-proposals.json',{'proposals':props}),('accepted-values.json',accepted),('applied-review.json',out)]: (r/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
print(out)
