import pathlib,json,hashlib,subprocess,xml.etree.ElementTree as ET
r=pathlib.Path(__file__).resolve().parent;c=r/'checkout'
read=lambda f:json.loads((r/f).read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=read('reconciliation.json')['base'];assert subprocess.check_output(['git','-C',str(c),'rev-parse','HEAD'],text=True).strip()==base
assert not subprocess.check_output(['git','-C',str(c),'status','--porcelain'],text=True)
p=read('quh-next-proposals.json');v=read('quh-next-review.json');assert v['packet_sha256']==sha(r/'quh-next-proposals.json')
for path,h in p['source_sha256'].items():assert sha(c/path)==h,path
vm={(x['locale'],x['key']):x for x in v['reviews']};assert len(vm)==len(p['proposals'])==2
normalized=[];checked=[]
for x0 in p['proposals']:
 x=dict(x0);q=vm[x['locale'],x['key']];assert q['decision']=='accept' and x['english']==q['english'] and x['proposed_value']==q['proposed']==q['final_value']
 anchors=[x['canonical_source_anchor'],*x['canonical_same_variety_anchors']]
 for a in [*anchors,*x['consumer_anchors']]:
  path=c/a['path'];line=path.read_text().splitlines()[a['line']-1];assert line==a['code']
  if 'key'in a:
   node=next(n for n in ET.parse(path).getroot()if n.get('name')==a['key']);assert ''.join(node.itertext())==a['value']
  checked.append({'path':a['path'],'line':a['line'],'sha256':sha(path),'kind':'canonical'if'key'in a else'consumer'})
 x['source_anchors']=anchors;x['value']=x['proposed_value'];normalized.append(x)
provenance={'original_proposal':'quh-next-proposals.json','original_proposal_sha256':sha(r/'quh-next-proposals.json'),'original_review':'quh-next-review.json','original_review_sha256':sha(r/'quh-next-review.json'),'validated_base':base,'normalization':'Structural source_sha256/source_hashes, canonical singular/list/source_anchors and proposed_value/value aliases only. Original complete values and review decisions preserved unchanged.'}
np={**p,'proposals':normalized,'source_hashes':p['source_sha256'],'normalization_provenance':provenance}
(r/'quh-normalized-proposals.json').write_text(json.dumps(np,ensure_ascii=False,indent=2)+'\n')
nv={**v,'packet_sha256':sha(r/'quh-normalized-proposals.json'),'normalization_provenance':provenance}
(r/'quh-normalized-review.json').write_text(json.dumps(nv,ensure_ascii=False,indent=2)+'\n')
(r/'original-review-pairs.json').write_text(json.dumps([['shn-next-proposals.json','shn-next-review.json'],['quh-next-proposals.json','quh-next-review.json']],indent=2)+'\n')
(r/'review-pairs.json').write_text(json.dumps([['shn-next-proposals.json','shn-next-review.json'],['quh-normalized-proposals.json','quh-normalized-review.json']],indent=2)+'\n')
boundaries=[]
for path,start,end in [('Paintroid/src/main/java/org/catrobat/paintroid/classic/AssemblyRenderer.kt',23,37),('Paintroid/src/main/java/org/catrobat/paintroid/classic/AssemblyRenderer.kt',50,52),('Paintroid/src/main/java/org/catrobat/paintroid/classic/AssemblyActivity.kt',323,335),('Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt',1253,1257),('Paintroid/src/main/java/org/catrobat/paintroid/classic/EditorNavigation.kt',14,14)]:
 assert sha(c/path)==p['source_sha256'][path]
 boundaries.append({'path':path,'start':start,'end':end,'sha256':sha(c/path),'text':'\n'.join((c/path).read_text().splitlines()[start-1:end])})
out={'result':'pass','provenance':provenance,'source_hashes_verified':p['source_sha256'],'anchors':checked,'additional_explicit_producer_ranges':boundaries,'range_provenance':'Explicit current-source ranges read to substantiate original producer prose; original author/review packets unchanged.'}
(r/'quh-preparation-reconciliation.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print({'result':'pass','canonical':sum(x['kind']=='canonical'for x in checked),'consumer_lines':sum(x['kind']=='consumer'for x in checked),'explicit_producer_ranges':len(boundaries)})
