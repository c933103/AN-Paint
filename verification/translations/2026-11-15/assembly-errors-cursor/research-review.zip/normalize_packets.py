import pathlib,json,hashlib,subprocess,re
r=pathlib.Path(__file__).resolve().parent;c=r/'checkout';read=lambda f:json.loads((r/f).read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();base=read('reconciliation.json')['base'];assert subprocess.check_output(['git','-C',str(c),'rev-parse','HEAD'],text=True).strip()==base
pairs=read('original-review-pairs.json');out=[];checks=[];corrections=read('source-anchor-normalizations.json')['corrections']
for pf,rf in pairs:
 p=read(pf);v=read(rf);assert v.get('proposal_sha256',v.get('proposal_packet_sha256',v.get('packet_sha256')))==sha(r/pf)
 for path,h in p.get('source_hashes',{}).items():assert sha(c/path)==h,(pf,path)
 ps=p.get('proposals',p.get('entries'));vs=v.get('reviews',v.get('decisions'));assert len(ps)==len(vs);vm={(x['locale'],x['key']):x for x in vs};normalized=[];reviewed=[];verified=[]
 for x0 in ps:
  x=dict(x0);q0=vm[x['locale'],x['key']];q=dict(q0);decision=q['decision'];decision={'accepted':'accept','revised':'revise','deferred':'defer'}.get(decision,decision);assert decision in ['accept','revise','defer','reject'];value=x.get('proposed_value',x.get('value'));final=q.get('final_value',q.get('accepted_value'));assert (final is None)==(decision in ['defer','reject'])
  if decision=='accept':assert final==value
  for k in ['proposed','proposed_value','submitted_value']:
   if k in q:assert q[k]==value
  if 'english'in q:assert q['english']==x['english']
  anchors=x.get('source_anchors',[])+x.get('canonical_anchors',[])+x.get('canonical_source_anchors',[])+([x['english_anchor']]if'english_anchor'in x else[])
  for a in anchors+x.get('consumer_anchors',[])+x.get('producer_boundaries',[])+x.get('producer_anchors',[])+p.get('producer_boundaries',[]):
   lines=(c/a['path']).read_text().splitlines();ranges=[]
   if 'sha256'in a:assert sha(c/a['path'])==a['sha256']
   if 'lines'in a:
    if isinstance(a['lines'],str):
     for part in a['lines'].replace('–','-').replace('—','-').replace(';',',').split(','):
      nums=[int(n.strip())for n in part.split('-')];assert len(nums)in[1,2];ranges.append((nums[0],nums[-1]))
    else:ranges=[tuple(a['lines'])]
   else:ranges=[(a['line'],a.get('end_line',a['line']))]
   for start,end in ranges:
    assert 1<=start<=end<=len(lines)
    if 'code'in a:
     current='\n'.join(lines[start-1:end]).strip()
     if current!=a['code'].strip():
      matches=[z for z in corrections if z['proposal_file']==pf and z['path']==a['path'] and z['start']==start and z['end']==end and z['original_code']==a['code']]
      assert len(matches)==1,(pf,x['key'],a['path'],start)
      fix=matches[0];assert current==fix['exact_full_code'].strip() and sha(c/a['path'])==fix['source_sha256'] and a['code'] in current
    verified.append({'path':a['path'],'start':start,'end':end,'sha256':sha(c/a['path'])})
  x['source_anchors']=anchors;x.pop('canonical_anchors',None);x.pop('canonical_source_anchors',None);x.pop('english_anchor',None);x['value']=value;normalized.append(x)
  reviewed.append({**q,'locale':x['locale'],'key':x['key'],'english':x['english'],'proposed':value,'decision':decision,'final_value':final})
 stem=pf.removesuffix('-proposals.json');npf=stem+'-normalized-proposals.json';nrf=stem+'-normalized-review.json'
 provenance={'original_proposal':pf,'original_proposal_sha256':sha(r/pf),'original_review':rf,'original_review_sha256':sha(r/rf),'authored_source_commit':p.get('source_commit',p.get('base')),'validated_current_base':base,'normalization':'Only structural field aliases and explicit key/hash-derived English/proposed columns; no wording or decision changed.'}
 np={**p,'proposals':normalized,'normalization_provenance':provenance};(r/npf).write_text(json.dumps(np,ensure_ascii=False,indent=2)+'\n');nr={'proposal_sha256':sha(r/npf),'reviews':reviewed,'normalization_provenance':provenance};(r/nrf).write_text(json.dumps(nr,ensure_ascii=False,indent=2)+'\n');out.append([npf,nrf]);checks.append({**provenance,'source_hashes_verified':p.get('source_hashes',{}),'verified_ranges':verified,'normalized_proposal_sha256':sha(r/npf),'normalized_review_sha256':sha(r/nrf)})
(r/'review-pairs.json').write_text(json.dumps(out,indent=2)+'\n');(r/'proposal-reconciliation.json').write_text(json.dumps({'base':base,'result':'pass','packets':checks},ensure_ascii=False,indent=2)+'\n');print({'pairs':len(out),'ranges':sum(len(x['verified_ranges'])for x in checks),'result':'pass'})
