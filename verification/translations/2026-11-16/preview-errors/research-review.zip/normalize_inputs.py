import pathlib,json,hashlib,subprocess,xml.etree.ElementTree as ET
r=pathlib.Path(__file__).resolve().parent;c=r/'checkout';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda f:json.loads((r/f).read_text())
base=read('reconciliation.json')['base'];assert subprocess.check_output(['git','-C',str(c),'rev-parse','HEAD'],text=True).strip()==base;assert not subprocess.check_output(['git','-C',str(c),'status','--porcelain'],text=True)
pairs=read('original-review-pairs.json');normalized_pairs=[];all_anchors=[];all_consumers=[];all_ranges=[];provenance=[]
for pf,rf in pairs:
 p=read(pf);v=read(rf);key='proposal_sha256'if'proposal_sha256'in v else'packet_sha256';assert v[key]==sha(r/pf)
 hashes=p.get('source_hashes',p.get('source_sha256',p.get('file_sha256')));assert isinstance(hashes,dict)
 for path,h in hashes.items():assert sha(c/path)==h,path
 vm={(q['locale'],q['key']):q for q in v['reviews']};assert len(vm)==len(p['proposals']);normalized=[]
 for x0 in p['proposals']:
  x=dict(x0);q=vm[x['locale'],x['key']];value=x.get('value',x.get('proposed_value'));assert value==q.get('proposed',q.get('proposed_value')) and x['english']==q['english'];assert q['decision'] in ['accept','revise','defer','reject']
  anchors=x.get('source_anchors',[])+([x['english_anchor']]if'english_anchor'in x else[])+x.get('same_variety_anchors',[])
  for a in anchors:
   path=c/a['path'];line=path.read_text().splitlines()[a['line']-1];assert a['key'] in line
   node=next(n for n in ET.parse(path).getroot()if n.get('name')==a['key']);assert ''.join(node.itertext())==a['value']
   if 'code'in a:assert a['code']==line
   all_anchors.append({'locale':x['locale'],'key':x['key'],'anchor':a})
  consumers=x.get('consumer_anchors',[x['runtime_consumer']]if'runtime_consumer'in x else[]);assert consumers
  for a in consumers:
   if'line'not in a:a={**a,'line':a['start']};assert a.get('end',a['line'])==a['line']
   assert (c/a['path']).read_text().splitlines()[a['line']-1]==a['code'];assert 'R.string.'+x['key'] in a['code'];all_consumers.append({'locale':x['locale'],'key':x['key'],'anchor':a})
  x['consumer_anchors']=[z['anchor']for z in all_consumers if z['locale']==x['locale'] and z['key']==x['key']]
  boundaries=x.get('producer_boundaries',[]);ranges=(boundaries if isinstance(boundaries,list) else [])+([x['producer_range']]if'producer_range'in x else[])+p.get('producer_ranges',[])
  assert isinstance(ranges,list)
  for a in ranges:
   lo=a.get('start_line',a.get('start'));hi=a.get('end_line',a.get('end'));assert '\n'.join((c/a['path']).read_text().splitlines()[lo-1:hi])==a['code'];all_ranges.append({'locale':x['locale'],'key':x['key'],'path':a['path'],'start':lo,'end':hi,'code':a['code'],'sha256':sha(c/a['path'])})
  x['source_anchors']=anchors;x.pop('english_anchor',None);x.pop('same_variety_anchors',None);x['value']=value;normalized.append(x)
 prefix=normalized[0]['locale'];npf=prefix+'-normalized-proposals.json';nrf=prefix+'-normalized-review.json';prov={'original_proposal':pf,'original_proposal_sha256':sha(r/pf),'original_review':rf,'original_review_sha256':sha(r/rf),'validated_base':base,'normalization':'Schema-only source hash aliases, canonical anchor consolidation, runtime-consumer singular/list and line/start aliases; values and review decisions unchanged. Original packets retained exactly.'};provenance.append(prov)
 (r/npf).write_text(json.dumps({**p,'source_hashes':hashes,'proposals':normalized,'normalization_provenance':prov},ensure_ascii=False,indent=2)+'\n');(r/nrf).write_text(json.dumps({**v,key:sha(r/npf),'normalization_provenance':prov},ensure_ascii=False,indent=2)+'\n');normalized_pairs.append([npf,nrf])
(r/'review-pairs.json').write_text(json.dumps(normalized_pairs,indent=2)+'\n');out={'result':'pass','base':base,'provenance':provenance,'canonical_anchor_occurrences':all_anchors,'runtime_consumer_occurrences':all_consumers,'production_ranges':all_ranges,'unique_runtime_source_lines':len({(a['anchor']['path'],a['anchor']['line'])for a in all_consumers}),'scope':'No application change; original packets exact, semantic decisions retained. Repeated source anchors are per-locale review bindings, not distinct consumers or repeated test coverage.'};(r/'preparation-reconciliation.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print({'result':'pass','packets':len(pairs),'canonical_occurrences':len(all_anchors),'runtime_bindings':len(all_consumers),'unique_runtime_lines':out['unique_runtime_source_lines'],'producer_ranges':len(all_ranges)})
