# Status/control preparation while PR #431 qualifies

This is preparation only on pending #431 head 4fc57f167505dc99ea4088466ff1564ae0c17616, tree b1dda28cc02cdecdfb81a7c28037bee99f58a01e. No new application branch/PR. Each of the four offered canonical catalogues has eight missing active status/control values. All 32 candidates are absent from eight immutable held heads across 32 head/catalogue pairs. Only missing values may be added; all old nodes/attributes must remain.

The complete source and candidate values are in inputs.json and candidate.json. The actual consumers were read at this source:

- ImageResizeDialog.kt:26–58 and AssemblyActivity.kt:303–312. The budget is available working memory. The status is conditional on the existing memory policy, not a guarantee of successful decoding or saving.
- SaveOptionsDialog.kt:76–91. Lossless mode is a checkbox labelled with the current format name through the single positional %1$s string argument. It does not mean a free or smaller file.
- AssemblyActivity.kt:184–197. Files/Documents guidance follows failure of ACTION_OPEN_DOCUMENT and its ACTION_GET_CONTENT fallback. Names are descriptive with the source English labels retained; Android vendor labels may vary. No promise that enabling one always fixes access.
- MediaGalleryActivity.kt:331–347. The whole download URL must satisfy the provider policy. Rejection can include non-host aspects; translations must not reduce this to a host-only restriction. The other error is exhaustion of the bounded redirect loop, not evidence of an outage or compromised provider.
- AssemblyActivity.kt:151–157. Unavailable time replaces a missing image modification timestamp. It does not refer to waiting time or a timeout.
- ClassicPaintActivity.kt:776 and 818–826. Pixel tapping belongs to the colour-picker instruction. Tool option is the single-choice setting dialog title.
- AssemblyActivity.kt:88 and output flow. Edit in Paint names the Paint editing action, not an export format.

Surrounding terminology: Valencian eina, píxel, memòria and existing polite Toqueu/Activeu; Asturian ferramienta, píxel, memoria and existing singular Toca/Activa; Occitan aisina, pixèl, memòria and polite Tocatz/Activatz; Basque tresna, pixel, memoria with existing Ukitu/Gaitu. These catalogue values supply context, not linguistic approval. Files/Documents source labels are retained, with Android vendor-name variability. No external primary source consulted.

Independent full-value review is needed: accept, revise or hold, preserving full URL-policy scope and distinguishing generic tool setting from tool selection. No native-human/UI/glyph/layout/speech/device claim. All older holds/rechecks and explicit restrictions remain unchanged. Publication must wait for #431 qualification plus a fresh develop/owner/held-head reconciliation.
