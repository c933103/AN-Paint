import json,zipfile,hashlib,re,xml.etree.ElementTree as ET
from pathlib import Path
P=Path(__file__).parent
old=zipfile.ZipFile(P.parent/'pr235-dc713/regression.zip');new=zipfile.ZipFile(P/'regression.zip')
def suites(z):
 paths=sorted(n for n in z.namelist() if '/test-results/' in n and '/TEST-' in n and n.endswith('.xml'))
 rows=[]
 for n in paths:
  root=ET.fromstring(z.read(n))
  assert all(root.attrib[k]=='0' for k in ('failures','errors','skipped')),(n,root.attrib)
  cases=list(root.iter('testcase')); assert len(cases)==int(root.attrib['tests'])
  for c in cases:
   assert not list(c);rows.append(c.attrib)
 ids=sorted((r['classname'],r['name']) for r in rows)
 assert len(ids)==len(set(ids))
 return paths,rows,ids
op,oc,oi=suites(old);np,nc,ni=suites(new)
assert op==np and oi==ni and len(ni)==1958 and len(np)==197
corrected=[c for c in nc if c['name']=='realFillThresholdAndInteriorShapeChoicePreserveDocumentAndForegroundAlpha'];assert len(corrected)==1
phases={}
for phase in ('python','jvm','lint'):
 prefix='build/reports/ci-phases/'+phase
 t=dict(line.split('=',1) for line in new.read(prefix+'.time').decode().splitlines());assert t['exit_status']=='0'
 for suffix in ('.started-at','.ended-at'): assert new.read(prefix+suffix).strip()
 if phase!='lint':
  lifecycle=dict(line.split('=',1) for line in new.read(prefix+'.lifecycle').decode().splitlines())
  assert lifecycle['launch_id']==new.read(prefix+'.owner').decode().strip()
  assert {k:v for k,v in lifecycle.items() if k!='launch_id'}=={'reason':'completed','forced_kill':'false','owned_children_remaining':'0','cleanup_complete':'true','output_complete':'true'}
  t['lifecycle']=lifecycle
 phases[phase]=t
log=new.read('build/reports/ci-phases/python.log').decode()
m=re.search(r'Ran (\d+) tests in ([0-9.]+)s\s+OK \(skipped=(\d+)\)',log);assert m,m
assert (int(m[1]),int(m[3]))==(2045,2)
lint=ET.fromstring(new.read('app/build/reports/lint-results-debug.xml'));assert not lint.findall('issue')
receipt={'commit':'420cb76fb1fc02a53a5b6296505be193eaa3bb2f','tree':'d2fab1608c333b195a1a06c6251191a664637f06','run':40998796695,'artifact':{'id':12952954591,'bytes':(P/'regression.zip').stat().st_size,'sha256':hashlib.sha256((P/'regression.zip').read_bytes()).hexdigest()},'jvm':{'cases':len(ni),'classes':len(np),'failures':0,'errors':0,'skips':0,'exact_premerge_identity_set_preserved':True,'corrected_method':corrected[0]},'python':{'cases':int(m[1]),'seconds':float(m[2]),'documented_skips':int(m[3])},'phases':phases,'lint_issues':0,'baseline':{'run':40995073540,'head':'dc713447975c15391d7aca9b803bbe64688507a2','synthetic':'7061b20bbe336a0219a88b708ba7b1a3792655b4','artifact':12952268061,'sha256':'24412e7fe47bd058a3dcd75c90659eeb2b6bfe70c8de63951f22bb4fe182ed86'},'prior_run_40989923300':'failure preserved, not reclassified'}
(P/'regression-verification.json').write_text(json.dumps(receipt,indent=2)+'\n');(P/'jvm-identities.json').write_text(json.dumps(ni,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
