import json,zipfile,hashlib,xml.etree.ElementTree as ET
from pathlib import Path
P=Path(__file__).parent
old=zipfile.ZipFile(P.parent/'pr235-dc713/api35.zip'); new=zipfile.ZipFile(P/'api35.zip')
ident=json.loads(new.read('composed-device-identity.json')); previous=json.loads(old.read('composed-device-identity.json'))
assert ident['commit']=='420cb76fb1fc02a53a5b6296505be193eaa3bb2f' and ident['run_id']=='40998796695'
assert ident['group_run_attempts']=={'core':1,'position':1} and ident['composed_in_run_attempt']==1
for k in ('build_variant','source_tests_sha256','device_sdk','source_sha256'): assert ident[k]==previous[k],k
core=json.loads(new.read('device-identity.json'))
for k in ('commit','run_id','build_variant','source_tests_sha256','device_sdk','apk_sha256','source_sha256','test_apk_sha256'): assert ident[k]==core[k],k
phases={}; all_ids=[]; native=[]; app=[]
for n in old.namelist():
 if n.endswith('/summary.json'):
  a=json.loads(old.read(n)); b=json.loads(new.read(n))
  if 'cases' not in a: continue
  assert b['success'] and b['returncode']==0 and not b['timed_out']
  assert not b['missing'] and not b['unexpected'] and not b['errors']
  for k in ('expected_tests','completed_tests','timeout_seconds','source_tests_sha256','device_sdk','excluded_classes','included_tests','sdk_suppressed_tests'): assert a[k]==b[k],(n,k)
  ids=lambda s: sorted((c['classname'],c['name']) for c in s['cases'])
  assert ids(a)==ids(b) and len(ids(b))==len(set(ids(b)))==b['expected_tests']
  assert all(c['status']=='passed' for c in b['cases'])
  (native if n.startswith('Paintroid/') else app).extend(ids(b)); all_ids.extend(ids(b))
  phases[n]={k:b[k] for k in ('success','completed_tests','expected_tests','timeout_seconds','elapsed_seconds','source_tests_sha256')}
for n in old.namelist():
 if n.endswith('.xml') and 'TEST-' in n:
  a=ET.fromstring(old.read(n));b=ET.fromstring(new.read(n))
  ids=lambda s: sorted((c.attrib['classname'],c.attrib['name']) for c in s.iter('testcase'))
  assert ids(a)==ids(b)
  assert all(b.attrib[k]=='0' for k in ('failures','errors','skipped'))
assert len(phases)==10 and len(app)==49 and len(native)==74 and len(all_ids)==len(set(all_ids))
assert sum(n.endswith('.png') for n in new.namelist())==147
receipt={'commit':ident['commit'],'tree':'d2fab1608c333b195a1a06c6251191a664637f06','run':40998796695,'artifact':{'id':12953017655,'bytes':(P/'api35.zip').stat().st_size,'sha256':hashlib.sha256((P/'api35.zip').read_bytes()).hexdigest()},'identity':ident,'phases':phases,'app_cases':49,'native_cases':74,'exact_premerge_identities_and_caps_preserved':True,'png_count':147,'limits':'Actual-merge installed regression; not a new SI/MY-specific installed visual or native-human linguistic certification.'}
(P/'api35-verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ('commit','run','app_cases','native_cases','exact_premerge_identities_and_caps_preserved','png_count')},indent=2))
