"""Read-only continuation of merged234's explicit typed-key presence definition."""
import json,hashlib,subprocess,tarfile,xml.etree.ElementTree as E
from pathlib import Path
R=Path('/workspace/scratch/bbca2890f602/seasia-si-my-za-combined-20261030');P=Path(__file__).parent
archive=Path('/workspace/scratch/bbca2890f602/nordic-fa-ir-ja-fr-evidence/merged234-source-inventory.tar.xz')
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='9549be41a95979664c5fd841c7dcd8969f96f0a3fe4df3d1405e21ebfe825788'
with tarfile.open(archive) as t:old=json.load(t.extractfile('merged234-current171-source.json'))
commit='420cb76fb1fc02a53a5b6296505be193eaa3bb2f';tree='d2fab1608c333b195a1a06c6251191a664637f06'
# Actual GitHub commit/ref GET binds this tree to the merge; the locally available
# identical Git tree object supplies bytes without reconstructing commit history.
assert old['source_commit']=='3b505f871ba6e52b6759be6d34bf7e4ec3995e46' and old['source_tree']=='c39f602e4fe749339df44e874b32efb9026a1249'
paths=['translations/string-importance.json','Paintroid/src/main/res/values/app_language_tags.xml','Paintroid/src/main/res/values/app_language_names.xml']+[r['catalogue_path']for r in old['rows']]
def blobs(ref):
 raw=subprocess.check_output(['git','-C',str(R),'cat-file','--batch'],input=('\n'.join(ref+':'+p for p in paths)+'\n').encode());out={};offset=0
 for path in paths:
  end=raw.index(b'\n',offset);header=raw[offset:end].decode().split();assert header[1]=='blob';size=int(header[2]);offset=end+1;out[path]=raw[offset:offset+size];offset+=size+1
 assert offset==len(raw);return out
current=blobs(tree);prior=blobs(old['source_tree']);assert current[paths[0]]==prior[paths[0]]
keys={t['id']:set(t['keys'])for t in json.loads(current[paths[0]])['tiers']if t['id']in('P0','P1')};assert {k:len(v)for k,v in keys.items()}=={'P0':92,'P1':249};assert len(old['rows'])==len({r['tag']for r in old['rows']})==171
for path,field in [(paths[1],'tag'),(paths[2],'picker_label')]:
 assert current[path]==prior[path];values=[e.text for e in E.fromstring(current[path]).find('string-array')];assert values==[r[field]for r in old['rows']]
rows=[];changed=[];key_deltas=[];per_locale=[]
for r in old['rows']:
 path=r['catalogue_path'];data=current[path];prior_data=prior[path];assert hashlib.sha256(prior_data).hexdigest()==r['current_catalogue_sha256']
 identity=lambda b:{e.tag+'/'+e.attrib['name']for e in E.fromstring(b)if e.tag in('string','plurals')and'name'in e.attrib}
 now=identity(data);before=identity(prior_data)
 counts={t:{'present':len(ks&now),'missing':len(ks-now),'total':len(ks)}for t,ks in keys.items()};assert r['current_explicit_priority_presence']=={t:{'present':len(ks&before),'missing':len(ks-before),'total':len(ks)}for t,ks in keys.items()}
 if data!=prior_data:changed.append(r['tag']);per_locale.append({'tag':r['tag'],'before':r['current_explicit_priority_presence'],'after':counts,'presence_delta':{t:counts[t]['present']-r['current_explicit_priority_presence'][t]['present']for t in keys}})
 if now!=before:key_deltas.append({'tag':r['tag'],'added':sorted(now-before),'removed':sorted(before-now)})
 rows.append({**{k:r[k]for k in('order','tag','picker_label','catalogue_path')},'current_catalogue_sha256':hashlib.sha256(data).hexdigest(),'current_explicit_priority_presence':counts,'current_review_acceptance_total':None})
totals={t:{'current_present':sum(r['current_explicit_priority_presence'][t]['present']for r in rows),'current_missing':sum(r['current_explicit_priority_presence'][t]['missing']for r in rows),'denominator':171*len(keys[t])}for t in keys}
assert set(changed)=={'si','my','za'} and all(not r['removed'] for r in key_deltas)
result={'prior_evidence_commit':'85b3d413ee610043b3191cc342ccf9aabccf6998','prior_inventory_archive_sha256':'9549be41a95979664c5fd841c7dcd8969f96f0a3fe4df3d1405e21ebfe825788','prior_source_commit':old['source_commit'],'prior_source_tree':old['source_tree'],'source_commit':commit,'source_tree':tree,'definition':old['definition'],'locale_count':171,'prior_totals':old['totals'],'totals':totals,'presence_delta':{t:totals[t]['current_present']-old['totals'][t]['current_present']for t in keys},'per_locale_delta':per_locale,'changed_catalogue_bytes_since_prior':changed,'typed_key_deltas_since_prior':key_deltas,'rows':rows}
(P/'merged235-current171-source.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in ('rows','typed_key_deltas_since_prior')},indent=2))
