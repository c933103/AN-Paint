import argparse,json,hashlib,sys,subprocess,xml.etree.ElementTree as E
from pathlib import Path
ap=argparse.ArgumentParser()
ap.add_argument('--source',type=Path,required=True);ap.add_argument('--candidate',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--historical',type=Path,required=True)
a=ap.parse_args();root=a.source.resolve();candidate=a.candidate.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
def bind(path,head,tree):
 def git(*args):return subprocess.check_output(['git','-C',str(path),*args],text=True).strip()
 assert git('rev-parse','HEAD')==head
 assert git('rev-parse','HEAD^{tree}')==tree
 assert git('diff','HEAD','--')==''
bind(root,'72f987b2b02b4a9a421a0c0874cce6a0d0b53934','11ea169938c0d3d4e90e4d56dc5debf6be79b94e')
bind(candidate,'2e58204c73ff24ea9b73fbaf4d265baa1e0c3fce','de438227d759a2def5fc987600c3c1591f452f9f')
sys.path.insert(0,str(root/'tools'));import translation_catalogues as c
historical={x['tag']:x for x in json.loads(a.historical.read_text())}
tiers=json.loads((root/'translations/string-importance.json').read_text())['tiers'];keys={t['id']:set(t['keys']) for t in tiers if t['id'] in ('P0','P1')}
assert len(keys['P0'])==92 and len(keys['P1'])==249
paths=c.catalogue_paths();tags=c.offered_tags();names=[x.text for x in E.parse(root/'Paintroid/src/main/res/values/app_language_names.xml').findall(".//string-array[@name='app_language_names']/item")];assert len(tags)==len(set(tags))==len(names)==171
pending={t:n for n,ts in {215:['da','is','no'],216:['hi','gu'],217:['nn','be','sq'],218:['th'],220:['hr','bs','mk']}.items() for t in ts}
active={t:'fa/he/ur' for t in ['fa','he','ur']};active.update({t:'sr/ch/shn' for t in ['sr-Cyrl','sr-Latn','ch','shn']});active.update({t:'si/my/za' for t in ['si','my','za']})
rows=[]
def entries(p):return {x.tag+'/'+x.attrib['name'] for x in E.parse(p).getroot() if 'name' in x.attrib and x.tag in ('string','plurals')}
for order,(tag,name) in enumerate(zip(tags,names),1):
 p=paths[tag];rel=str(p.relative_to(root));present=entries(p);h=historical.get(tag);sha=hashlib.sha256(p.read_bytes()).hexdigest();target=entries(candidate/rel)
 row={'order':order,'tag':tag,'picker_label':name,'catalogue_path':rel,'current_catalogue_sha256':sha,'current_explicit_priority_presence':{tier:{'present':len(ks&present),'missing':len(ks-present),'total':len(ks)} for tier,ks in keys.items()},'historical60354_review_counts':h['tiers'] if h else None,'historical_catalogue_bytes_equal':sha==h['catalogue_sha256'] if h else None,'historical_counts_are_current_acceptance':False,'current_review_acceptance_total':None,'pending_pr':pending.get(tag),'pending_integration_pr':221 if tag in pending else None,'pending_explicit_priority_presence':{tier:{'present':len(ks&target),'missing':len(ks-target),'total':len(ks)} for tier,ks in keys.items()} if tag in pending else None,'next_review_assignment':active.get(tag)}
 if tag not in pending:assert (candidate/rel).read_bytes()==p.read_bytes(),tag
 rows.append(row)
meta={'source_commit':'72f987b2b02b4a9a421a0c0874cce6a0d0b53934','source_tree':'11ea169938c0d3d4e90e4d56dc5debf6be79b94e','pending_integration_head':'2e58204c73ff24ea9b73fbaf4d265baa1e0c3fce','pending_integration_tree':'de438227d759a2def5fc987600c3c1591f452f9f','historical_index_ref':'8a960dea535b452a453489defeeb53750e12699a','scope':'Current explicit XML source presence for all171 picker choices, with pending PR overlay. NOT runtime resolution, new linguistic review, accepted-quality totals, or restart of stopped bulk archive. Historical acceptance counts stay dated60354, even where catalogue bytes match; consumer/source rebind is not inferred.','rows':rows}
meta['totals']={t:{'current_present':sum(x['current_explicit_priority_presence'][t]['present'] for x in rows),'current_missing':sum(x['current_explicit_priority_presence'][t]['missing'] for x in rows),'denominator':171*len(keys[t])} for t in keys};meta['pending_rows']=len(pending)
(out/'current171-source-and-pending.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
lines=['# Current171 source presence and pending integration','',meta['scope'],'','Production: `'+meta['source_commit']+'`. Pending integration: PR221 `'+meta['pending_integration_head']+'`.','', '| # | Tag | P0 present/92 | P1 present/249 | Pending source PR | Next review assignment |','|---:|---|---:|---:|---|---|']
for x in rows:lines.append(f"| {x['order']} | {x['tag']} | {x['current_explicit_priority_presence']['P0']['present']} | {x['current_explicit_priority_presence']['P1']['present']} | {x['pending_pr'] or '—'} | {x['next_review_assignment'] or '—'} |")
(out/'CURRENT-171.md').write_text('\n'.join(lines)+'\n');print(meta['totals']);print('pending rows',len(pending),'rows',len(rows))
