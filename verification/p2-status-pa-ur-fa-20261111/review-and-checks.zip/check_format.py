import base64, json, pathlib, subprocess, xml.etree.ElementTree as E

w = pathlib.Path(__file__).resolve().parent
p = json.loads((w / 'inputs.json').read_text())
root = E.parse(w / 'source' / p['paths']['fa-IR']).getroot()
value = next(n.text for n in root if n.get('name') == 'ui_lossless_format')
b64 = lambda s: base64.b64encode(s.encode()).decode()
rows = []
for label, expected in [('JPEG XL', 'JPEG XL بدون اتلاف'), ('WebP', 'WebP بدون اتلاف'), ('AVIF', 'AVIF بدون اتلاف')]:
    rows.append('\t'.join(['fa-IR', 'ui_lossless_format', b64(value), b64(expected), 's:' + b64(label)]))
(w / 'format-cases.tsv').write_text('\n'.join(rows) + '\n')
with (w / 'jdk-checks.log').open('w') as out:
    subprocess.run(['java', '-version'], stdout=out, stderr=subprocess.STDOUT, check=True)
    subprocess.run(['java', str(w / 'FormattingCheck.java'), str(w / 'format-cases.tsv'), '3'], stdout=out, stderr=subprocess.STDOUT, check=True)
print((w / 'jdk-checks.log').read_text())
