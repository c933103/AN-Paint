import hashlib, json, pathlib, stat, xml.etree.ElementTree as E

w = pathlib.Path(__file__).resolve().parent
load = lambda name: json.loads((w / name).read_text())
git = lambda b: hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
base = load('base-tree.json')
fresh = load('fresh-tree.json')
norm = lambda tree: {e['path']: {k: e[k] for k in ['path', 'mode', 'type', 'sha']} for e in tree['tree'] if e['type'] != 'tree'}
assert not fresh['truncated'] and norm(base) == norm(fresh) and base['sha'] == fresh['sha']
old = {p['number']: p for p in load('owners.json')}
new = {p['number']: p for p in load('fresh-owners.json')}
assert old == new
accepted = load('accepted-map.json')
review = load('review.json')
assert review['candidate_sha256'] == hashlib.sha256((w / 'candidate.json').read_bytes()).hexdigest()
assert review['accepted_map_sha256'] == hashlib.sha256((w / 'accepted-map.json').read_bytes()).hexdigest()
assert len(review['reviews']) == sum(map(len, accepted.values()))
for decision in review['reviews']:
    assert decision['final_value_decision'] == 'accept' and decision['accepted_value'] == accepted[decision['locale']][decision['key']]
held = load('held-absence.json')
blobs = load('held-blobs.json')
for pair in held:
    assert new[pair['pr']]['head'] == pair['head']
    text = blobs[pair['blob']]
    assert git(text.encode()) == pair['blob']
    assert not set(accepted[pair['tag']]) & {n.get('name') for n in E.fromstring(text)}
expected = {p['path']: p for p in load('expected-tree.json')}
changes = load('integration.json')
inputs = load('inputs.json')
for tag, values in accepted.items():
    path = inputs['paths'][tag]
    node_map = {n.get('name'): n for n in E.parse(w / 'source' / path).getroot()}
    assert all(node_map[k].text == value and node_map[k].attrib == inputs['source'][k]['attributes'] for k, value in values.items())
    assert git((w / 'source' / path).read_bytes()) == changes[tag]['blob'] == expected[path]['sha']
count = 0
for f in (w / 'source').rglob('*'):
    path = f.relative_to(w / 'source').as_posix()
    if f.is_file() and path in expected:
        e = expected[path]
        assert git(f.read_bytes()) == e['sha'], path
        assert ('100755' if f.stat().st_mode & stat.S_IXUSR else '100644') == e['mode'], path
        count += 1
out = {'base': inputs['base'], 'tree': fresh['sha'], 'complete_source_tree_unchanged': True, 'checked_materialized_files': count, 'complete_expected_leaves': len(expected), 'open_owners': len(new), 'held_heads': len({p['head'] for p in held}), 'held_catalogue_pairs': len(held), 'git_verified_held_blobs': len(blobs), 'new_values': sum(map(len, accepted.values())), 'old_nodes_preserved': sum(v['old_nodes_preserved'] for v in changes.values() if isinstance(v, dict)), 'source_changes': len(accepted)}
(w / 'publication-check.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps(out, indent=2))
