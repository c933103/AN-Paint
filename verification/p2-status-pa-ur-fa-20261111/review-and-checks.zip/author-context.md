# Punjabi, Urdu and Persian status/control batch

Base is freshly verified develop 5a39710f8207956671c3248922341d5898326e4e, tree ecf163df40e7a7d58cdc42e1c77875cdbd9b0b5a (PR #432). 31 missing active P2 values: Punjabi pa-IN 8, Urdu ur 8, Persian fa 6 and Iranian Persian fa-IR 9. These are four separately offered canonical catalogues. Existing fa tool-option and pixel-tap entries are deliberately left unchanged. Candidates are newly authored, not copied from held heads. All 378 locally materialized tracked files match the current tree before editing.

Read inputs.json for exact English resources/attributes and candidate.json for complete proposals. Review each complete value independently: accept, revise or hold. Do not infer native-human or exhaustive device/layout/glyph/speech acceptance. No external primary terminology reference consulted.

Current source consumers were inspected:
- ImageResizeDialog.kt:49 and AssemblyActivity.kt:311 append fits-the-current-budget to memory estimates. Budget is working memory, not money or storage space; no guarantee of all operations succeeding.
- SaveOptionsDialog.kt:87 sets a lossless checkbox using format.label as the positional %1$s argument (JPEG XL, WebP or AVIF). Only fa-IR lacks this value. The label does not mean free of charge or smaller size. A real JDK exact-output formatting sample will be run.
- AssemblyActivity.kt:194: after ACTION_OPEN_DOCUMENT and ACTION_GET_CONTENT both fail with ActivityNotFoundException, asks to enable the Files/Documents app. Those are Android application names, not an instruction to enable individual files. Names vary by vendor.
- MediaGalleryActivity.kt:336 validates the whole image URL, not only host, and :346 reports redirect-count exhaustion. Preserve full URL-policy scope; do not assert outage, maliciousness or credential failure.
- AssemblyActivity.kt:156 uses Time unavailable as a missing modification timestamp fallback, not elapsed time or timeout.
- ClassicPaintActivity.kt:822 uses Tool option as single-choice setting dialog title, not selection of the drawing tool itself.
- ClassicPaintActivity.kt:776 uses Tap a pixel as colour-picker instruction.
- AssemblyActivity.kt:88: Edit in Paint transfers an assembly into the Paint editor through requestOutput(true), not exporting to a format.

Terminology matches nearby current catalogue context: Punjabi ਮੈਮੋਰੀ, ਟੂਲ, ਪਿਕਸਲ and polite ਟੈਪ ਕਰੋ; Urdu میموری, آلہ and پکسل, polite تھپتھپائیں; Persian حافظه, ابزار, پیکسل and polite ضربه بزنید. Files/Documents are preserved as recognizable source labels while Android is transliterated in Persian, consistent with normal Persian usage. fa-IR has existing quoted strings; proposals require XML/Android escaping validation but should not change existing quoting.

RTL boundary: Persian redirect candidates contain the ordinary Persian U+200C ZWNJ in نمی‌شود; it is orthographic, not a bidi direction override. No newly inserted bidi controls. Android embedded Latin names and the formatted Latin format name need actual-device mixed-direction/layout testing for exhaustive acceptance, which this model/source review cannot establish. Please explicitly consider whether lossless format ordering and URL wording remain unambiguous.

Older holds, withdrawn conclusions and explicit #395/#400 restrictions remain unchanged. Fresh all-17 open PR owner identities match the prior baseline; selected status keys must additionally be absent across each of eight held heads before publication. No Work-side task, runtime or workflow edits, permanent wording oracle, release or unrelated change.


## Final integration note

Independent review retained 29 candidates and revised two Persian URL messages to make the unsupported object explicitly the internet address. The accepted-map.json values are final; the original candidate above remains an auditable proposal. The final orthographic U+200C is in پشتیبانی‌نشده. On the integrating executor, 46 affected host checks and three actual OpenJDK 21 exact-output cases passed. The independent reviewer did not execute JDK samples; its not-run statement is preserved as its own scope. No Android/RTL/device claim follows from the JDK result.
