import pathlib,json,hashlib,re,datetime,zipfile
p=pathlib.Path(__file__).parent;m=json.load(open(p/'verification-input.json'));r=json.load(open(p/'prior-evidence.json'))
assert 'sha256:'+hashlib.sha256((p/'prior-evidence.zip').read_bytes()).hexdigest()==m['link_artifact']['digest']
assert r['reused'] is True and r['policy']=='immediate-merge-prior-environment-v1'
assert r['merge']==m['develop']==m['pr']['merge_commit_sha']==m['postrun']['head_sha']=='7915ed52a868ba2bc2b5dbceaf98afd74a830481'
assert r['head']==m['pr']['head']=='d054e8e9c90c2445c650cb3e0b966760f71ac960'
assert r['checkout']=='5e3ad0e22f4ff7951a1d0dccad42542c75228787' and r['tree']=='4f0d9d332e7f7cc7c5b56e3255e4863a9b76f064'
assert r['run_id']==42947844398 and r['run_attempt']==1 and r['build_variant']=='debug' and r['device_sdk']==35
assert m['pr']['merged'] and r['pull_request']==m['pr']['number']==427
assert [v['sha'] for v in m['merge']['parents']]==[r['base'],r['head']] and m['merge']['tree']['sha']==r['tree']
assert m['postrun']=={'id':42950970654,'event':'push','head_sha':r['merge'],'status':'completed','conclusion':'success','run_attempt':1}
jobs=m['jobs']['jobs'];assert len(jobs)==7 and all(x['status']=='completed' for x in jobs)
assert [(x['name'],x['conclusion']) for x in jobs if x['conclusion']!='skipped']==[('Verify recent same-tree PR evidence','success')]
assert sum(x['conclusion']=='skipped' for x in jobs)==6
assert m['link_artifact']['workflow_run']['head_sha']==r['merge'] and m['link_artifact']['workflow_run']['id']==m['postrun']['id']
fresh={a['id']:a for a in m['original_artifacts']}
assert set(r['artifacts'])=={'build','tests','regression','exact','core','position'}
for kind,a in r['artifacts'].items():
 f=fresh[a['artifact_id']];assert f['name']==a['name'] and f['digest']==a['digest'] and not f['expired']
 assert f['workflow_run']['id']==r['run_id'] and f['workflow_run']['head_sha']==r['head']
 assert r['checkout'] in f['name']
for kind in ['regression','exact']:
 assert r['artifacts'][kind]['artifact_id']==m['original_qualification'][kind]['id'] and r['artifacts'][kind]['digest']==m['original_qualification'][kind]['digest']
rev=m['review'];assert rev['user']['id']==199175422 and rev['user']['type']=='Bot' and rev['app']['id']==1144995
state=json.loads(re.search(r'<!-- codex-review-state:v1 (.*?) -->',rev['body'],re.S)[1]);code=state['code_review']
assert code['commit_sha']==r['head'] and code['status']=='completed' and not code['has_any_findings'] and not code['has_unresolved_findings']
assert state['security_review']['commit_sha']==r['head'] and state['security_review']['status']=='completed'
assert r['review']['comment_id']==rev['id'] and r['review']['updated_at']==rev['updated_at'] and r['review']['head']==r['head']
for obs in r['observed_inputs'].values():
 assert obs['commit']==r['checkout'] and obs['tree']==r['tree'] and obs['run_id']==str(r['run_id']) and obs['attempt']=='1'
dt=lambda s:datetime.datetime.fromisoformat(s.replace('Z','+00:00'))
assert 0 <= (dt(r['merged_at'])-dt(r['prior_completed_at'])).total_seconds() <= 86400
assert 0 <= (dt(r['checked_at'])-dt(r['merged_at'])).total_seconds() <= 3600
result={'verified':True,'merge':r['merge'],'tree':r['tree'],'head':r['head'],'run':m['postrun']['id'],'original_run':r['run_id'],'link_artifact':m['link_artifact']['id'],'link_digest':m['link_artifact']['digest'],'original_artifact_identities_verified':6,'executed_postmerge_jobs':1,'skipped_postmerge_jobs':6,'merged_direct_P2':22576,'statement':'Same-tree prior PR evidence was reused. Six downstream jobs were skipped, not newly executed successes. Original exact/regression/composition archives were independently downloaded and checked during PR qualification. The existing workflow checked the other original large artifacts; this follow-up did not redownload those or run Android locally. No release or exhaustive installed/native-human certification.'}
(p/'postmerge.json').write_text(json.dumps(result,indent=2)+'\n')
with zipfile.ZipFile(p/'postmerge-evidence.zip','w',zipfile.ZIP_DEFLATED,9) as z:
 for n in ['prior-evidence.zip','prior-evidence.json','verification-input.json','verify.py','postmerge.json']:z.write(p/n,n)
print(json.dumps(result,indent=2))
