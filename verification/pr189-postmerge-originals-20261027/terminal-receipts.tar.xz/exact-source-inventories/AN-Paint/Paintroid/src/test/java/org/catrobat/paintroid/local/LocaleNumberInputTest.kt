/* AN Paint contributors, 2026. GNU AGPL-3.0-or-later. */
package org.catrobat.paintroid.local

import android.app.Activity
import android.app.AlertDialog
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Rect
import android.graphics.Typeface
import android.util.AndroidRuntimeException
import org.catrobat.paintroid.R
import android.os.Looper
import android.text.InputFilter
import android.text.InputType
import android.text.method.DigitsKeyListener
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import org.catrobat.paintroid.classic.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.Implementation
import org.robolectric.annotation.Implements
import org.robolectric.shadows.ShadowAlertDialog
import org.robolectric.shadows.ShadowInputMethodManager
import java.io.File
import java.text.DecimalFormatSymbols
import java.util.Locale
import java.util.concurrent.Executors

/** Editable insertion exercises the real key filter; setText alone can bypass it. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[21,25,35], qualifiers="w412dp-h900dp-port-xhdpi")
class LocaleNumberInputTest {
    private fun enter(field: EditText, text: String) {
        field.setText("")
        field.text.replace(0, 0, text)
        assertEquals("Numeric syntax must reach validation unchanged", text, field.text.toString())
    }
    private fun idle() = shadowOf(Looper.getMainLooper()).idle()
    @Suppress("DEPRECATION")
    private fun withActivity(tag: String, check: (Activity) -> Unit) {
        val oldLocale=Locale.getDefault()
        val oldResources=PaintApplication.currentResources
        val application=RuntimeEnvironment.getApplication()
        val oldTag=AppLanguage.selectedTag(application)
        AppLanguage.select(application,tag)
        val controller=Robolectric.buildActivity(LocalizedTestActivity::class.java)
        val activity=controller.get()
        activity.setTheme(R.style.ClassicPaintTheme)
        controller.setup()
        try {
            val locale=Locale.forLanguageTag(tag)
            AppLanguage.refresh(activity)
            assertNotSame(application.resources,activity.resources)
            assertEquals(locale,application.resources.configuration.locale)
            assertEquals(locale,activity.resources.configuration.locale)
            check(activity)
        } finally {
            ShadowAlertDialog.getLatestAlertDialog()?.dismiss()
            idle()
            controller.pause().stop().destroy()
            AppLanguage.select(application,oldTag)
            PaintApplication.currentResources=oldResources
            Locale.setDefault(oldLocale)
        }
    }

    @Test @Config(sdk=[21]) fun legacyTypefaceShadowDoesNotModelTheFrameworkIdentityCache() {
        val context=RuntimeEnvironment.getApplication()
        for(asset in listOf("fonts/anpaintnomui.ttf","fonts/notosansmongolian.ttf")) {
            val face=Typeface.createFromAsset(context.assets,asset)
            val first=Typeface.create(face,Typeface.BOLD)
            val second=Typeface.create(face,Typeface.BOLD)
            assertNotSame(first,second)
            assertEquals(first,second)
            assertEquals(Typeface.BOLD,first.style)
            assertEquals(shadowOf(face).fontDescription.familyName,shadowOf(first).fontDescription.familyName)
        }
    }

    @Test @Config(sdk=[21],shadows=[CachedApi21TypefaceShadow::class]) fun api21DialogCreationPrecedesDecorInspectionWithTheActualAppTheme() {
        for(tag in listOf("fr","ar","vi-Hani","mnc-Mong")) withActivity(tag) { activity ->
            // Exact original lifecycle sequence, independent of numeric filtering:
            // inspecting decor installs content before API21 AlertController requests its feature.
            val original=AlertDialog.Builder(activity).setMessage("message").setPositiveButton("OK",null).create()
            original.window!!.decorView
            val error=assertThrows(AndroidRuntimeException::class.java) {original.show()}
            assertTrue(error.message!!.contains("requestFeature() must be called before adding content"))
            original.dismiss()
            val uiFace=LocaleTypography.typeface(activity)
            uiFace?.let {
                assertSame(it,Typeface.create(it,it.style))
                val bold=Typeface.create(it,Typeface.BOLD)
                val italic=Typeface.create(it,Typeface.ITALIC)
                assertSame(bold,Typeface.create(it,Typeface.BOLD))
                assertSame(italic,Typeface.create(it,Typeface.ITALIC))
                assertNotSame(it,bold);assertNotSame(bold,italic)
                assertEquals(Typeface.BOLD,bold.style);assertEquals(Typeface.ITALIC,italic.style)
                assertEquals(shadowOf(it).fontDescription.familyName,shadowOf(bold).fontDescription.familyName)
                assertEquals(shadowOf(it).fontDescription.familyName,shadowOf(italic).fontDescription.familyName)
            }
            var clicks=0
            val repaired=EditorDialogBuilder(activity).setTitle("title").setMessage("message")
                .setPositiveButton("OK") {_,_->clicks++}.create()
            assertFalse(repaired.isShowing)
            repaired.show();idle()
            assertTrue(repaired.isShowing)
            repaired.getButton(AlertDialog.BUTTON_POSITIVE).performClick();idle()
            assertEquals(1,clicks);assertFalse(repaired.isShowing)
        }
    }

    @Test @Config(sdk=[21,25]) fun legacyDefaultNumberFilterReproducesTheUnfixedLoss() = withActivity("fr") { activity ->
        val field=EditText(activity).apply {inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL}
        field.text.append("12,5")
        assertEquals("125",field.text.toString())
        field.setText("");field.text.append("١٢٫٥")
        assertEquals("",field.text.toString())
        LocaleNumberInput.configure(field,decimal=true)
        enter(field,"12,5");assertEquals(12.5,uiNumber(field.text.toString())!!,0.0)
    }

    @Test @Config(sdk=[21,25,30,35]) fun everyOfferedLocaleRetainsItsDigitsAndDecimalSyntaxWithBothImeModes() {
        val context=RuntimeEnvironment.getApplication()
        val old=Locale.getDefault()
        try {
            val tags=AppLanguage.tags(context)
            assertEquals(171,tags.size)
            for(tag in tags) {
                val locale=Locale.forLanguageTag(tag)
                val localized=context.createConfigurationContext(Configuration(context.resources.configuration).apply {setLocale(locale);setLayoutDirection(locale)})
                Locale.setDefault(locale)
                val symbols=DecimalFormatSymbols(locale)
                fun digits(value: String)=value.map {if(it in '0'..'9') (symbols.zeroDigit.code+(it-'0')).toChar() else it}.joinToString("")
                for(decimal in listOf(false,true)) {
                    val field=EditText(localized)
                    field.contentDescription="numeric purpose"
                    val limit=InputFilter.LengthFilter(20)
                    field.filters=arrayOf(limit)
                    LocaleNumberInput.configure(field,decimal)
                    assertEquals(tag,InputType.TYPE_CLASS_NUMBER or if(decimal) InputType.TYPE_NUMBER_FLAG_DECIMAL else 0,field.inputType)
                    assertEquals(tag,field.inputType,field.keyListener.inputType)
                    assertEquals("numeric purpose",field.contentDescription)
                    assertTrue(field.filters.contains(limit))
                    for((text,expected) in listOf(digits("125") to 125.0,(digits("12")+symbols.decimalSeparator+digits("5")) to 12.5,"12.5" to 12.5)) {
                        enter(field,text)
                        assertEquals(tag,expected,uiNumber(field.text.toString())!!,0.0)
                    }
                    for(sign in setOf('-', '\u2212', symbols.minusSign)) {
                        enter(field,sign+digits("12"))
                        val parsed=uiNumber(field.text.toString())
                        assertTrue("$tag must not turn a negative into positive input",parsed==null || parsed<0)
                    }
                }
            }
        } finally {Locale.setDefault(old)}
    }

    @Test @Config(shadows=[NumericRestartInputShadow::class])
    fun focusedUnitSwitchRestartsInputWithTheFinalNumericMode() = withActivity("fr") { activity ->
        val field=EditText(activity).apply {tag="numeric_restart_probe"}
        activity.setContentView(field)
        field.requestFocus()
        activity.getSystemService(android.content.Context.INPUT_METHOD_SERVICE)
        idle()
        assertTrue(field.hasFocus())
        // Reproduce the first-head ordering: the restart sees the listener's
        // integer/text mode before the later raw decimal type is assigned.
        NumericRestartInputShadow.types.clear()
        field.keyListener=DigitsKeyListener.getInstance("0123456789.,+-")
        field.setRawInputType(InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        assertTrue(NumericRestartInputShadow.types.isNotEmpty())
        assertNotEquals(field.inputType,NumericRestartInputShadow.types.last())
        for(decimal in listOf(false,true,false,true,true)) {
            NumericRestartInputShadow.types.clear()
            LocaleNumberInput.configure(field,decimal)
            val expected=InputType.TYPE_CLASS_NUMBER or if(decimal) InputType.TYPE_NUMBER_FLAG_DECIMAL else 0
            assertTrue("Framework must restart input",NumericRestartInputShadow.types.isNotEmpty())
            assertTrue("Every restart must already see the final mode",NumericRestartInputShadow.types.all {it==expected})
            val info=EditorInfo()
            assertNotNull(field.onCreateInputConnection(info))
            assertEquals(expected,info.inputType)
            enter(field,"12,5")
        }
    }

    @Test fun dimensionsKeepFractionalPercentAndRejectFractionalPixelsAfterRepeatedUnitChanges() = withActivity("fr") { activity ->
        val controls=DimensionControls(activity,ImageDimensions(200,400))
        repeat(3) {
            controls.findViewWithTag<View>("size_percent").performClick()
            enter(controls.widthInput,"12,5")
            assertEquals(ImageDimensions(25,50),controls.dimensions)
            controls.findViewWithTag<View>("size_pixels").performClick()
            assertEquals("25",controls.widthInput.text.toString())
            enter(controls.widthInput,"12,5");assertNull(controls.dimensions)
            enter(controls.widthInput,"-12");assertNull(controls.dimensions)
            enter(controls.widthInput,"200");assertEquals(ImageDimensions(200,400),controls.dimensions)
        }
        assertTrue(controls.widthInput.contentDescription.isNotEmpty())
    }

    @Test fun dimensionsAcceptArabicAndPersianDigitsAndRetainRangeValidation() {
        for((tag,value) in listOf("ar" to "١٢٥","fa" to "۱۲۵")) withActivity(tag) { activity ->
            val controls=DimensionControls(activity,ImageDimensions(200,400))
            enter(controls.widthInput,value)
            assertEquals(ImageDimensions(125,250),controls.dimensions)
            enter(controls.widthInput,"0");assertNull(controls.dimensions)
            enter(controls.widthInput,"2147483648");assertNull(controls.dimensions)
        }
    }

    @Test fun cropRetainsDecimalCommaAndRejectsFractionalPixelsOrNegativeMargins() = withActivity("fr") { activity ->
        val item=AssemblyImage("a",File(activity.cacheDir,"not-decoded.image"),"a.png",null,ImageDimensions(200,400))
        var result: Map<String,Rect>?=null
        val dialog=ImageCropDialog(activity,listOf(item),{null}) {result=it}.show();idle()
        val root=dialog.window!!.decorView
        val left=root.findViewWithTag<EditText>("crop_left")
        enter(left,"12,5");dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick()
        assertNull(result);assertTrue(dialog.isShowing)
        root.findViewWithTag<View>("crop_percent").performClick()
        enter(left,"-12,5");dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick()
        assertNull(result);assertTrue(dialog.isShowing)
        enter(left,"12,5");dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick()
        assertEquals(Rect(25,0,200,400),result!!.getValue("a"));assertFalse(dialog.isShowing)
    }

    @Test fun normalizationRetainsCommaAcrossModeChangesAndCancelDoesNotCommit() = withActivity("fr") { activity ->
        val directory=File(activity.cacheDir,"numeric-normalize-${System.nanoTime()}")
        val assembly=ImageAssembly(directory)
        try {
            val file=File(directory,"a.image").apply {writeText("no decoder is used")}
            assembly.add(listOf(AssemblyImage("a",file,"a.png",null,ImageDimensions(200,400))))
            val dialog=NormalizeImagesDialog(activity,assembly,NormalizeAxis.WIDTH).show();idle()
            val root=dialog.window!!.decorView
            val input=root.findViewWithTag<EditText>("normalize_value")
            enter(input,"12,5");assertFalse(dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled)
            repeat(3) {
                root.findViewWithTag<View>("normalize_percent").performClick()
                enter(input,"12,5");assertTrue(dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled)
                root.findViewWithTag<View>("normalize_pixels").performClick()
                assertEquals("25",input.text.toString())
            }
            enter(input,"-25");assertFalse(dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled)
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).performClick()
            assertEquals(ImageDimensions(200,400),assembly.image("a").placedSize)
            val reopened=NormalizeImagesDialog(activity,assembly,NormalizeAxis.WIDTH).show();idle()
            enter(reopened.window!!.decorView.findViewWithTag("normalize_value"),"25")
            reopened.getButton(AlertDialog.BUTTON_POSITIVE).performClick()
            assertEquals(ImageDimensions(25,50),assembly.image("a").placedSize)
        } finally {directory.deleteRecursively()}
    }

    @Test fun textSizeAndSpacingRetainDecimalsAndTheExistingRanges() = withActivity("fr") { activity ->
        var result: TextSettings?=null
        val dialog=TextStyleDialog(activity,TextSettings("text"),Color.BLACK,Color.WHITE) {settings,_->result=settings;true}.show();idle()
        val root=dialog.window!!.decorView
        val size=root.findViewWithTag<EditText>("text_size")
        val spacing=root.findViewWithTag<EditText>("text_spacing")
        enter(size,"12,5");enter(spacing,"125,5")
        enter(size,"-12,5");dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick()
        assertNull(result);assertTrue(dialog.isShowing)
        enter(size,"12,5");enter(spacing,"300,5");dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick()
        assertNull(result);assertTrue(dialog.isShowing)
        enter(spacing,"125,5");dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick()
        assertEquals(12.5f,result!!.size,0f);assertEquals(1.255f,result!!.spacing,.00001f)
    }

    @Test fun sliderRetainsArabicDigitsAndRejectsPastedFractionsAndNegativeNumbers() = withActivity("ar") { activity ->
        var result=1
        val slider=NumericSlider(activity,"size",1,1,100) {result=it}
        slider.number.performClick();idle()
        val dialog=ShadowAlertDialog.getLatestAlertDialog()!!
        val field=dialog.window!!.decorView.findViewWithTag<EditText>("numeric_input")
        for(invalid in listOf("١٢٫٥","-١٢","١٠١")) {
            enter(field,invalid);dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick()
            assertTrue(dialog.isShowing);assertEquals(1,result)
        }
        enter(field,"٩٩");dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick()
        assertFalse(dialog.isShowing);assertEquals(99,result)
    }

    @Test fun colourRefactorKeepsCommaEntryAndNegativeRangeRejection() = withActivity("fr") { activity ->
        val picker=AdvancedColourDialog(activity,Color.RED,false) {}
        val dialog=picker.show();idle()
        val root=dialog.window!!.decorView
        val hue=root.findViewWithTag<EditText>("colour_h")
        enter(hue,"120,5");assertEquals(120.5f,picker.value.hsv[0],.001f)
        enter(hue,"-120,5");assertNotNull(hue.error)
        assertEquals(120.5f,picker.value.hsv[0],.001f)
    }

    @Test fun pageFieldRetainsPersianDigitsAndDisablesFractionalNegativeAndOutOfRangeEntries() = withActivity("fa") { activity ->
        val worker=Executors.newSingleThreadExecutor()
        val selection=ImportSelection(activity,worker,{0L},{},{},{throw AssertionError(it)})
        try {
            // Exercise the actual page form without staging/decoding a document.
            ImportSelection::class.java.getDeclaredMethod("showPages",String::class.java,Int::class.javaPrimitiveType).apply {isAccessible=true}.invoke(selection,"TIFF",20)
            idle()
            val dialog=ShadowAlertDialog.getLatestAlertDialog()!!
            val field=dialog.window!!.decorView.findViewWithTag<EditText>("import_page_number")
            val open=dialog.getButton(AlertDialog.BUTTON_POSITIVE)
            for(invalid in listOf("۱۲٫۵","-۱۲","۲۱","۰")) {enter(field,invalid);assertFalse(open.isEnabled)}
            enter(field,"۱۲");assertTrue(open.isEnabled)
            assertTrue(field.contentDescription.isNotEmpty())
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).performClick();idle();assertFalse(dialog.isShowing)
        } finally {selection.dispose();worker.shutdownNow()}
    }
}

/** Records the type seen at the framework restart boundary; no real keyboard is launched. */
@Implements(InputMethodManager::class)
class NumericRestartInputShadow : ShadowInputMethodManager() {
    companion object {val types=mutableListOf<Int>()}
    @Implementation
    override fun restartInput(view: View) {
        if(view.tag=="numeric_restart_probe") types.add((view as EditText).inputType)
    }
}
