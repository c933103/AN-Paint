/* AN Paint contributors, 2026. GNU AGPL-3.0-or-later. */
package org.catrobat.paintroid.local

import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Spinner
import android.widget.ArrayAdapter
import org.catrobat.paintroid.classic.LocaleTypography
import org.catrobat.paintroid.classic.VerticalText
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.util.Locale

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[30])
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class LocaleTypographyTest {
    private fun localizedContext()=RuntimeEnvironment.getApplication().let {base ->
        base.createConfigurationContext(Configuration(base.resources.configuration).apply {setLocale(Locale.getDefault())})
    }

    @Test fun nomPositionGlyphsEachProduceDistinctUnclippedNativeInk() {
        val context=RuntimeEnvironment.getApplication()
        val font=Typeface.createFromAsset(context.assets,"fonts/anpaintnomui.ttf")
        val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply {typeface=font;textSize=64f;color=Color.BLACK}
        // The byte-level font contract verifies each bundled cmap/outline identity;
        // hasGlyph alone would not rule out Android fallback.
        assertFalse(paint.hasGlyph(String(Character.toChars(0x10ffff))))
        val rasters=mutableListOf<IntArray>()
        for(point in listOf(0x4efd,0x6089,0x6578,0x91cd,0x2a700,0x2ca20)) {
            val text=String(Character.toChars(point));val label="U+${point.toString(16)}"
            assertTrue(label,paint.hasGlyph(text))
            val bounds=Rect();paint.getTextBounds(text,0,text.length,bounds)
            assertFalse(label,bounds.isEmpty);assertTrue(label,paint.measureText(text)>0f)
            val bitmap=Bitmap.createBitmap(128,128,Bitmap.Config.ARGB_8888)
            try {
                Canvas(bitmap).drawText(text,32f,88f,paint)
                val pixels=IntArray(128*128);bitmap.getPixels(pixels,0,128,0,0,128,128)
                assertTrue(label,pixels.count {Color.alpha(it)>0}>0)
                for(i in 0 until 128) {
                    assertEquals(label,0,Color.alpha(pixels[i]));assertEquals(label,0,Color.alpha(pixels[127*128+i]))
                    assertEquals(label,0,Color.alpha(pixels[i*128]));assertEquals(label,0,Color.alpha(pixels[i*128+127]))
                }
                assertFalse("$label duplicated another glyph raster",rasters.any {it.contentEquals(pixels)})
                rasters.add(pixels)
            } finally {bitmap.recycle()}
        }
    }

    @Test fun uiSubsetsStayOutOfDrawingChoicesAndPreserveExplicitFonts() {
        val context=RuntimeEnvironment.getApplication()
        val old=Locale.getDefault()
        try {
            val catalog=org.catrobat.paintroid.classic.FontCatalog(context)
            assertFalse(catalog.fonts.any {it.id in setOf("anpaintnomui","anpaintwuufallback")})
            val explicit=catalog.fonts.indexOfFirst {it.id=="lato"}
            assertTrue(explicit>0)
            for((tag,text) in listOf("vi-Hani" to "𡨸喃", "wuu-Hans" to "𠲎")) {
                Locale.setDefault(Locale.forLanguageTag(tag))
                val fallback=Typeface.create(LocaleTypography.typeface(context,Locale.getDefault()),Typeface.BOLD)
                assertSame(tag,fallback,catalog.faceForText(0,text,Typeface.BOLD))
                assertSame(tag,catalog.face(explicit),catalog.faceForText(explicit,text))
            }
            Locale.setDefault(Locale.forLanguageTag("vi-Hani"))
            val mongolian=catalog.fonts.indexOfFirst {it.id=="notosansmongolian"}
            assertTrue(mongolian>0)
            assertSame(catalog.face(mongolian),catalog.faceForText(0,"ᠮᠣᠩᠭᠤᠯ"))
        } finally {Locale.setDefault(old)}
    }
    @Test fun nomFontReachesNativeControlsButPreservesExplicitTextFonts() {
        val old=Locale.getDefault()
        try {
            Locale.setDefault(Locale.forLanguageTag("vi-Hani"))
            val context=localizedContext()
            val font=LocaleTypography.typeface(context)!!
            val paint=Paint().apply {typeface=font;textSize=32f}
            for(text in listOf("𡨸","𥻂","𦻳","𮞶")) assertTrue(text,paint.hasGlyph(text))
            val root=LinearLayout(context)
            val label=TextView(context).apply {text="𡨸喃"}
            val field=EditText(context).apply {text.append("𡨸");tag="ordinary_field"}
            val bold=TextView(context).apply {typeface=Typeface.DEFAULT_BOLD}
            root.addView(bold)
            val explicit=EditText(context).apply {tag="text_content";typeface=Typeface.MONOSPACE}
            val preview=TextView(context).apply {tag="font_option_monospace";typeface=Typeface.MONOSPACE}
            for(view in listOf(label,field,explicit,preview)) root.addView(view)
            LocaleTypography.install(root)
            assertSame(font,label.typeface);assertSame(font,field.typeface)
            assertEquals(Typeface.BOLD,bold.typeface.style)
            assertSame(Typeface.MONOSPACE,explicit.typeface);assertSame(Typeface.MONOSPACE,preview.typeface)
            val added=TextView(context);root.addView(added)
            root.viewTreeObserver.dispatchOnGlobalLayout()
            assertSame(font,added.typeface)
            assertSame(font,VerticalText.uiTypeface(context))
            val spinner=Spinner(context).apply {
                adapter=ArrayAdapter(context,android.R.layout.simple_spinner_dropdown_item,listOf("𡨸","𮞶"))
                setSelection(1)
            }
            root.addView(spinner);root.viewTreeObserver.dispatchOnGlobalLayout()
            assertEquals(1,spinner.selectedItemPosition)
            val popupRow=spinner.adapter.getDropDownView(1,null,root) as TextView
            assertSame(font,popupRow.typeface)
            assertEquals("𮞶",popupRow.text.toString())
            Locale.setDefault(Locale.forLanguageTag("wuu-Hans"))
            val wuContext=localizedContext()
            val wu=LocaleTypography.typeface(wuContext)!!
            assertTrue(Paint().apply {typeface=wu}.hasGlyph("𠲎"))
            val catalog=org.catrobat.paintroid.classic.FontCatalog(wuContext)
            assertFalse(catalog.fonts.any {it.id=="anpaintwuufallback"})
        } finally {Locale.setDefault(old)}
    }
}
