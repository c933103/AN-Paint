import hashlib, json, pathlib, zipfile

p = pathlib.Path(__file__).parent
x = json.loads((p/'postmerge-receipt.json').read_text())
m = json.loads((p/'postmerge-metadata.json').read_text())
a = json.loads((p/'fresh-artifact-metadata.json').read_text())
merge = json.loads((p/'merge.json').read_text())
wanted = {'reused':True, 'repository_id':1362702425, 'merge':'5a39710f8207956671c3248922341d5898326e4e', 'base':'7d41d341956a6fcd4246cb2ff8d05d7ad20e45f9', 'head':'126e151a8e5f650c22c1072a43c5f6da81e78591', 'checkout':'f1aee229fcba5833ccc030d8ff73dc1f30be534d', 'tree':'ecf163df40e7a7d58cdc42e1c77875cdbd9b0b5a', 'pull_request':432, 'run_id':42974214906, 'run_attempt':1, 'build_variant':'debug', 'device_sdk':35}
for k,v in wanted.items(): assert x[k] == v, (k,x[k])
assert merge['sha'] == x['merge'] and merge['tree']['sha'] == x['tree'] and [q['sha'] for q in merge['parents']] == [x['base'],x['head']]
assert m['develop']['object']['sha'] == x['merge']
assert m['run']['id'] == 42977148486 and m['run']['event'] == 'push' and m['run']['head_sha'] == x['merge']
assert m['run']['status'] == 'completed' and m['run']['conclusion'] == 'success' and m['run']['run_attempt'] == 1
assert len(m['jobs']['jobs']) == 7
assert sum(j['conclusion'] == 'skipped' for j in m['jobs']['jobs']) == 6
assert [j['name'] for j in m['jobs']['jobs'] if j['conclusion'] == 'success'] == ['Verify recent same-tree PR evidence']
byid = {q['id']:q for q in a['artifacts']}
assert len(x['artifacts']) == 6
for k,q in x['artifacts'].items():
    f = byid[q['artifact_id']]
    assert all(f[z] == q[z] for z in ['name','digest'])
    assert not f['expired'] and f['workflow_run']['id'] == x['run_id'] and f['workflow_run']['head_sha'] == x['head']
assert x['review']['comment_id'] == 6789030023 and x['review']['head'] == x['head'] and x['review']['app_id'] == 1144995 and x['review']['bot_id'] == 199175422
z = zipfile.ZipFile(p/'postmerge.zip'); assert z.testzip() is None and z.namelist() == ['prior-evidence.json']
digest = hashlib.sha256((p/'postmerge.zip').read_bytes()).hexdigest()
artifact = m['artifact']; assert artifact['digest'] == 'sha256:'+digest
assert artifact['workflow_run']['id'] == m['run']['id'] and artifact['workflow_run']['head_sha'] == x['merge'] and not artifact['expired']
r = {'verified':True, 'merge':x['merge'], 'tree':x['tree'], 'postmerge_run':42977148486, 'receipt_artifact':artifact['id'], 'receipt_sha256':digest, 'original_run':x['run_id'], 'original_checkout':x['checkout'], 'original_attempt':1, 'six_original_artifact_metadata_matched':True, 'fresh_preflight_jobs':1, 'downstream_skips':6, 'scope':'Verified bounded same-tree original-experiment reuse. Six downstream jobs skipped, not rerun. Original APK/source, instrumentation, regression, exact-script, position and composed-device artifact bytes were independently checked before merge. The workflow also checked original core/position bytes; no separate download of the original core artifact was needed for this independent follow-up.'}
(p/'postmerge-verification.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2))
with zipfile.ZipFile(p/'postmerge-results.zip','w',zipfile.ZIP_DEFLATED,9) as out:
    for name in ['postmerge-metadata.json','postmerge-receipt.json','postmerge.zip','verify-postmerge.py','fresh-artifact-metadata.json','postmerge-verification.json','merge.json']:out.write(p/name,name)
b = (p/'postmerge-results.zip').read_bytes()
print(json.dumps({'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'members':len(zipfile.ZipFile(p/'postmerge-results.zip').namelist()),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}))
