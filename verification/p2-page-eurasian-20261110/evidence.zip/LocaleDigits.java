import java.text.DecimalFormatSymbols;
import java.util.Locale;
public class LocaleDigits {
 public static void main(String[] args) {
  for(String tag:args) System.out.println(tag+" "+DecimalFormatSymbols.getInstance(Locale.forLanguageTag(tag)).getZeroDigit());
 }
}
