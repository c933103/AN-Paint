import json, re, hashlib, xml.etree.ElementTree as ET
from pathlib import Path
root=Path('/workspace/shared/anpaint-p2-eurasian-20261110')
out=Path('/workspace/shared/anpaint-p2-eurasian-evidence')
inputs=json.loads((out/'inputs.json').read_text())
T={
'fa': {
'formats22_pdf_invalid':'PDF خوانده نشد. ممکن است پرونده آسیب دیده باشد یا از قابلیت‌هایی استفاده کند که این نسخهٔ Android از آن‌ها پشتیبانی نمی‌کند.',
'formats22_pdf_encrypted':'PDF به گذرواژه نیاز دارد یا از رمزگذاری پشتیبانی‌نشده استفاده می‌کند. پیش از وارد کردن آن، یک نسخهٔ بدون محافظت ذخیره کنید.',
'formats22_pdf_file_size':'پروندهٔ PDF نباید خالی باشد و اندازهٔ آن نباید از 512 MiB بیشتر باشد.',
'formats22_pdf_page_count':'تعداد صفحه‌های PDF باید از ۱ تا %1$d باشد.',
'formats22_pdf_page_index':'انتخاب صفحهٔ PDF دیگر معتبر نیست. یک صفحه را از همین سند دوباره انتخاب کنید.',
'formats22_pdf_dimensions':'ابعاد صفحهٔ PDF نامعتبر است یا برای وارد کردن بیش از حد بزرگ است.',
'formats22_pdf_crop':'ناحیهٔ برش PDF باید مستطیلی با عرض و ارتفاع بزرگ‌تر از صفر باشد و به‌طور کامل درون صفحهٔ انتخاب‌شده قرار بگیرد.',
'formats22_pdf_memory':'رسم PDF از بودجهٔ حافظهٔ در دسترس برای تصویر فراتر می‌رود.'
},
'ur': {
'formats22_select_page':'صفحہ منتخب کریں',
'formats22_page_description':r'%1$s · %2$s\nصفحات کی تعداد: %3$d۔ تصویر کے طور پر ترمیم کرنے کے لیے ایک صفحہ منتخب کریں۔',
'formats22_page_number':'صفحہ نمبر',
'formats22_previous_page':'پچھلا صفحہ',
'formats22_next_page':'اگلا صفحہ',
'formats22_open_page':'صفحہ کھولیں',
'formats22_page_preview':'منتخب صفحے کا پیش منظر',
'formats22_page_range':'1 سے %1$d تک کوئی صفحہ نمبر درج کریں۔',
'formats22_loading_page':'صفحہ: %1$d، صفحات کی کل تعداد: %2$d · پیش منظر لوڈ ہو رہا ہے…',
'formats22_page_dimensions':'صفحہ: %1$d، صفحات کی کل تعداد: %2$d · %3$d × %4$d پکسل',
'formats22_preview_unavailable':'پیش منظر دستیاب نہیں: %1$s',
'formats22_preview_memory':'اس پیش منظر کے لیے میموری کافی نہیں ہے۔ صفحہ کھولنے پر، اگر ممکن ہوا تو، چھوٹی جہتوں کا اختیار دیا جائے گا۔',
'formats22_pdf_invalid':'PDF پڑھی نہیں جا سکی۔ ممکن ہے فائل خراب ہو یا اس میں ایسی خصوصیات ہوں جن کی Android کے اس ورژن میں معاونت نہیں ہے۔',
'formats22_pdf_encrypted':'PDF کے لیے پاس ورڈ درکار ہے یا اس میں ایسی خفیہ کاری استعمال ہوئی ہے جس کی معاونت نہیں ہے۔ درآمد کرنے سے پہلے اس کی ایک ایسی نقل محفوظ کریں جس پر حفاظتی پابندیاں نہ ہوں۔',
'formats22_pdf_file_size':'PDF فائل خالی نہیں ہونی چاہیے اور اس کا حجم 512 MiB سے زیادہ نہیں ہونا چاہیے۔',
'formats22_pdf_page_count':'PDF میں صفحات کی تعداد 1 سے %1$d تک ہونی چاہیے۔',
'formats22_pdf_page_index':'PDF کے صفحے کا انتخاب اب درست نہیں ہے۔ اس دستاویز سے دوبارہ ایک صفحہ منتخب کریں۔',
'formats22_pdf_dimensions':'PDF کے صفحے کی جہتیں درست نہیں ہیں یا درآمد کرنے کے لیے بہت بڑی ہیں۔',
'formats22_pdf_crop':'PDF میں تراش کا علاقہ ایک ایسا مستطیل ہونا چاہیے جس کی چوڑائی اور اونچائی صفر سے زیادہ ہوں اور جو مکمل طور پر منتخب صفحے کے اندر ہو۔',
'formats22_pdf_memory':'PDF کی تصویر بنانے کے لیے درکار میموری، تصاویر کے لیے دستیاب میموری کی مقررہ حد سے زیادہ ہے۔'
},
 'tt-Cyrl': {
'formats22_select_page':'Битне сайлау',
'formats22_page_description':r'%1$s · %2$s\nБитләр саны: %3$d. Рәсем итеп үзгәртү өчен бер бит сайлагыз.',
'formats22_page_number':'Бит номеры',
'formats22_previous_page':'Алдагы бит',
'formats22_next_page':'Киләсе бит',
'formats22_open_page':'Битне ачу',
'formats22_page_preview':'Сайланган битне алдан карау',
'formats22_page_range':'1–%1$d аралыгындагы бит номерын кертегез.',
'formats22_loading_page':'Бит: %1$d, барлыгы: %2$d · Алдан карау йөкләнә…',
'formats22_page_dimensions':'Бит: %1$d, барлыгы: %2$d · %3$d × %4$d пиксель',
'formats22_preview_unavailable':'Алдан карау мөмкин түгел: %1$s',
'formats22_preview_memory':'Алдан карау өчен хәтер җитми. Битне ачканда, мөмкин булса, кечерәк үлчәмнәр тәкъдим ителәчәк.',
'formats22_pdf_invalid':'PDF файлын укып булмады. Файл зарарланган булырга яки Android системасының бу версиясе хупламаган мөмкинлекләрне кулланырга мөмкин.',
'formats22_pdf_encrypted':'PDF өчен серсүз кирәк яки анда хупланмый торган шифрлау кулланыла. Импортлау алдыннан аның якланмаган күчермәсен саклагыз.',
'formats22_pdf_file_size':'PDF файлы буш булмаска һәм аның күләме 512 MiB чигеннән артмаска тиеш.',
'formats22_pdf_page_count':'PDF файлындагы битләр саны 1–%1$d аралыгында булырга тиеш.',
'formats22_pdf_page_index':'PDF битен сайлау инде яраклы түгел. Бу документтан битне яңадан сайлагыз.',
'formats22_pdf_dimensions':'PDF битенең үлчәмнәре яраксыз яки импортлау өчен артык зур.',
'formats22_pdf_crop':'PDF файлының кисү өлкәсе киңлеге дә, биеклеге дә нульдән зур булган һәм тулысынча сайланган бит эчендә урнашкан турыпочмаклык булырга тиеш.',
'formats22_pdf_memory':'PDF файлын рәсемгә әйләндерү өчен кирәкле хәтер күләме рәсемнәр өчен кулланыла алган хәтер чигеннән артып китә.'
}}
for loc,trs in T.items():
 assert set(trs)==set(inputs['missing_keys'][loc]),loc
 existing={e.get('name') for e in ET.parse(root/inputs['paths'][loc]).getroot()}
 assert not (set(trs)&existing),loc
 for k,v in trs.items():
  source=inputs['source'][k]['text']
  assert re.findall(r'%\d+\$[sd]',v)==re.findall(r'%\d+\$[sd]',source),(loc,k)
  assert re.findall(r'\\.',v)==re.findall(r'\\.',source),(loc,k,'escapes')
  assert not any(0x202a<=ord(c)<=0x202e or 0x2066<=ord(c)<=0x2069 for c in v),(loc,k,'bidi overrides/isolates')
  ET.fromstring('<string name="'+k+'">'+v+'</string>')
(out/'candidate-rtl-tatar.json').write_text(json.dumps({'translations':T},ensure_ascii=False,indent=2)+'\n')
print('Saved',sum(map(len,T.values())),'candidate values; exact missing-key sets, indexed typed slots, raw escapes and XML fragment parse verified.')
print('candidate sha256',hashlib.sha256((out/'candidate-rtl-tatar.json').read_bytes()).hexdigest())
