import json, hashlib
from pathlib import Path
p=Path('/workspace/shared/anpaint-p2-eurasian-evidence')
a=json.loads((p/'candidate-rtl-tatar.json').read_text())['translations']
base='https://github.com/c933103/AN-Paint/blob/6ad5692bf523ef84ffc2f2a5672153f6dc3ebd2b/'
meanings={
'formats22_select_page':'Choose a page.',
'formats22_page_description':'Show format and file name, then page count. Choose one page to edit as an image.',
'formats22_page_number':'Page number.',
'formats22_previous_page':'Previous page.',
'formats22_next_page':'Next page.',
'formats22_open_page':'Open the page.',
'formats22_page_preview':'Preview of the selected page.',
'formats22_page_range':'Enter a page number in the inclusive range 1 through the supplied upper bound.',
'formats22_loading_page':'Identify the current page and total page count; the preview is loading.',
'formats22_page_dimensions':'Identify the current page and total page count, then width times height in pixels.',
'formats22_preview_unavailable':'The preview is unavailable, followed by the actual supplied error message.',
'formats22_preview_memory':'There is insufficient memory for the preview. When opening the page, smaller dimensions will be offered if possible.',
'formats22_pdf_invalid':'The PDF could not be read. The file might be damaged or use features unsupported by this Android version; the cause is not asserted as proven.',
'formats22_pdf_encrypted':'The PDF requires a password or uses unsupported encryption. Save a copy without protection before importing it.',
'formats22_pdf_file_size':'The PDF file must not be empty, and its size must not exceed 512 MiB.',
'formats22_pdf_page_count':'The number of pages in the PDF must be in the inclusive range 1 through the supplied upper bound.',
'formats22_pdf_page_index':'The PDF page selection is no longer valid. Select a page from this same document again.',
'formats22_pdf_dimensions':'The PDF page dimensions are invalid or too large for import.',
'formats22_pdf_crop':'The PDF crop region must be a rectangle of positive width and height wholly inside the selected page.',
'formats22_pdf_memory':'Rendering the PDF needs more memory than the available image-memory budget permits.'
}
rationale={
'formats22_select_page':'Dialog title. Urdu uses the polite action form; Tatar uses the existing UI noun/infinitive style.',
'formats22_page_description':'%1$s is PDF/TIFF, %2$s is the supplied display name, and %3$d is total pages. Preserve the same complete meaning and source escape, not a substituted word list.',
'formats22_page_number':'Accessibility caption on the numeric entry field; this is a page number, not an internal zero-based index.',
'formats22_previous_page':'Used both as import-arrow accessibility text and visible legacy-credit page button text. Keep generic page wording.',
'formats22_next_page':'Used both as import-arrow accessibility text and visible legacy-credit page button text. Keep generic page wording.',
'formats22_open_page':'Positive button starts import of the selected page, not the entire document.',
'formats22_page_preview':'ImageView accessibility text identifies the selected page preview.',
'formats22_page_range':'Actual accepted input is 1..count; internal ImportedImage/PdfCodec indices are zero-based and must not be exposed as the UI range.',
'formats22_loading_page':'Use independent numeric labels instead of inflecting an arbitrary numeral. Preserve indexed integer roles and loading aspect.',
'formats22_page_dimensions':'%3$d/%4$d are the original page width/height, not the reduced preview dimensions. Use the unchanged multiplication symbol and source unit meaning.',
'formats22_preview_unavailable':'The appended error is unknown runtime text; do not add a definite corruption diagnosis or strip the supplied value.',
'formats22_preview_memory':'The later smaller-size offer is conditional. It does not promise automatic downsizing or successful import.',
'formats22_pdf_invalid':'Preserve epistemic uncertainty and the disjunction between possible damage and version-specific unsupported features.',
'formats22_pdf_encrypted':'Keep both password and unsupported-encryption alternatives, and the required pre-import unprotected-copy action. This is not an instruction to enter a password into AN Paint.',
'formats22_pdf_file_size':'Both file length >0 and <=512*1024*1024 are required. Preserve exact Latin unit token 512 MiB; empty means empty file, not a visually blank PDF page.',
'formats22_pdf_page_count':'PdfCodec permits 1..MAX_PAGES, currently 4096. Translate the range without attaching a number-dependent Turkic suffix to the arbitrary %1$d value.',
'formats22_pdf_page_index':'Selection is stale/invalid now. Explicit again corresponds to recovering by choosing a page from the document rather than reentering an internal index.',
'formats22_pdf_dimensions':'Keep invalid OR too large. No invented precise maximum and no claim that every rejection is due to oversized pages.',
'formats22_pdf_crop':'PdfCodec rejects negative/outside edges and left>=right or top>=bottom. Explicit positive width/height avoids the false interpretation that the crop must contain visible/nonblank picture content.',
'formats22_pdf_memory':'The comparison is estimated output/document/native render work against the supplied image-memory budget. Do not translate it as all physical RAM being exhausted or as a file-size limit.'
}
keynotes={}
for loc,values in a.items():
 keynotes[loc]={k:{'whole_value_meaning':meanings[k], 'contextual_rationale':rationale[k]} for k in values}
keynotes['ur']['formats22_pdf_encrypted']['wording_watchpoint']='حفاظتی پابندیاں literally refers to protective restrictions. Intended meaning is an unprotected copy; independent review should decide whether this is too broad or less natural than an explicit password/encryption-free copy. This wording is not independently established by the Mozilla terminology excerpts.'
keynotes['ur']['formats22_pdf_memory']['whole_value_meaning']='The memory needed to make an image of the PDF exceeds the available memory limit set for images.'
keynotes['tt-Cyrl']['formats22_pdf_crop']['wording_watchpoint']='турыпочмаклык is the explicit geometry noun rectangle. The existing catalogue shape label is Турыпочмак, a form that can also evoke right angle. The existing label is not edited. Whole-sentence geometry terminology remains an independent-review watchpoint.'
keynotes['tt-Cyrl']['formats22_pdf_memory']['whole_value_meaning']='The memory required to turn the PDF file into an image exceeds the limit of memory available for images.'
notes={
 'status':'48 model-authored candidate values for independent review only; no acceptance or native-human claim.',
 'source_identity':{'remote_base_sha':'6ad5692bf523ef84ffc2f2a5672153f6dc3ebd2b','remote_base_tree':'4c94fcd5af02b3f54583a4bcfb80f5743a249f0e','checkout_note':'Parent supplied and verified checkout tree matches this remote tree. Local HEAD is a temporary snapshot, not the remote commit identity.'},
 'scope':{'fa':8,'ur':20,'tt-Cyrl':20,'restriction':'Only input-listed absent keys. No existing values or application source changed; no publication, CI or review requests made.'},
 'source_contract':{'escape_correction':'Actual canonical XML and inputs.json each contain the two-codepoint sequence [92,110]: ONE literal backslash followed by n. Initial handoff wording describing two backslashes was corrected by parent. These exact source bytes are preserved.', 'host_runtime_distinction':'Parent reports host decode_display yields a newline; that result is not independent compiled-resource or installed rendering evidence.', 'placeholders':'Exact indexed typed slot sequence preserved for every value. Format/name/count and current-page/total-page/width/height roles retained.', 'technical_punctuation':'Preserved PDF, Android, 512 MiB, multiplication sign ×, middle dot · and loading ellipsis where applicable. Urdu uses Arabic comma/full stop in prose; Persian uses Persian script and a localized fixed ۱ for lower page bound. No bidi embeddings, overrides or isolates inserted.', 'rtl_hold':'Mixed RTL prose with Latin PDF/Android/MiB, numeric formatter output, multiplication signs, and arbitrary file/error values still require real Android bidi/layout review. Logical order in JSON or XML is not installed visual-order acceptance.'},
 'locale_assessment':{
  'fa':{'model_semantic_confidence':'high for these eight source meanings','model_fluency_confidence':'high, still not native-human acceptance','terminology':'Matches current locale usage: پرونده, وارد کردن, برش, ابعاد, حافظه and رسم. Mozilla corroborates گذرواژه, not full error wording.','holds':['Independent full-value review pending.','Installed mixed-direction technical punctuation, glyph/layout and speech/accessibility review unrun.']},
  'ur':{'model_semantic_confidence':'high; protection-copy wording is an explicit review watchpoint','model_fluency_confidence':'moderate to high; long technical clauses need independent review','terminology':'Matches current locale usage: پیش منظر, میموری, جہتیں, پکسل, تراش, درآمد. Previous/next page and password term corroborated by Mozilla. Numeric statuses use total-count labels to avoid singular/plural mismatches at 1.','holds':['Independent review of all full values, especially unprotected-copy wording and rendering/budget phrasing.','Long RTL status and crop/encryption texts, font shaping, bidi ordering and accessibility speech are unrun.']},
  'tt-Cyrl':{'model_semantic_confidence':'moderate to high, with crop and selection phrasing watchpoints','model_fluency_confidence':'moderate; cannot certify native Tatar idiomatic quality','terminology':'Matches current locale usage: бит, рәсем, алдан карау, хәтер, үлчәм, пиксель. Серсүз is corroborated in pinned OpenStreetMap Tatar resources. Descriptive rendering phrasing follows existing PDF raster hint.','holds':['Independent full-value review pending, especially турыпочмаклык geometry, якланмаган copy, and stale-selection clause.','No native Tatar reviewer, comprehensive external phrase corpus, installed glyph/layout, or speech review.']}
 },
 'sources':[
  {'kind':'canonical product context, not inherited wording acceptance','url':base+'Paintroid/src/main/res/values-fa/strings.xml','excerpts':['پیش‌نمایش','برش','حافظه'],'supports':'Local terminology consistency only; existing progress conclusions are not reinstated.'},
  {'kind':'canonical product context','url':base+'Paintroid/src/main/res/values-ur/strings.xml','excerpts':['پیش منظر','جہتیں','مستطیل'],'supports':'Preview, dimensions and rectangle terminology consistency only.'},
  {'kind':'canonical product context','url':base+'Paintroid/src/main/res/values-b%2Btt%2BCyrl/strings.xml','excerpts':['Алдан карау','Киңлек','Биеклек'],'supports':'Preview, width and height terminology consistency only; not whole-value acceptance.'},
  {'kind':'primary software localization terminology','url':'https://github.com/mozilla/pdf.js/blob/b600aecd1801b6a924adc85bb8d6b8b170bae107/l10n/fa/viewer.ftl','git_blob_sha':'d75bbf0809807d6bbdca04a33203a0d7a8858f4d','excerpts':['تعداد صفحه‌ها:','گذرواژه'],'supports':'Page-count and password terms only. Source retrieved at immutable commit; does not approve AN Paint complete phrases.'},
  {'kind':'primary software localization terminology','url':'https://github.com/mozilla/pdf.js/blob/b600aecd1801b6a924adc85bb8d6b8b170bae107/l10n/ur/viewer.ftl','git_blob_sha':'207ad480e1c53018e00bb750c942b763942e8d86','excerpts':['پچھلا صفحہ','اگلا صفحہ','پاس ورڈ'],'supports':'Previous/next page and password terms only. Other upstream Urdu phrases are not copied as approval of page-order, dimensions or encryption wording.'},
  {'kind':'primary software localization terminology','url':'https://github.com/openstreetmap/openstreetmap-website/blob/b8b9c3d1e9e412178426e9ba1b612e14e09f2320/config/locales/tt.yml#L141','git_blob_sha':'2e215b02a7fa7a4054c1332547ad947c6559b4c7','excerpts':['pass_crypt: Серсүз'],'supports':'Password term only, not encryption, protection or whole error wording.'}
 ],
 'research_limits':['No external primary full-phrase approval was located or claimed. Primary terminology evidence corroborates isolated terms only.','The attempted mozilla/pdf.js l10n/tt/viewer.ftl path returned 404; no Tatar PDF.js catalogue evidence is claimed.','A Tatar academy dictionary home-page read timed out. Search results suggest geometry variants but were not elevated into pinned primary dictionary acceptance.'],
 'consumer_evidence':[
  {'url':base+'Paintroid/src/main/java/org/catrobat/paintroid/classic/ImportSelection.kt','finding':'showPages uses all picker values directly, passes kind/name/count, validates one-based 1..count and subtracts one for ImportedImage, supplies original dimensions after reduced preview decoding; smaller dimensions conditional on later opening.'},
  {'url':base+'Paintroid/src/main/java/org/catrobat/paintroid/classic/PdfCodec.kt','finding':'Specific guards independently cover nonempty <=512 MiB file, count 1..4096, invalid index, page dimensions, positive contained crop and budget. SecurityException maps encryption; generic IllegalArgumentException/IOException map uncertain invalid-PDF explanation.'},
  {'url':base+'Paintroid/src/main/java/org/catrobat/paintroid/classic/LegacyImageCreditsActivity.kt','finding':'Previous/next page strings are reused as visible text for credit text pages, so PDF-specific arrow labels would be wrong.'}
 ],
 'tests_inspected_not_run':[
  {'path':'Paintroid/src/androidTest/java/org/catrobat/paintroid/classic/PdfCodecTest.kt','relevance':'Real PDF selected-page dimensions, valid crop pixels, invalid page/crop/budget, input preservation, and specific versus generic error paths.'},
  {'path':'Paintroid/src/test/java/org/catrobat/paintroid/local/JapanesePdfFailureTest.kt','relevance':'Generic failures must retain uncertain cause; encryption and size messages stay specific. Japanese tests do not certify these locales.'},
  {'path':'Paintroid/src/test/java/org/catrobat/paintroid/local/OrdinaryPriorityFollowthroughTest.kt','relevance':'Production page-dialog captions and one-based range/controls exercise current resources for their scoped locales; not new installed coverage.'},
  {'path':'Paintroid/src/test/java/org/catrobat/paintroid/local/LocaleNumberInputTest.kt','relevance':'Actual page form accepts localized Persian 12 and rejects 0, negatives, fractions and out-of-range values in its fixture; not complete current candidate coverage.'},
  {'path':'Paintroid/src/test/java/org/catrobat/paintroid/local/SwedishExtendedWordingTest.kt','relevance':'Existing page dialog tests use a real newline in expected decoded description and exercise invalid ranges; not Urdu/Tatar acceptance.'},
  {'path':'Paintroid/src/test/java/org/catrobat/paintroid/local/ImportSelectionFlowTest.kt','relevance':'Staged-file lifecycle, cancellation and selected-page persistence. No new claim of locale wording acceptance.'},
  {'path':'Paintroid/src/test/java/org/catrobat/paintroid/local/LegacyImportErrorLocaleTest.kt','relevance':'Selected-resource routing boundary versus technical parser causes; malformed ICO/DIB checks are not PDF semantic coverage.'}
 ],
 'validation':{'passed':['Candidate count 48: fa8/ur20/tt-Cyrl20.','Exact candidate keys equal the supplied missing keys; none already present in those canonical resources.','Indexed typed format slots preserve source order and types.','Raw backslash escape sequences match source per key.','Every candidate parses as an XML string fragment.','No Unicode bidi embedding/override/isolate control added.','Repository git status remained clean after candidate generation; only separate temporary evidence files written.'],'unrun':['Android resource compilation/aapt','Host application translation suite','JVM consumer tests','Installed API30/API35, font and bidi layout','Physical-device rendering','Native-human linguistic review','Accessibility speech/TalkBack'],'candidate_sha256':hashlib.sha256((p/'candidate-rtl-tatar.json').read_bytes()).hexdigest()},
 'key_notes':keynotes
}
(p/'candidate-rtl-tatar-notes.json').write_text(json.dumps(notes,ensure_ascii=False,indent=2)+'\n')
print('Saved notes:',len(keynotes['fa'])+len(keynotes['ur'])+len(keynotes['tt-Cyrl']),'full-value explanations; 6 pinned source links; explicit linguistic/runtime holds.')
