import hashlib, json, pathlib, re

p = pathlib.Path(__file__).parent
x = json.load(open(p / 'final-metadata.json'))
e = json.load(open(p / 'prior-evidence.json'))
pre, merged, run, jobs = x['premerge'], x['merge'], x['postRun'], x['postJobs']['jobs']
head, base = pre['pr']['head']['sha'], pre['pr']['base']['sha']
merge, tree, checkout = merged['commit']['sha'], merged['commit']['tree']['sha'], x['tested']['sha']
assert e['reused'] is True
for k, v in {'merge': merge, 'base': base, 'head': head, 'checkout': checkout, 'tree': tree,
             'pull_request': 420, 'run_id': 42863575177, 'run_attempt': 1,
             'build_variant': 'debug', 'device_sdk': 35, 'repository_id': 1362702425}.items():
    assert e[k] == v, k
assert run['head_sha'] == merge and run['id'] == 42868141805
assert run['event'] == 'push' and run['run_attempt'] == 1 and run['conclusion'] == 'success'
assert len(jobs) == 7
assert sum(j['conclusion'] == 'skipped' for j in jobs) == 6
assert next(j for j in jobs if j['name'] == 'Verify recent same-tree PR evidence')['conclusion'] == 'success'
assert pre['run']['head_sha'] == head and pre['run']['run_attempt'] == 1 and pre['run']['conclusion'] == 'success'
assert len(pre['jobs']['jobs']) == 7 and all(j['conclusion'] == 'success' for j in pre['jobs']['jobs'])
assert sorted(e['executed_jobs']) == sorted(j['name'] for j in pre['jobs']['jobs'] if j['name'] != 'Verify recent same-tree PR evidence')
for c in [merged['commit'], x['tested']]:
    assert c['tree']['sha'] == tree and [q['sha'] for q in c['parents']] == [base, head]
assert merged['pr']['merged'] and merged['pr']['merge_commit_sha'] == merge
assert e['merged_at'] == merged['pr']['merged_at']
assert e['association_proof'] == 'unique-head-and-merge-pr'
assert e['policy'] == 'immediate-merge-prior-environment-v1'
comment = next(c for c in x['freshComments'] if c['id'] == 6774123378)
assert comment['user']['id'] == 199175422 and comment['performed_via_github_app']['id'] == 1144995
state = json.loads(re.search(r'<!-- codex-review-state:v1 (.*?) -->', comment['body'], re.S)[1])
security = json.loads(re.search(r'<!-- codex-security-review:v1 (.*?) -->', comment['body'], re.S)[1])
assert state['code_review'] == {'commit_sha': head, 'has_any_findings': False, 'has_unresolved_findings': False, 'status': 'completed'}
assert state['security_review']['commit_sha'] == head and state['security_review']['status'] == 'completed'
assert security['headSha'] == head and security['status'] == 'completed' and security['mergeGateEnabled'] is False
assert e['review'] == {'comment_id': comment['id'], 'node_id': comment['node_id'], 'head': head,
                       'updated_at': comment['updated_at'], 'app_id': 1144995,
                       'bot_id': 199175422, 'security_gate_enabled': False}
assert not pre['threads']['review_threads']
assert set(e['artifacts']) == {'build', 'tests', 'regression', 'exact', 'core', 'position'}
actual = {a['id']: a for a in x['originalArtifacts']['artifacts']}
for recorded in e['artifacts'].values():
    a = actual[recorded['artifact_id']]
    assert a['name'] == recorded['name'] and a['digest'] == recorded['digest']
    assert checkout in a['name'] and not a['expired']
    assert a['workflow_run']['id'] == 42863575177 and a['workflow_run']['head_sha'] == head
assert set(e['observed_inputs']) == {'build', 'regression', 'exact', 'core', 'position'}
for v in e['observed_inputs'].values():
    assert v['commit'] == checkout and v['run_id'] == '42863575177' and v['attempt'] == '1'
assert e['original_identity']['commit'] == checkout
assert e['original_identity']['run_id'] == '42863575177' and e['original_identity']['run_attempt'] == '1'
assert e['original_identity']['build_variant'] == 'debug'
assert re.fullmatch('[0-9a-f]{64}', e['original_identity']['source_tests_sha256'])
artifact = x['postArtifacts']['artifacts'][0]
assert artifact['id'] == 13789125209 and artifact['name'] == 'prior-evidence-link-' + merge
assert artifact['workflow_run']['id'] == run['id'] and artifact['workflow_run']['head_sha'] == merge and not artifact['expired']
digest = hashlib.sha256((p / 'prior-evidence.zip').read_bytes()).hexdigest()
assert artifact['digest'] == 'sha256:' + digest
result = {'verified': True, 'reuse': True, 'postmerge_downstream_executed': False,
          'verified_original_artifacts': 6, 'prior_evidence_zip_sha256': digest,
          'statement': 'Downloaded linkage archive and verified digest, exact source/ordered parents/tree, trusted exact-head review and six original artifact IDs/names/digests/run identities against fresh metadata. The workflow validated original large artifact bytes; this independent pass did not redownload those large artifacts or execute Android locally.'}
(p / 'independent-verification.json').write_text(json.dumps(result, indent=2) + '\n')
result.update({'pr': 420, 'head': head, 'base': base, 'merge': merge, 'tree': tree, 'tested_checkout': checkout,
               'merged_at': merged['pr']['merged_at'], 'pr_run': {'id': 42863575177, 'attempt': 1, 'conclusion': 'success'},
               'review': e['review'], 'postmerge_run': {'id': 42868141805, 'attempt': 1, 'conclusion': 'success'},
               'receipt_artifact_id': artifact['id'], 'original_artifacts': e['artifacts'],
               'pr_jobs': [{'name': j['name'], 'id': j['id'], 'conclusion': j['conclusion']} for j in pre['jobs']['jobs']],
               'postmerge_jobs': [{'name': j['name'], 'id': j['id'], 'conclusion': j['conclusion']} for j in jobs],
               'release_claim': False})
(p / 'qualification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['verified', 'merge', 'tree', 'reuse', 'verified_original_artifacts', 'prior_evidence_zip_sha256']}, indent=2))
