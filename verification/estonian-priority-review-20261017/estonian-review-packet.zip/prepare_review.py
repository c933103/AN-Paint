from pathlib import Path
import json,re,hashlib,sys,collections,xml.etree.ElementTree as E
O=Path(__file__).resolve().parent;S=O/'source';sys.path.insert(0,str(S/'tools'));import translation_catalogues as c
BASE='b6a99b41c4390ca6a412e3a1938eb913c59509fb'
pairs=json.loads((O/'pairs.json').read_text());notes={int(x.split('\t',1)[0]):x.split('\t',1)[1] for x in (O/'annotations.tsv').read_text().splitlines()};prior=json.loads((O/'prior-receipts.json').read_text());byprior={x['key']:x for x in prior['receipts']}
independent=json.loads((O/'independent-review.json').read_text());changes={x['key']:x['recommended'] for x in independent['entries']}
p=S/'Paintroid/src/main/res/values-b+et/strings.xml';baseline=O/'baseline-estonian.xml'
if not baseline.exists():baseline.write_bytes(p.read_bytes())
raw=baseline.read_text();cor=[]
for item in independent['entries']:
 key=item['key'];new=item['recommended'];pat=rf'(<string name="{key}"[^>]*>)(.*?)(</string>)';m=re.search(pat,raw,re.S)
 if not m or m[2]!=item['old']:raise ValueError('Unexpected baseline: '+key)
 raw=raw[:m.start(2)]+new+raw[m.end(2):];cor.append(item)
p.write_text(raw)
fx={'schema_version':1,'note':'Six bounded Estonian P0/P1 values plus one P2 width-template dependency after full P0/P1 review. Tests do not certify native fluency, layout or all-language completion. All existing holds remain open.','values':{},'constraints':{}}
for r in cor:
 key=r['key'];fx['values'][key]={'default':r['english'],'et':r['recommended']};fx['constraints'][key]={'attributes':{'name':key},'formatted':True,'placeholders':dict(c.placeholders(r['english'])),'escaped_newline_count':r['recommended'].count('\\n')}
(S/'tools/fixtures/current_localization/estonian_priority_current_wording.json').write_text(json.dumps(fx,ensure_ascii=False,indent=2)+'\n');(O/'corrections.json').write_text(json.dumps(cor,ensure_ascii=False,indent=2)+'\n')
def hs(v):return hashlib.sha256(v.encode()).hexdigest()
entries=[]
for r in pairs:
 key=r['key'].split('/')[1];status='accepted_static_context' if r['refs'] else 'accepted_wording_only'
 if r['n'] in (101,103,241):status='accepted_wording_only'
 if r['n'] in (17,64,78,124,199,208,217):status='held_uncertain'
 if key in changes:status='corrected_independently_accepted'
 en=r['english']['value'];old=r['estonian']['value'];new=changes.get(key,old)
 e={**r,'candidate':new,'decision':status,'reason':notes[r['n']],'confidence':'high_semantic_moderate_idiomatic' if status!='held_uncertain' else 'open','source_revision':BASE,'english_sha256':hs(en),'before_sha256':hs(old),'candidate_sha256':hs(new),'prior_receipt':byprior.get(r['key']),'new_tracker_credit':False,'limit':'Model-based complete-value linguistic and static-consumer review only; no native-speaker, installed-layout, TalkBack or whole-language certification.'}
 for field,rel in [('english','Paintroid/src/main/res/values/strings.xml'),('estonian','Paintroid/src/main/res/values-b+et/strings.xml')]:
  line=next(i+1 for i,l in enumerate((S/rel).read_text().splitlines()) if 'name="'+key+'"' in l)
  e[field+'_source_url']=f'https://github.com/c933103/AN-Paint/blob/{BASE}/{rel}#L{line}'
 for ref in e['refs']:ref['url']=f"https://github.com/c933103/AN-Paint/blob/{BASE}/{ref['path']}#L{ref['line']}"
 entries.append(e)
review={'schema_version':1,'locale':'et','source_revision':BASE,'source_tree':'f12e3f31420ab23c8edc67d72607150b796b1571','entry_count':len(entries),'tiers':dict(collections.Counter(r['tier'] for r in entries)),'summary':dict(collections.Counter(r['decision'] for r in entries)),'prior_records_preserved':len(prior['receipts']),'prior_selected_records':sum(r['prior_receipt'] is not None for r in entries),'tracker_written':False,'scope':'All 341 P0/P1 entries have full-value assessment. One P2 width template is a separately authorized shared-consumer dependency; the remaining 375 canonical entries are not fully reviewed. Wording-only and uncertain judgments remain qualified.','selection_context':{'swedish':'103 present / 238 fallback among P0/P1; outside scoped catalogue set; no entries reviewed or gap filling.','estonian':'Scoped catalogue, all 341 P0/P1 present. Current branch/PR/evidence inventory found no full Estonian priority batch; historic nine receipts retained without duplicate credit.'},'prior_receipts_ref':'cc1d2718b88b9f08e25b3013ccdbc10770e7f332','prior_receipts_path':'verification/translation-entry-review-2026-10-13/entry-review-receipts.json','p2_dependency':[x for x in cor if x['tier']=='P2'],'entries':entries}
(O/'estonian-p0-p1-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in review.items() if k not in ('entries','p2_dependency')},indent=2))
