import hashlib, json, pathlib, zipfile

p = pathlib.Path(__file__).resolve().parent
read = lambda n: json.loads((p / n).read_text())
s = json.loads((p.parent / 'session.json').read_text())
x, m, a, merge, qualified = map(read, ['postmerge-receipt.json', 'postmerge-metadata.json', 'fresh-artifact-metadata.json', 'merge.json', 'qualified.json'])
wanted = {'reused': True, 'repository_id': 1362702425, 'merge': s['merge'], 'base': s['base'], 'head': s['head'], 'checkout': s['tested_checkout'], 'tree': s['tree'], 'pull_request': s['pr'], 'run_id': s['run'], 'run_attempt': 1, 'build_variant': 'debug', 'device_sdk': 35}
for k, v in wanted.items():
    assert x[k] == v, (k, x[k], v)
assert merge['sha'] == x['merge'] and merge['tree']['sha'] == x['tree']
assert [q['sha'] for q in merge['parents']] == [x['base'], x['head']]
assert m['develop']['object']['sha'] == x['merge']
assert m['run']['id'] == s['postmerge_run'] and m['run']['event'] == 'push' and m['run']['head_sha'] == x['merge']
assert m['run']['status'] == 'completed' and m['run']['conclusion'] == 'success' and m['run']['run_attempt'] == 1
assert len(m['jobs']['jobs']) == 7 and sum(j['conclusion'] == 'skipped' for j in m['jobs']['jobs']) == 6
assert [j['name'] for j in m['jobs']['jobs'] if j['conclusion'] == 'success'] == ['Verify recent same-tree PR evidence']
byid = {q['id']: q for q in a['artifacts']}
assert set(x['artifacts']) == {'build', 'tests', 'regression', 'exact', 'core', 'position'}
for k, q in x['artifacts'].items():
    f = byid[q['artifact_id']]
    assert all(f[z] == q[z] for z in ['name', 'digest'])
    assert not f['expired'] and f['workflow_run']['id'] == x['run_id'] and f['workflow_run']['head_sha'] == x['head']
assert x['review']['comment_id'] == qualified['review_comment'] and x['review']['updated_at'] == qualified['review_updated']
assert x['review']['head'] == x['head'] and x['review']['app_id'] == 1144995 and x['review']['bot_id'] == 199175422
z = zipfile.ZipFile(p / 'postmerge.zip')
assert z.testzip() is None and z.namelist() == ['prior-evidence.json']
assert json.loads(z.read('prior-evidence.json')) == x
digest = hashlib.sha256((p / 'postmerge.zip').read_bytes()).hexdigest()
artifact = m['artifact']
assert artifact['digest'] == 'sha256:' + digest
assert artifact['workflow_run']['id'] == m['run']['id'] and artifact['workflow_run']['head_sha'] == x['merge'] and not artifact['expired']
out = {'verified': True, 'merge': x['merge'], 'tree': x['tree'], 'postmerge_run': s['postmerge_run'], 'receipt_artifact': artifact['id'], 'receipt_sha256': digest, 'original_run': x['run_id'], 'original_checkout': x['checkout'], 'original_attempt': 1, 'six_original_artifact_metadata_matched': True, 'fresh_preflight_jobs': 1, 'downstream_skips': 6, 'association_proof': x['association_proof'], 'scope': 'Verified bounded same-tree original-experiment reuse. Six downstream jobs skipped, not rerun or newly passed. The independent premerge verification checked actual APK/source, instrumentation, regression, exact-script, position and composed-device bytes plus source-discovered native/app inventories. The workflow also checked original core/position bytes; no separate original core download was required in this follow-up.'}
(p / 'postmerge-verification.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps(out, indent=2))
