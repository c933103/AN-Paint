import json,pathlib,re
p=pathlib.Path(__file__).resolve().parent;s=json.load(open(p.parent/'session.json'));g=json.load(open(p/'terminal-gates.json'));run=g['run'];jobs=g['jobs']['jobs'];pr=g['pr'];review=g['review']
assert run['id']==s['run'] and run['head_sha']==s['head'] and run['run_attempt']==1 and run['event']=='pull_request' and run['status']=='completed' and run['conclusion']=='success'
required={'Verify recent same-tree PR evidence','Build APK and corresponding source','Regression tests and lint','Exact-script resource generation','Position dialog API 35','Core emulator API 35','Emulator API 35'}
assert {j['name'] for j in jobs}==required and all(j['status']=='completed' and j['conclusion']=='success' and j['head_sha']==s['head'] for j in jobs)
assert pr['state']=='open' and not pr['draft'] and not pr['merged'] and pr['mergeable'] is True and pr['head']['sha']==s['head'] and pr['base']['sha']==s['base'] and pr['base']['ref']=='develop'
assert g['develop']['commit']['sha']==s['base'] and g['develop']['protected'] is False and g['rulesets']==[]
assert review['user']['login']=='chatgpt-codex-connector[bot]' and review['user']['id']==199175422 and review['performed_via_github_app']['id']==1144995
x=json.loads(re.search(r'<!-- codex-review-state:v1 (.*?) -->',review['body'])[1]);assert x['code_review']=={'commit_sha':s['head'],'has_any_findings':False,'has_unresolved_findings':False,'status':'completed'}
assert x['security_review']['commit_sha']==s['head'] and x['security_review']['status']=='completed';security=json.loads(re.search(r'<!-- codex-security-review:v1 (.*?) -->',review['body'])[1]);assert security['headSha']==s['head'] and security['status']=='completed' and security['mergeGateEnabled'] is False
assert not g['threads']['review_threads'] and not any(r['state']=='CHANGES_REQUESTED' for r in g['reviews']['reviews'])
for before in json.load(open(p/'owner-baseline.json')):
 after=next(o for o in g['owners'] if o['number']==before['number'])
 assert after['head']==before['head'] and after['base']==before['base'],before['number']
a=json.load(open(p/'artifact-verification.json'));assert a['head']==s['head'] and a['checkout']==s['tested_checkout'] and a['tree']==s['tree'] and a['device']['app_api35']>0 and a['device']['native_api35']>0 and a['regression']['python_passes']>0
out={'qualified':True,'head':s['head'],'checkout':s['tested_checkout'],'tree':s['tree'],'run':s['run'],'attempt':1,'checks':len(jobs),'review_comment':review['id'],'review_updated':review['updated_at'],'old_owners_unchanged':len(g['owners'])-1,'counts':{'python_passes':a['regression']['python_passes'],'python_skips':a['regression']['python_skips'],'jvm':a['regression']['jvm'],'native_api35':a['device']['native_api35'],'app_api35':a['device']['app_api35'],'exact_probes':a['exact_probes']}}
(p/'qualified.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
