import hashlib,io,json,pathlib,re,sys,zipfile,xml.etree.ElementTree as E
p=pathlib.Path(__file__).resolve().parent;s=json.loads((p.parent/'session.json').read_text());meta=json.loads((p/'artifact-meta.json').read_text());byid={a['id']:a for a in meta['artifacts']};files=json.loads((p/'artifact-files.json').read_text())
def digest(b):return hashlib.sha256(b).hexdigest()
def archive(kind):
 a=byid[files[kind]['id']];b=(p/files[kind]['file']).read_bytes();assert a['digest']=='sha256:'+digest(b),kind
 assert not a['expired'] and a['workflow_run']['id']==s['run'] and a['workflow_run']['head_sha']==s['head']
 assert s['tested_checkout'] in a['name'];z=zipfile.ZipFile(io.BytesIO(b));names=z.namelist();assert len(names)==len(set(names)) and z.testzip() is None
 assert all(not pathlib.PurePosixPath(n).is_absolute() and '..' not in pathlib.PurePosixPath(n).parts for n in names)
 return z,a
out={'run':s['run'],'head':s['head'],'checkout':s['tested_checkout'],'tree':s['tree'],'verified_artifacts':{}}
zs={}
for kind in files:
 zs[kind],a=archive(kind);out['verified_artifacts'][kind]={'id':a['id'],'digest':a['digest']}
if 'exact' in zs:
 z=zs['exact'];x=json.loads(z.read('summary.json'));assert x['success'] and x['commit']==s['tested_checkout'] and x['tree']==s['tree']
 for q in x['probes']:
  assert (q['exit_code']==0)==q['expected_success'];assert digest(z.read(q['name']+'.log'))==q['log_sha256']
 out['exact_probes']=len(x['probes'])
if 'apk-source' in zs:
 z=zs['apk-source'];build=json.loads(z.read('build/delivery/build-info.json'));assert build['commit']==s['tested_checkout'] and build['run_id']==str(s['run']) and build['build_variant']=='debug'
 apk=z.read('app/build/outputs/apk/debug/app-debug.apk');src=z.read('build/delivery/AN-Paint-source.zip');assert digest(apk)==build['apk_sha256'] and digest(src)==build['source_sha256']
 with zipfile.ZipFile(io.BytesIO(apk)) as az:assert az.read('assets/local-source/AN-Paint-source.zip')==src
 sz=zipfile.ZipFile(io.BytesIO(src));tree=json.loads((p/'tested-tree.json').read_text());assert tree['sha']==s['tree'] and not tree['truncated'];missing=[];count=0
 for e in tree['tree']:
  if e['type']!='blob':continue
  n='AN-Paint/'+e['path']
  if n not in sz.namelist():missing.append(e['path']);continue
  b=sz.read(n);assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==e['sha'],e['path'];count+=1
  if e['path'].startswith(('tools/','app/src/androidTest/','Paintroid/src/androidTest/')):
   target=p/'source'/e['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
 assert missing==['.gitignore','.idea/codeStyles/Project.xml','colorpicker/.gitignore']
 out['source']={'matched_tracked_blobs':count,'known_gradle_ant_exclusions':missing,'embedded_matches_standalone':True,'apk_sha256':build['apk_sha256'],'source_sha256':build['source_sha256'],'signing':build['signing']}
if 'instrumentation' in zs:
 z=zs['instrumentation'];ip={n:digest(z.read(n)) for n in z.namelist() if n.endswith('.apk')};assert len(ip)==2;out['test_apks']=ip
if 'regression' in zs:
 z=zs['regression'];obs=json.loads(z.read('build/reports/ci-phases/observed-inputs.json'));assert obs['commit']==s['tested_checkout'] and obs['run_id']==str(s['run']) and obs['attempt']=='1'
 xmls=[n for n in z.namelist() if '/test-results/testDebugUnitTest/TEST-' in n and n.endswith('.xml')];counts={k:0 for k in ['tests','failures','errors','skipped']}
 for n in xmls:
  x=E.fromstring(z.read(n))
  for k in counts:counts[k]+=int(x.get(k,0))
 assert counts['tests']>0 and not sum(counts[k] for k in ['failures','errors','skipped'])
 m=re.search(r'Ran (\d+) tests in [\d.]+s\s+OK(?: \(skipped=(\d+)\))?\s*$',z.read('build/reports/ci-phases/python.log').decode());assert m
 out['regression']={'python_passes':int(m[1])-int(m[2] or 0),'python_skips':int(m[2] or 0),'jvm':counts,'jvm_xml_files':len(xmls)}
if 'position' in zs:
 z=zs['position'];identity=json.loads(z.read('device-identity.json'));assert identity['commit']==s['tested_checkout'] and identity['run_id']==str(s['run']) and identity['run_attempt']=='1' and identity['device_sdk']==35
 if 'source' in out:assert identity['apk_sha256']==out['source']['apk_sha256'] and identity['source_sha256']==out['source']['source_sha256']
 root=p/'position'
 for n in z.namelist():
  if n.endswith('/'):continue
  dest=root/n;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z.read(n))
 sys.path.insert(0,str(p/'source/tools'))
 from app_instrumentation_matrix import verify_app_reports,read_app_reports
 from run_android_instrumentation import declared_tests,source_tests_sha256
 source=p/'source/app/src/androidTest';eligible=declared_tests(source,sdk_level=35)
 pos=verify_app_reports(eligible,35,read_app_reports(root,35,'position'),source_tests_sha256(source),declared_tests(source)-eligible,'position')
 assert pos['source_tests_sha256']==identity['source_tests_sha256'] and pos['selected_tests']==pos['completed_tests']
 out['position_identity']=identity;out['position_tests']=pos['completed_tests'];(p/'fresh-position-validator.json').write_text(json.dumps(pos,indent=2)+'\n')
if 'composition' in zs:
 z=zs['composition'];identity=json.loads(z.read('composed-device-identity.json'));selection=json.loads(z.read('artifact-selection.json'))
 assert identity['commit']==s['tested_checkout'] and identity['run_id']==str(s['run']) and identity['device_sdk']==35 and identity['build_variant']=='debug'
 assert identity['composed_in_run_attempt']==1 and identity['group_run_attempts']=={'core':1,'position':1}
 assert identity['apk_sha256']==out['source']['apk_sha256'] and identity['source_sha256']==out['source']['source_sha256']
 assert identity['test_apk_sha256']==out['test_apks']['app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk']
 assert selection['run_id']==s['run'] and selection['current_attempt']==1 and selection['checkout']==s['tested_checkout'] and selection['workflow_head']==s['head']
 for kind,a in selection['selected'].items():
  actual=byid[a['artifact_id']];assert all(actual[k]==a[k] for k in ['name','digest','created_at','updated_at']);assert actual['workflow_run']['id']==s['run']
  if kind=='position':assert a['artifact_id']==files['position']['id']
 root=p/'composition'
 for n in z.namelist():
  if n.endswith('/'):continue
  dest=root/n;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z.read(n))
 sys.path.insert(0,str(p/'source/tools'))
 from app_instrumentation_matrix import verify_app_reports,read_app_reports
 from run_android_instrumentation import declared_tests,source_tests_sha256
 source=p/'source/app/src/androidTest';eligible=declared_tests(source,sdk_level=35)
 app=verify_app_reports(eligible,35,read_app_reports(root,35),source_tests_sha256(source),declared_tests(source)-eligible)
 assert app['source_tests_sha256']==identity['source_tests_sha256'] and app['completed_tests']==app['selected_tests']==app['sdk_eligible_tests']
 native=json.loads(z.read('Paintroid/androidTest-results/summary.json'));assert native['success'] and native['completed_tests']==native['expected_tests'] and not any(native[k] for k in ['missing','unexpected','errors']);assert all(c['status']=='passed' for c in native['cases'])
 native_source=p/'source/Paintroid/src/androidTest'
 from run_android_instrumentation import parse_protocol
 native_eligible=declared_tests(native_source,sdk_level=35)
 assert native['source_tests_sha256']==source_tests_sha256(native_source) and native['device_sdk']==35
 assert native['excluded_classes']==[] and native['included_tests']==[] and native['sdk_suppressed_tests']==[]
 native_fresh=parse_protocol(z.read('Paintroid/androidTest-results/instrumentation.log').decode(),native_eligible,returncode=native['returncode'],timed_out=native['timed_out'])
 assert native_fresh['success'] and native_fresh['cases']==native['cases'] and native_fresh['completed_tests']==len(native_eligible)
 (p/'fresh-native-validator.json').write_text(json.dumps(native_fresh,indent=2)+'\n')
 out['device']={'native_api35':native_fresh['completed_tests'],'app_api35':app['completed_tests'],'identity':identity,'selection':selection};(p/'fresh-app-validator.json').write_text(json.dumps(app,indent=2)+'\n')
out['limits']='Independent source-bound artifact/report verification only. Not a new execution, native-human review, exhaustive linguistic/UI/glyph/layout/speech acceptance or release.'
(p/'artifact-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['position_identity','device']},indent=2));print('Device results',out.get('device',{}).get('native_api35'),out.get('device',{}).get('app_api35'))
