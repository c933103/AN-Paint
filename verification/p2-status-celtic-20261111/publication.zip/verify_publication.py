import copy, hashlib, json, pathlib, stat, zipfile, xml.etree.ElementTree as E
w=pathlib.Path(__file__).resolve().parent
load=lambda n:json.loads((w/n).read_text())
git=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
norm=lambda tree:{e['path']:{k:e[k] for k in ['path','mode','type','sha']} for e in tree['tree'] if e['type']!='tree'}
base=load('base-tree.json');fresh=load('fresh-tree.json');expected={e['path']:e for e in load('expected-tree.json')}
assert not base['truncated'] and not fresh['truncated'] and norm(base)==norm(fresh)
old={p['number']:p for p in load('owners.json') if p['number']!=433};new={p['number']:p for p in load('fresh-owners.json')};assert old==new
package=load('package.json');b=(w/'preparation.zip').read_bytes();assert len(b)==package['bytes'] and hashlib.sha256(b).hexdigest()==package['sha256'] and git(b)==package['git_blob']
with zipfile.ZipFile(w/'preparation.zip') as z:
 assert z.testzip() is None
 for name,entry in load('manifest.json').items():
  b=z.read(name);assert b==(w/name).read_bytes() and len(b)==entry['bytes'] and hashlib.sha256(b).hexdigest()==entry['sha256'],name
accepted=load('accepted-map.json');review=load('review.json');inputs=load('inputs.json');integration=load('integration.json')
assert review['candidate_sha256']==hashlib.sha256((w/'candidate.json').read_bytes()).hexdigest()
assert review['accepted_map_sha256']==hashlib.sha256(json.dumps(accepted,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert len(review['reviews'])==sum(map(len,accepted.values()))==32
for d in review['reviews']: assert d['final_value_decision']=='accept' and d['accepted_value']==d['final_value']==accepted[d['locale']][d['key']]
held=load('held-absence.json');blobs=load('held-blobs.json')
for pair in held:
 assert new[pair['pr']]['head']==pair['head'];b=blobs[pair['blob']];assert git(b.encode())==pair['blob']
 assert not set(accepted[pair['tag']])&{n.get('name') for n in E.fromstring(b)}
count=0
for f in (w/'source').rglob('*'):
 path=f.relative_to(w/'source').as_posix()
 if f.is_file() and path in expected:
  assert git(f.read_bytes())==expected[path]['sha'],path
  assert ('100755' if f.stat().st_mode&stat.S_IXUSR else '100644')==expected[path]['mode'],path
  count+=1
changes=[path for path in expected if expected[path]!=norm(fresh)[path]]
assert set(changes)==set(inputs['paths'].values()) and set(expected)==set(norm(fresh))
for tag,values in accepted.items():
 path=inputs['paths'][tag];txt=(w/'source'/path).read_text();nodes={n.get('name'):n for n in E.fromstring(txt)}
 for k,v in values.items():
  n=nodes[k];assert n.text==v and n.attrib==inputs['source'][k]['attributes']
  txt=txt.replace('    '+E.tostring(n,encoding='unicode').rstrip()+'\n','')
 assert git(txt.encode())==norm(fresh)[path]['sha'],tag
 assert git((w/'source'/path).read_bytes())==integration[tag]['blob']
out={'base':'ecdf4d97c431bc49eb4356f6a6abf8cd2600d466','base_tree':inputs['base_tree'],'prepared_source_base':inputs['base'],'complete_source_tree_unchanged':True,'checked_materialized_files':count,'complete_expected_leaves':len(expected),'open_owners':len(new),'held_heads':len({p['head'] for p in held}),'held_catalogue_pairs':len(held),'git_verified_held_blobs':len(blobs),'new_values':32,'old_nodes_preserved':sum(integration[t]['old_nodes_preserved'] for t in accepted),'source_changes':len(changes),'prepared_packet_git_blob':package['git_blob']}
(w/'publication-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
