from pathlib import Path
import json,hashlib,shutil,os,re,xml.etree.ElementTree as E
O=Path(__file__).resolve().parent; S=O/'source'; prior=Path('/workspace/shared/anpaint-turkish-full-review-20261017');tree=json.loads((prior/'develop-tree.json').read_text()); assert tree['sha']=='e414a4df64a56c2d8a2f374741b1f1b58fceea9b'
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
roots=[prior/'source',prior/'worktree',prior/'application-candidate'];manifest=[];missing=[]
for row in tree['tree']:
 if row['type']!='blob':continue
 rel=row['path']
 for root in roots:
  p=root/rel
  if p.is_file() and blob(p.read_bytes())==row['sha']:
   dest=S/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest);dest.chmod(0o755 if row['mode']=='100755' else 0o644);manifest.append({'path':rel,'git_blob_sha':row['sha'],'mode':row['mode'],'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()});break
 else:missing.append(rel)
if missing:raise RuntimeError(missing)
(O/'develop-tree.json').write_text(json.dumps(tree,indent=2)+'\n');(O/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');shutil.copyfile(prior/'prior-receipts.json',O/'prior-receipts.json')
en={e.get('name'):''.join(e.itertext()) for e in E.parse(S/'Paintroid/src/main/res/values/strings.xml').getroot()};el={e.get('name'):''.join(e.itertext()) for e in E.parse(S/'Paintroid/src/main/res/values-el/strings.xml').getroot()};pri=json.loads((S/'translations/string-importance.json').read_text());files={str(p.relative_to(S)):p.read_text().splitlines() for p in S.rglob('*') if p.suffix in ('.kt','.java','.xml','.html','.js') and '/main/' in str(p) and '/res/values' not in str(p) and '/res/drawable' not in str(p)};pairs=[];context={}
for tier in pri['tiers']:
 if tier['id'] not in ('P0','P1'):continue
 for key in tier['keys']:
  name=key.split('/')[1];refs=[]
  for f,lines in files.items():
   for i,line in enumerate(lines):
    if re.search(r'(?:R\.string\.|@string/)'+re.escape(name)+r'\b',line):refs.append({'path':f,'line':i+1});context.setdefault(f,[]).append((i,name))
  pairs.append({'n':len(pairs)+1,'tier':tier['id'],'key':key,'english':en[name],'greek':el.get(name),'refs':refs})
(O/'pairs.json').write_text(json.dumps(pairs,ensure_ascii=False,indent=2)+'\n');(O/'pairs.txt').write_text('\n\n'.join(f"{r['n']} {r['tier']} {r['key']}\nEN: {r['english']}\nEL: {r['greek']}\nCALLS: "+', '.join(Path(x['path']).name+':'+str(x['line']) for x in r['refs']) for r in pairs)+'\n')
for f,locs in context.items():
 seen=set();out=[]
 for i,name in locs:
  rg=range(max(0,i-5),min(len(files[f]),i+7));chunk=[f'{j+1}: {files[f][j]}' for j in rg if j not in seen];seen.update(rg)
  if chunk:out.append('\n'.join(chunk))
 p=O/'context'/Path(f).name;p.parent.mkdir(exist_ok=True);p.write_text('\n\n'.join(out)+'\n')
print('source files',len(manifest),'pairs',len(pairs),'without refs',len([r for r in pairs if not r['refs']]))
