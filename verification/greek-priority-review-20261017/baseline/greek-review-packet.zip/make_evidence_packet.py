from pathlib import Path
import json,zipfile,hashlib
O=Path(__file__).resolve().parent
required=['README.md','acceptance-and-limits.json','validation-development-notes.md','test-summary.json','greek-p0-p1-341-review.json','compact-ledger.json','greek-corrections-and-holds.json','prior-receipts.json','source-manifest.json','candidate-manifest.json','develop-tree.json','pairs.json','pairs.txt','decisions.tsv','prepare.py','build_packet.py','validate_packet.py','make_evidence_packet.py','greek-four-priority-corrections.patch','greek-application.patch','packet-validation-normal.json','packet-validation-optimized.json','focused-normal.log','focused-optimized.log','host-normal.log','host-optimized.log','catalogue-validation.log','priority-validation.json','aapt-compile.stdout.log','aapt-compile.stderr.log','aapt/compiled-greek.zip']
files={r:O/r for r in required}
for base in ['context','source/tools','source/translations']:
 for p in (O/base).rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':files[str(p.relative_to(O))]=p
for r in ['AGENTS.md','CI.md','TRANSLATING.md','README.md','verification/README.md','Paintroid/src/main/res/values/strings.xml','Paintroid/src/main/res/values-el/strings.xml']:
 p=O/'source'/r
 if p.is_file():files['source/'+r]=p
for row in json.loads((O/'pairs.json').read_text()):
 for ref in row['refs']:
  r='source/'+ref['path'];files[r]=O/r
for r in ['Paintroid/src/main/res/values-el/strings.xml','tools/test_greek_priority_wording.py','tools/fixtures/current_localization/greek_priority_current_wording.json']:files['candidate/'+r]=O/'candidate'/r
manifest={'source_revision':'e414a4df64a56c2d8a2f374741b1f1b58fceea9b','contents_scope':'Full evidence, all referenced production consumers and relevant text inputs; source/ and candidate/ are deliberately partial text snapshots. Complete checkout required for full-tree validator.','files':[{'path':r,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for r,p in sorted(files.items())]}
(O/'packet-file-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');files['packet-file-manifest.json']=O/'packet-file-manifest.json'
with zipfile.ZipFile(O/'greek-review-packet.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for r,p in sorted(files.items()):z.write(p,r)
with zipfile.ZipFile(O/'greek-review-packet.zip') as z:
 if z.testzip() is not None:raise ValueError('ZIP CRC failure')
 for r,p in files.items():
  if z.read(r)!=p.read_bytes():raise ValueError('ZIP readback '+r)
standalone=['README.md','compact-ledger.json','greek-corrections-and-holds.json','acceptance-and-limits.json','test-summary.json','greek-review-packet.zip','packet-file-manifest.json']
(O/'SHA256SUMS').write_text(''.join(hashlib.sha256((O/r).read_bytes()).hexdigest()+'  '+r+'\n' for r in standalone))
print(json.dumps({'files':len(files),'archive_bytes':(O/'greek-review-packet.zip').stat().st_size,'archive_sha256':hashlib.sha256((O/'greek-review-packet.zip').read_bytes()).hexdigest()}))
