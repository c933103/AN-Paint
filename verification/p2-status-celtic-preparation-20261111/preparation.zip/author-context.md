# Celtic status preparation, independent review requested

Preparation only on pending PR #433 application head ae3cc888807db6928e5d962fa4fe16860699ba79, tree 9705571dba69bacbb7270363cdcc1f3923de790c. No application branch or next PR will be created until #433 and actual develop qualify, then active owners/holds and full source tree must be refreshed. 32 proposals, eight missing active P2 values each in offered ga (Irish), cy (Welsh), gd (Scottish Gaelic), br (Breton) catalogues. Existing strings remain unchanged; no assumption of prior linguistic approval.

Read exact English/attributes/missing keys in inputs.json and full candidates in candidate.json. Independently assess each complete value, revise what is confidently correctable and hold uncertainty. The author has greater uncertainty about Scottish Gaelic redirect plurals and Breton gallery terminology; do not rubber-stamp these. In Irish the Paint action is rendered as editing with Paint, avoiding a forced/unverified mutation of the product name. Check whether the equivalent action remains clear. Check Welsh pixel mutation and Gaelic noun cases, and the exact referent of unsupported URL clauses. No format parameters are newly proposed.

Actual source contexts are unchanged from #433 and are available in source/:
- ImageResizeDialog.kt:49 and AssemblyActivity.kt:311: fits-the-current-budget appended to image memory estimates. Working memory, not money or storage; no guarantee of operation success.
- AssemblyActivity.kt:194: enable Android Files/Documents app after ACTION_OPEN_DOCUMENT and ACTION_GET_CONTENT both raise ActivityNotFoundException. Those are apps, not individual files; vendor labels vary.
- MediaGalleryActivity.kt:336: whole image-URL validation (scheme/user-info/port/provider-host/path), not just host. :346 is redirect-count exhaustion. No outage/malice/security assertion.
- AssemblyActivity.kt:156: time unavailable replaces missing modification timestamp, not elapsed time or timeout.
- ClassicPaintActivity.kt:822: tool option is single-choice setting-dialog title, not selecting a drawing tool.
- ClassicPaintActivity.kt:776: tap a pixel is colour-picker instruction.
- AssemblyActivity.kt:88: edit in Paint transfers generated assembly into the Paint editor, not an export format.

Nearby catalogue context: Irish cuimhne, uirlis, picteilín, Tapáil, Cumasaigh; Welsh cof, offeryn, picsel, Tapiwch, Galluogwch; Scottish Gaelic cuimhne, inneal, piogsail, Thoir gnogag, Cuir ... an comas; Breton memor, ostilh, piksel, Pouezit, Gweredekait. Files/Documents are kept recognizable. Curly apostrophes are ordinary orthographic text and should remain Android-safe; no bidi controls. Please preserve every actual-language distinction rather than replacing unfamiliar wording with a neighboring language.

Return review.json with individual exact source/candidate/final value and accept/revise/hold rationale, and accepted-map.json with only final accepted values. Public-facing reviewer label should not contain internal task paths. No source/repository modifications. Independent model/source review is not native-human or exhaustive UI/layout/glyph/accessibility/speech/device acceptance. No external primary terminology source consulted. All older holds/rechecks/restrictions remain untouched.


## Independent review and final-source checks

The separate full-value review retained 30 proposals and revised Irish and Breton memory-limit wording; all 32 final values accepted, no new holds. Its limited external terminology checks corroborated the Scottish Gaelic redirect plural and Breton gallery/redirection/memory terms. The review lists each source and its narrow support, not full-sentence native acceptance. All 46 affected existing host checks passed on final source. There are no new format parameters. All 1,611 old nodes/attributes remain unchanged. A verification driver initially assumed the candidate digest was canonical JSON, but the reviewer used file bytes for the candidate and canonical JSON for the accepted map; correct conventions then passed. That was a verifier assumption, not a translation test failure or source edit.
