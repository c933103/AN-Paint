# API30 release evidence-transport diagnosis and proposed correction

This is a design for parent review, not an implemented source change. The reviewed budget tree remains frozen at `db713bbf28abdf45311454329b6435b1ce24b62d`.

## Exact observed boundary

Run `38073935029`, release-configured source tree `6d6b90c1999d9e771970ab08e4c275e999c446ca`:

- API30 job `114279985346` completed all 73 native and 22 app methods, including both vertical shards. All three required API30 combined-union receipts were written, and main completed at +351 seconds. This is protocol/source coverage, not screenshot acceptance.
- Cleanup's `adb pull /sdcard/Android/data/paint.anpaint.android/files/vertical-locale-evidence` returned `Permission denied` while attempting to stat that exact directory. Artifact `11677704020` has 29 files and no screenshot matrix. SHA256 `a676f3ee8e164864e613c3a696256391bc096df1492763b399641234e8ad12b2`.
- The same exact release source completed API35 main at +494 seconds and uploaded screenshot evidence in artifact `11678419053` (SHA256 `a813678e7a67623567a5b7e890449be7c822c8af38463db22c2a3db9f1463ca6`). Its independent artifact verification is in progress. This difference does not prove a universal API30/35 storage rule; it proves the present host pull path is unreliable on the required API30 release environment.
- Earlier PR41 success was debug/API35. PR34's release/API30 standalone run did not include this vertical evidence collector. We do not infer debug/API30 behavior, which has not been tested here.

## Source ownership

`VerticalLocaleDeviceTest.kt:553–563` writes its original screenshot bytes into `File(targetContext.getExternalFilesDir(null), "vertical-locale-evidence")` and checks nonempty screenshots and frame differences. `VerticalControlReachabilityProbe.kt:40–42,417–418,461–467` writes the 64 reachability screenshots and eight JSON receipts into its `reachability` subdirectory, through the same owning target context. These app-owned writes passed; the later host access failed.

`ci_emulator.sh:157–158` clears the old external evidence path before tests. Lines 211–223 pull the directory and then require both strict screenshot and reachability validators. The failure is correctly retained; it must not be made optional.

`app/build.gradle:89–106` selects release instrumentation with normal release configuration. Do not change debuggability, signing mode, production permissions, root state, storage app-ops, or the rendered UI tests.

## Recommended supported export

Use a **test-only, app-owned MediaStore Downloads export** of the already-captured synthetic evidence. Android documents that on Android 10+ an app can access and modify its own MediaStore Downloads entries without storage permissions:
https://developer.android.com/training/data-storage/shared/media

1. Add an instrumentation-only JUnit lifecycle rule/helper. Map the four existing test method names to their four fixed locale identifiers; no arbitrary filename or shell command comes from the device UI. Keep every existing test method body and assertion, direct-ADB runner and phase selector unchanged.
2. At the start of each test, the owning app clears only that locale's exact, allowlisted synthetic evidence filenames in its app-specific directory. This prevents stale original files from qualifying. It also removes only its own exact MediaStore export entry for that locale. No broad recursive export or unrelated app data is read.
3. After the original test and cleanup, read the existing evidence bytes through the owning target context. Package one ZIP per locale, with the original relative paths and a transport manifest. Four locales each have 8 original captures + 16 reachability captures + 2 JSON receipts = 26 data files, 104 overall. Do not recapture, render, resize or alter image/receipt bytes.
4. Write through `ContentResolver.insert/openOutputStream` into a fixed `MediaStore.Downloads` relative directory such as `Download/anpaint-ci-vertical-evidence/`, with a fixed allowlisted locale ZIP name, MIME `application/zip`, and `IS_PENDING=1`. Close and verify the written length/name/path, then clear `IS_PENDING` only after the ZIP is complete. Delete a failed pending entry. This grants no permission and introduces no production provider or endpoint.
5. The host clears/checks absence of only that public synthetic export directory before both shards, inside the existing 10-second reset deadline. Cleanup pulls only the public export directory inside the existing 15-second collection deadline. It then validates/extracts into the unchanged host evidence layout and runs the original screenshot and reachability validators. No fallback accesses the denied Android/data path.
6. Use the same export path on API30 and API35 and debug/release. This avoids conditional weaker acceptance. Both installed API30/35 release jobs must validate the new exact source; host mocks are insufficient. Debug behavior should also have an explicit compatibility test/receipt, not an inferred pass.

This export is narrow: the app reads only its own synthetic test artifacts and deliberately publishes only those bytes using its supported ownership APIs. It does not try to evade the failed host access by changing OS permissions, running root, or making release debuggable.

## Safeguards and failure semantics

- Allowlist locale names and all 104 original relative data paths. Canonical source path must be under the exact app-owned evidence directory; reject symlinks, unknown files in the exported selection, traversal, absolute paths and unsafe ZIP entry names. No paths come from translated UI labels or document names.
- Each locale ZIP contains a versioned manifest with captured SDK, exact test-method identity, expected file inventory, actual lengths and SHA256 per original data file. Require a final complete marker only when all expected files exist and the original test succeeded. Source/APK identity remains independently checked by the existing build provenance and runner source digest.
- Bound bytes before allocating/streaming: proposed 2 MiB per original file, 8 MiB per locale uncompressed, 32 MiB combined uncompressed, 8 MiB per ZIP, 64 KiB manifest and exactly 27 members per successful ZIP (26 data + manifest). Existing PR41 evidence has 104 files totaling 7,131,642 bytes; its largest file is a 605,648-byte reachability JSON. Recheck the new API35 sample before finalizing these limits. The caps are transport sanity guards, not a test deadline extension.
- Host rejects missing/extra/duplicate ZIPs, duplicate member names, directory/symlink entries, encrypted entries, unsupported manifest versions, renamed `(1)` MediaStore filenames, cross-locale swaps, wrong SDK/method, length/hash mismatch, truncation, oversized or missing data, and partial markers. Extract only after full bounded validation, atomically into a fresh destination. Never use generic unsafe `extractall` on unchecked input.
- On a failed UI test, preserve a clearly marked partial export of available allowlisted evidence if possible, but never claim a complete manifest. The test failure and missing matrix stay failures. Export failure itself must fail the test/collector; it cannot suppress the original failure. Preserve both errors when they coexist.
- The original raw method union can remain a separate successful receipt while collection fails. Screenshot acceptance still requires all 96 images, all eight reachability receipts, hashes, native input provenance and rendered-image review.
- Export happens inside the existing 180-second vertical invocations. Reset and pull deadlines remain 10/15 seconds; native/ordinary/gallery/seed/verify deadlines and 36/46 outer budgets stay unchanged. If installed export exceeds those limits, diagnose/reduce overhead rather than increase phase caps.

## Validation before publication

- Host fixture tests for every path/inventory/size/hash/SDK/partial corruption above, tested in normal, -O and PYTHONOPTIMIZE modes; whole suite and historical source replay remain required.
- Instrumentation helper contracts: fixed locale-method map, no broad storage/root/shell-permission APIs, no production manifest changes, exact original Android test-method bodies/assertions preserved, no new or removed phase method identities. Deterministic lifecycle clearing/export only affects evidence.
- Kotlin/JVM tests for ZIP manifest/path/limits if helper logic can be factored without changing application code. Android provider calls need installed tests; do not pretend host source checks prove them.
- Real API30 and API35 release CI must show complete transport manifests, byte-verified extraction, original union, 96 decoded/reviewed images, eight receipts, 28 native drags and unchanged phase deadlines. Preserve the failed API30 artifact as the regression witness. Do not publish the frozen budget-only candidate as a complete fix for this separate failure.

## Alternatives considered

- `UiAutomation.executeShellCommandRw` is API31+, so it does not solve API30. Its official API reference confirms the minimum: https://developer.android.com/reference/android/app/UiAutomation#executeShellCommandRw(java.lang.String)
- Chunked shell commands could copy bytes to shell-owned storage, but add command-quoting, binder-size and excessive per-chunk overhead concerns. MediaStore provides a clearer app-owned export without broad shell privileges.
- Instrumentation status streaming would require changing the strict direct-ADB protocol parser (unknown status codes currently fail) and handling transaction limits. It is unnecessary for this targeted collection correction.
