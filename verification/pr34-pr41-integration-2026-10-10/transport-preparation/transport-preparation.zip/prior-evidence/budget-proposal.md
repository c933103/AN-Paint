# PR34 combined timeout correction: proposal for review

Source under review: PR34 head `739a3dcf1a59785d98a5f5a00f4b76a1b00e6472`, tree `6d6b90c1999d9e771970ab08e4c275e999c446ca`. Line references below refer to that immutable source. Nothing in this proposal has been published as a source change.

## Recommendation

- Emulator execution step: **36 minutes**, replacing 15. This accommodates the existing modeled longest failure-and-collection path of 2,069 seconds plus a separate 60-second operational allowance, rounded up to whole minutes: ceil((2069 + 60) / 60) = 36. It is a hard cancellation ceiling, **not a runtime target or a universal termination guarantee**.
- Emulator job: **46 minutes**, replacing 25. Preserve the existing 6-minute image step and the existing 4-minute checkout/download/upload/job-overhead allowance: 36 + 6 + 4. This is the smallest change that preserves those existing allowances, rather than silently shrinking them. A lower 43–45-minute job cap would reduce that old overhead allowance; no claim is made that 46 is a mathematical minimum across all infrastructure conditions.
- Every existing native/ordinary/gallery/vertical/seed/verify deadline and assertion stays exactly unchanged: 180 / 180 / 90 / 180 / 180 / 60 / 60 seconds. No retry or missing-method exemption is introduced. Ordinary/gallery acceptance-margin targets remain 30 / 20 seconds.
- Host Python step: propose **4 minutes**, replacing 2, after inspecting the exact old-run failure log. The final local composed suite took 167.102 seconds; an earlier full run took 144.499 seconds. Three minutes leaves only 12.898 seconds over the higher sample, less than the observed 22.603-second spread. Four is the first whole-minute setting exceeding the higher sample plus that observed spread. This is an operational allowance, not evidence that the current CI failure is caused only by timeout.
- Separately flag the checks job: its existing 20-minute outer cap is less than the aggregate current step maxima (2 + 8 + 2 + 12 + 6 + 6 = 36 minutes), so it has always been an aggregate cancellation policy rather than a full-path guarantee. Increasing Python to 4 would make that 38. A minimal companion **22-minute** checks job preserves the previous 2-minute relative allowance; it does not claim to admit all step maxima. Alternatively, a full structural checks-path model would need a separate policy decision. Do not conflate this inherited limit with the emulator correction.

## Additive path model: API35

All figures here are nominal controlled-subprocess timeout sums, excluding the separately identified unbounded work. They are deliberately larger than observed successful execution, and do not predict normal runtime.

| Component | Seconds | Immutable source references and accounting |
|---|---:|---|
| AVD create + ADB discovery + shared readiness + main APK install | 270 | `tools/ci_emulator.sh:258–285`: 30 + 60 + **one shared 120** + 60. Do not multiply readiness by its seven probes. Startup command kill graces occur on failing prefixes and cannot be appended to the full seven-invocation path. |
| Instrumentation | 930 | `ci_emulator.sh:104,142,169,180,197,293–310`: 180 native + 180 ordinary + 90 gallery + 180 + 180 vertical + 60 seed + 60 verify. |
| Seven runner preparations | 630 | `tools/run_android_instrumentation.py:371–395`: each does SDK query 15 + test APK install 60 + instrumentation discovery 15 = 90. This is **in addition** to main APK installation. It is outside `capture_live`'s phase deadline. |
| Seed-only runner live-PID query | 10 | `run_android_instrumentation.py:408–409`. Separate from the outer shell PID checks, counted once. |
| Outer restart boundary | 90 | `ci_emulator.sh:93–95,120–132`: launcher 30 + four PID checks × 10 + resumed-activity dumpsys 10 + external force-stop 10. The internal seed PID above is a fifth, distinct query. |
| Vertical evidence-directory reset | 10 | `ci_emulator.sh:157–158`. Occurs once before both shards. |
| Capture tail allowance | 35 | `run_android_instrumentation.py:295–332`: seven × 5-second `communicate` tail. The normal `wait` uses the **remaining phase deadline**, not a second whole phase. |
| Cleanup controlled commands + process polling | 54 | `ci_emulator.sh:208–235`: logcat 10 + 3 kill grace, pull 15 + 3, emulator kill 10 + 3, at most ten 1-second polls. Count cleanup once after the main driver, not once per phase. |
| Recoverable phase-timeout cleanup on longest continuing path | 40 | `run_android_instrumentation.py:423–426`: native, either vertical shard, and verify can each timeout and spend a 10-second target force-stop while all seven selected invocations are still attempted. See the branch analysis below. |
| **Controlled-path envelope** | **2,069** | 270 + 930 + 630 + 10 + 90 + 10 + 35 + 54 + 40. |
| Explicit processing/scheduling allowance | **60** | Source inventory, protocol parsing/report writes, startup shell/process scheduling, screenshot and reachability verification; this is an allowance under the outer hard stop, not a proven inner bound. |
| **Provision before minute rounding** | **2,129** | **36 minutes = 2,160 seconds**, leaving 31 seconds after the stated allowance. |

The all-success controlled path is 2,029 seconds, without the 40-second timeout recovery term. The long failing path must remain a failure even if all later phases run and artifacts upload.

## Mutually exclusive branches and double-counting checks

1. **Ordinary or gallery fails:** both are still attempted, and both vertical shards still run, but API35 restart is skipped (`ci_emulator.sh:302–322`). Removing seed + verify + outer restart removes 410 seconds from the all-success path. Even permitting recovery in all five attempted phases gives 2,029 − 410 + 50 = **1,669 seconds**, below 2,069.
2. **Seed fails:** the seed invocation's `|| return` (`:100–104`) prevents the post-seed 50 seconds of boundary work and the complete 155-second verify preparation/capture. Allow native + two vertical + seed recoveries: 2,029 − 205 + 40 = **1,864 seconds**.
3. **Outer restart command fails:** each command's `|| return` prevents later boundary commands and verify. Even failure at the final 10-second PID check adds only its 1-second kill grace while removing the entire 155-second verify invocation: 2,029 − 155 + 1 + 30 = **1,905 seconds**. Earlier boundary failure is shorter. Recovery here is only native + two vertical; it is not the runner's instrumentation-timeout force-stop.
4. **Vertical reset fails:** its 3-second grace is possible, but both 275-second shard invocations are then skipped. It cannot be added to the all-seven envelope. Independent restart may still run and failure remains retained (`:157–183,315–322`).
5. **Startup fails:** the 5-second AVD/ADB/install kill graces or final readiness probe's 1-second grace belong to a failing startup prefix. There are no later instrumentation phases on that branch. Earlier readiness probe timeouts consume the shared 120 seconds; do not add every probe's timeout/grace again outside that shared budget.
6. **Capture timeout versus exceptional tail:** ordinary controlled timeout returns `(returncode, timed_out=True)` after up to 5 seconds of tail drain, then main may spend 10 seconds force-stopping. If `communicate(timeout=5)` itself raises and the `finally` wait takes another 5 seconds, the tuple assignment at `:419` never completes; main's `timed_out` remains false, so it does **not** also get the 10-second force-stop. Thus max tail/recovery for a failing invocation is max(5 + 10, 5 + 5) = **15 seconds**, not 20. The table counts 5 + 10 only for the four failures that preserve the full path.
7. **Cleanup:** pull failure skips both Python visual verifiers; screenshot-verifier failure skips reachability (`:211–223`). These sequential guards do not add another cleanup invocation or another device pull. Python verifiers are covered only by the operational allowance and outer cap.
8. **API30:** no outer restart, seed, seed PID or verify. Five instrumentation phases total 810 seconds. Worst continuing recoveries are five × 10, so controlled envelope is 270 + 810 + 450 + 10 + 25 + 54 + 50 = **1,669 seconds**. Shared 36-minute step is sized for the larger API35 path; no API35 methods are spuriously required on API30.

## What this model does not bound

- The Python processes launched for source inventories, seed-summary checks, final union validation, screenshot verification and reachability have no individual shell timeout (`ci_emulator.sh:78–86,106–118,216–223,330–331`). Their filesystem reads, parsers and writes can stall until the Actions outer deadline.
- `progress` uses `tee`; shell mkdir/rm/cat/grep/printf and file redirection are not individually timed. Log I/O and filesystem stalls are not universally bounded.
- Inside `capture_live`, process creation, `os.read`, saved-log flushes and live stdout writes are not preempted by its monotonic check (`run_android_instrumentation.py:300,310–316`). OS process creation and termination/wait behavior can outlast a Python timeout under pathological conditions. The 5-second tail and runner preparation sums describe their configured limits, not an OS liveness theorem.
- Emulator is launched as a background process with no separate runtime limit (`ci_emulator.sh:262–265`), intentionally lasting through the tests. Readiness, cleanup and the Actions step/job are its controls.
- Checkout/download/upload actions have no explicit step deadline (`android.yml:250–260,273–280`); the job is their hard cancellation authority. Infrastructure cancellation itself may take grace time, and can leave incomplete artifacts. Neither a timeout nor an incomplete archive is acceptable test success.

The 36/46-minute settings therefore supply a finite operational stop and enough budget for configured controlled paths plus explicit allowances. They do not make every sub-operation independently bounded, and do not guarantee reports after an infrastructure hang.

## Observations informing allowances, not composition acceptance

- PR41 run 38069153905 API35 main script reached completion at +547 seconds; its full test step was 549 seconds (16:56:48–17:05:57 UTC), about 2 seconds for successful collection/cleanup. Startup to native was 48 seconds. Job was 600 seconds, image step 40 seconds; residual checkout/download/upload/job overhead was **11 seconds**.
- PR34 standalone run 38064577479 API35 test step was 274 seconds; API30 was 174. Image steps were 39 / 61 seconds. Job residual overhead was **29 / 19 seconds**. Their ordinary/gallery samples were 132.727 / 46.404 seconds (API35), 79.770 / 33.308 (API30).
- Preserving 4 minutes of existing job overhead is conservative relative to 11–29 observed seconds and does not secretly count another 6-minute image install inside the script. We do **not** add PR34 and PR41 observed durations and call that a combined pass.
- Current run 38073935029 has Python step failure after 133 wall seconds against its 120-second step cap. Exact failure logs are not yet available while the enclosing job runs. Its JVM step passed in 473 seconds. Timeout is presently a hypothesis, not the confirmed sole failure cause.

## Proposed changes and regression checks

1. Restrict implementation to outer workflow step/job budgets, explanatory comments/docs, and host contracts. No Android/JVM method, direct-ADB runner, invocation selector or inner deadline changes.
2. Parse the actual workflow device step/job and verify 36 / 46, unchanged 6-minute image step, exact seven phase allowances and the complete source-method union. Assert arithmetic and all mutually exclusive branch maxima above; reject old 15/25 and under-budget mutations.
3. Preserve all existing host test identifiers; add a new budget test module and update existing expected configuration values without deleting cases. Existing phase failure/timeout, missing/duplicate receipt, SDK/source mismatch and normal/-O/environment negative controls still run.
4. Re-run full host suite, focused shell/union/budget tests and verified-source historical PR7/PR9 replay in normal, -O and PYTHONOPTIMIZE modes. Confirm identical Android source and method identities, direct runner bytes, selectors and assertions versus `739a3dcf`.
5. Finish collecting the failed run's exact logs/annotations and artifacts before describing causes. Keep any assertion failure separate from timeout. Publish corrected source only after review of this proposal; retain the failed run/review in the durable record, then request fresh Codex review once and require fresh release-configured API30 + API35 installed CI on the corrected exact source. Merge remains held.


## Reviewed decision and exact old-run follow-up

Parent accepted implementation of emulator step/job 36/46 and Python/checks-job
4/22, keeping all inner deadlines unchanged and recording the checks-job aggregate
policy risk separately. Publication still requires final diff/tree review.

The exact job log now confirms the Python step timed out after two minutes at
18:02:58.3787749Z. The regression artifact (ID 11678028821, SHA256
`ccaac7039c811401d0a8ab00a49cdff2c7522cb274ace16bc68f12db11f5d445`)
subsequently preserved a late process completion: 462 tests in 176.348 seconds,
wrapper 176.752 seconds and exit 0, with two inherited optional-Pillow skips.
They are `IcoContainerTest.test_adam7_fixture_pixels_match_independent_pillow_decoder`
and `IcoContainerTest.test_export_opens_with_independent_pillow_ico_decoder`.
Exact ordered source test inventory matches the 462-character progress row and
locates both skips at indices 220 and 223. No assertion failure was reported.
This process artifact does not convert the timed-out Actions step to a pass.
The artifact independently verifies all 793 expected JVM methods with zero
failures/errors/skips and zero lint issues; Python CI remains failed.
