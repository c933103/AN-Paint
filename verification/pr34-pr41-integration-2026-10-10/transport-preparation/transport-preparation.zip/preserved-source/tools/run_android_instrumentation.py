#!/usr/bin/env python3
"""Run an already-built Android test APK with a deadline and fail-closed reports.

This deliberately does not invoke Gradle: emulator jobs test the exact APKs from
one build job. Android's instrumentation protocol, not adb's exit code alone,
determines success. Reports are written even after installation/runner failures.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import selectors
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

Identity = tuple[str, str]


ANNOTATIONS = r'(?:@[\w.]+(?:\([^()]*\))?\s*)+'
SDK_ANNOTATION = r'@(?:[\w.]+\.)?SdkSuppress\b'


def sdk_bounds(annotations: str, path: Path) -> tuple[int, int] | None:
    """Support literal stable-SDK bounds; reject unsupported syntax rather than omit tests."""
    matches = list(re.finditer(r'@([\w.]+)(?:\(([^()]*)\))?', annotations))
    sdk = [match for match in matches if match.group(1).split('.')[-1] == 'SdkSuppress']
    if not sdk:
        return None
    if len(sdk) != 1 or sdk[0].group(1) not in ('SdkSuppress', 'androidx.test.filters.SdkSuppress'):
        raise ValueError(f'Unsupported SdkSuppress annotation in {path}')
    arguments = sdk[0].group(2)
    if arguments is None or not arguments.strip():
        raise ValueError(f'SdkSuppress must declare literal SDK bounds in {path}')
    bounds = {}
    for argument in arguments.split(','):
        match = re.fullmatch(r'\s*(minSdkVersion|maxSdkVersion)\s*=\s*([1-9][0-9]*)\s*', argument)
        if not match or match.group(1) in bounds:
            raise ValueError(f'Unsupported or duplicate SdkSuppress argument in {path}')
        bounds[match.group(1)] = int(match.group(2))
    minimum, maximum = bounds.get('minSdkVersion', 1), bounds.get('maxSdkVersion', 2147483647)
    if minimum > maximum:
        raise ValueError(f'Contradictory SdkSuppress bounds in {path}')
    return minimum, maximum


def declared_tests(directory: Path, *, sdk_level: int | None = None) -> set[Identity]:
    if sdk_level is not None and (type(sdk_level) is not int or sdk_level < 1):
        raise ValueError('SDK level must be a positive integer')
    expected: set[Identity] = set()
    seen: set[Identity] = set()
    for path in sorted(directory.rglob('*.kt')):
        source = path.read_text()
        package = re.search(r'^package\s+([\w.]+)', source, re.M)
        owner = re.search(r'^[ \t]*(?P<annotations>' + ANNOTATIONS + r')?'
                          r'(?:(?:internal|public|open|abstract)\s+)*class\s+(?P<owner>\w+)', source, re.M)
        annotated = list(re.finditer(r'(?P<annotations>' + ANNOTATIONS + r')'
                                    r'(?:(?:public|internal|suspend)\s+)*fun\s+(?P<method>`[^`]+`|\w+)\s*\(', source))
        methods = [match for match in annotated if re.search(r'@Test\b', match.group('annotations'))]
        if len(methods) != len(re.findall(r'@Test\b', source)):
            raise ValueError(f'Unparsed @Test in {path}; update the test inventory parser')
        if methods and not (package and owner):
            raise ValueError(f'Cannot identify the test class in {path}')
        class_annotations = (owner.group('annotations') or '') if owner else ''
        class_bounds = sdk_bounds(class_annotations, path)
        parsed_sdk = len(re.findall(SDK_ANNOTATION, class_annotations))
        for match in methods:
            annotations = match.group('annotations')
            method_bounds = sdk_bounds(annotations, path)
            parsed_sdk += len(re.findall(SDK_ANNOTATION, annotations))
            identity = (package.group(1) + '.' + owner.group('owner'), match.group('method').strip('`'))
            if identity in seen:
                raise ValueError(f'Duplicate declared test: {identity}')
            seen.add(identity)
            # AndroidJUnitRunner gives the method annotation precedence over the class.
            bounds = method_bounds if method_bounds is not None else class_bounds
            if sdk_level is None or bounds is None or bounds[0] <= sdk_level <= bounds[1]:
                expected.add(identity)
        if parsed_sdk != len(re.findall(SDK_ANNOTATION, source)):
            raise ValueError(f'Unparsed SdkSuppress in {path}; update the test inventory parser')
    if not seen:
        raise ValueError(f'No declared test methods in {directory}')
    return expected


def source_tests_sha256(directory: Path) -> str:
    """Bind reports to the exact relative paths and bytes of the Kotlin test inputs.

    This identifies the checked-out test source, not the APK's build provenance.
    The workflow still supplies the already-built APKs from its exact-source build.
    """
    files = [(path.relative_to(directory).as_posix(), hashlib.sha256(path.read_bytes()).hexdigest())
             for path in sorted(directory.rglob('*.kt'))]
    if not files:
        raise ValueError(f'No Kotlin test source in {directory}')
    return hashlib.sha256(json.dumps(files, separators=(',', ':')).encode('utf-8')).hexdigest()


def requested_tests(values: list[str], declared: set[Identity], excluded: list[str]) -> set[Identity]:
    """Reject ambiguous, duplicate, undeclared or conflicting method selectors."""
    requested: set[Identity] = set()
    identifier = r'[A-Za-z_$][A-Za-z0-9_$]*'
    for value in values:
        if not re.fullmatch(identifier + r'(?:\.' + identifier + r')*#' + identifier, value):
            raise ValueError(f'--include-test requires one literal CLASS#METHOD identity: {value!r}')
        owner, method = value.split('#')
        identity = (owner, method)
        if identity in requested:
            raise ValueError(f'Duplicate --include-test identity: {value}')
        if identity not in declared:
            raise ValueError(f'Included test not found in source inventory: {value}')
        if owner in excluded:
            raise ValueError(f'Included test conflicts with --exclude-class: {value}')
        requested.add(identity)
    return requested


RESTART_SEED = 'paint.anpaint.android.AcceptedCreditRestartSeedTest'
RESTART_VERIFY = 'paint.anpaint.android.AcceptedCreditRestartVerifyTest'


def restart_partition(expected: set[Identity]) -> tuple[set[Identity], set[Identity], set[Identity]]:
    """Every app method belongs to exactly one phase, including future classes."""
    seed = {item for item in expected if item[0] == RESTART_SEED}
    verify = {item for item in expected if item[0] == RESTART_VERIFY}
    ordinary = expected - seed - verify
    if len(seed) != 1 or len(verify) != 1 or not ordinary:
        raise ValueError('Restart regression requires one seed, one verify and ordinary app tests')
    return ordinary, seed, verify


def restart_sdk(reports: list[dict]) -> int:
    """Accepted-credit restart evidence must come from one captured API35 device."""
    if len(reports) != 3 or any(type(report.get('device_sdk')) is not int
                                or report['device_sdk'] != 35 for report in reports):
        raise ValueError('Three phase reports with the captured API35 SDK are required')
    return 35


def verify_restart_reports(expected: set[Identity], reports: list[dict]) -> dict:
    sdk_level = restart_sdk(reports)
    partitions = restart_partition(expected)
    if len(reports) != 3:
        raise ValueError('Three completed app reports are required')
    completed: set[Identity] = set()
    for wanted, report, seed_mode in zip(partitions, reports, (False, True, False)):
        identities = [(case['classname'], case['name']) for case in report['cases']]
        if (report.get('success') is not True or report.get('leave_target_running') is not seed_mode
                or report.get('expected_tests') != len(wanted)
                or report.get('completed_tests') != len(wanted)
                or any(case['status'] != 'passed' for case in report['cases'])
                or len(identities) != len(set(identities)) or set(identities) != wanted
                or completed.intersection(identities)):
            raise ValueError('App reports do not provide the exact disjoint successful phase inventory')
        completed.update(identities)
    if completed != expected:
        raise ValueError('App reports omit declared source tests')
    return {'success': True, 'device_sdk': sdk_level,
            'declared_tests': len(expected), 'completed_tests': len(completed),
            'completed': sorted(completed)}


def parse_protocol(output: str, expected: set[Identity], *, returncode: int | None = 0,
                   timed_out: bool = False, run_errors: list[str] | None = None) -> dict:
    """Parse raw `am instrument -w -r` output, rejecting incomplete test runs."""
    cases: list[dict] = []
    errors = list(run_errors or [])
    fields: dict[str, str] = {}
    last_field = None
    started: set[Identity] = set()
    completed: set[Identity] = set()
    final_codes: list[int] = []
    declared_counts: set[int] = set()
    for line in output.splitlines():
        if line.startswith('INSTRUMENTATION_STATUS: '):
            key, separator, value = line[len('INSTRUMENTATION_STATUS: '):].partition('=')
            if separator:
                fields[key] = value
                last_field = key
        elif line.startswith('INSTRUMENTATION_STATUS_CODE: '):
            try:
                code = int(line.split(':', 1)[1])
            except ValueError:
                errors.append(f'Malformed status code: {line}')
                fields, last_field = {}, None
                continue
            identity = (fields.get('class', ''), fields.get('test', ''))
            if 'numtests' in fields:
                try:
                    declared_counts.add(int(fields['numtests']))
                except ValueError:
                    errors.append(f'Malformed numtests: {fields["numtests"]}')
            if code in (1, 0, -1, -2, -3, -4):
                if not all(identity):
                    errors.append(f'Test status {code} has no class/method: {fields}')
                elif code == 1:
                    if identity in started or identity in completed:
                        errors.append(f'Duplicate test start: {identity}')
                    started.add(identity)
                else:
                    if identity in completed:
                        errors.append(f'Duplicate test result: {identity}')
                    # Android reports @Ignore directly, without a start event.
                    if code not in (-3, -4) and identity not in started:
                        errors.append(f'Test ended without a start event: {identity}')
                    completed.add(identity)
                    status = {0: 'passed', -1: 'error', -2: 'failure',
                              -3: 'skipped', -4: 'skipped'}[code]
                    cases.append({'classname': identity[0], 'name': identity[1],
                                  'status': status,
                                  'message': fields.get('stack', fields.get('stream', '')).strip()})
            else:
                errors.append(f'Unknown instrumentation status {code}: {fields}')
            fields, last_field = {}, None
        elif line.startswith('INSTRUMENTATION_CODE: '):
            try:
                final_codes.append(int(line.split(':', 1)[1]))
            except ValueError:
                errors.append(f'Malformed final result: {line}')
            last_field = None
        elif line.startswith(('INSTRUMENTATION_FAILED:', 'INSTRUMENTATION_ABORTED:')):
            errors.append(line)
            last_field = None
        elif line.startswith('INSTRUMENTATION_RESULT: '):
            key, _, value = line[len('INSTRUMENTATION_RESULT: '):].partition('=')
            if key in ('shortMsg', 'longMsg'):
                errors.append(f'Runner {key}: {value}')
            last_field = None
        elif last_field is not None:
            # Stack traces and stream fields span several protocol lines.
            fields[last_field] += '\n' + line

    if timed_out:
        errors.append('Instrumentation exceeded its deadline')
    if returncode != 0:
        errors.append(f'adb exited with status {returncode}')
    if final_codes != [-1]:
        errors.append(f'Missing or unsuccessful final instrumentation result: {final_codes}')
    if fields:
        errors.append('Truncated instrumentation status bundle')
    if not completed:
        errors.append('No tests completed')
    if not expected:
        errors.append('Expected test inventory is empty')
    if declared_counts != {len(expected)}:
        errors.append(f'Runner test counts {sorted(declared_counts)} do not match {len(expected)} declared methods')
    missing, unexpected = expected - completed, completed - expected
    if missing:
        errors.append(f'{len(missing)} declared test method(s) did not complete')
        for owner, name in sorted(missing):
            cases.append({'classname': owner, 'name': name, 'status': 'error',
                          'message': 'Test started but did not finish' if (owner, name) in started
                                     else 'Declared test was not executed'})
    if unexpected:
        errors.append(f'Unexpected tests: {sorted(unexpected)}')
    failed = [case for case in cases if case['status'] != 'passed']
    return {'success': not errors and not failed, 'expected_tests': len(expected),
            'completed_tests': len(completed), 'missing': sorted(missing),
            'unexpected': sorted(unexpected), 'errors': errors, 'cases': cases,
            'returncode': returncode, 'timed_out': timed_out}


def write_reports(output: Path, suite: str, result: dict, elapsed: float) -> None:
    cases = list(result['cases'])
    if result['errors']:
        cases.append({'classname': suite, 'name': '__instrumentation_run__',
                      'status': 'error', 'message': '\n'.join(result['errors'])})
    root = ET.Element('testsuite', name=suite, tests=str(len(cases)),
                      failures=str(sum(c['status'] == 'failure' for c in cases)),
                      errors=str(sum(c['status'] == 'error' for c in cases)),
                      skipped=str(sum(c['status'] == 'skipped' for c in cases)),
                      time=f'{elapsed:.3f}')
    for case in cases:
        node = ET.SubElement(root, 'testcase', classname=case['classname'], name=case['name'])
        if case['status'] != 'passed':
            child = ET.SubElement(node, case['status'], message=case['message'].split('\n')[0])
            child.text = case['message']
    # Android logs can contain control bytes not legal in XML 1.0.
    for element in root.iter():
        for key, value in element.attrib.items():
            element.set(key, re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', '', value))
        if element.text:
            element.text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', '', element.text)
    ET.indent(root)
    safe_suite = re.sub(r'[^\w.-]', '_', suite)
    ET.ElementTree(root).write(output / f'TEST-{safe_suite}.xml', encoding='utf-8', xml_declaration=True)
    (output / 'summary.json').write_text(json.dumps({**result, 'elapsed_seconds': elapsed}, indent=2) + '\n')


def capture_live(command: list[str], log: Path, deadline_seconds: int) -> tuple[int, bool]:
    """Drain output continuously while enforcing the wall-clock deadline."""
    timed_out = False
    deadline = time.monotonic() + deadline_seconds
    with log.open('wb') as saved:
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        try:
            with selectors.DefaultSelector() as selector:
                selector.register(process.stdout, selectors.EVENT_READ)
                while selector.get_map():
                    if time.monotonic() >= deadline:
                        timed_out = True
                        process.kill()
                        break
                    for key, _ in selector.select(timeout=min(0.25, max(0, deadline - time.monotonic()))):
                        data = os.read(key.fileobj.fileno(), 65536)
                        if not data:
                            selector.unregister(key.fileobj)
                        else:
                            saved.write(data)
                            saved.flush()
                            print(data.decode('utf-8', errors='replace'), end='', flush=True)
                remaining = max(0.01, deadline - time.monotonic())
                try:
                    process.wait(timeout=remaining)
                except subprocess.TimeoutExpired:
                    timed_out = True
                    process.kill()
                # Kill closes adb's pipe; preserve any last buffered result lines.
                tail, _ = process.communicate(timeout=5)
                if tail:
                    saved.write(tail)
                    print(tail.decode('utf-8', errors='replace'), end='', flush=True)
        finally:
            if process.poll() is None:
                process.kill()
                process.wait(timeout=5)
    return process.returncode, timed_out


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--adb', default='adb')
    parser.add_argument('--apk', type=Path, required=True, help='Already-built instrumentation test APK')
    parser.add_argument('--source-tests', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--suite', required=True)
    parser.add_argument('--component', help='test.package/androidx.test.runner.AndroidJUnitRunner')
    parser.add_argument('--exclude-class', action='append', default=[])
    parser.add_argument('--include-test', action='append', default=[], metavar='CLASS#METHOD',
                        help='Run only these exact declared, SDK-eligible methods; repeat for each method')
    parser.add_argument('--leave-target-running', action='store_true',
                        help='API35 accepted-credit seed only: attach to live app and retain activities')
    parser.add_argument('--timeout-seconds', type=int, default=480)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    log = args.output / 'instrumentation.log'
    log.write_text('')
    started = time.monotonic()
    expected: set[Identity] = set()
    errors: list[str] = []
    returncode, timed_out = None, False
    component, target = args.component, None
    target_pid = None
    sdk_level = None
    sdk_suppressed: set[Identity] = set()
    source_digest = None
    try:
        if args.timeout_seconds <= 0:
            raise ValueError('--timeout-seconds must be positive')
        expected = declared_tests(args.source_tests)
        source_digest = source_tests_sha256(args.source_tests)
        unknown_exclusions = set(args.exclude_class) - {owner for owner, _ in expected}
        if unknown_exclusions:
            raise ValueError(f'Excluded class not found in source inventory: {sorted(unknown_exclusions)}')
        requested = requested_tests(args.include_test, expected, args.exclude_class)
        device_sdk = subprocess.run([args.adb, 'shell', 'getprop', 'ro.build.version.sdk'],
                                    capture_output=True, text=True, timeout=15, check=True)
        if not re.fullmatch(r'[1-9][0-9]*', device_sdk.stdout.strip()):
            raise ValueError('Device SDK query did not return a positive integer')
        sdk_level = int(device_sdk.stdout.strip())
        eligible = declared_tests(args.source_tests, sdk_level=sdk_level)
        sdk_suppressed = expected - eligible
        if requested - eligible:
            raise ValueError(f'Included tests are not eligible for device SDK {sdk_level}: {sorted(requested-eligible)}')
        expected = {item for item in eligible if item[0] not in args.exclude_class}
        if args.include_test:
            expected = requested
        if not expected:
            raise ValueError('Exclusions removed every declared test')
        if args.leave_target_running and (len(expected) != 1 or {owner for owner, _ in expected} != {RESTART_SEED}):
            raise ValueError('--leave-target-running is restricted to the one-method accepted-credit seed')
        if not args.apk.is_file():
            raise ValueError(f'Test APK not found: {args.apk}')
        installed = subprocess.run([args.adb, 'install', '-r', '-t', str(args.apk)],
                                   capture_output=True, text=True, timeout=60)
        (args.output / 'install.log').write_text(installed.stdout + installed.stderr)
        if installed.returncode or not re.search(r'^Success\s*$', installed.stdout, re.M):
            raise RuntimeError(f'Test APK installation failed: {installed.stdout}{installed.stderr}')
        instrumentation = subprocess.run([args.adb, 'shell', 'pm', 'list', 'instrumentation'],
                                         capture_output=True, text=True, timeout=15, check=True)
        available = dict(re.findall(r'^instrumentation:(\S+)\s+\(target=([^)]*)\)', instrumentation.stdout, re.M))
        if component is None:
            if len(available) != 1:
                raise ValueError(f'Pass --component; installed instrumentation is ambiguous: {sorted(available)}')
            component = next(iter(available))
        if component not in available:
            raise ValueError(f'Instrumentation {component} was not installed; found {sorted(available)}')
        target = available[component]
        command = [args.adb, 'shell', 'am', 'instrument', '-w', '-r']
        if args.leave_target_running:
            if target != 'paint.anpaint.android':
                raise ValueError('Accepted-credit seed must target paint.anpaint.android')
            live = subprocess.run([args.adb, 'shell', 'pidof', target],
                                  capture_output=True, text=True, timeout=10, check=True)
            if not re.fullmatch(r'[1-9][0-9]*', live.stdout.strip()):
                raise ValueError('Accepted-credit seed requires exactly one already-running target PID')
            target_pid = int(live.stdout.strip())
            command += ['--no-restart', '-e', 'waitForActivitiesToComplete', 'false']
        if args.exclude_class:
            command += ['-e', 'notClass', ','.join(args.exclude_class)]
        if args.include_test:
            command += ['-e', 'class', ','.join(sorted(args.include_test))]
        command.append(component)
        returncode, timed_out = capture_live(command, log, args.timeout_seconds)
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
        errors.append(str(error))
    finally:
        if timed_out and target:
            try:
                subprocess.run([args.adb, 'shell', 'am', 'force-stop', target],
                               capture_output=True, timeout=10)
            except (OSError, subprocess.SubprocessError):
                pass  # Emulator job cleanup still terminates the device.
        result = parse_protocol(log.read_text(errors='replace'), expected, returncode=returncode,
                                timed_out=timed_out, run_errors=errors)
        result['component'] = component
        result['excluded_classes'] = args.exclude_class
        result['included_tests'] = sorted(args.include_test)
        result['source_tests_sha256'] = source_digest
        result['timeout_seconds'] = args.timeout_seconds
        result['device_sdk'] = sdk_level
        result['sdk_suppressed_tests'] = sorted(sdk_suppressed)
        result['leave_target_running'] = args.leave_target_running
        result['target_pid_before_instrumentation'] = target_pid
        write_reports(args.output, args.suite, result, time.monotonic() - started)
    print(json.dumps({key: result[key] for key in ('success', 'expected_tests', 'completed_tests', 'errors')}, indent=2))
    return 0 if result['success'] else 1


if __name__ == '__main__':
    raise SystemExit(main())

