from pathlib import Path
import ast,subprocess,json,hashlib,sys
root=Path('/workspace/shared/anpaint-pr34-evidence-transport-20261010');p=Path(__file__).parent;git=lambda *a:subprocess.check_output(['git',*a],cwd=root)
base='739a3dcf1a59785d98a5f5a00f4b76a1b00e6472';budget='db713bbf28abdf45311454329b6435b1ce24b62d';tree=git('write-tree').decode().strip()
manifest=lambda ref:dict(line.split('\t',1)[::-1] for line in git('ls-tree','-r',ref).decode().splitlines())
old,new,budgetfiles=manifest(base),manifest(tree),manifest(budget);changed=[x for x in sorted(set(old)|set(new)) if old.get(x)!=new.get(x)];diffbudget=[x for x in sorted(set(budgetfiles)|set(new)) if budgetfiles.get(x)!=new.get(x)]
if set(old)-set(new):raise SystemExit('source removals')
for name,value in new.items():
 mode,kind,blob=value.split();data=(root/name).read_bytes();actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 if actual!=blob:raise SystemExit('Index/worktree differs: '+name)
kt='app/src/androidTest/java/paint/anpaint/android/VerticalLocaleDeviceTest.kt';oldkt=git('show',base+':'+kt);newkt=(root/kt).read_bytes()
restored=newkt.replace(b'import org.junit.Rule\n',b'').replace(b'    @get:Rule val evidenceExport=VerticalEvidenceExportRule(instrumentation)\n',b'')
if restored!=oldkt:raise SystemExit('original Kotlin method/body drift')
for name in old:
 if name.startswith(('app/','Paintroid/')) and name!=kt and old[name]!=new[name]:raise SystemExit('unexpected Android source change: '+name)
if old['tools/run_android_instrumentation.py']!=new['tools/run_android_instrumentation.py']:raise SystemExit('runner changed')
def ids(data):
 return {c.name+'.'+f.name for c in ast.parse(data).body if isinstance(c,ast.ClassDef) for f in c.body if isinstance(f,ast.FunctionDef) and f.name.startswith('test_')}
removed=[];added=[]
for name in sorted(x for x in new if x.startswith('tools/test_') and x.endswith('.py')):
 before=ids(git('show',base+':'+name)) if name in old else set();after=ids((root/name).read_bytes());removed+=sorted(before-after);added+=[name+':'+x for x in sorted(after-before)]
if removed:raise SystemExit(removed)
sys.path.insert(0,str(root/'tools'));from run_android_instrumentation import declared_tests,source_tests_sha256
from test_ci_timeout_budget import validate_budget
model,limits,_=validate_budget((root/'.github/workflows/android.yml').read_text())
r={'base':base,'budget_tree':budget,'candidate_tree':tree,'path_count':len(new),'changed_from_published':changed,'changed_from_budget':diffbudget,'removed_paths':[],'original_vertical_file_restored_byte_identical':True,'original_vertical_blob':old[kt],'restored_vertical_sha256':hashlib.sha256(restored).hexdigest(),'all_other_existing_app_paintroid_files_unchanged':True,'direct_runner_blob':new['tools/run_android_instrumentation.py'],'all_previous_host_method_identifiers_retained':True,'added_host_methods':added,'app_source_sha256':source_tests_sha256(root/'app/src/androidTest'),'app_methods':sorted(declared_tests(root/'app/src/androidTest')),'native_methods':sorted(declared_tests(root/'Paintroid/src/androidTest')),'budget_model':model,'outer_minutes':list(limits),'sdk_validation':'not_run_locally_no_Android_SDK_or_Kotlin_compiler','fresh_release_API30_API35_CI_required':True}
(p/'candidate-audit.json').write_text(json.dumps(r,indent=2)+'\n');(p/'candidate-manifest.json').write_text(json.dumps(new,sort_keys=True,indent=2)+'\n');(p/'transport.patch').write_bytes(git('diff','--cached','--binary',budget));(p/'complete-correction.patch').write_bytes(git('diff','--cached','--binary',base))
print(json.dumps({k:v for k,v in r.items() if k not in ['app_methods','native_methods','added_host_methods']},indent=2))
