import hashlib,json,pathlib,stat,xml.etree.ElementTree as E
p=pathlib.Path(__file__).resolve().parent;w=p.parent
read=lambda f:json.loads(f.read_text())
s=read(w/'session.json');tree=read(p/'actual-tree.json');merge=read(p/'merge.json');expected=read(w/'expected-tree.json');base=read(w/'publication-tree.json')
norm=lambda es:{e['path']:{k:e[k] for k in ['path','mode','type','sha']} for e in es if e['type']!='tree'}
actual=norm(tree['tree']);assert not tree['truncated'] and actual==norm(expected)
assert merge['sha']==s['merge'] and merge['tree']['sha']==s['tree'] and [x['sha'] for x in merge['parents']]==[s['base'],s['head']]
git=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
count=0
for f in (w/'source').rglob('*'):
 path=f.relative_to(w/'source').as_posix()
 if f.is_file() and path in actual:
  assert git(f.read_bytes())==actual[path]['sha'],path
  assert ('100755' if f.stat().st_mode&stat.S_IXUSR else '100644')==actual[path]['mode'],path
  count+=1
accepted=read(w/'accepted-map.json');inputs=read(w/'inputs.json');integ=read(w/'integration.json');review=read(w/'review.json');before=norm(base['tree'])
for tag,values in accepted.items():
 path=inputs['paths'][tag];text=(w/'source'/path).read_text();nodes={n.get('name'):n for n in E.fromstring(text)}
 for k,v in values.items():
  n=nodes[k];assert n.text==v and n.attrib==inputs['source'][k]['attributes']
  text=text.replace('    '+E.tostring(n,encoding='unicode').rstrip()+'\n','')
 assert git(text.encode())==before[path]['sha'],tag
for r in review['reviews']:
 if r['final_value_decision']=='hold':assert r['key'] not in {n.get('name') for n in E.parse(w/'source'/inputs['paths'][r['locale']]).getroot()}
recount=read(p/'actual-recount.json')
totals={tier:{k:sum(v[tier][k] for v in recount.values()) for k in ['present','missing','total']} for tier in ['P0','P1','P2','P3']}
complete=sum(all(v[tier]['missing']==0 for tier in totals) for v in recount.values())
empty=sum(all(v[tier]['present']==0 for tier in totals) for v in recount.values())
out={'merge':s['merge'],'tree':s['tree'],'remote_leaves':len(actual),'verified_materialized_files':count,'accepted_values':sum(map(len,accepted.values())),'old_nodes_preserved':sum(integ[t]['old_nodes_preserved'] for t in accepted),'held_values_absent':sum(r['final_value_decision']=='hold' for r in review['reviews']),'options':len(recount),'direct_presence_totals':totals,'complete_catalogues':complete,'partial_catalogues':len(recount)-complete-empty,'empty_catalogues':empty}
(p/'actual-source-verification.json').write_text(json.dumps(out,indent=2)+'\n')
print('Verified actual source:',len(actual),'remote leaves,',count,'materialized files,',out['accepted_values'],'accepted values and',out['old_nodes_preserved'],'preserved nodes')
