from pathlib import Path
import json,sys,copy,xml.etree.ElementTree as E,hashlib
r=Path(__file__).resolve().parents[1];sys.path.insert(0,str(r/'source/tools'))
import test_georgian_armenian_azerbaijani_priority_wording as t
f=t.fixture(t.FIXTURE);t.validate(f);count=0
for tag,loc in f['locales'].items():
 for section in ['values','retained']:
  for key,row in loc[section].items():
   data=copy.deepcopy(f);data['locales'][tag][section][key]['display']+=' corrupted'
   try:t.validate(data)
   except ValueError:count+=1
   else:raise AssertionError((tag,section,key,'display'))
 for key,row in loc['values'].items():
  node=E.Element('string',row['attributes']);node.text=row['target']+' changed';root=E.Element('resources');root.append(node)
  try:t.complete_string(E.tostring(root,encoding='unicode'),key,row,f['sources'][key])
  except ValueError:count+=1
  else:raise AssertionError((tag,key,'target'))
 for key in loc['context']:
  data=copy.deepcopy(f);data['locales'][tag]['context'][key]['target']+=' forged'
  try:t.validate(data)
  except ValueError:count+=1
  else:raise AssertionError((tag,key,'context'))
 for key in loc['holds']:
  data=copy.deepcopy(f);data['locales'][tag]['holds'][key]['previous']={'value':'forged','attributes':{'name':key}}
  try:t.validate(data)
  except ValueError:count+=1
  else:raise AssertionError((tag,key,'hold'))
for field in ['value','attributes']:
 for key in f['sources']:
  data=copy.deepcopy(f)
  if field=='value':data['sources'][key]['value']+=' forged'
  else:data['sources'][key]['attributes']['translatable']='false'
  try:t.validate(data)
  except ValueError:count+=1
  else:raise AssertionError((key,'source',field))
jvm=r/'source/Paintroid/src/test/java/org/catrobat/paintroid/local/GeorgianArmenianAzerbaijaniPriorityWordingTest.kt';assert jvm.read_bytes()==(r/'test-drafts'/jvm.name).read_bytes()
out={'result':'pass','independent_negative_probes':count,'jvm_sha256':hashlib.sha256(jvm.read_bytes()).hexdigest(),'review':'All ten JVM methods read; indexed formatting successor read; no hosted or installed execution claim.','source_mutation':False};(r/'independent-preflight/independent-sensitivity-review.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
