from pathlib import Path
import sys,json,copy,hashlib
from unittest.mock import patch
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'source/tools'))
import test_current_localization_contracts as c
import memory_warning_source_review as m
fixture=c.fixture('georgian_armenian_azerbaijani_priority_wording.json');tests=[]
def reject(label,fn):
 try:fn()
 except (ValueError,AssertionError):tests.append(label);return
 raise AssertionError('Mutation accepted: '+label)
for tag in ['ka','hy','az']:
 for key in m.KEYS:
  assert m.current_source_expectation(key,tag,None)==fixture['locales'][tag]['values'][key]['target']
  reject(f'{tag}/{key}/historical-present',lambda:m.current_source_expectation(key,tag,'bad'))
  for field,value in [('source','BAD'),('attributes',{'name':key,'formatted':'false'}),('previous','BAD')]:
   d=copy.deepcopy(fixture);(d['sources'][key] if field=='source' else d['locales'][tag]['values'][key])[('value' if field=='source' else field)]=value;orig=m.fixture
   with patch.object(m,'fixture',side_effect=lambda n:d if n=='georgian_armenian_azerbaijani_priority_wording.json' else orig(n)):
    reject(f'{tag}/{key}/{field}',lambda:m.current_source_expectation(key,tag,None))
 for key in c.EXPECTED_KEYS[c.FAMILIES[2]]|{c.TAGGED_COLOUR_KEY}:
  for field,value in [('source','BAD'),('attributes',{'name':key,'formatted':'false'}),('previous','BAD')]:
   d=copy.deepcopy(fixture);(d['sources'][key] if field=='source' else d['locales'][tag]['values'][key])[('value' if field=='source' else field)]=value;orig=c.fixture
   with patch.object(c,'fixture',side_effect=lambda n:d if n=='georgian_armenian_azerbaijani_priority_wording.json' else orig(n)):
    reject(f'{tag}/{key}/{field}',c.current_tagged_colour_data if key==c.TAGGED_COLOUR_KEY else lambda:c.wording_fixture(c.FAMILIES[2]))
data=c.current_tagged_colour_data();strings={tag:c.catalogues.read_strings(path)for tag,path in c.paths().items()};offered=set(c.catalogues.offered_tags());en=strings['default'][c.TAGGED_COLOUR_KEY]
c.require_tagged_colour_resolution(data,strings,offered,en)
r={'result':'PASS','independent_rejected_mutations':len(tests),'mutations':tests,'files':{n:hashlib.sha256((P/'source/tools'/n).read_bytes()).hexdigest()for n in ['test_current_localization_contracts.py','memory_warning_source_review.py']},'scope':'Strict finite memory/SVG/tagged-colour predecessors/source/attributes ; all three additions only; no runtime claim.'};(P/'independent-preflight/shared-guard-verification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
