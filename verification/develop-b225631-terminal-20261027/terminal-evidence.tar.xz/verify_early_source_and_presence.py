"""Verify original final-push source, then count actual per-catalogue priority presence."""
from pathlib import Path
import hashlib,io,json,sys,xml.etree.ElementTree as E,zipfile
B=Path(__file__).resolve().parent;A=B/'ci-originals';head='b225631aa4609d9d0c64513982f56cb39d864125';run=40573409015;sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
metadata=json.loads((A/'early-artifacts-metadata.json').read_text());verified=[]
for prefix in ('apk-and-source','instrumentation-apks','exact-script-generation'):
 m=next(m for m in metadata if m['name'].startswith(prefix));p=A/(m['name']+'.zip');raw=p.read_bytes();assert len(raw)==m['size_in_bytes']and sha(raw)==m['digest'].removeprefix('sha256:');assert m['workflow_run']['id']==run and m['workflow_run']['head_sha']==head;verified.append({'id':m['id'],'name':m['name'],'bytes':len(raw),'sha256':sha(raw)})
 if prefix=='apk-and-source':
  with zipfile.ZipFile(p)as z:info=json.loads(z.read('build/delivery/build-info.json'));source=z.read('build/delivery/AN-Paint-source.zip');assert sha(source)==info['source_sha256'];assert sha(z.read('app/build/outputs/apk/debug/app-debug.apk'))==info['apk_sha256']
assert info['commit']==head and info['run_id']==str(run)
tree=json.loads((B/'remote-tree.json').read_text());assert tree['sha']=='28ada9cbc9cf3c7509dbed764ebb7e245e064b8f'and not tree.get('truncated');zipper=zipfile.ZipFile(io.BytesIO(source));missing=[];S=B/'inventory-source';S.mkdir(exist_ok=True);modes=0
for row in tree['tree']:
 if row['type']!='blob':continue
 try:zi=zipper.getinfo('AN-Paint/'+row['path']);raw=zipper.read(zi)
 except KeyError:missing.append(row['path']);continue
 assert blob(raw)==row['sha'],row['path'];assert format((zi.external_attr>>16)&0o177777,'o')==row['mode'],(row['path'],oct(zi.external_attr>>16),row['mode']);modes+=1
 p=S/row['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);p.chmod(0o755 if row['mode']=='100755'else 0o644)
assert missing==['.gitignore','.idea/codeStyles/Project.xml','colorpicker/.gitignore']
sys.path.insert(0,str(S/'tools'));import translation_catalogues as c
manifest=json.loads((S/'translations/string-importance.json').read_text());tiers={t['id']:set(t['keys'])for t in manifest['tiers']if t['id']in ('P0','P1')};assert len(tiers['P0'])==92 and len(tiers['P1'])==249 and not tiers['P0']&tiers['P1'];tags=c.offered_tags();assert len(tags)==len(set(tags))==171
rows=[];paths=c.catalogue_paths()
for tag in tags:
 p=paths[tag];raw=p.read_bytes();nodes=E.fromstring(raw);ids={n.tag+'/'+n.get('name')for n in nodes};assert len(ids)==len(nodes)
 rows.append({'tag':tag,'catalogue_path':str(p.relative_to(S)),'catalogue_git_blob':blob(raw),'catalogue_sha256':sha(raw),'typed_entries_present':len(ids),'tiers':{tier:{'denominator':len(keys),'present':len(keys&ids),'missing':len(keys-ids),'present_identities':sorted(keys&ids),'missing_identities':sorted(keys-ids)}for tier,keys in tiers.items()}})
aggregate={tier:{'denominator':sum(r['tiers'][tier]['denominator']for r in rows),'present':sum(r['tiers'][tier]['present']for r in rows),'missing':sum(r['tiers'][tier]['missing']for r in rows)}for tier in tiers}
result={'head':head,'tree':tree['sha'],'run_id':run,'event':'push','original_final_push_source_sha256':sha(source),'source_blobs_and_modes_verified':modes,'expected_omitted_metadata':missing,'offered_locales':171,'priority_manifest_sha256':sha((S/'translations/string-importance.json').read_bytes()),'aggregate':aggregate,'rows':rows,'scope':'Structural actual typed entry presence in each canonical catalogue only. No fallback inheritance expansion, linguistic acceptance, review completion or source correctness inferred from presence.','previous_recomputed_totals_supplied_by_root':{'P0':{'present':7376,'missing':8356},'P1':{'present':20789,'missing':21790}},'deltas_from_previous':{tier:{'present':aggregate[tier]['present']-old,'missing':old-aggregate[tier]['present']}for tier,old in [('P0',7376),('P1',20789)]}}
(B/'all171-priority-presence-final-push.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');(B/'early-source-verification.json').write_text(json.dumps({'head':head,'run_id':run,'artifact_digests_verified':verified,'source_blobs_verified':modes,'source_modes_verified':modes,'source_sha256':sha(source),'expected_omitted_metadata':missing},indent=2)+'\n');print(json.dumps({'head':head,'run_id':run,'source_blobs_and_modes_verified':modes,'aggregate':aggregate,'deltas':result['deltas_from_previous']},indent=2))
