import copy, hashlib, json, pathlib, subprocess, sys, xml.etree.ElementTree as E
sys.path.insert(0,'tools')
import string_importance as s
import translation_catalogues as t
w=pathlib.Path('/workspace/shared/anpaint-p2-page-four-evidence')
p=json.load(open(w/'inputs.json'));review=json.load(open(w/'review.json'));values=review['accepted'];m=s.load_manifest()
base=json.load(open(w/'current-base-tree.json'));old={x['path']:(x['mode'],x['type'],x['sha']) for x in base['tree'] if x['type']!='tree'}
status=subprocess.check_output(['git','diff','--numstat'],text=True).splitlines()
assert len(status)==len(values)
for line in status:
 adds,deletes,path=line.split('\t');tag=next(tag for tag,path2 in p['paths'].items() if path2==path)
 assert int(adds)==len(values[tag]) and deletes=='0'
assert not subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True)
subprocess.run(['git','add','--',*p['paths'].values()],check=True)
rows=subprocess.check_output(['git','ls-files','-s'],text=True).splitlines();new={}
for row in rows:
 mode,sha,rest=row.split(' ',2);stage,path=rest.split('\t',1);assert stage=='0';new[path]=(mode,'blob',sha)
assert new.keys()==old.keys() and len(new)==1283
for path,entry in new.items():
 if path not in p['paths'].values():assert old[path]==entry
 else:assert old[path][:2]==entry[:2]
tree=subprocess.check_output(['git','write-tree'],text=True).strip()
(w/'expected-tree.json').write_text(json.dumps({'tree':tree,'entries':{path:{'mode':v[0],'type':v[1],'sha':v[2]} for path,v in new.items()}},indent=2)+'\n')
coverage={tag:s.locale_coverage(m,tag) for tag in t.offered_tags()}
after={tier:{'present':sum(x[tier]['present'] for x in coverage.values()),'total':sum(x[tier]['total'] for x in coverage.values())} for tier in s.TIERS}
before=json.load(open(w/'coverage-before.json'))['summary'];n=sum(len(x) for x in values.values())
assert after['P2']['present']==before['P2']['present']+n
assert all(after[k]==before[k] for k in ['P0','P1','P3'])
(w/'coverage-after.json').write_text(json.dumps({'summary':after,'coverage':coverage},indent=2)+'\n')
print(json.dumps({'tree':tree,'entries':len(new),'new_values':n,'summary':after},indent=2))
