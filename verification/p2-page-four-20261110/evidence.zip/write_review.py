import json, hashlib, re, collections
from pathlib import Path
import xml.etree.ElementTree as ET
p=Path('/workspace/shared/anpaint-p2-page-four-evidence')
root=Path('/workspace/shared/anpaint-p2-page-four-20261110')
cand=json.loads((p/'candidate.json').read_text()); inp=json.loads((p/'inputs.json').read_text())
notes={
'ht':[
'Chwazi is an imperative; yon paj requests one document page.',
'Preserves format/name/count and raw newline escape; modifye li kòm yon imaj conveys editing the chosen page as an image.',
'Nimewo paj is the page-number field label, not the number of pages.',
'Paj anvan an means the preceding page, suitable for both document and credits navigation.',
'Paj apre a means the following page, not the final page.',
'Louvri is an open command and paj la identifies the selected page.',
'Apèsi denotes a preliminary view; paj ki chwazi a makes selection explicit.',
'Ant 1 ak the upper bound communicates the allowed page-number interval.',
'Paj X sou Y expresses page position out of total; ap chaje is ongoing preview loading.',
'Piksèl means pixels; dimension order, multiplication sign and all four arguments remain intact.',
'Pa disponib describes unavailable preview and leaves the detailed error argument intact.',
'Memwa is working memory; smaller dimensions are offered only si sa posib, without promising successful decoding.',
'Pa t ka li conveys inability to read; possible damage and unsupported Android-version functions remain alternatives.',
'Modpas and chifreman distinguish password from encryption; save an unprotected copy before import is explicit.',
'Ki pa vid and ki pa depase preserve nonempty and inclusive 512 MiB maximum.',
'Ant 1 ak the supplied maximum retains the valid page count.',
'Pa valab ankò conveys no longer valid, followed by selecting from this document.',
'Dimansyon, plural yo, and enpòtasyon preserve invalid or too-large import dimensions.',
'Rektang is rectangle; lajè and wotè each exceed zero and rete nèt anndan requires full containment.',
'Rendering as an image is explicit and compares memory demand with the available image-memory limit, not disk space.'
],
'ku':[
'Rûpelekê is the oblique indefinite page object of hilbijêre; single-page choice is clear.',
'Revise feminine wêneyekê to masculine oblique wêneyekî after wek; page reference wê remains feminine. Format/name/count and image-edit purpose are preserved.',
'Hejmara rûpelê labels the number of an individual page, unlike Hejmara rûpelan for total pages.',
'Rûpela berê is previous page and remains generic for the credits reader.',
'Rûpela paşîn expresses the following page in this sequential navigation context; not an action to jump to the last page.',
'Rûpelê is the object of the open imperative veke.',
'Pêşdîtina uses the preview construct form with the selected-page modifier.',
'Hejmareke rûpelê is a page-number object; ji 1 heta maximum gives the required range.',
'Page X ji Y plus tê barkirin denotes ongoing preview loading.',
'Pîksel denotes pixels and the four arguments retain page position and width by height.',
'Ne berdest e states unavailability and preserves the detailed error.',
'Bîr denotes memory, and ger gengaz be qualifies the offer of smaller dimensions; no success guarantee.',
'Reading failure, possible file damage and Android-version unsupported features remain distinct.',
'Revise derxî nav sepanê, whose verb can imply taking out, to unambiguous nominal hundirxistinê. Password/encryption alternatives and unprotected-copy saving remain.',
'HOLD: pelekî in this predicative construction has an unresolved case/gender issue. Bounds are semantically correct, but the existing catalogue itself varies pel/pela/pelekî and cannot settle this full sentence. Obtain competent Kurmanji grammatical review rather than adopting an unverified replacement.',
'Ji 1 heta maximum rûpelan preserves the page-count bounds.',
'Êdî ne derbasdar conveys no longer valid; choose a page from this document is retained.',
'Plural mezinahiyên with in preserves invalid or excessive dimensions; anîna nav sepanê describes import into the app.',
'HOLD: çargoşe can describe a four-sided shape, and does not independently establish the exact rectangle constraint. The joint firehî û bilindahiya phrase also needs competent grammatical review to ensure both axes are strictly positive. Full containment is clear. Existing catalogue rectangle terminology alone is not sufficient proof.',
'Çêkirina wêneyê ji PDF describes raster production and compares required memory with the available image-memory limit, not file storage.'
],
'so':[
'Dooro bog is an imperative to select a page.',
'Tirada bogagga gives page count; hal bog explicitly chooses one page to edit as an image. Raw newline and arguments retained.',
'Lambarka bogga means page number rather than total count.',
'Bogga hore is the preceding page in sequential controls and works in the credits reader too.',
'Bogga xiga is the next page.',
'Fur bogga is the open-page command.',
'Hordhaca is the definite construct of the existing preliminary-view term. Although Horfiirin is more literal in MediaWiki, the selected-page preview context supports this established label; terminology confidence is moderate.',
'Geli requests entry; lambar bog identifies page number; range 1 through maximum is retained.',
'La soo gelinayaa marks ongoing loading. Hordhaca is contextually the preview, not a separate introductory document.',
'Dhibco sawireed explicitly identifies image pixels rather than generic dots; all four arguments are retained.',
'Lama heli karo expresses unavailable preview, followed by the unchanged reason argument.',
'Xusuus refers to memory; smaller sizes are qualified by haddii ay suurtagal tahay, without guaranteeing success.',
'Revise wuu dhaawacmi karaa, which can mean may become damaged, to an explicit possibility of existing damage. Preserve unsupported Android-version features as the other possible cause.',
'Revise soo dejin, which can imply downloading, to soo gelin barnaamijka for import into the application. Password/unsupported encryption and saving an unprotected copy remain.',
'Aan madhnayn and aan ka weynayn preserve nonempty and inclusive 512 MiB limit.',
'1 ilaa maximum bog gives the inclusive page count, not page selection.',
'Hadda sax ma aha conveys selection is no longer valid in the current state; recovery chooses from this document.',
'Revise the download-like soo dejiyo to barnaamijka la soo geliyo for import. Cabbirrada and plural agreement preserve dimensions.',
'Leydi denotes a rectangle, including ordinary orthographic variation from existing laydi; gebi ahaan requires full containment and both named axes exceed zero.',
'Memory required to produce an image from PDF exceeds available image-memory allocation. It does not suggest freeing disk storage.'
],
'su':[
'Pilih hiji kaca requests a single page.',
'Jumlah kaca is page count; diédit salaku gambar keeps edit-as-image meaning and raw newline/arguments.',
'Nomer kaca labels page number rather than count.',
'Kaca saméméhna is previous page and remains applicable to credits navigation.',
'Kaca salajengna is next page, corroborated by primary source.',
'Buka kaca commands opening the page.',
'Pratilik is understandable as a preliminary inspection/view in this app; anu dipilih explicitly ties it to the selected page. Primary source uses Pramidang but does not invalidate this compound.',
'Lebetkeun is the entry imperative and ti 1 nepi ka maximum expresses the valid interval.',
'Nuju ngamuat conveys loading in progress; page X tina Y retains page and total.',
'Piksel means pixels and dimension order and all arguments remain unchanged.',
'Henteu sadia expresses unavailability and retains the detailed reason.',
'Mémori is memory; smaller sizes are offered only lamun mungkin. No claim that a smaller preview will succeed.',
'Henteu bisa dibaca means cannot be read; possible damage and features unsupported by this Android version are preserved.',
'Sandi/énkripsi distinguish password/encryption; simpen salinan tanpa panyalindungan is saving an unprotected copy before importing.',
'Henteu kosong plus henteu leuwih ti 512 MiB retains nonempty and inclusive maximum.',
'1 nepi ka maximum kaca gives the page-count interval.',
'Henteu sah deui expresses no longer valid, followed by selection from this document.',
'Ukuran conveys page dimensions here; invalid or too large to import is preserved.',
'Revise sagi opat (generic quadrilateral) to sagi opat panjang (rectangle), matching the existing precise rectangle term. Rubakna jeung jangkungna explicitly names both dimensions; each exceeds zero and sagemblengna di jero retains full containment.',
'Ngahasilkeun gambar tina PDF is rendering as an image; mémori demand exceeds the available image-memory limit, not disk capacity.'
]}
revisions={
('ku','formats22_page_description'):r'%1$s · %2$s\nHejmara rûpelan: %3$d. Rûpelekê hilbijêre da ku wê wek wêneyekî biguherînî.',
('ku','formats22_pdf_encrypted'):'PDF şîfreyekê dixwaze an şîfrekirina ku nayê piştgirîkirin bi kar tîne. Berî hundirxistinê, kopiyeke bêparastin tomar bike.',
('so','formats22_pdf_invalid'):'PDF lama akhrin karin. Waxaa laga yaabaa in faylku dhaawacmay ama uu adeegsado astaamo aanu noocan Android taageerin.',
('so','formats22_pdf_encrypted'):'PDF waxa uu u baahan yahay eray sir ah ama waxa uu adeegsadaa sirgelin aan la taageerin. Kaydi nuqul aan ilaalin lahayn ka hor inta aanad barnaamijka soo gelin.',
('so','formats22_pdf_dimensions'):'Cabbirrada bogga PDF sax ma aha ama aad bay ugu weyn yihiin in barnaamijka la soo geliyo.',
('su','formats22_pdf_crop'):'Wewengkon pamotongan PDF kudu mangrupa sagi opat panjang anu rubakna jeung jangkungna leuwih ti nol sarta sagemblengna aya di jero kaca anu dipilih.'
}
holds={('ku','formats22_pdf_file_size'),('ku','formats22_pdf_crop')}
report={'review_type':'Independent internal model-assisted complete-value semantic and linguistic review','base_sha':inp['base_sha'],'accepted':{},'decisions':{},'summary':{},'sources':[],'consumer_context':[
'ImportSelection: generic PDF/TIFF page chooser; arguments are format, filename, total pages; page field is 1-based, then converted to 0-based on open.',
'ImportSelection: loading status displays current/total; dimensions are original source width and height in pixels, not preview bitmap dimensions. Preview memory message offers a conditional smaller-dimension path, not guaranteed success.',
'PdfCodec: file length must be 1..512*1024*1024 inclusive; page count 1..4096; width and height each 1..500000 PDF points, multiplied by two for source pixels.',
'PdfCodec: crop left/top nonnegative and right/bottom inside source dimensions; width/height strictly positive. Rectangular geometry is required, not merely a four-sided shape.',
'PdfCodec: SecurityException maps to password or unsupported encryption; an unprotected copy is the recovery instruction. Image working-memory estimate includes bitmap, document and rendering reserve, not available disk space.',
'LegacyImageCreditsActivity: previous/next labels are reused for paginated saved credit text, so neither should mention PDF specifically.'
], 'limits':['Not native-human review or certification.','No installed UI, screen-reader, line-wrap or font rendering proof.','Primary-source terms corroborate vocabulary, not these new complete sentences.','Held values are excluded from accepted; leave their keys absent.','Application XML was not edited.']}
default={e.get('name'):e.text for e in ET.parse(root/'Paintroid/src/main/res/values/strings.xml').getroot()}
assert all(default[k]==v['text'] for k,v in inp['source'].items())
for tag,values in cand.items():
 report['accepted'][tag]={}; report['decisions'][tag]={}
 current={e.get('name') for e in ET.parse(root/inp['paths'][tag]).getroot()}
 assert not current.intersection(values)
 for (k,original),reason in zip(values.items(),notes[tag],strict=True):
  pair=(tag,k); value=revisions.get(pair,original)
  status='hold' if pair in holds else ('revise_accept' if pair in revisions else 'accept')
  conf='low' if status=='hold' else ('medium' if tag=='ku' or ('preview' in k or 'loading' in k) and tag in ['so','su'] else 'medium-high')
  assert sorted(re.findall(r'%\d+\$[sd]',value))==sorted(re.findall(r'%\d+\$[sd]',inp['source'][k]['text']))
  assert value.count('\\n')==inp['source'][k]['text'].count('\\n') and '\n' not in value
  report['decisions'][tag][k]={'decision':status,'candidate':original,'value':None if status=='hold' else value,'reason':reason,'confidence':conf,'limits':['Model-assisted linguistic judgment; no native-human or installed-UI verification.']+(['Needs competent Kurmanji review before addition.'] if status=='hold' else [])}
  if status!='hold':report['accepted'][tag][k]=value
 data=(p/f'source-{tag}.json').read_bytes(); ident=json.loads((p/f'source-{tag}-identity.json').read_text())
 actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 assert actual==ident['sha'],(tag,actual,ident)
 source=json.loads(data)
 report['sources'].append({'locale':tag,'url':ident['display_url'],'git_blob_sha':actual,'verified':True,'context_terms':{k:source[k] for k in ['edit','savearticle','preview','showpreview','nextpage','prevpage','import','filehist-dimensions','userlogin-yourpassword'] if k in source},'target_catalogue':inp['paths'][tag]})
counts=collections.Counter(d['decision'] for l in report['decisions'].values() for d in l.values())
report['summary']={'reviewed':80,'accepted_unchanged':counts['accept'],'accepted_after_revision':counts['revise_accept'],'held':counts['hold'],'accepted_total':sum(map(len,report['accepted'].values())),'per_locale_accepted':{k:len(v) for k,v in report['accepted'].items()},'placeholder_and_raw_escape_checks':'Passed for all accepted values; source text verified against actual default XML.','all_keys_absent_before_change':True,'important_findings':['Six precise revisions: Kurdish image noun case/gender and import direction; Somali existing damage and two import ambiguities; Sundanese rectangle precision.','Two Kurdish values held: file-size predicate case/gender and exact rectangular crop wording.']}
(p/'review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report['summary'],ensure_ascii=False,indent=2))
