import collections, copy, hashlib, json, pathlib, re, subprocess, sys, unicodedata
import xml.etree.ElementTree as E

sys.path.insert(0, 'tools')
import translation_catalogues as catalogues
from current_localization_contracts import decode_display

w = pathlib.Path('/workspace/shared/anpaint-p2-page-four-evidence')
p = json.load(open(w / 'inputs.json'))
review = json.load(open(w / 'review.json'))
values = review['accepted']
assert subprocess.check_output(['git', 'status', '--porcelain'], text=True) == ''
assert subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], text=True).strip() == p['base_tree']
assert set(values) <= set(p['paths']) <= set(catalogues.offered_tags())
source = {n.get('name'): n for n in E.parse('Paintroid/src/main/res/values/strings.xml').getroot()}
tiers = {k: t['id'] for t in json.load(open('translations/string-importance.json'))['tiers'] for k in t['keys']}
held = {(x['path'], x['key']) for xs in json.load(open(w / 'fresh-held-changes.json')).values() for x in xs}

def node_value(node):
    n = copy.deepcopy(node)
    n.tail = None
    return E.tostring(n, encoding='unicode')

summary = {}
for locale, accepted in values.items():
    assert set(accepted) <= set(p['missing_keys'][locale])
    path = p['paths'][locale]
    target = pathlib.Path(path)
    assert catalogues.catalogue_paths()[locale].relative_to(catalogues.ROOT).as_posix() == path
    old = target.read_text()
    before = E.fromstring(old)
    old_nodes = {n.get('name'): node_value(n) for n in before}
    assert len(old_nodes) == len(before)
    pending = set() # All proposed keys independently absent in 32 fresh held/pending target blobs.
    additions = []
    for key, value in accepted.items():
        assert key not in old_nodes and key not in pending and (path, key) not in held
        assert tiers['string/' + key] == 'P2'
        assert p['source'][key] == {'text': source[key].text, 'attributes': source[key].attrib}
        assert value and value == unicodedata.normalize('NFC', value)
        assert collections.Counter(re.findall(r'%[0-9]+[$][a-zA-Z]', value)) == collections.Counter(re.findall(r'%[0-9]+[$][a-zA-Z]', source[key].text))
        assert value.count(r'\n') == source[key].text.count(r'\n') and '\n' not in value
        assert not any(ord(c) < 32 for c in value)
        assert not catalogues.android_string_errors(value)
        assert not catalogues.format_string_errors(value, source[key].get('formatted') != 'false')
        assert decode_display(value)
        assert any(key in f.read_text() for f in pathlib.Path('Paintroid/src/main/java').rglob('*.kt'))
        node = E.Element('string', source[key].attrib)
        node.text = value
        additions.append('    ' + E.tostring(node, encoding='unicode') + '\n')
    assert old.count('</resources>') == 1
    final = old.replace('</resources>', ''.join(additions) + '</resources>')
    parsed = E.fromstring(final)
    nodes = {n.get('name'): n for n in parsed}
    assert len(nodes) == len(parsed) == len(before) + len(accepted)
    assert all(node_value(nodes[k]) == v for k, v in old_nodes.items())
    assert all(nodes[k].text == v and nodes[k].attrib == source[k].attrib for k, v in accepted.items())
    target.write_text(final)
    summary[locale] = {'old_nodes_preserved': len(before), 'new_values': len(accepted), 'path': path,
                       'blob': subprocess.check_output(['git', 'hash-object', path], text=True).strip()}
summary['accepted_map_sha256'] = hashlib.sha256(json.dumps(values, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
summary['total_new_values'] = sum(len(v) for v in values.values())
(w / 'integration.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(summary, ensure_ascii=False, indent=2))
