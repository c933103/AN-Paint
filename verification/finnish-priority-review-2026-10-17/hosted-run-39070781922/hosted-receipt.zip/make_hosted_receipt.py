from pathlib import Path
import hashlib,json,re,zipfile,xml.etree.ElementTree as ET
O=Path(__file__).resolve().parent; P=O/'hosted-run-39070781922'
run=json.loads((P/'run-terminal.json').read_text()); jobs=json.loads((P/'jobs-terminal.json').read_text())
merge=json.loads((P/'tested-merge.json').read_text()); jvm=json.loads((P/'jvm-summary.json').read_text())
assert run['status']=='completed' and run['conclusion']=='success'
assert run['head_sha']=='69fe1495d4468fc028cf1bc30bdac35e70e6cdf0'
assert len(jobs)==6 and all(j['status']=='completed' and j['conclusion']=='success' for j in jobs)
assert merge['tree']['sha']=='c723db3d5e2c3202ea24c021f6a3e3574e840a83'
assert [p['sha']for p in merge['parents']]==['b6a99b41c4390ca6a412e3a1938eb913c59509fb',run['head_sha']]
assert jvm['aggregate']=={'tests':1113,'failures':0,'errors':0,'skipped':0}
fi=ET.parse(P/'FinnishPriorityWordingTest.xml').getroot()
assert {x.attrib['name']for x in fi.findall('testcase')}=={
 'actualLanguagePickerExplainsEnglishFallbackWithoutCompletenessClaim',
 'actualDimensionSummaryHandlesSingularAndGroupedCounts',
 'liveDimensionDescriptionsUseInflectedUnitsAcrossRepeatedSwitches',
 'failedPngAndDerivedEncodersReportIncompleteEncodingAndKeepSourcePixels'}
assert fi.attrib['tests']=='4' and all(fi.attrib[k]=='0' for k in ('failures','errors','skipped'))
lint=ET.parse(P/'regression-extract/app/build/reports/lint-results-debug.xml').getroot(); assert not lint.findall('issue')
python=(P/'regression-extract/build/reports/ci-phases/python.log').read_text()
assert re.search(r'Ran 918 tests in 207\.619s\n\nOK',python)
cov=json.loads((P/'emulator-extract/app/coverage.json').read_text())
identity=json.loads((P/'emulator-extract/composed-device-identity.json').read_text())
assert cov['success'] and cov['inventory_validated'] and cov['receipt_scope']=='complete-composed-app-union'
assert len(cov['completed'])==45 and len(set(map(tuple,cov['completed'])))==45
assert identity['commit']==merge['sha'] and identity['run_id']==str(run['id'])
assert identity['group_run_attempts']=={'core':1,'position':1}
with zipfile.ZipFile(P/'emulator-api35.zip') as z:
 native=ET.fromstring(z.read('Paintroid/androidTest-results/TEST-Paintroid.xml'))
 assert native.attrib['tests']=='74' and all(native.attrib[k]=='0' for k in ('failures','errors','skipped'))
summary={'run_id':run['id'],'run_url':run['html_url'],'run_attempt':run['run_attempt'],'status':run['status'],'conclusion':run['conclusion'],'head_sha':run['head_sha'],'tested_pr_merge_sha':merge['sha'],'tested_tree':merge['tree']['sha'],'same_tree_as_reviewed_head':True,'jobs':[{'name':j['name'],'id':j['id'],'conclusion':j['conclusion']}for j in jobs],'checks':{'python':{'passed':918,'seconds':207.619},'jvm':dict(jvm['aggregate'],reports=jvm['reports']),'finnish_consumer_tests':{'passed':4,'seconds':float(fi.attrib['time']),'methods':[dict(x.attrib) for x in fi.findall('testcase')]},'lint':{'issues':0},'exact_script_resource_graph':{'passed_probes':9},'api35_native':dict(native.attrib),'api35_app':{'passed':45,'receipt_scope':cov['receipt_scope'],'phases':cov['phases'],'device_identity':identity}},'limits':['Finnish tests are source-bound JVM/Robolectric checks, not installed Finnish layout or TalkBack coverage.','The general API35 regression suite is not whole-catalogue linguistic acceptance.','API30, physical-device coverage and private upgrade signing were not requested or established by this run.','APK/source hashes are the hosted composed identity receipt; this packet does not claim a separate local signature or embedded-source reinspection.','Initial local optimized failure and overwritten raw-log disclosure remain unchanged in the first evidence packet.'],'preservation':'Additive to evidence commit c2d1bdd3fd1f4f37f640f2fe3b38d031d25543a8; every existing source/evidence leaf and mode retained.'}
(P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files=['README.md','summary.json','run-terminal.json','jobs-terminal.json','artifacts-terminal.json','tested-merge.json','exact-script-summary.json','exact-script.zip','build-job.log','regression-job.log','exact-script-job.log','position-job.log','core-job.log','union-job.log','jvm-summary.json','FinnishPriorityWordingTest.xml','junit-reports.zip','emulator-receipts.zip','emulator-extract/app/coverage.json','emulator-extract/composed-device-identity.json']
files += [str(p.relative_to(P))for p in sorted((P/'regression-extract').rglob('*'))if p.is_file()]
manifest={f:hashlib.sha256((P/f).read_bytes()).hexdigest()for f in files}
(P/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');files.append('manifest.json')
with zipfile.ZipFile(P/'hosted-receipt.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in files:z.write(P/f,f)
 z.write(__file__,'make_hosted_receipt.py')
with zipfile.ZipFile(P/'hosted-receipt.zip') as z:
 for f,h in manifest.items():assert hashlib.sha256(z.read(f)).hexdigest()==h
(P/'packet.sha256').write_text(hashlib.sha256((P/'hosted-receipt.zip').read_bytes()).hexdigest()+'  hosted-receipt.zip\n')
print(json.dumps({'files':len(files)+1,'archive_bytes':(P/'hosted-receipt.zip').stat().st_size,'summary':summary},indent=2))
