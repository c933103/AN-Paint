# Translating AN Paint

**Localization status reset — 28 September 2026: all previous progress, completion, repair, verification and no-defect conclusions for PRs #2–#9, #12 and #15 are withdrawn. Every item requires a full recheck; no previous progress is accepted.**

See the [individual recheck register](https://github.com/c933103/AN-Paint/blob/review/localization-integration/verification/localization-recheck-register.md). The rejected delivery is additional material to check, not an accepted audit. Historical source, test outputs and evidence classifications remain available as inputs. They carry no current completion credit. The current picker scope (14 October 2026) is 171 locale options: 59 scoped catalogues and 112 outside-scope catalogues with explicit English fallback for this bounded work. Completing those 112 catalogues is outside this task. These counts do not claim translation completeness or linguistic acceptance. The 81-locale scope counts in withdrawn historical audits refer to the earlier 140-choice inventory, not the current 171-option scope.

## Translation importance tiers

Each translatable source key belongs to exactly one P0–P3 importance tier,
independent of its language-specific coverage and linguistic-review status.
P0 prioritizes data loss/recovery and irreversible warnings; P1 covers basic
editing; P2 covers extended features; P3 covers detailed help and reference.
This does not exempt any tier from eventual translation or legal obligations.

See [the tier policy](translations/STRING_IMPORTANCE.md) and the exact
[per-key manifest](translations/string-importance.json). Run
`python3 tools/string_importance.py --locale ceb --missing-keys` for a
P0-first gap list for a locale. The tool counts exact-catalogue presence only;
neither presence nor tier classification certifies that a translation was
reviewed. Existing withdrawn translation-review claims remain withdrawn.

AN Paint uses ordinary Android resource catalogues. The English source catalogue is
`Paintroid/src/main/res/values/strings.xml`. Keep every translatable default string,
plural and string-array in that file so the translation-service source is complete.
Other default XML files may contain styles, identifiers and non-translatable resources.

Each localized `strings.xml` under `Paintroid/src/main/res/values*/` is a
**canonical source file**. It is not generated from JSON and must not be overwritten
from Paintroid, GIMP, Krita, LibreOffice, MediaWiki, Android or any other application.

Those older catalogues remain under `translations/` as reference and provenance.
They can be useful terminology evidence, but they are not assumed to be correct.
When their wording conflicts with the meaning of AN Paint, the AN Paint translation
should be corrected directly in the locale's `strings.xml`.

The intended end state is a complete catalogue for every language offered by
View → Languages and Android's App languages page. English fallback is only a
temporary migration condition until the applicable catalogue work has been independently checked; no current progress is accepted.

## Six language options added on 12 October 2026

The first addition brought the inventory to 146 choices. Hausa (`ha`), Igbo (`ig`), Lingala (`ln`),
Sundanese (`su`), Yoruba (`yo`) and Zulu (`zu`) are selectable in the app and in
Android App languages. Their exact canonical XML catalogues intentionally contain
no translated entries yet: all current translatable source strings and plural
resources use default English fallback. Selecting a language is not a
claim of translated UI, linguistic review, or installed-device verification.

The existing picker explains untranslated English fallback. The dedicated
[translation progress tracker](https://github.com/c933103/AN-Paint/pull/56)
records the outstanding catalogue and review work. The addition fixture at
`tools/fixtures/language_option_additions_20261012.json` records the six identities
and status. Historical 140-choice/81-fallback evidence remains available in the
[immutable archive](verification/README.md). Current regressions check the live
resources and the explicit current scope directly.

## Further options and principal varieties requested on 12 October 2026

The 12 October inventory had **167 choices**, adding **21 options** to the merged
146-choice baseline. Fourteen requested languages retain their individual option:
Nigerian Pidgin (`pcm`), Somali (`so`), Assamese (`as`), Wolof (`wo`), Haitian Creole
(`ht`), Tok Pisin (`tpi`), Navajo (`nv`), Cherokee (`chr`), Yucatec Maya (`yua`),
Chamorro (`ch`), Samoan (`sm`), Māori (`mi`), Sanskrit (`sa`) and Tajik (`tg`).
The current IANA registry marks Sanskrit as a macrolanguage; no narrower Sanskrit
variety was requested.

Following the clarification to use the main varieties, the broad `nah` and `qu`
placeholders are replaced by seven concrete individual-language options:

- Nahuatl: Central Huasteca (`nch`), Eastern Huasteca (`nhe`), Western Huasteca (`nhw`).
- Quechua: Cusco (`quz`), Ayacucho / Chanka (`quy`), South Bolivian (`quh`),
  Chimborazo Highland Quichua (`qug`).

This is a practical principal-variety set, not an exhaustive catalogue. In
particular, `quz` is not all Southern Quechua and `qug` is not all Ecuadorian Kichwa.
Native-name bases are source-backed; regional qualifiers are explicit editorial
disambiguators. No automatic fallback between these individual tags is implied.
The source and selection limits are recorded with the addition fixture.

Each new catalogue has **zero translated strings and plural resources**;
all current translatable keys use default-English fallback pending actual translation.
The active fixture is `tools/fixtures/language_option_additions_20261012_second.json`.
That inventory preserved the original 59 scoped catalogues and all
81 existing fallback identities, adding **27 empty catalogues for 108 fallbacks**.
The 14 October additions below extend the current contract to 112 fallbacks.
It checks current identity, status, resource values and fallback behavior without
reconstructing historical snapshots. The earlier unpublished 162-choice candidate is superseded; its
retained test/review evidence is historical and does not accept this successor.

## Further languages and Filipino — 14 October 2026

Four individually registered selectable tags bring the inventory to **171**: Old English (`ang`, Ænglisc), Old Norse (`non`, Norrœna), Moroccan Arabic (`ary`, الدارجة المغربية) and Standard Moroccan Tamazight (`zgh`, ⵜⴰⵎⴰⵣⵉⵖⵜ / Tamaziɣt (Morocco)). Moroccan Arabic is distinct from `ar`; `zgh` is not all Amazigh languages, including the existing separate Kabyle `kab`. The first two are historical languages, not variants of modern English or Norwegian.

These four have empty exact canonical XML catalogues with **0 strings and 0 plurals translated**, default-English fallback, no linguistic review, and no claim of historical phrasing or script/font acceptance. See `tools/fixtures/language_option_additions_20261014.json`. The `tl` Tagalog menu identity is replaced with **Filipino (`fil`)**. Its pre-existing translations are transferred byte-identically to `values-b+fil/strings.xml`, and saved `tl` preferences and Android 13 choices migrate to `fil`. This is **not** independent linguistic review for Filipino. Historical `tl` import/provenance files remain, but `tl` is not a duplicate selectable option. The 59 scoped catalogues now include `fil` instead of `tl`; fallback count rises to **112**. All previous review obligations remain open.

## Editing a translation

Edit the locale directly, for example:

- `Paintroid/src/main/res/values-ja/strings.xml`
- `Paintroid/src/main/res/values-fr/strings.xml`
- `Paintroid/src/main/res/values-zh-rHK/strings.xml`
- `Paintroid/src/main/res/values-b+yue+Hant/strings.xml`
- `Paintroid/src/main/res/values-b+sr+Latn/strings.xml`

Keep one `strings.xml` catalogue for each exact offered language/script/region.
Use explicit BCP-47 Android qualifiers for variants where a plain language qualifier
would be ambiguous.

Do not edit `translations/local-translations.json`,
`translations/basic-translations.json`, `translations/main-menu-translations.json`
or the imported catalogue snapshots as a way of changing the live UI. They document
earlier/imported work and can be consulted when reviewing terminology.

`crowdin.yml` points directly from the English Android catalogue to localized
Android `strings.xml` files, so no conversion step is needed for Crowdin or similar
Android-resource translation systems. There is one source file and one output file
per locale; do not map multiple source files onto the same localized `strings.xml`.
Before the first export, upload the existing canonical translations to the
maintainer-owned project. Review exports in a clean checkout before accepting them:
keep exact language/script/region directories, reject missing keys or unexpected
English replacements, and run the checks below. A service export must not silently
replace newer canonical edits.

## Correctness rules

- Translate according to the actual AN Paint operation and surrounding UI. Existing
  wording from another application is evidence, not authority.
- Preserve positional placeholders such as `%1$s`, `%2$d` and `%3$.2f`.
  Their position may change but their number and type must not.
- Translate all plural forms required by the target language and preserve their
  placeholders.
- Preserve escaped newlines, literal percent signs, resource references and XML
  escaping.
- Entries marked `translatable="false"` are identifiers such as fixed export
  filenames and are not translated.
- Product, codec and licence names should remain recognizable where they are proper
  names.
- Legal licence bodies and copyright notices remain available verbatim; translate
  only their UI/navigation labels unless the licence itself supplies an official
  localized text.
- Distinguish regional and script variants where their terminology actually differs.
  Do not substitute a neighbouring language merely because it is easier to source.
- Script-specific catalogues must use the requested script. Romanized variants are
  not allowed to fall back to Cyrillic/Han/etc. text unless the item is itself a
  proper name conventionally written that way.
- Canvas directions, coordinates, image rotation and physical attachment directions
  describe image geometry. They must not be semantically mirrored merely because
  the surrounding interface is right-to-left.

## Sinitic variety conventions

Several language tags cover varieties for which a script tag alone does not identify
one universal written standard. AN Paint currently uses these explicit conventions:

- `lzh-Hant`: technical Literary Chinese in Traditional characters. Modern product,
  codec and computing terms may remain modern where forcing an archaic paraphrase
  would obscure the operation.
- `hak-Hant-TW`: Taiwan Sixian Hakka in Han characters.
- `hak-Latn-TW`: the same Sixian Hakka wording in Pha̍k-fa-sṳ (PFS), not a
  romanization of Mandarin text.
- `nan-Hant-TW`: Taiwan Southern Min / Taiwanese Hokkien in Han characters.
- `nan-Latn-TW`: the same Taiwanese wording in Pe̍h-ōe-jī (POJ), not Mandarin
  transliteration.
- `wuu-Hans`: Simplified-script written Wu using Shanghainese as the concrete
  vernacular basis. `wuu` is a macrolanguage tag and this catalogue must not be
  described as a standardized pan-Wu written norm.

Han- and Latin-script pairs must stay semantically aligned, but the Latin catalogue
is a real orthographic rendering of the target variety rather than a character-by-
character transliteration of Standard Chinese.

## Validation

`tools/translation_catalogues.py` reads the canonical XML directly. Run:

```sh
python3 tools/translation_catalogues.py
python3 tools/translation_catalogues.py --complete
python3 -m unittest discover -s tools -p 'test_translations.py'
```

The first command checks catalogue/resource structure and format placeholders.
`--complete` additionally requires every translatable source key and plural
resource in every offered non-English locale. These are structural checks only. Key coverage does not establish semantic
correctness, completed review, or acceptance of the original conversation work.
All earlier progress remains withdrawn pending full recheck.

Then run the normal Android unit/lint checks and inspect both orientations, short
screens, large font sizes, dialogs, accessibility labels and RTL layouts as
applicable.

`TranslationReadinessTest` covers layout/resource behavior under RTL conditions.
`AppLanguageTest` covers persisted app-language choice, localized numeric entry,
Android 13 integration, and preserving the current canvas/undo/selection state
through a language change.

## Provenance material

Files under `translations/upstream/` and the GIMP/Krita/LibreOffice/MediaWiki/
Android snapshot files are retained so previous wording and licences remain
auditable. They do not regenerate or override canonical Android locale files.

Known imported errors should remain documented where useful. For example, the
historical Paintroid Japanese horizontal/vertical flip strings were reversed;
AN Paint's canonical Japanese catalogue uses `左右反転` for horizontal flip and
`上下反転` for vertical flip.
