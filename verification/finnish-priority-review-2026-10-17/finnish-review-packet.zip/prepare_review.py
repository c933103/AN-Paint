from pathlib import Path
import json,re,hashlib,sys,collections,xml.etree.ElementTree as E
O=Path(__file__).resolve().parent;S=O/'source';sys.path.insert(0,str(S/'tools'));import translation_catalogues as c
REV='b6a99b41c4390ca6a412e3a1938eb913c59509fb'
pairs=json.loads((O/'pairs.json').read_text());notes={int(x.split('\t',1)[0]):x.split('\t',1)[1] for x in (O/'decisions.tsv').read_text().splitlines()}
prior_all=json.loads((O/'all-prior-receipts.json').read_text());prior={k:([x for x in v if x.get('tag')=='fi'] if k in ('receipts','superseded_receipts','partial_reviews') else v) for k,v in prior_all.items() if k!='cohorts'}
prior['source_ref']='cc1d2718b88b9f08e25b3013ccdbc10770e7f332';prior['source_blob_sha']='004a38a070bc4ea215a82fdd41028aac5e341f3b'
(O/'prior-receipts.json').write_text(json.dumps(prior,ensure_ascii=False,indent=2)+'\n');byprior={x['key']:x for x in prior['receipts']}
changes={
 'ui_the_encoder_did_not_finish':'Kooderi ei suorittanut koodausta loppuun.',
 'language20_translation_note':r'Sovelluksen kieli\n\nKäännöksiä ylläpidetään AN Paintin kieliresursseissa. Uusi tai kääntämätön teksti näkyy englanniksi.',
 'ui_d_d_px_d_pixels_2f_mp':'%1$d × %2$d px · Pikselimäärä: %3$,d (%4$.2f MP)',
 'ui_height_in':'Korkeus %1$s',
 'ui_width_in':'Leveys %1$s',
 'ui_pixels_6ec9c2':'pikseleinä',
 'ui_percent_fd8671':'prosentteina',
}
p=S/'Paintroid/src/main/res/values-fi/strings.xml';base=O/'baseline-finnish.xml'
if not base.exists():base.write_bytes(p.read_bytes())
raw=base.read_text();en={e.get('name'):''.join(e.itertext()) for e in E.parse(S/'Paintroid/src/main/res/values/strings.xml').getroot() if e.tag=='string'}
cor=[]
for key,new in changes.items():
 m=re.search(rf'(<string name="{key}">)(.*?)(</string>)',raw,re.S)
 old=m[2];raw=raw[:m.start(2)]+new+raw[m.end(2):];r=next((x for x in pairs if x['key']=='string/'+key),None)
 cor.append({'key':key,'tier':r['tier'] if r else 'P2','english':en[key],'before':old,'after':new,'reason':notes[r['n']] if r else 'Sole authorized P2 companion: Leveys %1$s composes with shared pikseleinä/prosentteina to match the corrected height accessibility sentence. Both axes have the same actual consumer and require coordinated repair.','consumers':r['refs'] if r else [{'path':'Paintroid/src/main/java/org/catrobat/paintroid/classic/DimensionControls.kt','line':81}]})
p.write_text(raw)
fx={'schema_version':1,'note':'Seven bounded Finnish full-value corrections: six P0/P1 and one paired P2 width consumer. No whole-language/native-speaker certification. Other uncertainty and processing-label holds remain unchanged.','values':{},'constraints':{}}
for r in cor:
 key=r['key'];fx['values'][key]={'default':r['english'],'fi':r['after']};fx['constraints'][key]={'attributes':{'name':key},'formatted':True,'placeholders':dict(c.placeholders(r['english']))}
(S/'tools/fixtures/current_localization/finnish_priority_current_wording.json').write_text(json.dumps(fx,ensure_ascii=False,indent=2)+'\n');(O/'corrections.json').write_text(json.dumps(cor,ensure_ascii=False,indent=2)+'\n')
def hs(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
entries=[]
for r in pairs:
 key=r['key'].split('/')[1];status='accepted_static_context' if r['refs'] else 'accepted_wording_only'
 if r['n'] in (101,103,241):status='accepted_wording_only'
 if r['n'] in (17,78,124,126,199,208,227,236,286):status='held_uncertain'
 if key in changes:status='corrected_independently_accepted'
 old=r['finnish']['value'];new=changes.get(key,old)
 entries.append({**r,'candidate':new,'decision':status,'reason':notes[r['n']],'confidence':'high_semantic_moderate_idiomatic' if status!='held_uncertain' else 'open','source_revision':REV,'english_sha256':hs(r['english']['value']),'before_sha256':hs(old),'candidate_sha256':hs(new),'prior_receipt':byprior.get(r['key']),'new_tracker_credit':False,'limit':'Model-based full-value linguistic and static-consumer review only; no native-speaker, installed-layout, TalkBack or whole-language certification.'})
review={'schema_version':1,'locale':'fi','source_revision':REV,'entry_count':len(entries),'tiers':dict(collections.Counter(r['tier'] for r in entries)),'summary':dict(collections.Counter(r['decision'] for r in entries)),'prior_records_preserved':len(prior['receipts']),'prior_selected_records':sum(r['prior_receipt'] is not None for r in entries),'tracker_written':False,'scope':'All 341 P0/P1 full values plus one separately counted P2 width companion. Other 375 canonical entries not fully reviewed; no P3 edits.','entries':entries,'paired_consumer_correction':[r for r in cor if r['tier']=='P2']}
for e in entries:
 name=e['key'].split('/')[1]
 for field,rel in [('english','Paintroid/src/main/res/values/strings.xml'),('finnish','Paintroid/src/main/res/values-fi/strings.xml')]:
  line=next(i+1 for i,l in enumerate((S/rel).read_text().splitlines()) if 'name="'+name+'"' in l)
  e[field+'_source_url']=f'https://github.com/c933103/AN-Paint/blob/{REV}/{rel}#L{line}'
 for ref in e['refs']:ref['url']=f"https://github.com/c933103/AN-Paint/blob/{REV}/{ref['path']}#L{ref['line']}"
(O/'finnish-p0-p1-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in review.items() if k not in ('entries','paired_consumer_correction')},indent=2))
