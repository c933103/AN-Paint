114:                     4 -> showAsset(activity,ui(R.string.ui_icons_fonts_artwork_credits),"legal/ASSET_CREDITS.txt")
115:                     5 -> showAsset(activity,ui(R.string.ui_icon_licences_kde_breeze),"legal/ICON_NOTICES.txt")
116:                     6 -> showAsset(activity,ui(R.string.ui_jpeg_xl_codec_licences),"legal/JPEG_XL_NOTICES.txt")
117:                     7 -> showAsset(activity,ui(R.string.ui_webp_codec_licences),"legal/WEBP_NOTICES.txt")
118:                     else -> showAsset(activity,ui(R.string.ui_heic_avif_codec_licences),"legal/HEIF_AVIF_NOTICES.txt")
119:                 }
120:             }.setNegativeButton(ui(R.string.ui_cancel),null).show()
121:         }
122:         action(ui(R.string.ui_done),"terms_done") { dialog.dismiss() }
123:         val actionView=if(VerticalText.uiVertical(activity)) ResponsiveDialogColumns(activity).apply {addView(actions)} else actions
124:         body.region(actionView,.35f,"terms_actions_scroll")
125:         dialog.setContentView(body)
126:         LocaleTypography.install(body)
127:         fun resize() {
128:             val m=activity.resources.displayMetrics

94:         body.body(scroll)
95:         val actions=ResponsiveDialogActions(activity).apply {tag="terms_actions";gravity=Gravity.CENTER_VERTICAL}
96:         fun action(label: String,tagName: String,run: (Button) -> Unit) {
97:             val b=FlowButton(activity).apply { columnHeightDp=96;this.text=label;tag=tagName;isAllCaps=false;textSize=12f;minWidth=0;minimumWidth=0;minHeight=dp(48);minimumHeight=dp(48);setPadding(dp(6),dp(4),dp(6),dp(4));setOnClickListener { run(this) } }
98:             actions.action(b)
99:         }
100:         action(ui(R.string.ui_copy_all),"terms_copy") { button ->
101:             (activity.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText(title,text))
102:             LocaleTypography.showMessage(activity,ui(R.string.ui_full_text_copied),Toast.LENGTH_SHORT,button)
103:         }
104:         action(ui(R.string.ui_other_terms),"terms_more") { _ ->
105:             val options=listOf(ui(R.string.ui_about_copyright),ui(R.string.ui_agpl_licence),ui(R.string.ui_third_party_notices),ui(R.string.ui_font_licences),ui(R.string.ui_icons_artwork),ui(R.string.ui_icon_licences),ui(R.string.ui_jpeg_xl_codec_licences),ui(R.string.ui_webp_codec_licences),ui(R.string.ui_heic_avif_codec_licences))
106:             EditorDialogBuilder(activity).setTitle(ui(R.string.ui_other_terms))
107:                 .setItems(options.toTypedArray()) { _, index ->
108:                 dialog.dismiss()

129:             dialog.window?.setLayout((m.widthPixels*.94f).toInt(),android.view.ViewGroup.LayoutParams.WRAP_CONTENT)
130:         }

109:                 when (index) {
110:                     0 -> showAbout(activity)
