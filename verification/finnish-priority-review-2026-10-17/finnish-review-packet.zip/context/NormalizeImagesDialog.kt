32:             return target.roundToLong().takeIf { it in 1..Int.MAX_VALUE.toLong() }?.toInt()
33:         }
34:         fun display(pixels: Int) {
35:             input.setText(if (percent) String.format(Locale.ROOT,"%.4f",pixels*100.0/largest).trimEnd('0').trimEnd('.') else pixels.toString())
36:         }
37:         val dialog=EditorDialogBuilder(activity).setTitle(ui(if (axis == NormalizeAxis.WIDTH) R.string.ui_same_width else R.string.ui_same_height))
38:             .setView(ScrollView(activity).apply { addView(body) }).setNegativeButton(ui(R.string.ui_cancel),null).setPositiveButton(ui(R.string.ui_apply_to_all),null).create()
39:         fun refresh() {
40:             var valid=false
41:             try {
42:                 val target=value() ?: throw IllegalArgumentException(ui(R.string.ui_enter_a_positive_size))
43:                 val normalized=assembly.images.map { it.copy(normalization=ImageNormalization(axis,target)).placedSize }
44:                 val other=normalized.map { if (axis==NormalizeAxis.WIDTH) it.height else it.width }
45:                 info.text=ui(if (isWidth) R.string.ui_normalize_width_info else R.string.ui_normalize_height_info, target, other.minOrNull(), other.maxOrNull(), largest)
46:                 valid=true

47:             } catch (error: IllegalArgumentException) { info.text=error.message }
48:             dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.isEnabled=valid
49:         }
50:         listOf(ui(R.string.ui_pixels),ui(R.string.ui_percent)).forEachIndexed { index,label ->

51:             units.addView(RadioButton(activity).apply {
52:                 id=View.generateViewId(); tag="normalize_${if(index==0) "pixels" else "percent"}"; text=label; isChecked=index==0
53:                 setOnClickListener {
54:                     val old=value(); units.check(id); percent=index==1
55:                     LocaleNumberInput.configure(input, decimal = percent)
56:                     input.contentDescription=if (percent) ui(if (isWidth) R.string.ui_normalize_width_input_percent else R.string.ui_normalize_height_input_percent, largest) else ui(if (isWidth) R.string.ui_width else R.string.ui_height, "px")
57:                     old?.let { display(it) }; refresh()
58:                 }
59:             },LinearLayout.LayoutParams(0,-2,1f))
60:         }
61:         input.contentDescription=ui(if (isWidth) R.string.ui_width else R.string.ui_height, "px")
62:         body.addView(units); body.addView(input)
63:         val presets=LinearLayout(activity)
64:         listOf(ui(R.string.ui_smallest) to smallest,ui(R.string.ui_largest) to largest).forEach { (label,pixels) ->

65:             presets.addView(Button(activity).apply { text=label; isAllCaps=false; tag="normalize_${label.lowercase(Locale.ROOT)}"; setOnClickListener { display(pixels); refresh() } },LinearLayout.LayoutParams(0,dp(48),1f))
66:         }
67:         body.addView(presets); body.addView(info)
68:         body.addView(Button(activity).apply {
69:             text=ui(R.string.ui_restore_original_sizes); isAllCaps=false; tag="normalize_reset"
