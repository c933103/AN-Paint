28:         val temporary = File.createTempFile("dib-export-", ".tmp", file.absoluteFile.parentFile)
29:         try {
30:             temporary.outputStream().buffered().use { output ->
31:                 val rows = LegacyImageEncoder.Rows { y, row -> image.getPixels(row, 0, image.width, 0, y, image.width, 1) }
32:                 LegacyImageEncoder.dib(image.width, image.height, rows, output, budget)
33:             }
34:             if (!temporary.renameTo(file)) throw IOException(ui(R.string.save20_destination_error))
35:         } catch (error: LegacyImageEncoder.Failure) {
36:             if (error.reason == 1) throw IOException(ui(R.string.formats22_dib_size_limit), error)
37:             throw IOException(ui(R.string.save20_encoding_budget), error)
38:         } finally { temporary.delete() }
39:     }
40: }

15:         val temporary = File.createTempFile("dib-input-", ".bmp", file.absoluteFile.parentFile)
16:         try {
17:             try {
18:                 temporary.outputStream().buffered().use { PackedDib.toBmp(file, it) }
19:                 LegacyColourMetadata.check(temporary)
20:             } catch (error: LegacyColourMetadata.UnsupportedColour) {
21:                 throw IOException(ui(R.string.save20_unsupported_image_colour), error)
22:             }
23:             return block(temporary)
24:         } finally { temporary.delete() }
25:     }
26: 
27:     fun encode(image: Bitmap, file: File, budget: Long) {
