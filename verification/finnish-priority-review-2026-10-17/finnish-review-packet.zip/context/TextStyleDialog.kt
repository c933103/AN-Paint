93:         listOf(bold,italic,underline,strike,box).forEach { it.setOnCheckedChangeListener { _,_ -> update() } }
94:         val selected=object : AdapterView.OnItemSelectedListener {
95:             override fun onItemSelected(parent: AdapterView<*>?,view: View?,position: Int,id: Long) { update() }
96:             override fun onNothingSelected(parent: AdapterView<*>?)=Unit
97:         };font.onItemSelectedListener=selected;align.onItemSelectedListener=selected;direction.onItemSelectedListener=selected;glyphs.onItemSelectedListener=selected
98:         val dialog=EditorDialogBuilder(activity).setTitle(ui(R.string.ui_place_text)).setView(ScrollView(activity).apply { addView(body) })
99:             .setNegativeButton(ui(R.string.ui_cancel),null).setPositiveButton(ui(R.string.ui_add_text),null).create()
100:         dialog.setOnShowListener { dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
101:             val pixels=uiNumber(size.text.toString())?.toFloat();val percent=uiNumber(spacing.text.toString())?.toFloat()
102:             when {
103:                 pixels==null || pixels !in 1f..1024f -> size.error=ui(R.string.ui_use_1_1024_pixels)
104:                 percent==null || percent !in 50f..300f -> spacing.error=ui(R.string.ui_use_50_300)
105:                 else -> {
106:                     val settings=TextSettings(input.text.toString(),pixels,font.selectedItemPosition,bold.isChecked,italic.isChecked,underline.isChecked,strike.isChecked,box.isChecked,align.selectedItemPosition,percent/100,TextDirection.values()[direction.selectedItemPosition],GlyphOrientation.values()[glyphs.selectedItemPosition])
107:                     if (commit(settings,catalog.faceForText(settings.font,settings.text,style()))) dialog.dismiss()

43:         val sizes=LinearLayout(activity)
44:         listOf(ui(R.string.ui_size_pixels) to size,ui(R.string.ui_line_spacing) to spacing).forEach { (name,field) ->
45:             val col=LinearLayout(activity).apply { orientation=LinearLayout.VERTICAL;addView(label(name));addView(field) }
46:             sizes.addView(col,LinearLayout.LayoutParams(0,-2,1f))
47:         };body.addView(sizes)
48:         fun check(text: String,tagName: String,value: Boolean)=CheckBox(activity).apply { this.text=text;tag=tagName;isChecked=value }
49:         val bold=check(ui(R.string.ui_bold),"text_bold",initial.bold);val italic=check(ui(R.string.ui_italic),"text_italic",initial.italic)
50:         val underline=check(ui(R.string.ui_underline),"text_underline",initial.underline);val strike=check(ui(R.string.ui_strikethrough),"text_strike",initial.strike)
51:         listOf(bold,italic,underline,strike).chunked(2).forEach { items ->
52:             val row=LinearLayout(activity);items.forEach { row.addView(it,LinearLayout.LayoutParams(0,dp(48),1f)) };body.addView(row)
53:         }
54:         val align=Spinner(activity).apply { tag="text_alignment";contentDescription=ui(R.string.ui_text_alignment);adapter=ArrayAdapter(activity,android.R.layout.simple_spinner_dropdown_item,arrayOf(ui(R.string.ui_left_aligned),ui(R.string.ui_centred),ui(R.string.ui_right_aligned)));setSelection(initial.alignment) }
55:         body.addView(align,LinearLayout.LayoutParams(-1,dp(48)))
56:         val direction=Spinner(activity).apply {tag="text_direction";contentDescription=ui(R.string.ui_text_direction23)
57:             adapter=ArrayAdapter(activity,android.R.layout.simple_spinner_dropdown_item,arrayOf(ui(R.string.ui_horizontal23),ui(R.string.ui_vertical_rl23),ui(R.string.ui_vertical_lr23)));setSelection(initial.direction.ordinal)}

58:         body.addView(label(ui(R.string.ui_text_direction23)));body.addView(direction,LinearLayout.LayoutParams(-1,dp(48)))
59:         val glyphs=Spinner(activity).apply {tag="text_glyph_orientation";contentDescription=ui(R.string.ui_vertical_letters23)
60:             adapter=ArrayAdapter(activity,android.R.layout.simple_spinner_dropdown_item,arrayOf(ui(R.string.ui_vertical_mixed23),ui(R.string.ui_vertical_sideways23),ui(R.string.ui_vertical_upright23)));setSelection(initial.glyphOrientation.ordinal)}
61:         body.addView(label(ui(R.string.ui_vertical_letters23)));body.addView(glyphs,LinearLayout.LayoutParams(-1,dp(48)))
62:         body.addView(label(ui(R.string.ui_vertical_hint23)))

75:             preview.underline=underline.isChecked;preview.strike=strike.isChecked;preview.opaque=box.isChecked
76:             preview.direction=TextDirection.values()[direction.selectedItemPosition]
77:             preview.orientation=GlyphOrientation.values()[glyphs.selectedItemPosition]
78:             preview.spacing=((uiNumber(spacing.text.toString())?.toFloat() ?: 100f)/100).coerceIn(.5f,3f)
79:             preview.align=arrayOf(Paint.Align.LEFT,Paint.Align.CENTER,Paint.Align.RIGHT)[align.selectedItemPosition]
80:             glyphs.visibility=if(preview.direction==TextDirection.HORIZONTAL) View.GONE else View.VISIBLE
81:             val names=if(preview.direction==TextDirection.HORIZONTAL) arrayOf(ui(R.string.ui_left_aligned),ui(R.string.ui_centred),ui(R.string.ui_right_aligned))
82:                 else arrayOf(ui(R.string.ui_top23),ui(R.string.ui_centred),ui(R.string.ui_bottom23))
83:             val old=align.selectedItemPosition
84:             if(align.getItemAtPosition(0)!=names[0]) {align.adapter=ArrayAdapter(activity,android.R.layout.simple_spinner_dropdown_item,names);align.setSelection(old);VerticalUi.spinner(align)}
85:             preview.invalidate()
86:         }
87:         val watcher=object : TextWatcher {
88:             override fun beforeTextChanged(s: CharSequence?,start: Int,count: Int,after: Int)=Unit
89:             override fun onTextChanged(s: CharSequence?,start: Int,before: Int,count: Int) { update() }

90:             override fun afterTextChanged(s: Editable?)=Unit

33:         fun label(text: String)=TextView(activity).apply { this.text=text;textSize=13f }
34:         val body=LinearLayout(activity).apply { orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(6),dp(16),dp(10)) }
35:         val input=EditText(activity).apply { tag="text_content";hint=ui(R.string.ui_type_text);setText(initial.text);inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE;filters=arrayOf(InputFilter.LengthFilter(8192));minLines=2 }
36:         body.addView(input)
37:         val catalog=FontCatalog(activity)
38:         val font=Spinner(activity).apply { tag="text_font";contentDescription=ui(R.string.ui_font_family);adapter=catalog.adapter();setSelection(initial.font.coerceIn(catalog.fonts.indices)) }
39:         body.addView(label(ui(R.string.ui_font)));body.addView(font,LinearLayout.LayoutParams(-1,dp(48)))
40:         fun number(value: String,tagName: String)=EditText(activity).apply { tag=tagName;LocaleNumberInput.configure(this, decimal = true);setText(value);setSelectAllOnFocus(true);isSingleLine=true }
41:         val size=number(initial.size.toInt().toString(),"text_size")
42:         val spacing=number((initial.spacing*100).toInt().toString(),"text_spacing")

32:         fun dp(n: Int)=(n*activity.resources.displayMetrics.density+.5f).toInt()

92:         listOf(input,size,spacing).forEach { it.addTextChangedListener(watcher) }

63:         val box=check(ui(R.string.ui_fill_text_box_with_bg_colour),"text_box",initial.box);body.addView(box)
64:         body.addView(label(ui(R.string.ui_preview)))
65:         val preview=TextPreview(activity).apply {tag="text_preview"}
66:         body.addView(preview,LinearLayout.LayoutParams(-1,dp(180)))
67:         val credit=Button(activity).apply { text=ui(R.string.ui_font_licences);tag="font_licences";isAllCaps=false;setOnClickListener { LegalInfo.showAsset(activity,ui(R.string.ui_font_licences),"legal/FONT_NOTICES.txt") } }
68:         body.addView(credit,LinearLayout.LayoutParams(-1,dp(48)))
69:         fun style()=(if (bold.isChecked) Typeface.BOLD else 0) or (if (italic.isChecked) Typeface.ITALIC else 0)
70:         fun update() {
71:             val face=catalog.faceForText(font.selectedItemPosition,input.text.toString(),style());input.typeface=face;preview.face=face
72:             preview.value=input.text.toString().ifBlank { ui(R.string.ui_aa_bb_0123) }

29: class TextStyleDialog(private val activity: Activity,private val initial: TextSettings,private val foreground: Int,private val background: Int,
30:     private val commit: (TextSettings,Typeface) -> Boolean) {
31:     fun show(): AlertDialog {

108:                 }
109:             }
110:         } }
111:         update();dialog.show();return dialog

112:     }
