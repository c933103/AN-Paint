18: 
19: /** Estimates are doubles only for byte display/comparison; exact pixel counts use Long. */
20: fun memoryLabel(bytes: Double): String {
21:     val units = arrayOf("B", "KiB", "MiB", "GiB", "TiB", "PiB", "EiB")
22:     var amount = bytes.coerceAtLeast(0.0); var unit = 0
23:     while (amount >= 1024 && unit < units.lastIndex) { amount /= 1024; unit++ }
24:     return ui(R.string.ui_1f_s, amount, units[unit])
25: }
26: 
27: data class ImportPlan(val target: ImageDimensions, val sample: Int, val decodedPixels: Long) {
28:     fun estimatedBytes(residentPixels: Long) = max(target.pixels * 12.0, decodedPixels * 4.0 + target.pixels * 8.0) + residentPixels * 4.0
29:     companion object {
30:         fun create(source: ImageDimensions, target: ImageDimensions): ImportPlan {
31:             require(target.width <= source.width && target.height <= source.height) { ui(R.string.ui_choose_dimensions_no_larger_than_the_original) }
32:             fun ceilDivide(n: Int, d: Int) = (n.toLong() + d - 1) / d

156:         if(ico) return IcoCodec.decode(file,plan.target,decoderBudget)
157:         var decoded: Bitmap? = null
158:         var output: Bitmap? = null
159:         try {
160:             val colour = checkNotNull(platformColour)
161:             val raw = withPlatformFile { platformFile -> colour.withDecodeFile(platformFile) { BitmapFactory.decodeFile(it.path,colour.options(plan.sample)) } }
162:                 ?: throw IOException(ui(R.string.ui_android_could_not_decode_this_image))
163:             decoded = raw
164:             val input = colour.convert(raw)
165:             if (input !== raw) { raw.recycle(); decoded = input }
166:             input.density = Bitmap.DENSITY_NONE
167:             val rotation = orientation?.rotationDegrees ?: 0; val flip = orientation?.isFlipped == true
168:             if (rotation == 0 && !flip && input.width == plan.target.width && input.height == plan.target.height && input.isMutable && input.config == Bitmap.Config.ARGB_8888) {
169:                 decoded = null; return input
170:             }

33:             var sample = 1
34:             // Keep at least the requested detail. Decode a bounded power-of-two sample,
35:             // then scale once to the exact requested dimensions while applying EXIF.
36:             while (sample < (1 shl 30) && sample * 2 <= max(source.width, source.height) &&
37:                 ceilDivide(source.width, sample * 2) >= target.width && ceilDivide(source.height, sample * 2) >= target.height) sample *= 2
38:             return ImportPlan(target, sample, ceilDivide(source.width,sample) * ceilDivide(source.height,sample))
39:         }

9: import java.io.IOException
10: import kotlin.math.*
11: 
12: data class ImageDimensions(val width: Int, val height: Int) {
13:     init { require(width > 0 && height > 0) { ui(R.string.ui_enter_positive_image_dimensions) } }
14:     val pixels: Long get() = width.toLong() * height
15:     fun describe() = ui(R.string.ui_d_d_px_d_pixels_2f_mp, width, height, pixels, pixels / 1_000_000.0)
16:     fun scaled(scale: Double) = ImageDimensions(max(1, floor(width * scale).toInt()), max(1, floor(height * scale).toInt()))
17: }

7: import androidx.exifinterface.media.ExifInterface
8: import java.io.File

42: 
43: fun ImageMemoryPolicy.accepts(plan: ImportPlan, residentPixels: Long): Boolean =
44:     plan.target.pixels <= maxPixels(residentPixels) && plan.decodedPixels <= ImageMemoryPolicy.MAX_BITMAP_PIXELS && plan.estimatedBytes(residentPixels) <= workingBytes.toDouble()
45: 
46: fun ImageMemoryPolicy.checkImport(plan: ImportPlan, residentPixels: Long) {
47:     check(plan.target.width, plan.target.height, residentPixels)
48:     if (!accepts(plan, residentPixels)) throw ImageSizeException(ui(R.string.ui_the_decoder_and_editing_buffers_need_about_the, memoryLabel(plan.estimatedBytes(residentPixels)), memoryLabel(workingBytes.toDouble())))
49: }
50: 
51: fun ImageMemoryPolicy.suggestResize(source: ImageDimensions, residentPixels: Long, maxScale: Double = 1.0): ImageDimensions? {
52:     if (!accepts(ImportPlan.create(source, ImageDimensions(1,1)), residentPixels)) return null
53:     var low = 0.0; var high = maxScale.coerceIn(0.0,1.0)
54:     // Leave 10% of the computed working budget free for changes while the dialog is open.
55:     repeat(48) {
56:         val scale = (low + high) / 2

82:         policy.accepts(plan,residentPixels) &&
83:             plan.decodedPixels <= (Int.MAX_VALUE.toLong()-8) / minOf(decodedBytesPerPixel,8) &&
84:             estimatedBytes(plan,residentPixels) <= policy.workingBytes.toDouble()
85: 
86:     fun checkImport(policy: ImageMemoryPolicy, plan: ImportPlan, residentPixels: Long) {
87:         policy.check(plan.target.width,plan.target.height,residentPixels)
88:         if(!accepts(policy,plan,residentPixels)) throw ImageSizeException(ui(R.string.ui_the_decoder_and_editing_buffers_need_about_the,
89:             memoryLabel(estimatedBytes(plan,residentPixels)),memoryLabel(policy.workingBytes.toDouble())))
90:     }
91: 
92:     fun suggestResize(source: ImageDimensions, policy: ImageMemoryPolicy, residentPixels: Long, maxScale: Double = 1.0): ImageDimensions? {
93:         if(!accepts(policy,ImportPlan.create(source,ImageDimensions(1,1)),residentPixels)) return null
94:         var low=0.0;var high=maxScale.coerceIn(0.0,1.0)
95:         repeat(48) {
96:             val scale=(low+high)/2;val plan=ImportPlan.create(source,source.scaled(scale))

143:     fun estimatedBytes(plan: ImportPlan,residentPixels: Long)=memoryRequirements.estimatedBytes(plan,residentPixels)
144:     fun accepts(policy: ImageMemoryPolicy,plan: ImportPlan,residentPixels: Long)=memoryRequirements.accepts(policy,plan,residentPixels)
145:     fun checkImport(policy: ImageMemoryPolicy,plan: ImportPlan,residentPixels: Long)=memoryRequirements.checkImport(policy,plan,residentPixels)
146:     fun suggestResize(policy: ImageMemoryPolicy,residentPixels: Long,maxScale: Double=1.0)=memoryRequirements.suggestResize(dimensions,policy,residentPixels,maxScale)
147: 
148:     fun decode(plan: ImportPlan,workingBytes: Long=ImageMemoryPolicy.forRuntime().workingBytes,residentPixels: Long=0): Bitmap {
149:         if (estimatedBytes(plan,residentPixels)>workingBytes) throw ImageSizeException(ui(R.string.ui_the_decoder_and_editing_buffers_need_about_the,
150:             memoryLabel(estimatedBytes(plan,residentPixels)),memoryLabel(workingBytes.toDouble())))
151:         val decoderBudget=memoryRequirements.decoderBudget(workingBytes,plan.target,residentPixels)
152:         if(jxl) return JxlCodec.decode(file,plan.target,decoderBudget)
153:         if(heif) return HeifCodec.decode(file,plan.target,decoderBudget)
154:         if(tiff) return TiffCodec.decode(file,plan.target,decoderBudget,pageIndex=pageIndex)
155:         if(pdf) return PdfCodec.decode(file,plan.target,decoderBudget,pageIndex=pageIndex)

127:         if(jxl) {val size=JxlCodec.dimensions(file);bounds.outWidth=size.width;bounds.outHeight=size.height}
128:         else if(heif) {val size=HeifCodec.dimensions(file);bounds.outWidth=size.width;bounds.outHeight=size.height}
129:         else if(tiff) {val size=TiffCodec.dimensions(file,pageIndex);bounds.outWidth=size.width;bounds.outHeight=size.height}
130:         else if(pdf) {val size=PdfCodec.dimensions(file,pageIndex);bounds.outWidth=size.width;bounds.outHeight=size.height}
131:         else if(ico) {val size=IcoCodec.dimensions(file);bounds.outWidth=size.width;bounds.outHeight=size.height}
132:         else withPlatformFile {BitmapFactory.decodeFile(it.path, bounds)}
133:         if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IOException(ui(R.string.ui_this_file_is_not_a_supported_image_use))
134:         orientation = if(jxl || heif || tiff || dib || pdf || ico) null else try { ExifInterface(file.path) } catch (_: IOException) { null }
135:         dimensions = if (orientation?.rotationDegrees in listOf(90,270)) ImageDimensions(bounds.outHeight,bounds.outWidth) else ImageDimensions(bounds.outWidth,bounds.outHeight)
136:         // Inspect the native source/tile footprint once, not on every slider tick.
137:         // Ordinary formats never initialize a JNI library here.
138:         memoryRequirements=ImportMemoryRequirements(
139:             when {heif -> HeifCodec.decodeWorkingBytes(file,ImageDimensions(1,1));tiff -> TiffCodec.decodeWorkingBytes(file,ImageDimensions(1,1),pageIndex);
140:                 pdf -> PdfCodec.decodeWorkingBytes(file,ImageDimensions(1,1),pageIndex);ico -> IcoCodec.decodeWorkingBytes(file,ImageDimensions(1,1));else -> null},
141:             platformColour?.decodedWorkingBytesPerPixel ?: 4,platformColour?.metadataWorkingBytes ?: 0)
