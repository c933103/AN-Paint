30:         val suggested = memoryRequirements.suggestResize(source,policy(),residentPixels,maxScale) ?: ImageDimensions(1,1)
31:         val sizing = DimensionControls(activity,source,suggested,"resize",true)
32:         body.addView(label(ui(R.string.ui_resize_the_copy), "resize_heading")); body.addView(sizing)
33:         val estimate = label("", "resize_estimate"); body.addView(estimate)
34:         body.addView(label(ui(if(memoryRequirements.hasNativeWork) R.string.ui_codec_resize_memory_floor else R.string.ui_sampled_resize_memory_explanation), "resize_explanation"))
35:         var accepted = false
36:         val dialog = EditorDialogBuilder(activity).setTitle(ui(R.string.ui_resize_large_image))
37:             .setView(ScrollView(activity).apply { addView(body) })
38:             .setNegativeButton(ui(R.string.ui_cancel), null).setPositiveButton(ui(R.string.ui_resize_and_load), null).create()
39:         fun target(): ImageDimensions? = sizing.dimensions?.takeIf { it.width <= source.width && it.height <= source.height }
40:         fun refresh(): Boolean {
41:             val current = policy()
42:             budget.text = ui(R.string.ui_current_safe_editing_budget_s_up_to_2f, memoryLabel(current.workingBytes.toDouble()), current.maxPixels(residentPixels) / 1_000_000.0)
43:             val size = target()
44:             val plan = size?.let { ImportPlan.create(source,it) }

28:         val budget = label("", "resize_budget"); body.addView(budget)
29:         val maxScale = previousAttempt?.let { it.width.toDouble() / source.width * .75 } ?: 1.0

45:             val fits = plan != null && memoryRequirements.accepts(current,plan,residentPixels)
46:             val cannotResize=memoryRequirements.hasNativeWork && !memoryRequirements.accepts(current,ImportPlan.create(source,ImageDimensions(1,1)),residentPixels)

47:             estimate.text = if (size == null) ui(R.string.ui_enter_positive_dimensions_no_larger_than_the_original)
48:                 else ui(R.string.ui_copy_decoded_image_at_this_size_estimated_loading, size.describe(), memoryLabel(size.pixels * 4.0), memoryLabel(memoryRequirements.estimatedBytes(plan!!,residentPixels))) +
49:                     if (fits) ui(R.string.ui_fits_the_current_budget) else if(cannotResize) "\n"+ui(R.string.ui_no_resize_fits_decoder_memory) else ui(R.string.ui_too_large_for_the_current_budget_reduce_the)
50:             dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.isEnabled = fits
51:             return fits
52:         }
53:         sizing.changed = { refresh() }
54:         dialog.setOnDismissListener { if (!accepted) cancel() }
55:         dialog.setOnShowListener {

56:             refresh()
57:             dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {

26:         body.addView(label(ui(R.string.ui_original_decoded_image_rgba_4_bytes_pixel_estimated, source.describe(), memoryLabel(source.pixels * 4.0), memoryLabel(memoryRequirements.estimatedBytes(ImportPlan.create(source,source),residentPixels))), "resize_original"))
27:         body.addView(label(ui(R.string.ui_the_full_image_and_working_buffers_exceed_the), "resize_reason"))

21:     fun show(): AlertDialog {
22:         val density = activity.resources.displayMetrics.density
23:         fun dp(n: Int) = (n * density + .5f).toInt()
24:         fun label(value: String, name: String) = TextView(activity).apply { text = value; tag = name; textSize = 14f; setPadding(0,dp(5),0,dp(5)) }
25:         val body = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20),dp(8),dp(20),dp(12)) }
