56:         if (required > budget) throw IOException(ui(R.string.save20_encoding_budget))
57:     }
58:     private fun replace(destination: File, prefix: String, write: (File) -> Unit) {
59:         val temporary = File.createTempFile(prefix, ".tmp", destination.absoluteFile.parentFile)
60:         try {
61:             write(temporary)
62:             if (!temporary.renameTo(destination)) throw IOException(ui(R.string.save20_destination_error))
63:         } finally { temporary.delete() }
64:     }
65: }

50:                 }
51:             }
52:         } finally { if (scaled !== image) scaled.recycle() }
53:     }
54: 
55:     private fun requireBudget(required: Long, budget: Long) {

27:         requireBudget(image.allocationByteCount.toLong() + image.width.toLong()*8 + 1024*1024, budget)
28:         replace(file, "base64-export-") { temporary ->
29:             temporary.outputStream().buffered().use { output ->
30:                 output.write("data:image/png;base64,".toByteArray(Charsets.US_ASCII))
31:                 val encoded = TextImageData.Base64Output(output)
32:                 if (!image.compress(Bitmap.CompressFormat.PNG, 100, encoded))
33:                     throw IOException(ui(R.string.ui_the_encoder_did_not_finish))
34:                 encoded.finish()
35:                 output.write('\n'.code)
36:             }
37:         }
38:     }
39: 
40:     fun encodeAscii(image: Bitmap, file: File, columns: Int, invert: Boolean, budget: Long) {
41:         val rows = TextImageData.asciiRows(image.width, image.height, columns)
