13:         try {
14:             temporary.outputStream().buffered().use { output ->
15:                 val rows = LegacyImageEncoder.Rows { y, row -> image.getPixels(row, 0, image.width, 0, y, image.width, 1) }
16:                 if (gif) LegacyImageEncoder.gif(image.width, image.height, rows, output, budget, dither)
17:                 else LegacyImageEncoder.bmp(image.width, image.height, rows, output, budget)
18:             }
19:             if (!temporary.renameTo(file)) throw IOException(ui(R.string.save20_destination_error))
20:         } catch (error: LegacyImageEncoder.Failure) {
21:             throw IOException(ui(when(error.reason) {
22:                 1 -> R.string.save20_bmp_size_limit
23:                 2 -> R.string.save20_gif_size_limit
24:                 else -> R.string.save20_encoding_budget
25:             }),error)
26:         } finally { temporary.delete() }
27:     }

28: }
