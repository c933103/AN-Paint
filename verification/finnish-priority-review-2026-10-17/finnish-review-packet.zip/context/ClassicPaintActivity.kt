232:             try {
233:                 val session=CreditEditSession.open(filesDir,token)
234:                 val field=session.draft?.takeIf {value -> document.imageCredits.any {it.source==value.source}}
235:                 if(field!=null) showImageCredits(field,session)
236:                 else unrestoredCreditSessionToken=null
237:             } catch(_: Exception) {
238:                 creditSessionRestoreError=EditorDialogBuilder(this).setMessage(ui(R.string.gallery_credit_could_not_save))
239:                     .setPositiveButton(ui(R.string.ui_done),null).show()
240:             }
241:         }
242:         deliverPendingInputs()
243:     }
244: 
245:     private fun deferStartupInput() = !startupReady || !initialCanvasSized ||
246:         pendingStartupEvents.isNotEmpty() || deliveringStartupEvents

893:                 galleryCreditSessionToken=session.token
894:                 startActivityForResult(Intent(this,MediaGalleryActivity::class.java)
895:                     .putExtra("gallery_provider",IllustrationSource.values()[index-1].name)
896:                     .putExtra("gallery_canvas_width",document.bitmap.width)
897:                     .putExtra("gallery_resident_pixels",document.residentPixels)
898:                     .putExtra(CreditEditSession.EXTRA_SESSION,session.token),GALLERY_IMAGE)
899:             } catch(_: Exception) {message(ui(R.string.gallery_credit_could_not_save))}
900:         }.setNegativeButton(ui(R.string.ui_cancel),null).show()
901:     }
902: 
903:     private fun selectAfterPaste() {
904:         // Switching to selection before pasting avoids committing a new floating image.
905:         updateStatus(); paintCanvas.invalidate()
906:     }
907: 

1179:         }
1180:         if(requestCode==GALLERY_IMAGE) {
1181:             val token=data?.getStringExtra(CreditEditSession.EXTRA_SESSION)
1182:             val expectedSession=galleryCreditSessionToken
1183:             if((expectedSession!=null && token!=expectedSession) ||
1184:                 (expectedSession==null && data?.hasExtra(LegacyImageCreditsActivity.EXTRA_SELECTED_TOKEN)==true)) {
1185:                 message(ui(R.string.gallery_credit_could_not_save));return
1186:             }
1187:             val returnedSession=try {token?.let {CreditEditSession.open(filesDir,it,restoreDraft=false)}} catch(_: Exception) {
1188:                 message(ui(R.string.gallery_credit_could_not_save));return
1189:             }
1190:             // A late accepted result must not rewrite a fresh/replaced editor. A standalone
1191:             // Gallery may still return an unedited image insertion; it carries no credit edits.
1192:             if(returnedSession!=null && expectedSession==null &&
1193:                 (returnedSession.accepted || returnedSession.edits.isNotEmpty() || data?.hasExtra("gallery_file")!=true)) {

1194:                 message(ui(R.string.gallery_credit_could_not_save));return
1195:             }
1196:             val encoded=data?.getStringExtra("document_image_credits")

1197:             if(returnedSession==null && encoded!=null) {
1198:                 message(ui(R.string.gallery_credit_could_not_save));return
1199:             }
1200:             if(returnedSession!=null) {
1201:                 try {
1202:                     val edits=returnedSession.edits

1203:                     document.editImageCredits(edits) // Validate all sources before mutating any of them.
1204:                     if(edits.isNotEmpty())unrestoredCreditSessionToken=null
1205:                     if(token!=null && returnedSession!=null) {
1206:                         returnedSession.adoptionReceipt?.let {adoptedCreditSessions[token]=it}

1462:                 document.editImageCredits(edits)
1463:                 session.adoptionReceipt?.let {adoptedCreditSessions[session.token]=it}
1464:             },onDismiss={
1465:                 try {
1466:                     session.saveDraft(null)
1467:                     if(!session.accepted) session.discard()
1468:                 } catch(_: Exception) {message(ui(R.string.gallery_credit_could_not_save))}
1469:                 imageCreditSession=null
1470:             })
1471:             if(editor!=null) {
1472:                 imageCreditSession=session;imageCreditEditor=editor
1473:                 // Establish ownership only after the editor exists. Either successful restore
1474:                 // or a fresh editor supersedes retry state; failed construction keeps it.
1475:                 // No old session/archive file is deleted by changing this association.
1476:                 unrestoredCreditSessionToken=null

1477:             }
1478:         } catch(_: Exception) {message(ui(R.string.gallery_credit_could_not_save))}
1479:     }
1480:     private fun preserveCreditEditor() {
1481:         try {
1482:             val field=imageCreditEditor?.takeIf {it.dialog.isShowing}?.snapshot?.invoke() ?: return
1483:             imageCreditSession?.saveDraft(field)
1484:         } catch(_: Exception) {
1485:             LocaleTypography.showMessage(this,ui(R.string.gallery_credit_could_not_save),Toast.LENGTH_LONG,
1486:                 imageCreditEditor?.dialog?.window?.decorView)

1487:         }
1488:     }
1489:     private fun creditAdoptionReceipts(metadata: JSONObject,history: RasterHistory.Snapshot): Map<String,CreditEditSession.AdoptionReceipt> {
1490:         return adoptedCreditSessions.filter {(token,receipt) ->runCatching {
1491:             val session=CreditEditSession.open(filesDir,token,restoreDraft=false)
1492:             session.revision==receipt.revision && session.acceptedSnapshot==receipt.snapshotToken && session.representedBy(metadata,history)
1493:         }.getOrDefault(false)}

1207:                         if(!returnedSession.accepted && !returnedSession.hasDraft) returnedSession.discard()
1208:                     }
1209:                 } catch(_: IllegalArgumentException) {message(ui(R.string.gallery_credit_too_large));return}
1210:                   catch(_: org.json.JSONException) {message(ui(R.string.ui_invalid_autosave_metadata));return}
1211:             }
1212:             galleryCreditSessionToken=null
1213:             if(data?.hasExtra(LegacyImageCreditsActivity.EXTRA_SELECTED_TOKEN)==true) {
1214:                 attachLegacyImageCredit(data.getStringExtra(LegacyImageCreditsActivity.EXTRA_SELECTED_TOKEN))
1215:                 if(data.hasExtra("gallery_file")!=true)return
1216:             }
1217:             if(data?.hasExtra("gallery_file")!=true && (returnedSession!=null || encoded!=null)) return

1437:             val added=try {
1438:                 document.attachImageCredit(credit) {projected ->
1439:                     AutosaveStore.metadataBytes(draftMetadata().put("image_credits",projected))
1440:                     HistoryArchive.validate(document.historySnapshot())
1441:                 }
1442:             } catch(_: IllegalArgumentException) {
1443:                 message(ui(R.string.gallery_credit_too_large));return@editAction
1444:             }
1445:             LocaleTypography.showMessage(this,ui(if(added) R.string.legacy_credits_added
1446:                 else R.string.legacy_credits_existing),Toast.LENGTH_SHORT,paintCanvas)
1447:         }
1448:     }
1449: 
1450:     private fun creditEditContext()=CreditEditContext(draftMetadata(),HistoryArchive.manifest(document.historySnapshot()))
1451:     private fun showImageCredits(draft: GalleryCredits.EditorDraft?=null) {showImageCredits(draft,null)}

825:     private fun command(title: String,icon: Int,action: () -> Unit)=PanelCommand(title,action,icon)
826:     private fun menuActions(name: String): List<PanelCommand> = when(name) {
827:         "File"->(listOf<Pair<String,()->Unit>>(
828:             ui(R.string.ui_new) to {confirmReplacement {dimensionsDialog(false,true)}},
829:             ui(R.string.ui_load_image) to {confirmReplacement {launchOpen(false)}},
830:             ui(R.string.ui_save) to {requestSave(false)},
831:             ui(R.string.save20_title) to {showSaveOptions(savedTarget?.options?.format ?: ImageFormat.PNG)},
832:             ui(R.string.ui_export_as23) to {showSaveOptions(exportOptions.format,export=true)},
833:             ui(R.string.ui_save_and_share) to {showSaveOptions(exportOptions.format,true,export=true)},
834:             ui(R.string.ui_image_assembly) to {openAssembly()},
835:             ui(R.string.ui_how_to_use) to {showHelp()},
836:             ui(R.string.ui_about_credits23) to {showAboutOptions()}
837:         ) + if(autosaveBlocked || autosave.recoveryCopies().isNotEmpty()) listOf(ui(R.string.ui_export_recovery_copy) to {requestRecoveryExport()}) else emptyList()).map {PanelCommand(it.first,it.second)}
838:         "Edit"->listOf(
839:             command(ui(R.string.ui_select_all),R.drawable.breeze_select_all) {selectAll();selectTab("Edit")},

1611:                 File(filesDir,"classic-recovery.png").delete()
1612:             } catch (e: Exception) { error=e } catch (e: OutOfMemoryError) { error=e }
1613:             val failure=error
1614:             runOnUiThread { if (!isDestroyed) {
1615:                 autosaving=false
1616:                 if (failure==null) { creditSessions.forEach {(token,revision) ->if(adoptedCreditSessions[token]==revision) adoptedCreditSessions.remove(token)};draftStatus=ui(R.string.ui_draft_saved);lastAutosaveError=null }
1617:                 else { failedDraftGeneration=generation;lastAutosaveError=failure.message;draftStatus=ui(R.string.ui_autosave_failed_use_save) }
1618:                 endIo()
1619:             } }
1620:         }
1621:     }
1622:     override fun onSaveInstanceState(outState: Bundle) {
1623:         if(pendingStartupEvents.isNotEmpty()) outState.putParcelableArrayList("startup_events",ArrayList(pendingStartupEvents))
1624:         preserveCreditEditor()
1625:         (imageCreditSession?.token ?: unrestoredCreditSessionToken)?.let {outState.putString("main_credit_session",it)}

844:             command(ui(R.string.ui_resize_image),R.drawable.classic_resize) {dimensionsDialog(true,false)},
845:             command(ui(R.string.ui_flip_horizontal),R.drawable.classic_flip_h) {paintCanvas.applyPending();document.transform(Matrix().apply {setScale(-1f,1f)})},
846:             command(ui(R.string.ui_flip_vertical),R.drawable.classic_flip_v) {paintCanvas.applyPending();document.transform(Matrix().apply {setScale(1f,-1f)})},
847:             command(ui(R.string.ui_rotate_90_clockwise),R.drawable.classic_rotate90) {paintCanvas.applyPending();document.transform(Matrix().apply {setRotate(90f)});paintCanvas.fit()},
848:             command(ui(R.string.ui_rotate_180),R.drawable.classic_rotate180) {paintCanvas.applyPending();document.transform(Matrix().apply {setRotate(180f)})},
849:             command(ui(R.string.ui_invert_colours),R.drawable.classic_invert) {paintCanvas.applyPending();document.invert()},
850:             command(ui(R.string.ui_clear_image),R.drawable.breeze_eraser) {paintCanvas.applyPending();document.clear()}
851:         )
852:         "View"->listOf(
853:             command(PaintTool.ZOOM.label,R.drawable.breeze_zoom_in) {chooseTool(PaintTool.ZOOM)},
854:             command(ui(R.string.ui_pixel_grid33),R.drawable.classic_grid) {paintCanvas.grid=!paintCanvas.grid;paintCanvas.invalidate()},
855:             command(ui(R.string.ui_cursor_drawing32),R.drawable.classic_cursor) {
856:                 cursorOptionsExpanded=!cursorOptionsExpanded
857:                 if(cursorOptionsExpanded) {paintCanvas.setCursorDrawing(false);populateCursorOptions()}
858:                 syncPanels()

1394:         val file=recoveryExport ?: return
1395:         beginIo()
1396:         worker.execute {
1397:             try {
1398:                 file.inputStream().use { source -> contentResolver.openOutputStream(uri,"wt")?.use { source.copyTo(it) } ?: throw IOException(ui(R.string.ui_this_location_is_not_writable)) }
1399:                 runOnUiThread { if (!isDestroyed) { endIo();message(ui(R.string.ui_recovery_copy_exported_extract_canvas_png_from_the)) } }
1400:             } catch (e: Exception) { ioFailed(ui(R.string.ui_could_not_export_the_recovery_copy),e) }
1401:         }
1402:     }
1403: 
1404:     private fun displayName(uri: Uri): String {
1405:         try { contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
1406:             val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
1407:             if (index >= 0 && cursor.moveToFirst()) return cursor.getString(index) ?: ui(R.string.ui_menu_image)
1408:         } } catch (_: Exception) { /* Display metadata is optional. */ }

1273:                             selected={source ->
1274:                                 importSelection=null;pendingImportFile=source.file
1275:                                 val plan=ImportPlan.create(source.dimensions,source.dimensions)
1276:                                 if(source.accepts(ImageMemoryPolicy.forDevice(this),plan,document.residentPixels)) decodeImage(source,import,source.dimensions,asEdit,credits,whiteBacking)
1277:                                 else askToResize(source,import,asEdit=asEdit,credits=credits,whiteBacking=whiteBacking)
1278:                             },cancelled={importSelection=null;endIo()},failed={error ->
1279:                                 importSelection=null;ioFailed(ui(R.string.ui_could_not_open_image),error)
1280:                             })
1281:                         importSelection=selection;selection.start(cached,name)
1282:                     }
1283:                 }
1284:             } catch (e: Exception) { ioFailed(ui(R.string.ui_could_not_open_image), e) }
1285:             catch (e: OutOfMemoryError) { ioFailed(ui(R.string.ui_not_enough_memory_to_inspect_this_image), e) }
1286:             finally { temporary?.delete() }
1287:         }

1288:     }
1289: 
1290:     private fun askToResize(source: ImportedImage, import: Boolean, previousAttempt: ImageDimensions? = null, asEdit: Boolean = false,credits: List<ImageCredit> = emptyList(),whiteBacking: Boolean = false) {
1291:         if (isDestroyed || isFinishing) { source.file.delete(); return }
1292:         resizeDialog = ImageResizeDialog(this,source.dimensions,document.residentPixels,

1322:                             // image and its credits in Undo, but do not attribute the new composite
1323:                             // to unrelated gallery sources from the previous canvas.
1324:                             else { paintCanvas.cancelPending(); document.replace(bitmap,asEdit,retainCredits=false);unrestoredCreditSessionToken=null; filename = source.name;savedTarget=null; paintCanvas.fit() }
1325:                             endIo()
1326:                         } catch (error: Exception) {
1327:                             if (document.bitmap !== bitmap && document.selection?.image !== bitmap) bitmap.recycle()
1328:                             ioFailed(ui(R.string.ui_could_not_open_image), error)
1329:                         } catch (error: OutOfMemoryError) {
1330:                             if (document.bitmap !== bitmap && document.selection?.image !== bitmap) bitmap.recycle()
1331:                             ioFailed(ui(R.string.ui_not_enough_memory_to_finish_opening_this_image), error)
1332:                         }
1333:                     } else bitmap.recycle()
1334:                 }
1335:             } catch (_: ImageSizeException) {
1336:                 // Device memory may change while the user considers the proposed size.

1337:                 runOnUiThread { askToResize(source,import,target,asEdit,credits,whiteBacking) }
1338:             } catch (_: OutOfMemoryError) {
1339:                 // A budget is an estimate, not a guarantee. Offer a smaller copy after an allocation failure too.
1340:                 runOnUiThread { askToResize(source,import,target,asEdit,credits,whiteBacking) }
1341:             } catch (e: Exception) { source.file.delete(); ioFailed(ui(R.string.ui_could_not_open_image), e) }
1342:         }
1343:     }
1344: 
1345:     private fun writeImage(uri: Uri) {
1346:         paintCanvas.applyPending()
1347:         beginIo()
1348:         val snapshot=document.bitmap
1349:         val options=exportOptions;val exporting=isExporting;val sharing=shareAfterSave;shareAfterSave=false

1360:                 runOnUiThread {if(!isDestroyed) {
1361:                     if(!exporting) {filename=name;savedTarget=SavedTarget(uri,name,options);document.markSaved();scheduleAutosave()};endIo();LocaleTypography.showMessage(this,ui(R.string.ui_saved, name),Toast.LENGTH_SHORT)
1362:                     if(sharing) shareSavedImage(file,options.format)
1363:                     val action=afterSave;afterSave=null
1364:                     if(exporting && action!=null) message(ui(R.string.ui_export_did_not_save23)) else action?.invoke()
1365:                 }}
1366:             } catch(error: Exception) {ioFailed(ui(R.string.ui_could_not_save_image),error)}
1367:               catch(error: OutOfMemoryError) {ioFailed(ui(R.string.ui_not_enough_memory_to_save_in_this_format),error)}
1368:             finally {encoded?.delete()}
1369:         }
1370:     }
1371:     private fun shareSavedImage(file: File,format: ImageFormat) {
1372:         try {
1373:             val uri=androidx.core.content.FileProvider.getUriForFile(this,"$packageName.fileprovider",file)
1374:             val send=Intent(Intent.ACTION_SEND).apply {

1064: 
1065:     private fun confirmReplacement(action: () -> Unit) {
1066:         paintCanvas.applyPending()
1067:         if (!document.dirty) { action(); return }
1068:         EditorDialogBuilder(this).setTitle(ui(R.string.ui_save_your_changes)).setMessage(ui(R.string.ui_your_current_image_has_unsaved_changes))
1069:             .setPositiveButton(ui(R.string.ui_save_a5d0d9)) { _, _ -> afterSave = action; requestSave(false) }
1070:             .setNeutralButton(ui(R.string.ui_discard_changes23)) { _, _ -> action() }.setNegativeButton(ui(R.string.ui_keep_editing23), null).show()
1071:     }
1072: 
1073:     fun launchOpen(import: Boolean) {
1074:         if (busy) return
1075:         launchPicker(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
1076:             addCategory(Intent.CATEGORY_OPENABLE)
1077:             // Some otherwise valid images are labelled as generic binary by providers.
1078:             type = "*/*"

125:     private var autosaveReady = false
126:     private var autosaveBlocked = false
127:     private var recoveryNotice: String? = null
128:     private var recoveryExport: File? = null
129:     private var autosaving = false
130:     private var stopped = false
131:     private var draftStatus = ui(R.string.ui_draft_not_saved_yet)
132:     private val saveDraft = Runnable { saveDraftIfReady() }
133:     private val surface = EditorColours.surface
134:     private val ink = EditorColours.onSurface
135: 
136:     override fun onCreate(savedInstanceState: Bundle?) {
137:         super.onCreate(savedInstanceState)
138:         AppLanguage.refresh(this);filename=ui(R.string.ui_untitled);textSettings=TextSettings()
139:         autosave=AutosaveStore(filesDir)

1610:                 retireCreditSessions(creditSessions,metadata,history)

1358:                 val name=displayName(uri)
1359:                 if(sharing) encoded=null

840:             command(ui(R.string.ui_canvas_bounds),R.drawable.classic_bounds) {trimCanvas()},
841:             command(ui(R.string.ui_delete_selection),R.drawable.classic_delete) {if(!document.deleteSelection()) message(ui(R.string.ui_select_an_area_first))},
842:             command(ui(R.string.ui_canvas_size),R.drawable.classic_canvas_size) {dimensionsDialog(false,false)},
843:             command(ui(R.string.ui_crop_to_selection),R.drawable.classic_crop) {if(document.cropSelection()) paintCanvas.fit() else message(ui(R.string.ui_select_an_area_first))},

1146:             recoveryExport=file
1147:             launchPicker(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
1148:                 addCategory(Intent.CATEGORY_OPENABLE);type="application/zip";putExtra(Intent.EXTRA_TITLE,ui(R.string.ui_an_paint_recovery_zip, file.lastModified()))
1149:             },EXPORT_RECOVERY)
1150:         }
1151:         if (copies.size==1) choose(copies.first()) else if (copies.isNotEmpty()) EditorDialogBuilder(this)
1152:             .setTitle(ui(R.string.ui_export_recovery_copy_144b8a)).setItems(copies.map { java.text.DateFormat.getDateTimeInstance().format(java.util.Date(it.lastModified())) }.toTypedArray()) { _,i -> choose(copies[i]) }
1153:             .setNegativeButton(ui(R.string.ui_cancel),null).show()
1154:     }
1155: 
1156:     private fun openAssembly() {
1157:         paintCanvas.applyPending()
1158:         startActivityForResult(Intent(this,AssemblyActivity::class.java).putExtra("resident_pixels",document.residentPixels),ASSEMBLY_IMAGE)
1159:     }
1160: 

1218:             val file=data?.getStringExtra("gallery_file")?.let {File(cacheDir,it)}

1001:     }
1002: 
1003:     private fun dimensionsDialog(stretch: Boolean, fresh: Boolean) {
1004:         val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(6), dp(20), dp(6)) }
1005:         val sizing = DimensionControls(this,ImageDimensions(document.bitmap.width,document.bitmap.height),locked = stretch)
1006:         column.addView(sizing)
1007:         if (!fresh) column.addView(label(if (stretch) ui(R.string.ui_scales_the_image_unlock_the_ratio_to_stretch) else ui(R.string.ui_keeps_pixels_at_the_top_left_smaller_canvas), 12f))
1008:         column.addView(label(ui(R.string.ui_current_safe_budget_2f_mp, ImageMemoryPolicy.forDevice(this).maxPixels(document.residentPixels) / 1_000_000.0), 12f))
1009:         val dialog = EditorDialogBuilder(this).setTitle(if (fresh) ui(R.string.ui_new_image) else if (stretch) ui(R.string.ui_resize_image_ab28be) else ui(R.string.ui_canvas_size_30460e)).setView(ScrollView(this).apply { addView(column) }).setNegativeButton(ui(R.string.ui_cancel), null).setPositiveButton(ui(R.string.ui_apply), null).create()
1010:         dialog.setOnShowListener { dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
1011:             val size = sizing.dimensions
1012:             if (size == null) sizing.widthInput.error = ui(R.string.ui_enter_positive_dimensions)
1013:             else editAction {
1014:                 checkImageSize(size.width,size.height); paintCanvas.applyPending()
1015:                 if (fresh) { document.newImage(size.width,size.height);unrestoredCreditSessionToken=null; filename = ui(R.string.ui_untitled);savedTarget=null } else document.resize(size.width,size.height,stretch)

1375:                 type=format.mime;putExtra(Intent.EXTRA_STREAM,uri)

1393:     private fun exportRecoveryTo(uri: Uri) {

824:     private data class PanelCommand(val first: String,val second: () -> Unit,val icon: Int?=null)

1063:     }

1062:         }.show()

1355:                 ImageExporter.encode(snapshot,file,options,ImageMemoryPolicy.forDevice(this).workingBytes)
1356:                 contentResolver.openOutputStream(uri,"wt")?.use {output -> file.inputStream().use {it.copyTo(output)}}
1357:                     ?: throw IOException(ui(R.string.ui_the_selected_location_is_not_writable))

910:     private fun pasteSelection() {
911:         chooseTool(PaintTool.SELECT)
912:         if (document.paste()) selectAfterPaste() else message(ui(R.string.ui_paste_hint34))
913:     }
914: 
915:     private fun editAction(action: () -> Unit): Boolean {
916:         if (autosaving) { message(ui(R.string.ui_the_draft_is_saving_try_again_shortly));return false }
917:         try { action();return true }
918:         catch (error: OutOfMemoryError) { editFailed(error) }
919:         catch (error: IOException) { editFailed(error) }
920:         catch (error: IllegalArgumentException) { editFailed(error) }
921:         return false
922:     }
923: 
924:     private fun checkImageSize(width: Int, height: Int) {

1428:     private fun showLegacyImageCredits() {
1429:         startActivityForResult(Intent(this,LegacyImageCreditsActivity::class.java),LEGACY_CREDITS)
1430:     }
1431: 
1432:     private fun attachLegacyImageCredit(token: String?) {
1433:         val credit=ImageCreditArchive.find(this,token) ?: return
1434:         if(busy) {message(ui(R.string.ui_the_draft_is_saving_try_again_shortly));return}
1435:         if(credit.source.isBlank()) {message(ui(R.string.ui_could_not_complete_the_operation));return}
1436:         editAction {

1376:                 clipData=android.content.ClipData.newRawUri(ui(R.string.ui_an_paint_image),uri)
1377:                 addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
1378:             }
1379:             startActivity(Intent.createChooser(send,ui(R.string.ui_share_saved_image)))
1380:         } catch(error: Exception) {message(ui(R.string.ui_the_image_was_saved_but_android_could_not, error.message))}
1381:     }
1382: 
1383:     private fun exportSourceTo(uri: Uri) {
1384:         beginIo()
1385:         worker.execute {
1386:             try {
1387:                 assets.open(SOURCE_ASSET).use { source -> contentResolver.openOutputStream(uri, "wt")?.use { source.copyTo(it) } ?: throw IOException(ui(R.string.ui_this_location_is_not_writable)) }
1388:                 runOnUiThread { if (!isDestroyed) { endIo(); message(ui(R.string.ui_source_code_exported_including_build_scripts_and_licence)) } }

1351:             var encoded: File?=null
1352:             try {
1353:                 val directory=File(cacheDir,"images").apply {mkdirs()}
1354:                 val file=File.createTempFile("AN-Paint-",options.format.extension,directory);encoded=file

925:         ImageMemoryPolicy.forDevice(this).check(width, height, if (::document.isInitialized) document.residentPixels else 0)
926:     }
927: 
928:     private fun editFailed(error: Throwable) {
929:         message(if (error is ImageSizeException) error.message!! else if (error is OutOfMemoryError) ui(R.string.ui_there_is_not_enough_memory_for_this_operation)
930:             else ui(R.string.ui_could_not_complete_the_edit, error.message ?: ui(R.string.ui_please_try_again)))
931:     }
932: 
933:     private fun backgroundEdit(action: () -> Unit) {
934:         if (busy) return
935:         beginIo()
936:         worker.execute {
937:             try { action() }

1389:             } catch (e: Exception) { ioFailed(ui(R.string.ui_could_not_export_source_code), e) }
1390:         }
1391:     }
1392: 

699:         if (::zoomSlider.isInitialized) {
700:             syncingZoom = true; zoomSlider.progress = paintCanvas.sliderForZoom(); syncingZoom = false
701:             zoomSlider.isEnabled = !busy
702:             zoomSlider.contentDescription = ui(R.string.ui_canvas_zoom_771f84, paintCanvas.zoomLabel())
703:         }
704:         if (::options.isInitialized) options.findViewWithTag<TextView>("selection_dimensions")?.text=document.selection?.let {
705:             ui(R.string.ui_0f_0f_px_1f,it.rect.width(),it.rect.height(),it.rotation)
706:         } ?: ui(R.string.ui_select_an_area)
707:         if (::options.isInitialized) root.findViewWithTag<TextView>("trim_dimensions")?.text = paintCanvas.trim?.rect?.let { ui(R.string.ui_px_724eb3, it.width(), it.height()) } ?: ""
708:         if (::editDetails.isInitialized && paintCanvas.trim==null) {editDetails.visibility=View.GONE;editCommands.visibility=View.VISIBLE}
709:         titleText.text = "$filename${if (document.dirty) " *" else ""}"
710:         // Pending geometry can be cancelled; an empty history alone cannot be undone.
711:         redoButton.isEnabled = !busy && document.canRedo
712:         undoButton.isEnabled = !busy && (document.canUndo || paintCanvas.hasPendingEdit)
713:         toolButtons.forEach { (tool, view) -> view.isSelected = tool == paintCanvas.tool; view.invalidate() }

756: 
757:             }
758:             PaintTool.FILL -> addSlider(ui(R.string.ui_tolerance), document.tolerance.toInt(), 100) { document.tolerance = it.toFloat() }
759:             PaintTool.ZOOM -> {
760:                 options.addView(label(ui(R.string.ui_pinch_to_zoom_drag_to_pan),12f))
761:                 options.addView(button(ui(R.string.ui_draw_again), "navigate_draw") { chooseTool(drawingTool) },LinearLayout.LayoutParams(-1,dp(48)))
762:                 options.addView(button(ui(R.string.ui_100), "zoom_actual") { paintCanvas.zoomAt(1f) },LinearLayout.LayoutParams(-1,dp(44)))
763:                 options.addView(button(ui(R.string.ui_fit), "zoom_fit") { paintCanvas.fit() }, LinearLayout.LayoutParams(-1, dp(44)))
764:             }
765:             PaintTool.PENCIL -> addSlider(ui(R.string.ui_size_px),paintCanvas.pencilSize.toInt(),100,1,"pencil_size") {paintCanvas.pencilSize=it.toFloat()}
766:             PaintTool.TEXT -> options.addView(label(ui(R.string.ui_tap_canvas_to_type), 12f))
767:             PaintTool.PICKER -> options.addView(label(ui(R.string.ui_tap_a_pixel), 12f))
768:             else -> {
769:                 addSlider(ui(R.string.ui_size_px), document.strokeWidth.toInt(), 100, 1, "brush_size") { document.strokeWidth = it.toFloat() }
770:                 if (tool == PaintTool.ROUND_RECT) addSlider(ui(R.string.ui_radius_px),document.cornerRadius.toInt(),

959:                 }}
960:                 setOnLongClickListener {if(!busy) editPaletteColour(index);true}
961:             }
962:             customPaletteCells.add(cell);strip.addView(cell,LinearLayout.LayoutParams(dp(40),dp(40)).apply {setMargins(dp(2),dp(2),dp(2),dp(2))})
963:         }
964:         row.addView(HorizontalScrollView(this).apply {addView(strip)},LinearLayout.LayoutParams(0,dp(44),1f))
965:         row.addView(panelButton(ui(R.string.ui_add_colour26),"add_colour",R.drawable.classic_palette) {addColour()},LinearLayout.LayoutParams(-2,toolHeight))
966:         parent.addView(label(ui(R.string.ui_saved_palette23)));parent.addView(row);refreshCustomPalette()
967:     }
968:     private fun refreshCustomPalette() {
969:         val palette=CustomColours(this)
970:         customPaletteCells.forEachIndexed {index,cell ->
971:             cell.colour=if(palette.has(index)) palette.colour(index) else null
972:             cell.contentDescription=cell.colour?.let {ui(R.string.ui_colour,String.format(java.util.Locale.ROOT,"#%06X",it and 0xffffff))}
973:                 ?: ui(R.string.ui_empty_palette26,index+1)

1086:             if (intent.action == Intent.ACTION_OPEN_DOCUMENT) {
1087:                 try { startActivityForResult(Intent(intent).setAction(Intent.ACTION_GET_CONTENT), request); return }
1088:                 catch (_: ActivityNotFoundException) { /* Explain the missing picker below. */ }
1089:             }
1090:             afterSave = null
1091:             message(ui(R.string.ui_android_could_not_find_a_file_picker_enable))
1092:         } catch (e: SecurityException) { afterSave = null; message(ui(R.string.ui_android_blocked_the_file_picker, e.message)) }
1093:     }
1094: 
1095:     private fun requestSave(jpeg: Boolean) {
1096:         if(jpeg) {showSaveOptions(ImageFormat.JPEG);return}
1097:         val target=savedTarget
1098:         if(target==null) showSaveOptions(ImageFormat.PNG)
1099:         else {exportOptions=target.options;isExporting=false;shareAfterSave=false;writeImage(target.uri)}
1100:     }

1085:         catch (_: ActivityNotFoundException) {

1016:                 paintCanvas.fit(); updateStatus(); dialog.dismiss()
1017:             }

1038:     private fun showBoundsOptions() {
1039:         activeTab="Edit";sidebarExpanded=true;editCommands.visibility=View.GONE;editDetails.visibility=View.VISIBLE
1040:         editDetails.removeAllViews()
1041:         editDetails.addView(label(ui(R.string.ui_drag_out_to_expand_in_to_trim_drag),12f))
1042:         editDetails.addView(label("").apply {tag="trim_dimensions"})
1043:         fun finish() {editDetails.visibility=View.GONE;editCommands.visibility=View.VISIBLE;syncPanels()}
1044:         editDetails.addView(button(ui(R.string.ui_apply_bounds),"trim_apply") {paintCanvas.applyTrim();finish()},LinearLayout.LayoutParams(-1,dp(48)))
1045:         editDetails.addView(button(ui(R.string.ui_cancel),"trim_cancel") {paintCanvas.cancelTrim();finish()},LinearLayout.LayoutParams(-1,dp(48)))
1046:         editDetails.addView(button(ui(R.string.ui_fit),"trim_fit") {paintCanvas.fit()},LinearLayout.LayoutParams(-1,dp(48)))
1047:         if(VerticalText.uiVertical(this@ClassicPaintActivity)) VerticalUi.panel(editDetails)
1048:         syncPanels();updateStatus()
1049:     }
1050:     override fun onKeyShortcut(keyCode: Int, event: android.view.KeyEvent): Boolean {
1051:         if (event.isCtrlPressed && keyCode == android.view.KeyEvent.KEYCODE_A && !busy) { editAction { selectAll() }; return true }
1052:         return super.onKeyShortcut(keyCode,event)

676:             it.text=ui(if(paintCanvas.cursorDrawing) R.string.ui_cursor_stop31 else R.string.ui_cursor_start31)
677:             it.isEnabled=!busy;it.isSelected=paintCanvas.cursorDrawing;it.contentDescription=it.text
678:             LocaleTooltip.set(it,it.text)
679:         }
680:         root.findViewWithTag<PanelToolButton>("command_View_2")?.isSelected=paintCanvas.cursorMode
681:         val normalStatus=ui(R.string.ui_px, paintCanvas.tool.label, paintCanvas.zoomStatusLabel(), document.bitmap.width, document.bitmap.height, draftStatus)
682:         val shownStatus=if(busy) (if(autosaving) ui(R.string.ui_autosaving_draft) else ui(R.string.ui_working)) else normalStatus
683:         if(!VerticalText.uiVertical(this@ClassicPaintActivity)) {
684:             statusText.maxLines=if(paintCanvas.cursorMode) Int.MAX_VALUE else 2
685:             if(paintCanvas.cursorMode) {
686:                 val available=if(statusText.width>0) statusText.width-statusText.compoundPaddingLeft-statusText.compoundPaddingRight
687:                     else dp((resources.configuration.screenWidthDp-242).coerceAtLeast(32))
688:                 @Suppress("DEPRECATION")
689:                 fun textHeight(value: String)=android.text.StaticLayout(value,statusText.paint,available.coerceAtLeast(1),
690:                     android.text.Layout.Alignment.ALIGN_NORMAL,statusText.lineSpacingMultiplier,statusText.lineSpacingExtra,statusText.includeFontPadding).height

992:             }.show()
993:     }
994:     private fun editPaletteColour(index: Int) {
995:         val store=CustomColours(this)
996:         if(!store.has(index)) {addColour(index);return}
997:         EditorDialogBuilder(this).setTitle(String.format(java.util.Locale.ROOT,"#%06X",store.colour(index) and 0xffffff))
998:             .setItems(arrayOf(ui(R.string.ui_background_colour),ui(R.string.ui_edit_colour26),ui(R.string.ui_remove_palette23))) {_,action ->
999:                 when(action) {0->setColour(store.colour(index),true);1->addColour(index);2->{store.remove(index);refreshCustomPalette()}}
1000:             }.setNegativeButton(ui(R.string.ui_cancel),null).show()

809: 
810:     private fun addChoice(values: List<String>, selected: Int, action: (Int) -> Unit) {
811:         val choice = button(values[selected], "tool_option") {}
812:         choice.setOnClickListener {
813:             EditorDialogBuilder(this).setTitle(ui(R.string.ui_tool_option)).setSingleChoiceItems(values.toTypedArray(), selected) { dialog, which ->
814:                 action(which); choice.text = values[which]; dialog.dismiss()
815:             }.setNegativeButton(ui(R.string.ui_cancel), null).show()
816:         }
817:         options.addView(choice, LinearLayout.LayoutParams(-1, dp(48)))
818:     }
819: 
820:     private fun menuTitle(name: String): String=ui(when(name) {
821:         "Draw"->R.string.ui_draw26;"File"->R.string.ui_menu_file;"Edit"->R.string.ui_menu_edit
822:         "View"->R.string.ui_menu_view;"Color"->R.string.ui_colour_tab23;else->R.string.ui_menu_help
823:     })

908:     private fun cutSelection() { if (!document.cutSelection()) message(ui(R.string.ui_select_an_area_first)) }

977:         val store=CustomColours(this)
978:         val index=slot ?: (0 until 16).firstOrNull {!store.has(it)}
979:         if(index==null) {
980:             val entries=store.entries()
981:             EditorDialogBuilder(this).setTitle(ui(R.string.ui_replace_palette23))
982:                 .setItems(entries.map {String.format(java.util.Locale.ROOT,"#%06X",it.second and 0xffffff)}.toTypedArray()) {_,which ->addColour(entries[which].first)}
983:                 .setNegativeButton(ui(R.string.ui_cancel),null).show()
984:             return
985:         }
986:         colourPreviewOriginal=document.foreground to document.background
987:         AdvancedColourDialog(this,if(slot!=null && store.has(slot)) store.colour(slot) else document.foreground,false,
988:             preview={document.foreground=it;updateColours(false)},paletteChanged={refreshCustomPalette()},
989:             closed={colourPreviewOriginal?.let {document.foreground=it.first;updateColours(false)};colourPreviewOriginal=null},
990:             initialMode=1,addingToPalette=true,replacingPaletteColour=store.has(index)) {colour ->
991:                 colourPreviewOriginal=null;store.replace(index,colour);refreshCustomPalette();setColour(colour,false)

1053:     }

1161:     public override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {

648:             statusText = label(ui(R.string.ui_ready), 11f).apply {tag="status_text";maxLines=2}
649:             row.addView(statusText, LinearLayout.LayoutParams(0, dp(44), 1f))
650:         } else row.gravity=Gravity.END
651:         val zoomRow = LinearLayout(this).apply {isBaselineAligned=false; gravity = Gravity.CENTER_VERTICAL; tag = "zoom_controls" }
652:         zoomRow.addView(actionIcon(EditIcon.MINUS, "zoom_out") { paintCanvas.zoomStep(1/1.5f) }, LinearLayout.LayoutParams(dp(40), dp(44)))
653:         zoomSlider = ZoomSeekBar(this).apply {
654:             tag = "zoom_slider"; contentDescription = ui(R.string.ui_canvas_zoom); max = 1000
655:             setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
656:                 override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) {
657:                     if (fromUser && !syncingZoom && !busy) paintCanvas.zoomAt(paintCanvas.zoomForSlider(value))
658:                 }
659:                 override fun onStartTrackingTouch(bar: SeekBar?) = Unit
660:                 override fun onStopTrackingTouch(bar: SeekBar?) = Unit
661:             })
662:         }

696:             if(statusText.layoutParams.height!=height) statusText.layoutParams=statusText.layoutParams.apply {this.height=height}
697:         }
698:         statusText.text = (if(VerticalText.uiVertical(this@ClassicPaintActivity)) filename+"\n" else "") + shownStatus

69:     private val tabPanels = linkedMapOf<String, View>()
70:     private val tabButtons = linkedMapOf<String, Button>()
71:     private lateinit var editDetails: LinearLayout
72:     private lateinit var editCommands: View
73:     private var expandedEditGroup: EditGroup?=null
74:     private enum class EditGroup(val labelId: Int,val icon: Int,val commands: List<Int>) {
75:         SELECTION(R.string.ui_category_selection,R.drawable.breeze_select,listOf(0,2,4)),
76:         CANVAS(R.string.ui_edit_canvas33,R.drawable.classic_canvas_size,listOf(1,3,5,10,11)),
77:         TRANSFORM(R.string.ui_edit_transform33,R.drawable.classic_rotate90,listOf(6,7,8,9))
78:     }
79:     private lateinit var toolDrawer: ScrollView
80:     private var portraitColours: View? = null
81:     private var filename = ui(R.string.ui_untitled)
82:     private var exportOptions=ExportOptions()
83:     private var savedTarget: SavedTarget? = null

531:         categoryButtons.forEach {(category,view) ->
532:             view.selectedTool=categoryTools[category] ?: category.tools.first()
533:             view.expanded=toolOptionsExpanded && expandedCategory==category
534:             view.isSelected=paintCanvas.tool in category.tools;view.refresh()
535:         }
536:         sidebarToggle.isSelected=sidebarExpanded
537:         sidebarToggle.contentDescription=if(sidebarExpanded) ui(R.string.ui_collapse_toolbox) else ui(R.string.ui_expand_toolbox)
538:         getSharedPreferences("classic-ui",MODE_PRIVATE).edit().putBoolean("sidebar_expanded",sidebarExpanded).apply()
539:     }
540: 
541:     private fun dp(value: Int) = (value * resources.displayMetrics.density + .5f).toInt()
542:     private fun label(value: String, size: Float = 13f) = FlowTextView(this).apply {
543:         text = value; textSize = size; setTextColor(ink); gravity = Gravity.CENTER_VERTICAL
544:     }
545:     private fun button(value: String, tagName: String, action: () -> Unit) = FlowButton(this).apply {

974:         }
975:     }
976:     private fun addColour(slot: Int?=null) {

598:         tabs.addView(sidebarToggle,LinearLayout.LayoutParams(dp(44),dp(44)).apply {gravity=Gravity.END})
599:         root.addView(tabs,LinearLayout.LayoutParams(if(landscape) -2 else -1,if(landscape) 0 else -2))
600:     }
601: 
602:     private fun makePalette(editor: LinearLayout) {
603:         val row = LinearLayout(this).apply { tag="palette_bar"; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(2), dp(4), dp(2)) }; paletteBar=row
604:         val scroll = HorizontalScrollView(this).apply { contentDescription = ui(R.string.ui_colour_palette_tap_for_foreground_hold_for_background) }
605:         val palette = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
606:         val colours = arrayOf(
607:             "000000", "808080", "800000", "808000", "008000", "008080", "000080", "800080", "808040", "004040", "0080FF", "004080", "8000FF", "804000",
608:             "FFFFFF", "C0C0C0", "FF0000", "FFFF00", "00FF00", "00FFFF", "0000FF", "FF00FF", "FFFF80", "00FF80", "80FFFF", "8080FF", "FF0080", "FF8040"
609:         )
610:         colours.toList().chunked(14).forEach { values ->
611:             val strip = LinearLayout(this)
612:             values.forEach { hex ->

613:                 val colour = Color.parseColor("#$hex")
614:                 val swatch = View(this).apply {
615:                     tag = "colour_$hex"; contentDescription = ui(R.string.ui_colour_tap_foreground_hold_background, hex)
616:                     isFocusable = true
617:                     background = GradientDrawable().apply { setColor(colour); setStroke(dp(2), EditorColours.outline) }
618:                     setOnClickListener { if (!busy) setColour(colour,false) }
619:                     setOnLongClickListener { if (!busy) setColour(colour,true); true }
620:                 }
621:                 strip.addView(swatch, LinearLayout.LayoutParams(dp(36), dp(36)).apply { setMargins(dp(1), dp(1), dp(1), dp(1)) })
622:             }
623:             palette.addView(strip)

779:                 }
780:                 if (tool in listOf(PaintTool.RECTANGLE, PaintTool.POLYGON, PaintTool.ELLIPSE, PaintTool.ROUND_RECT,PaintTool.HEART,PaintTool.STAR,PaintTool.ARROW))
781:                     addChoice(listOf(ui(R.string.ui_outline), ui(R.string.ui_solid_fill), ui(R.string.ui_fill_line)), document.shapeStyle) { document.shapeStyle = it; paintCanvas.invalidate() }
782:             }
783:         }
784:         if (tool in listOf(PaintTool.POLYGON, PaintTool.CURVE, PaintTool.SELECT, PaintTool.LASSO)) {
785:             options.addView(button(when (tool) { PaintTool.POLYGON -> ui(R.string.ui_finish_polygon); PaintTool.CURVE -> ui(R.string.ui_finish_curve); else -> ui(R.string.ui_commit_selection) }, "apply") {
786:                 paintCanvas.applyPending()
787:             }, LinearLayout.LayoutParams(-1, dp(48)))
788:         }
789:         if(tool==PaintTool.POLYGON) options.addView(CheckBox(this).apply {
790:             tag="polygon_close";text=ui(R.string.ui_close_polygon);textSize=11f;isChecked=paintCanvas.closePolygon
791:             setOnCheckedChangeListener {_,checked -> paintCanvas.closePolygon=checked;paintCanvas.invalidate();scheduleAutosave()}
792:         })
793:         options.addView(button(ui(R.string.ui_how_to_use), "tool_help") {

175:     }
176: 
177:     private fun receiveStartup(result: Result<AutosaveStore.Recovery<RecoveredEditor>>) {
178:         val recoveredEditor=result.getOrElse {error ->
179:             // Do not install or autosave an empty canvas after unexpected startup failure.
180:             lastIoError=error.message ?: ui(R.string.ui_please_try_again)
181:             startupFailure=ui(R.string.ui_could_not_complete_the_edit,lastIoError!!);showStartup();return
182:         }
183:         if(isFinishing || isDestroyed) {worker.execute {recoveredEditor.value.document.close()};return}
184:         if(!autosave.isCurrent(recoveredEditor)) {
185:             worker.execute {recoveredEditor.value.document.close()};startup.start();return
186:         }
187:         val recovery=recoveredEditor.value
188:         document=recovery.document
189:         filename=recovery.filename;textSettings=recovery.textSettings;savedTarget=recovery.savedTarget

938:             catch (error: OutOfMemoryError) { runOnUiThread { if (!isDestroyed) editFailed(error) } }

247: 

877:             ui(R.string.ui_image_codec_licences) to {LegalInfo.showCodecLicences(this)},
878:             ui(R.string.ui_font_licences) to {LegalInfo.showAsset(this,ui(R.string.ui_font_licences),"legal/FONT_NOTICES.txt")},
879:             ui(R.string.ui_icon_licences) to {LegalInfo.showAsset(this,ui(R.string.ui_icon_licences_kde_breeze),"legal/ICON_NOTICES.txt")}) +
880:             if(ImageCreditArchive.hasRecords(this)) listOf(ui(R.string.legacy_credits_title) to {showLegacyImageCredits()})
881:             else emptyList()
882:         EditorDialogBuilder(this).setScrollableTitle(ui(R.string.ui_about_credits23)).setItems(actions.map {it.first}.toTypedArray()) {_,index->actions[index].second()}
883:             .setNegativeButton(ui(R.string.ui_done),null).show()
884:     }
885: 
886:     private fun showOtherImages() {
887:         val sources=listOf(ui(R.string.ui_from_device34))+IllustrationSource.values().map {it.label}
888:         EditorDialogBuilder(this).setTitle(ui(R.string.ui_other_images34)).setItems(sources.toTypedArray()) {_,index ->
889:             if(index==0) launchOpen(true)
890:             else try {
891:                 paintCanvas.pauseGesture()

1556:         } else {
1557:             toggle(ui(R.string.ui_smooth_freehand_strokes),document.strokeSmoothing) { document.strokeSmoothing=it }
1558:             toggle(ui(R.string.ui_smooth_pixel_edges_anti_aliasing),document.antialiasing) { document.antialiasing=it }
1559:             column.addView(label(ui(R.string.ui_pencil_crisp_adjustable_strokes)))
1560:         }
1561:         EditorDialogBuilder(this).setTitle(if(preview) ui(R.string.ui_magnified_preview_ea9209) else ui(R.string.ui_drawing_settings_d900c6))
1562:             .setView(ScrollView(this).apply {addView(column)}).setPositiveButton(ui(R.string.ui_done),null).show()
1563:     }
1564:     private fun syncFullscreen() {
1565:         if(!::root.isInitialized) return
1566:         for(i in 0 until root.childCount) root.getChildAt(i).let { it.visibility=if(fullscreen && it.tag!="workspace_overlay") View.GONE else View.VISIBLE }
1567:         syncPanels()
1568:         root.findViewWithTag<View>("vertical_status_rail")?.visibility=if(fullscreen) View.GONE else View.VISIBLE
1569:         root.findViewWithTag<View>("vertical_ribbon_rail")?.visibility=if(fullscreen) View.GONE else View.VISIBLE
1570:         sidebarToggle.visibility=if(fullscreen) View.GONE else View.VISIBLE

1575:     }
1576:     private fun showHelp() = message(ui(R.string.ui_help23))
1577:     private fun message(text: String) { if (!isFinishing && !isDestroyed) EditorDialogBuilder(this).setTitle("AN Paint").setMessage(text).setPositiveButton(ui(R.string.ui_ok), null).show() }
1578: 
1579:     private fun scheduleAutosave() {
1580:         if (!autosaveReady || autosaveBlocked || isDestroyed) return
1581:         draftGeneration++;draftStatus=ui(R.string.ui_draft_pending)
1582:         autosaveHandler.removeCallbacks(saveDraft)
1583:         autosaveHandler.postDelayed(saveDraft,if (stopped) 0 else 1500)
1584:     }
1585:     private fun draftMetadata(): JSONObject = JSONObject().apply {
1586:         put("version",1);put("filename",filename);put("dirty",document.dirty)
1587:         put("image_credits",document.imageCreditsState())
1588:         savedTarget?.let {put("save_target",it.json())}
1589:         put("foreground",colourPreviewOriginal?.first ?: document.foreground);put("background",colourPreviewOriginal?.second ?: document.background)

755:                 },LinearLayout.LayoutParams(-1,dp(48)))

265: 
266:     private val panelLimit get() = dp(if (landscape) (resources.configuration.screenHeightDp-96).coerceAtLeast(136) else minOf(256, resources.configuration.screenHeightDp / 3))
267:     private val sidePanelWidth get() = dp(minOf(248,resources.configuration.screenWidthDp / 3))
268:     private val toolHeight get() = PanelToolButton.tileSize(this)
269:     private fun buildWorkspace() {
270:         paintCanvas.pauseGesture()
271:         paintCanvas.contentDescription=ui(R.string.ui_drawing_canvas_pinch_and_move_two_fingers_to)
272:         (paintCanvas.parent as? android.view.ViewGroup)?.removeView(paintCanvas)
273:         toolButtons.clear();categoryButtons.clear();categoryGroups.clear();recentCells.clear()
274:         tabPanels.clear();tabButtons.clear();customPaletteCells.clear()
275:         root=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;setBackgroundColor(surface);fitsSystemWindows=true}
276:         setContentView(root);makeHeader();LocaleTypography.install(root)
277:         tabPanelHost=FrameLayout(this).apply {tag="tab_panel_host"}
278:         val sideRibbon=if(landscape) LinearLayout(this).apply {
279:             orientation=LinearLayout.HORIZONTAL;isBaselineAligned=false;tag="vertical_ribbon_rail";layoutDirection=View.LAYOUT_DIRECTION_LTR

794:             message(if(paintCanvas.cursorMode && tool in listOf(PaintTool.PENCIL,PaintTool.BRUSH,PaintTool.WATERCOLOR,PaintTool.ERASER)) ui(R.string.ui_cursor_help29) else tool.hint)
795:         }, LinearLayout.LayoutParams(-1, dp(48)))
796:         if(tool in listOf(PaintTool.PENCIL,PaintTool.BRUSH,PaintTool.WATERCOLOR,PaintTool.SPRAY,PaintTool.ERASER,PaintTool.LINE,PaintTool.CURVE)) {
797:             options.addView(button(ui(R.string.ui_drawing_settings),"drawing_settings") {showDrawingSettings(false)},LinearLayout.LayoutParams(-1,dp(48)))
798:         }
799:         if(VerticalText.uiVertical(this@ClassicPaintActivity)) VerticalUi.panel(options)
800:         updateStatus()
801:     }
802: 
803:     private fun addSlider(name: String, value: Int, maximum: Int, minimum: Int = 0, tagName: String? = null, action: (Int) -> Unit) {
804:         val control=NumericSlider(this,name,value,minimum,maximum) { action(it);paintCanvas.invalidate();scheduleAutosave() }
805:         control.slider.tag=tagName

1555:             }.apply {tag="preview_magnification"})

84:     private var isExporting = false

85:     private var shareAfterSave=false

1018:         } }; dialog.show()
1019:     }
1020: 

663:         zoomRow.addView(zoomSlider, LinearLayout.LayoutParams(dp(108), dp(44)))
664:         zoomRow.addView(actionIcon(EditIcon.PLUS, "zoom_in") { paintCanvas.zoomStep(1.5f) }, LinearLayout.LayoutParams(dp(40), dp(44)))
665:         zoomRow.addView((if(VerticalText.uiVertical(this@ClassicPaintActivity)) actionIcon(EditIcon.FIT,"zoom_fit_view") {paintCanvas.fit()} else button(ui(R.string.ui_fit),"zoom_fit_view") {paintCanvas.fit()}).apply {
666:             contentDescription=ui(R.string.ui_fit_entire_canvas_in_view)
667:         },LinearLayout.LayoutParams(dp(44),dp(44)))
668:         row.addView(zoomRow)
669:         root.addView(row)
670:     }
671: 
672:     private fun updateStatus() {
673:         if (!::statusText.isInitialized) return

771:                     maxOf(64,minOf(document.bitmap.width,document.bitmap.height)/2,document.cornerRadius.toInt()),tagName="corner_radius") {

1054: 

674:         root.findViewWithTag<PanelToolButton>("cursor_draw_toggle")?.let {

740:         options.removeAllViews()
741:         options.addView(label(tool.label, 12f).apply { typeface = Typeface.DEFAULT_BOLD })
742:         when (tool) {
743:             PaintTool.SELECT, PaintTool.LASSO -> {
744:                 options.addView(label(ui(R.string.ui_corners_and_edges_resize_round_handle_rotates),11f))
745:                 options.addView(label("").apply { tag="selection_dimensions" })
746:                 options.addView(button(ui(R.string.ui_fit_selection34),"selection_fit_canvas") {
747:                     if(document.fitSelectionToCanvas()) paintCanvas.fit()
748:                 })
749:                 options.addView(button(ui(R.string.ui_original_size34),"selection_original_size") {
750:                     if(document.restoreSelectionSize()) paintCanvas.fit()
751:                 })
752:                 options.addView(CheckBox(this).apply {
753:                     tag="selection_lock_aspect";text=ui(R.string.ui_lock_proportions);textSize=11f;isChecked=paintCanvas.lockSelectionAspect
754:                     setOnCheckedChangeListener { _,checked -> paintCanvas.lockSelectionAspect=checked;scheduleAutosave() }

892:                 val session=CreditEditSession.create(filesDir,document.imageCredits,creditEditContext())

859:             },
860:             command(ui(R.string.ui_magnifier33),R.drawable.breeze_zoom_in) {showDrawingSettings(true)},
861:             command(ui(R.string.ui_languages23),R.drawable.classic_languages) {AppLanguage.showPicker(this) {buildWorkspace()}},
862:             command(ui(R.string.ui_fullscreen33),R.drawable.classic_fullscreen) {fullscreen=!fullscreen;syncFullscreen()},
863:             command(ui(R.string.ui_how_to_use),android.R.drawable.ic_menu_help) {message(ui(R.string.ui_pixel_grid_help33))}
864:         )
865:         else->emptyList()
866:     }
867:     private fun menuActionEnabled()=!busy
868:     private fun showAboutOptions() {
869:         val actions=listOf(

1528:         },LinearLayout.LayoutParams(0,dp(48),1f))
1529:         column.addView(shapeRow)
1530:         column.addView(CheckBox(this).apply {
1531:             tag="cursor_magnifier_enabled";text=ui(R.string.ui_show_magnified_drawing_preview);isChecked=paintCanvas.cursorMagnifier
1532:             setOnCheckedChangeListener {_,on ->paintCanvas.cursorMagnifier=on;paintCanvas.invalidate();scheduleAutosave()}
1533:         })
1534:         column.addView(NumericSlider(this,ui(R.string.ui_magnification),(paintCanvas.previewMagnification*100).toInt(),100,400) {
1535:             paintCanvas.previewMagnification=it/100f;paintCanvas.invalidate();scheduleAutosave()
1536:         }.apply {tag="cursor_magnification"})
1537:         column.addView(NumericSlider(this,ui(R.string.ui_cursor_marker_size31),(paintCanvas.cursorMarkerScale*100).toInt(),100,200) {
1538:             paintCanvas.cursorMarkerScale=it/100f;paintCanvas.invalidate();scheduleAutosave()
1539:         }.apply {tag="cursor_marker_size"})
1540:         val content=if(VerticalText.uiVertical(this@ClassicPaintActivity)) {VerticalUi.panel(column);ColumnScrollView(this).apply {addView(column)}} else column
1541:         cursorOptionsHost.addView(content)
1542:     }

1547:         }
1548:         if(preview) {
1549:             toggle(ui(R.string.ui_show_magnified_drawing_preview),paintCanvas.activeMagnifier,"magnifier_enabled") {
1550:                 paintCanvas.activeMagnifier=it
1551:                 populateCursorOptions()
1552:             }
1553:             column.addView(NumericSlider(this,ui(R.string.ui_magnification),(paintCanvas.previewMagnification*100).toInt(),100,400) {
1554:                 paintCanvas.previewMagnification=it/100f;paintCanvas.invalidate();scheduleAutosave()

1409:         return uri.lastPathSegment?.substringAfterLast('/') ?: ui(R.string.ui_menu_image)
1410:     }
1411:     private fun beginIo() { operationsInFlight++; busy = true; lastIoError = null; paintCanvas.isEnabled = false; updateStatus() }
1412:     private fun endIo() { operationsInFlight = (operationsInFlight - 1).coerceAtLeast(0); busy = operationsInFlight > 0; paintCanvas.isEnabled = !busy; updateStatus(); if (!busy && autosaveReady && draftGeneration != savedDraftGeneration && draftGeneration != failedDraftGeneration) { autosaveHandler.removeCallbacks(saveDraft); autosaveHandler.postDelayed(saveDraft,if (stopped) 0 else 1500) }; if(!busy) deliverPendingInputs() }
1413:     private fun ioFailed(prefix: String, e: Throwable) {
1414:         runOnUiThread { if (!isDestroyed) { afterSave = null; endIo(); lastIoError = "$prefix. ${e.message ?: ui(R.string.ui_try_a_different_file_or_location)}"; message(lastIoError!!) } }
1415:     }

1416:     private fun setColour(colour: Int,background: Boolean) {
1417:         if(background) document.background=colour else document.foreground=colour

1293:             { ImageMemoryPolicy.forDevice(this) },previousAttempt,

1571:         val workspace=root.findViewWithTag<FrameLayout>("workspace_overlay")
1572:         workspace.findViewWithTag<View>("leave_fullscreen")?.let {workspace.removeView(it)}
1573:         if(fullscreen) workspace.addView(button(ui(R.string.ui_show_controls),"leave_fullscreen") {fullscreen=false;syncFullscreen()},FrameLayout.LayoutParams(-2,if(VerticalText.uiVertical(this@ClassicPaintActivity)) -2 else dp(48),Gravity.TOP or Gravity.END))
1574:         window.decorView.systemUiVisibility=if(fullscreen) View.SYSTEM_UI_FLAG_FULLSCREEN else View.SYSTEM_UI_FLAG_VISIBLE

299:         } else sidebar.addView(HorizontalScrollView(this).apply {tag="primary_tool_scroll";addView(primary)},LinearLayout.LayoutParams(-1,toolHeight))
300:         val drawerContent=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;setPadding(dp(4),0,dp(4),dp(4))}
301:         toolDrawer=ScrollView(this).apply {tag="tool_scroll";addView(drawerContent)}
302:         ToolCategory.values().forEach {category ->
303:             val group=LinearLayout(this).apply {isBaselineAligned=false;tag="category_tools_${category.name}"}
304:             category.tools.forEach {group.addView(makeToolButton(it),LinearLayout.LayoutParams(-2,toolHeight))}
305:             if(category==ToolCategory.INSERT) group.addView(panelButton(ui(R.string.ui_other_images34),"insert_other_images",android.R.drawable.ic_menu_gallery) {
306:                 showOtherImages()
307:             },LinearLayout.LayoutParams(toolHeight,toolHeight))
308:             val rail: View=if(landscape) {
309:                 // Wrap the category into tiles above its options, beside the primary tool rail.
310:                 val grid=GridLayout(this).apply {columnCount=2;alignmentMode=GridLayout.ALIGN_BOUNDS}
311:                 while(group.childCount>0) grid.addView(VerticalUi.detach(group.getChildAt(0)),GridLayout.LayoutParams().apply {
312:                     width=toolHeight;height=toolHeight
313:                 })

775:                 if (tool == PaintTool.SPRAY) addSlider(ui(R.string.ui_spray_radius_px),document.sprayRadius.toInt(),100,1,"spray_radius") { document.sprayRadius=it.toFloat() }
776:                 if (tool in listOf(PaintTool.BRUSH,PaintTool.WATERCOLOR,PaintTool.ERASER,PaintTool.LINE)) {
777:                     val tips=if(tool==PaintTool.BRUSH) listOf(ui(R.string.ui_round),ui(R.string.ui_square),ui(R.string.ui_calligraphy)) else listOf(ui(R.string.ui_round),ui(R.string.ui_square))
778:                     addChoice(tips,document.brushTip.coerceIn(tips.indices)) {document.brushTip=it}

909:     private fun copySelection() { if (!document.copySelection()) message(ui(R.string.ui_select_an_area_first)) }

174:         setContentView(loading);LocaleTypography.install(loading)

164:         val loading=LinearLayout(this).apply {
165:             tag="editor_startup";orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER
166:             setBackgroundColor(surface)
167:             if(startupFailure==null) addView(ProgressBar(this@ClassicPaintActivity).apply {tag="editor_startup_progress"})
168:             addView(FlowTextView(this@ClassicPaintActivity).apply {
169:                 tag="editor_startup_label";columnHeightDp=(resources.configuration.screenHeightDp-160).coerceIn(96,240)
170:                 text=startupFailure ?: ui(R.string.ui_please_wait_for_the_current_operation);contentDescription=text;setTextColor(ink)
171:                 gravity=Gravity.CENTER;setPadding(dp(24),dp(24),dp(24),dp(24))
172:             })
173:         }

546:         text = value; tag = tagName; contentDescription = value
547:         isAllCaps = false; textSize = 13f; minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0
548:         setPadding(dp(8), dp(6), dp(8), dp(6))
549:         setOnClickListener { if (!busy) editAction(action) else message(ui(R.string.ui_please_wait_for_the_current_operation)) }
550:     }
551: 
552:     private fun panelButton(value: String,tagName: String,icon: Int,action: () -> Unit)=PanelToolButton(this).apply {
553:         text=value;contentDescription=value;tag=tagName;labelledIcon(icon)
554:         LocaleTooltip.set(this,value)
555:         setOnClickListener {if(!busy) editAction(action) else message(ui(R.string.ui_please_wait_for_the_current_operation))}
556:     }
557: 

558:     private fun actionIcon(icon: EditIcon, tagName: String, action: () -> Unit) = ActionButton(this, icon).apply {
559:         tag = tagName
560:         setOnClickListener { if (!busy) editAction(action) }
561:         setOnLongClickListener { LocaleTypography.showMessage(this@ClassicPaintActivity, icon.label, Toast.LENGTH_SHORT); true }
562:     }
563: 

675:             it.visibility=if(paintCanvas.cursorAvailable) View.VISIBLE else View.GONE

714:         categoryButtons.forEach {(category,view) ->view.isSelected=paintCanvas.tool in category.tools;view.invalidate()}
715:         listOf("File","Edit","View").forEach {refreshCommandPanel(it)}

642:     }
643: 
644:     private fun makeStatus() {
645:         cursorStatusHeight=0
646:         val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(7), 0, dp(3), 0) }
647:         if(!VerticalText.uiVertical(this@ClassicPaintActivity)) {

417:         colourStatus=ColourStatusButton(this).apply {
418:             tag="colour_status";editForeground={if(!busy) colourDialog(false)};editBackground={if(!busy) colourDialog(true)}
419:         }
420:         colourHeader.addView(colourStatus,LinearLayout.LayoutParams(dp(132),dp(88)))
421:         val swapIcon=if(VerticalText.uiVertical(this@ClassicPaintActivity)) R.drawable.classic_swap else R.drawable.classic_swap_vertical
422:         colourHeader.addView(panelButton(ui(R.string.ui_swap23),"swap_colours",swapIcon) {val old=document.foreground;document.foreground=document.background;document.background=old;updateColours()},LinearLayout.LayoutParams(-2,toolHeight))
423:         colourHeader.addView(panelButton(ui(R.string.ui_reset_bw23),"reset_colours",R.drawable.classic_bw) {document.foreground=Color.BLACK;document.background=Color.WHITE;updateColours()},LinearLayout.LayoutParams(-2,toolHeight))
424:         colourHeader.addView(panelButton(ui(R.string.ui_advanced),"advanced_colour",R.drawable.classic_palette) {colourDialog(false,advanced=true)},LinearLayout.LayoutParams(-2,toolHeight))
425:         if(landscape) {
426:             val actions=LinearLayout(this).apply {isBaselineAligned=false}
427:             while(colourHeader.childCount>1) actions.addView(VerticalUi.detach(colourHeader.getChildAt(1)))
428:             colourHeader.orientation=LinearLayout.VERTICAL;colourHeader.addView(actions,LinearLayout.LayoutParams(-2,-2))
429:         }
430:         colours.addView(HorizontalScrollView(this).apply {addView(colourHeader)})
431:         makePalette(colours);makeCustomPalette(colours)

1525:                     paintCanvas.cursorShape=position;paintCanvas.invalidate();scheduleAutosave()
1526:                 }
1527:             }

1543:     private fun showDrawingSettings(preview: Boolean) {
1544:         val column=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(8),dp(18),dp(8))}
1545:         fun toggle(title: String,value: Boolean,controlTag: String?=null,change: (Boolean)->Unit) {
1546:             column.addView(CheckBox(this).apply {tag=controlTag;text=title;isChecked=value;setOnCheckedChangeListener {_,on -> change(on);paintCanvas.invalidate();scheduleAutosave()} })

772:                     document.cornerRadius=it.toFloat();paintCanvas.invalidate()
773:                 }

774:                 if (tool == PaintTool.WATERCOLOR) addSlider(ui(R.string.ui_strength),document.watercolorStrength,100,1,"watercolor_strength") { document.watercolorStrength=it }

416:         val colourHeader=LinearLayout(this).apply {isBaselineAligned=false;gravity=Gravity.CENTER_VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_LTR}

1236:             val name = data?.getStringExtra("assembly_output")
1237:             val file = name?.let { File(filesDir,it) }
1238:             if (file == null || file.parentFile != filesDir || !file.name.startsWith("assembly-output-") || !file.isFile) { message(ui(R.string.ui_the_assembly_output_is_unavailable_reopen_image_assembly)); return }
1239:             readImage(Uri.fromFile(file),false,asEdit = true,deleteAfterCopy = true); return
1240:         }
1241:         val uri = data?.data ?: data?.clipData?.getItemAt(0)?.uri
1242:         if (uri == null) { message(ui(R.string.ui_the_picker_returned_no_file_please_choose_the)); afterSave = null; return }
1243:         when (requestCode) {
1244:             OPEN_IMAGE, IMPORT_IMAGE -> readImage(uri, requestCode == IMPORT_IMAGE)
1245:             SAVE_IMAGE -> {
1246:                 if(!isExporting) try {
1247:                     val flags=(data?.flags ?: 0) and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
1248:                     if(flags!=0) contentResolver.takePersistableUriPermission(uri,flags)
1249:                 } catch(_: SecurityException) { /* Some providers grant session-only access. */ }
1250:                 writeImage(uri)

1259:         worker.execute {
1260:             var temporary: File? = null
1261:             try {
1262:                 val cached = File.createTempFile("classic-import-", ".image", cacheDir)
1263:                 temporary = cached
1264:                 contentResolver.openInputStream(uri)?.use { ImportFiles.copy(it,cached) }
1265:                     ?: throw IOException(ui(R.string.ui_the_selected_provider_did_not_return_any_image))
1266:                 val name=if(asEdit) ui(R.string.ui_assembly_png) else displayName(uri)
1267:                 if(deleteAfterCopy) File(uri.path!!).delete()
1268:                 temporary=null
1269:                 runOnUiThread {
1270:                     if(isDestroyed || isFinishing) cached.delete()
1271:                     else {
1272:                         val selection=ImportSelection(this,worker,{document.residentPixels},

1418:         recentColours.add(colour);refreshRecentColours();updateColours()
1419:     }
1420:     private fun refreshRecentColours() {
1421:         recentCells.forEachIndexed { index,cell ->
1422:             val colour=recentColours.colours.getOrNull(index)

86:     private lateinit var recentColours: RecentColours
87:     private val recentCells=mutableListOf<View>()
88:     private val customPaletteCells=mutableListOf<SavedColourCell>()
89:     private var fullscreen=false

140:         galleryCreditSessionToken=savedInstanceState?.getString("gallery_credit_session")
141:         // Adoption receipts belong only to this instance's captured document generation.
142:         // Replaying them onto a recovered older draft could release credits never saved there.
143:         recentColours=RecentColours(this)
144:         val prefs=getSharedPreferences("classic-ui",MODE_PRIVATE)
145:         val firstArrowLayout=!prefs.getBoolean("arrow_layout_initialized",false)
146:         sidebarExpanded=firstArrowLayout || prefs.getBoolean("sidebar_expanded",true)

1021:     private fun selectAll() {
1022:         chooseTool(PaintTool.SELECT)
1023:         document.select(RectF(0f,0f,document.bitmap.width.toFloat(),document.bitmap.height.toFloat()))

1112:             legacyCredits=if(ImageCreditArchive.hasRecords(this)) ::showLegacyImageCredits else null).show()
1113:     }
1114:     private fun chooseSaveLocation(proposedName: String=filename) {
1115:         launchPicker(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
1116:             addCategory(Intent.CATEGORY_OPENABLE);type=exportOptions.format.mime
1117:             addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
1118:             putExtra(Intent.EXTRA_TITLE,ExportNames.withExtension(proposedName.ifBlank {ui(R.string.ui_untitled)},exportOptions.format))
1119:         },SAVE_IMAGE)
1120:     }
1121:     override fun onNewIntent(intent: Intent) {
1122:         super.onNewIntent(intent);setIntent(intent)
1123:         if(externalImageUri(intent)==null) return
1124:         if(deferStartupInput()) {enqueueExternalImage(intent);deliverPendingInputs()}
1125:         else handleExternalImage(intent)
1126:     }
