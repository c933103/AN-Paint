129:             val checks = images.map { item -> CheckBox(activity).apply {
130:                 text = item.name; tag = "crop_include_${item.id}"; isChecked = item.id in selected
131:                 setOnCheckedChangeListener { _, checked -> if (checked) selected.add(item.id) else selected.remove(item.id); refresh() }
132:                 body.addView(this)
133:             } }
134:             val actions = LinearLayout(activity)
135:             listOf(ui(R.string.ui_all) to true,ui(R.string.ui_none) to false).forEach { (label,checked) -> actions.addView(Button(activity).apply {
136:                 text = label; isAllCaps = false; tag = if(checked) "crop_all" else "crop_none"; setOnClickListener { checks.forEach { it.isChecked = checked } }
137:             },LinearLayout.LayoutParams(0,-2,1f)) }; body.addView(actions)
138:         }
139:         preview.changed = { rect -> displayValues(rect); refresh(false) }
140:         displayValues(if (images.size == 1) reference.crop else Rect(0,0,reference.dimensions.width,reference.dimensions.height)); refresh()
141:         val dialog = EditorDialogBuilder(activity).setTitle(if (images.size == 1) ui(R.string.ui_crop, reference.name) else ui(R.string.ui_batch_crop_images))
142:             .setView(ScrollView(activity).apply { addView(body) }).setNegativeButton(ui(R.string.ui_cancel),null).setPositiveButton(ui(R.string.ui_apply_crop),null).create()
143:         dialog.setOnShowListener { dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {

144:             try {
145:                 require(selected.isNotEmpty()) { ui(R.string.ui_choose_at_least_one_image) }
146:                 val m = margins() ?: throw IllegalArgumentException(ui(R.string.ui_enter_all_four_trim_amounts))
147:                 val crops = images.filter { it.id in selected }.associate { it.id to m.rect(it.dimensions) }
148:                 apply(crops); dialog.dismiss()
149:             } catch (error: Exception) { status.text = error.message ?: ui(R.string.ui_could_not_apply_the_crop) }
150:         } }; dialog.show(); return dialog

66:             }
67:         })
68:         body.addView(preview,LinearLayout.LayoutParams(-1,dp(200)))
69:         body.addView(TextView(activity).apply { text = ui(R.string.ui_trim_from_the_original_edges_drag_the_handles); textSize = 13f })
70:         val unitRow = RadioGroup(activity).apply { orientation = LinearLayout.HORIZONTAL }
71:         val fields = linkedMapOf<String,EditText>()
72:         val edges = linkedMapOf("left" to R.string.ui_left,"top" to R.string.ui_top,"right" to R.string.ui_right,"bottom" to R.string.ui_bottom)
73:         fun margins(): CropMargins? {
74:             val n = fields.values.map { uiNumber(it.text.toString()) ?: return null }
75:             return CropMargins(n[0],n[1],n[2],n[3],percent)
76:         }
77:         fun displayValues(r: Rect) {
78:             syncing = true
79:             val values = listOf(r.left,r.top,reference.dimensions.width-r.right,reference.dimensions.height-r.bottom)
80:             fields.values.forEachIndexed { i, field ->

151:     }
152: }

17: 
18: class CropPreview(context: Context) : View(context) {
19:     var bitmap: Bitmap? = null
20:     var crop: CropOverlay? = null
21:     var changed: (Rect) -> Unit = {}
22:     private var scale = 1f; private var x = 0f; private var y = 0f
23:     init { isFocusable = true; isClickable = true; contentDescription = ui(R.string.ui_crop_preview_drag_an_edge_or_corner_drag) }
24:     private fun position() {
25:         val size = crop?.image ?: return; val pad = 14 * resources.displayMetrics.density
26:         scale = min((width-2*pad).coerceAtLeast(1f)/size.width,(height-2*pad).coerceAtLeast(1f)/size.height)
27:         x = (width-size.width*scale)/2; y = (height-size.height*scale)/2
28:     }
29:     override fun onDraw(canvas: Canvas) {
30:         canvas.drawColor(EditorColours.surfaceDim); val c = crop ?: return; position()
31:         canvas.save(); canvas.translate(x,y); canvas.scale(scale,scale)

82:                 field.setText(String.format(Locale.ROOT,"%.4f",n).trimEnd('0').trimEnd('.'))
83:             }; syncing = false
84:         }
85:         fun refresh(updatePreview: Boolean = true) {
86:             if (syncing) return
87:             try {
88:                 val m = margins() ?: throw IllegalArgumentException(ui(R.string.ui_enter_a_trim_amount_for_every_edge))
89:                 val crop = m.rect(reference.dimensions)
90:                 if (updatePreview) { preview.bitmap = previewBitmap(reference); preview.crop = CropOverlay(reference.dimensions,crop); preview.invalidate() }
91:                 val count = images.count { it.id in selected }
92:                 images.filter { it.id in selected }.forEach { m.rect(it.dimensions) }
93:                 status.text = activity.resources.getQuantityString(R.plurals.ui_crop_preview_images,count,crop.width(),crop.height(),count)
94:             } catch (error: IllegalArgumentException) { status.text = error.message }
95:         }
96:         listOf(ui(R.string.ui_pixels), ui(R.string.ui_percent)).forEachIndexed { index, name ->

97:             unitRow.addView(RadioButton(activity).apply {
98:                 text = name; id = View.generateViewId(); tag = "crop_${if (index == 0) "pixels" else "percent"}"; isChecked = index == 0
99:                 setOnClickListener {
100:                     unitRow.check(id)
101:                     val previous = try { margins()?.rect(reference.dimensions) } catch (_: IllegalArgumentException) { null }
102:                     percent = index == 1
103:                     if (previous != null) displayValues(previous)
104:                     fields.forEach { (key,field) -> field.contentDescription = ui(if(percent) R.string.ui_trim_in_percent else R.string.ui_trim_in_pixels,ui(edges.getValue(key))) }

119:                         override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { if (fields.size == 4) refresh() }
120:                         override fun afterTextChanged(s: Editable?) = Unit
121:                     })
122:                 }; fields[key] = field; column.addView(field); row.addView(column,LinearLayout.LayoutParams(0,-2,1f))
123:             }; body.addView(row)
124:         }
125:         body.addView(Button(activity).apply { text = ui(R.string.ui_reset_crop); isAllCaps = false; tag = "crop_reset"; setOnClickListener { displayValues(Rect(0,0,reference.dimensions.width,reference.dimensions.height)); refresh() } })
126:         body.addView(status); status.setOnClickListener { refresh() }
127:         if (images.size > 1) {
128:             body.addView(TextView(activity).apply { text = ui(R.string.ui_apply_to_these_images) })
