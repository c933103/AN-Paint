256:     }
257:     private fun read(): List<AssemblyImage> {
258:         val list = JSONObject(saved.readFully().toString(Charsets.UTF_8)).getJSONArray("images")
259:         require(list.length() <= MAX_IMAGES)
260:         return (0 until list.length()).map { i ->
261:             val o = list.getJSONObject(i); val file = File(directory,o.getString("file"))
262:             require(file.canonicalFile.parentFile == directory.canonicalFile && file.isFile) { ui(R.string.ui_an_assembly_source_image_is_missing) }
263:             val c = o.getJSONArray("crop")
264:             AssemblyImage(o.getString("id"),file,o.getString("name"),if (o.isNull("time")) null else o.getLong("time"),
265:                 ImageDimensions(o.getInt("width"),o.getInt("height")),Rect(c.getInt(0),c.getInt(1),c.getInt(2),c.getInt(3)),
266:                 if (o.optBoolean("placed")) Attachment(if (o.isNull("anchor")) null else o.getString("anchor"),if (o.isNull("edge")) null else SnapEdge.valueOf(o.getString("edge"))) else null,
267:                 if (o.has("normalize_axis")) ImageNormalization(NormalizeAxis.valueOf(o.getString("normalize_axis")),o.getInt("normalize_pixels")) else null,o.optInt("page",0),
268:                 if (o.has("position")) o.getJSONArray("position").let { p ->
269:                     require(p.length() == 2)
270:                     fun coordinate(index: Int): Int {

43:         fun amount(n: Double, base: Int): Int {
44:             val p = if (percent) n * base / 100 else n
45:             require(p <= base && (percent || n == kotlin.math.floor(n))) { ui(R.string.ui_trim_amounts_must_fit_inside_each_image_use) }
46:             return p.roundToInt()
47:         }
48:         val r = Rect(amount(left,size.width),amount(top,size.height),size.width-amount(right,size.width),size.height-amount(bottom,size.height))
49:         require(r.width() > 0 && r.height() > 0) { ui(R.string.ui_the_trim_would_remove_the_entire_image) }
50:         return r
51:     }
52: }
53: 
54: /** Original files stay on disk. Crops and attachments are reversible metadata edits. */
55: class ImageAssembly(val directory: File) {
56:     companion object { const val MAX_IMAGES = 20 }
57:     private val saved = AtomicFile(File(directory,"project.json"))

149:             done.add(item.id); pending.remove(item)
150:         }
151:         validate(next); return next
152:     }
153:     fun clear() = change(emptyList())
154:     fun crop(ids: Set<String>, margins: CropMargins) {
155:         require(ids.isNotEmpty()) { ui(R.string.ui_choose_at_least_one_image) }
156:         change(state.map { if (it.id in ids) it.copy(crop = margins.rect(it.dimensions)) else it })
157:     }
158:     fun crop(id: String, rect: Rect) = change(state.map { if (it.id == id) it.copy(crop = Rect(rect)) else it })
159:     fun crop(crops: Map<String,Rect>) = change(state.map { item -> crops[item.id]?.let { item.copy(crop = Rect(it)) } ?: item })
160:     fun place(id: String, attachment: Attachment) {
161:         val next = detached(id).map { if (it.id == id) it.copy(attachment = attachment,position = null) else it }
162:         validateSnapPlacement(id,next); change(next)
163:     }

23:     val croppedSize get() = ImageDimensions(crop.width(),crop.height())
24:     val placedSize: ImageDimensions get() {
25:         val n = normalization ?: return croppedSize
26:         require(n.pixels > 0) { ui(R.string.ui_use_a_positive_target_dimension) }
27:         val base = if (n.axis == NormalizeAxis.WIDTH) crop.width() else crop.height()
28:         val other = if (n.axis == NormalizeAxis.WIDTH) crop.height() else crop.width()
29:         require(base > 0 && other > 0) { ui(R.string.ui_the_crop_must_contain_at_least_one_pixel) }
30:         val scaled = (other.toLong()*n.pixels+base/2)/base
31:         require(scaled in 1..Int.MAX_VALUE.toLong()) { ui(R.string.ui_the_normalized_image_dimensions_are_outside_android_s) }
32:         return if (n.axis == NormalizeAxis.WIDTH) ImageDimensions(n.pixels,scaled.toInt()) else ImageDimensions(scaled.toInt(),n.pixels)
33:     }
34: }
35: data class SnapTarget(val attachment: Attachment, val rect: Rect)
36: enum class AssemblySort(private val labelId: Int) { NAME_ASC(R.string.ui_filename_a_z), NAME_DESC(R.string.ui_filename_z_a), OLDEST(R.string.ui_modified_oldest_first), NEWEST(R.string.ui_modified_newest_first);
37:     val label: String get() = ui(labelId)

217:         }
218:         items.filter { it.isPlaced }.forEach { resolve(it) }; return result
219:     }
220:     private fun validate(items: List<AssemblyImage>) {
221:         require(items.size <= MAX_IMAGES && items.map { it.id }.distinct().size == items.size)
222:         require(items.count { it.attachment != null && it.attachment.anchor == null } <= 1) { ui(R.string.ui_the_first_image_starts_at_the_top_left) }
223:         items.forEach { require(it.attachment == null || it.position == null) { ui(R.string.ui_invalid_image_attachments) }; require(it.crop.left >= 0 && it.crop.top >= 0 && it.crop.right <= it.dimensions.width && it.crop.bottom <= it.dimensions.height && it.crop.width() > 0 && it.crop.height() > 0) { ui(R.string.ui_the_crop_must_stay_inside_the_image) }; it.placedSize }
224:         val rects = layout(items)
225:         val snapped = items.filter { it.attachment != null }
226:         for (i in snapped.indices) for (j in i+1 until snapped.size) require(!Rect.intersects(rects.getValue(snapped[i].id),rects.getValue(snapped[j].id))) { ui(R.string.ui_that_arrangement_overlaps_another_image_use_a_different) }
227:     }
228:     private fun validateSnapPlacement(id: String, items: List<AssemblyImage>) {
229:         validate(items)
230:         val rects = layout(items); val target = rects.getValue(id)
231:         require(rects.none { (other,rect) -> other != id && Rect.intersects(target,rect) }) { ui(R.string.ui_that_arrangement_overlaps_another_image_use_a_different) }

38: }
39: data class CropMargins(val left: Double, val top: Double, val right: Double, val bottom: Double, val percent: Boolean) {
40:     fun rect(size: ImageDimensions): Rect {
41:         val values = listOf(left,top,right,bottom)
42:         require(values.all { it.isFinite() && it >= 0 }) { ui(R.string.ui_trim_amounts_must_be_zero_or_greater) }

20:     val dimensions: ImageDimensions, val crop: Rect = Rect(0,0,dimensions.width,dimensions.height), val attachment: Attachment? = null, val normalization: ImageNormalization? = null,val pageIndex: Int = 0, val position: ImagePosition? = null) {
21:     init {require(pageIndex>=0)}
22:     val isPlaced get() = attachment != null || position != null
