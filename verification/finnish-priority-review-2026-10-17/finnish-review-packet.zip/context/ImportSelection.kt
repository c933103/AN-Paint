86:             } catch(error: Exception) {fail(error)} catch(error: OutOfMemoryError) {fail(error)}
87:         }
88:     }
89:     private fun showAnimation(info: AnimationInfo) {
90:         val frames=if(info.frameCountExact) info.frameCount.toString() else ui(R.string.formats22_at_least_frames,info.frameCount)
91:         val message=if(info.frameCount<2) ui(R.string.formats22_animation_unknown,info.format) else
92:             ui(R.string.formats22_animation_message,info.format,frames)+"\n\n"+
93:                 ui(if(info.pngDefaultImageSeparate) R.string.formats22_animation_poster else R.string.formats22_animation_still)
94:         dialog=EditorDialogBuilder(activity).setTitle(ui(if(info.frameCount<2) R.string.formats22_open_still else R.string.formats22_animation_title)).setMessage(message)
95:             .setPositiveButton(ui(R.string.formats22_open_still)) {_,_->finishSelection(0)}
96:             .setNegativeButton(ui(R.string.ui_cancel)) {_,_->cancel()}.setOnCancelListener {cancel()}.show()
97:     }
98:     private fun showPages(kind: String,count: Int) {
99:         require(count>0)
100:         val body=LinearLayout(activity).apply {orientation=LinearLayout.VERTICAL;setPadding(24,12,24,12)}

101:         body.addView(TextView(activity).apply {text=ui(R.string.formats22_page_description,kind,name,count)})

102:         if(kind=="PDF") body.addView(TextView(activity).apply {text=ui(R.string.formats22_pdf_raster_hint)})

85:                 }

103:         val row=LinearLayout(activity).apply {gravity=Gravity.CENTER_VERTICAL}

104:         val previous=Button(activity).apply {text="‹";contentDescription=ui(R.string.formats22_previous_page);tag="import_previous_page"}
105:         val field=EditText(activity).apply {tag="import_page_number";LocaleNumberInput.configure(this);setSingleLine(true);contentDescription=ui(R.string.formats22_page_number);setText("1");selectAll()}
106:         val next=Button(activity).apply {text="›";contentDescription=ui(R.string.formats22_next_page);tag="import_next_page"}
107:         val buttonWidth=(56*activity.resources.displayMetrics.density).toInt()
108:         row.addView(previous,LinearLayout.LayoutParams(buttonWidth,-2));row.addView(field,LinearLayout.LayoutParams(0,-2,1f));row.addView(next,LinearLayout.LayoutParams(buttonWidth,-2));body.addView(row)
109:         val status=TextView(activity).apply {tag="import_page_status"};body.addView(status)
110:         val image=ImageView(activity).apply {tag="import_page_preview";adjustViewBounds=true;scaleType=ImageView.ScaleType.FIT_CENTER;contentDescription=ui(R.string.formats22_page_preview)}

20:     fun copy(input: InputStream, destination: File) {
21:         destination.outputStream().use { output ->
22:             val buffer=ByteArray(64*1024);var total=0L
23:             while(true) {
24:                 val count=input.read(buffer);if(count<0) break
25:                 total+=count
26:                 if(total>MAX_BYTES) throw IOException(ui(R.string.formats22_import_limit))
27:                 output.write(buffer,0,count)
28:             }
29:         }
30:     }
31:     fun normalize(file: File) {
32:         if(TextImageCodec.inspect(file)) TextImageCodec.decodeToFile(file,file,MAX_BYTES)
33:     }
34: }

111:         previewView=image
112:         body.addView(image,LinearLayout.LayoutParams(-1,(220*activity.resources.displayMetrics.density).toInt()))
113:         val chooser=EditorDialogBuilder(activity).setTitle(ui(R.string.formats22_select_page))
114:             .setView(ScrollView(activity).apply {addView(body)})
115:             .setPositiveButton(ui(R.string.formats22_open_page),null)
116:             .setNegativeButton(ui(R.string.ui_cancel)) {_,_->cancel()}.setOnCancelListener {cancel()}.create()
117:         dialog=chooser
118:         fun page()=field.text.toString().toIntOrNull()?.takeIf {it in 1..count}
119:         fun update() {
120:             val value=page();val ticket=++generation
121:             previous.isEnabled=value!=null && value>1;next.isEnabled=value!=null && value<count
122:             chooser.getButton(AlertDialog.BUTTON_POSITIVE)?.isEnabled=value!=null
123:             image.setImageDrawable(null);releasePreview()
124:             if(value==null) {status.text=ui(R.string.formats22_page_range,count);return}
