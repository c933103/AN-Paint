142:                 spray(previous); invalidate(); postDelayed(this, 40)
143:             }
144:         }
145:     }
146: 
147:     init {
148:         contentDescription = ui(R.string.ui_drawing_canvas_pinch_and_move_two_fingers_to)
149:         isFocusable = true
150:         setLayerType(LAYER_TYPE_SOFTWARE, null)
151:     }
152: 
153:     fun selectTool(next: PaintTool) {
154:         applyPending()
155:         if(next!=tool) cursorDrawing=false
156:         if (next !in listOf(PaintTool.SELECT, PaintTool.LASSO)) document.finishSelection()

574:         val grip=rotationHandle(s);val top=s.geometry.point(s.rect.centerX(),s.rect.top)
575:         canvas.drawLine(top.x,top.y,grip.x,grip.y,edge)
576:         canvas.drawCircle(grip.x,grip.y,7*d,fill);canvas.drawCircle(grip.x,grip.y,7*d,edge)
577:         val direction=VerticalText.uiDirection(context)
578:         if(direction==TextDirection.HORIZONTAL) {
579:             val text=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=edge.color;textSize=11*resources.displayMetrics.scaledDensity/zoom;typeface=VerticalText.uiTypeface(context) }
580:             canvas.drawText(ui(R.string.ui_rotate),grip.x+10*d,grip.y+4*d,text)
581:         } else {
582:             // The caller is already in document coordinates. Counter-scale only
583:             // this caption so even a 1e-9 zoom uses ordinary pixel font metrics.
584:             val pixels=resources.displayMetrics.density
585:             val text=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=edge.color;textSize=11*resources.displayMetrics.scaledDensity;typeface=VerticalText.uiTypeface(context) }
586:             val viewport=RectF(rulerInset,rulerInset,width-bar,height-bar).apply {inset(4*pixels,4*pixels)}
587:             val caption=VerticalCanvasCaption(ui(R.string.ui_rotate),text,viewport.height(),direction)
588:             val screen=toScreen(grip.x,grip.y)

589:             val selection=s.geometry.bounds()
590:             val first=toScreen(selection.left,selection.top);val last=toScreen(selection.right,selection.bottom)
591:             // Include resize-box half-width, outline stroke and antialias clearance.
592:             val avoid=RectF(first.x,first.y,last.x,last.y).apply {inset(-7*pixels,-7*pixels)}
593:             val origin=caption.beside(screen,viewport,10*pixels,avoid)
594:             canvas.save();canvas.translate(grip.x,grip.y);canvas.scale(1/zoom,1/zoom)
595:             caption.draw(canvas,origin.x-screen.x,origin.y-screen.y)
