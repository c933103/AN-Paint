149:             text = ui(R.string.language20_translation_note)
150:             val padding = (20 * resources.displayMetrics.density).toInt()
151:             setPadding(padding, padding, padding, padding / 2)
152:             LocaleTypography.typeface(activity)?.let {typeface=it}
153:             VerticalUi.caption(this,128)
154:         }
155:         return AlertDialog.Builder(activity).setTitle(ui(R.string.language20_app_language))
156:             .setCustomTitle(if(VerticalText.uiVertical(activity)) ColumnScrollView(activity).apply {addView(note)} else note)
157:             .setSingleChoiceItems(object: android.widget.ArrayAdapter<String>(activity,android.R.layout.simple_list_item_single_choice,labels) {
158:                 override fun getView(position: Int,convertView: android.view.View?,parent: android.view.ViewGroup): android.view.View {
159:                     // Script-specific rows are never recycled as ordinary horizontal rows.
160:                     val view=super.getView(position,null,parent) as TextView
161:                     val locale=if(position==0) deviceLanguage else Locale.forLanguageTag(choices[position])
162:                     view.textLocale=locale
163:                     VerticalUi.languageChoice(view,locale)

133:         return context.createConfigurationContext(config).getString(R.string.language20_device_default)
134:     }
135: 
136:     fun showSettings(activity: Activity, changed: () -> Unit) {
137:         val current = selectedTag(activity).let { if (it.isEmpty()) deviceDefaultLabel(activity) else name(it) }
138:         EditorDialogBuilder(activity).setTitle(ui(R.string.language20_settings))
139:             .setItems(arrayOf(ui(R.string.language20_current, current))) { _, _ -> showPicker(activity, changed) }
140:             .setNegativeButton(ui(R.string.ui_done), null).show()
141:     }
142: 
143:     fun showPicker(activity: Activity, changed: () -> Unit): AlertDialog {
144:         val choices = listOf("") + tags(activity)
145:         // Use one device-locale snapshot for both the label and its row typography.
146:         val deviceLanguage=deviceLocale(activity)
147:         val labels = choices.map { if (it.isEmpty()) deviceDefaultLabel(activity,deviceLanguage) else name(it) }

127:         val resource = resourceLocale(chosen)
128:         val config=Configuration().apply {
129:             fontScale=0f
130:             if(Build.VERSION.SDK_INT>=24) setLocales(LocaleList(resource)) else setLocale(resource)
131:             setLayoutDirection(chosen)
132:         }

148:         val note = TextView(activity).apply {

165:                 }
166:             }, choices.indexOf(selectedTag(activity))) { dialog, which ->
167:                 dialog.dismiss()
168:                 if (choices[which] != selectedTag(activity)) {
169:                     select(activity, choices[which]); refresh(activity); changed()
170:                 }
171:             }.setNegativeButton(ui(R.string.ui_cancel), null).show().also { dialog ->
172:                 val cancel=dialog.getButton(AlertDialog.BUTTON_NEGATIVE)
173:                 LocaleTypography.typeface(activity)?.let {cancel.typeface=it}
174:                 VerticalUi.caption(cancel,96)
175:             }
176:     }
177: }
