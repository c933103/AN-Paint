16: class RasterHistory(parent: File) : Closeable {
17:     data class Entry(val file: File, val width: Int, val height: Int, val imageCredits: List<ImageCredit> = emptyList())
18:     data class Snapshot(val undo: List<Entry> = emptyList(),val redo: List<Entry> = emptyList())
19:     private val directory = File(parent, "session-${UUID.randomUUID()}")
20: 
21:     fun capture(bitmap: Bitmap, imageCredits: List<ImageCredit> = emptyList()): Entry {
22:         if (!directory.isDirectory && !directory.mkdirs()) throw IOException(ui(R.string.ui_cannot_create_the_undo_cache_free_some_device))
23:         val file = File.createTempFile("undo-", ".rgba", directory)
24:         val deflater = Deflater(Deflater.BEST_SPEED)
25:         try {
26:             DataOutputStream(DeflaterOutputStream(BufferedOutputStream(file.outputStream()), deflater)).use { out ->
27:                 out.writeInt(0x50504c34); out.writeInt(bitmap.width); out.writeInt(bitmap.height)
28:                 val bytes = ByteArray(32 * 1024)
29:                 val integers = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asIntBuffer()
30:                 val pixels = IntArray(bytes.size / 4)

45:     }
46: 
47:     /** Import immutable compressed snapshots without allocating all their historical bitmaps. */
48:     fun importSnapshot(input: InputStream,width: Int,height: Int,sha256: String): Entry {
49:         require(width>0 && height>0 && width.toLong()*height<=Int.MAX_VALUE/4)
50:         require(sha256.matches(Regex("[0-9a-f]{64}")))
51:         if(!directory.isDirectory && !directory.mkdirs()) throw IOException(ui(R.string.ui_cannot_create_the_undo_cache_free_some_device))
52:         val file=File.createTempFile("undo-",".rgba",directory)
53:         try {
54:             val digest=java.security.MessageDigest.getInstance("SHA-256")
55:             file.outputStream().buffered().use {out ->
56:                 val buffer=ByteArray(32768)
57:                 while(true) {val n=input.read(buffer);if(n<0)break;out.write(buffer,0,n);digest.update(buffer,0,n)}
58:             }
59:             val actual=digest.digest().joinToString("") {"%02x".format(it.toInt() and 255)}

60:             if(actual!=sha256) throw IOException(ui(R.string.ui_the_undo_cache_is_damaged))
61:             DataInputStream(InflaterInputStream(file.inputStream().buffered())).use {
62:                 if(it.readInt()!=0x50504c34 || it.readInt()!=width || it.readInt()!=height) throw IOException(ui(R.string.ui_the_undo_cache_is_damaged))
63:             }
64:             return Entry(file,width,height)
65:         } catch(error: Throwable) {file.delete();throw error}
66:     }
67: 
68:     fun restore(entry: Entry, current: Bitmap): Bitmap {

69:         // Validate the compressed stream before modifying the current image.
70:         // A reclaimed or damaged cache entry must not leave a partially restored canvas.

75:         catch (error: Throwable) { if (output !== current) output.recycle(); throw error }
76:     }
77: 
78:     private fun read(entry: Entry, bitmap: Bitmap?) {
79:         DataInputStream(InflaterInputStream(BufferedInputStream(entry.file.inputStream()))).use { input ->
80:             if (input.readInt() != 0x50504c34 || input.readInt() != entry.width || input.readInt() != entry.height)
81:                 throw IOException(ui(R.string.ui_the_undo_cache_is_damaged))
82:             val bytes = ByteArray(32 * 1024)
83:             val integers = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asIntBuffer()
84:             val pixels = IntArray(bytes.size / 4)
85:             for (y in 0 until entry.height) {
86:                 var x = 0
87:                 while (x < entry.width) {
88:                     val count = minOf(pixels.size, entry.width - x)
89:                     input.readFully(bytes, 0, count * 4)

91:                         integers.clear(); integers.get(pixels, 0, count)
92:                         bitmap.setPixels(pixels, 0, count, x, y, count, 1)
93:                     }
94:                     x += count
95:                 }
96:             }
97:             if (input.read() != -1) throw IOException(ui(R.string.ui_unexpected_data_in_the_undo_cache))
98:         }
99:     }
100: 
101:     fun discard(entry: Entry) { entry.file.delete() }
102:     override fun close() { directory.deleteRecursively() }
103: }
