10: import org.catrobat.paintroid.R
11: 
12: /** A category remembers its last tool; opening it also makes that tool active. */
13: enum class ToolCategory(val labelId: Int,val tools: List<PaintTool>) {
14:     BRUSH(R.string.ui_drawing23,listOf(PaintTool.PENCIL,PaintTool.BRUSH,PaintTool.WATERCOLOR,PaintTool.SPRAY)),
15:     SELECTION(R.string.ui_category_selection,listOf(PaintTool.SELECT,PaintTool.LASSO)),
16:     INSERT(R.string.ui_category_insert,listOf(PaintTool.LINE,PaintTool.CURVE,PaintTool.RECTANGLE,PaintTool.ROUND_RECT,
17:         PaintTool.ELLIPSE,PaintTool.POLYGON,PaintTool.HEART,PaintTool.STAR,PaintTool.ARROW,PaintTool.TEXT));
18:     companion object { fun forTool(tool: PaintTool)=values().firstOrNull {tool in it.tools} }
19: }
20: 
21: class ToolCategoryButton(context: Context,val category: ToolCategory,var selectedTool: PaintTool,private val down: Boolean): PanelToolButton(context) {
22:     var expanded=false
23:     init {refresh()}
24:     fun refresh() {

9: import android.view.View

25:         text=ui(category.labelId);disclosure=expanded;disclosureBeside=!down
26:         labelledIcon(toolIcon(selectedTool))
27:         contentDescription=ui(if(expanded) R.string.ui_collapse_tool_category else R.string.ui_expand_tool_category,ui(category.labelId),selectedTool.label)
28:         LocaleTooltip.set(this,contentDescription)
29:         invalidate()
30:     }
31: }

8: import android.graphics.Typeface
