40:         return minOf(MAX_BITMAP_PIXELS, (workingBytes - residentBytes).coerceAtLeast(0) / 12)
41:     }
42:     fun check(width: Int, height: Int, residentPixels: Long = 0) {
43:         require(width > 0 && height > 0) { ui(R.string.ui_enter_positive_image_dimensions) }
44:         val pixels = width.toLong() * height.toLong()
45:         val permitted = maxPixels(residentPixels)
46:         if (pixels > permitted) throw ImageSizeException(ui(R.string.ui_d_d_pixels_2f_mp_exceeds_the_current,
47:             width, height, pixels / 1_000_000.0, permitted / 1_000_000.0))
48:     }
49: }
50: class ImageSizeException(message: String) : IllegalArgumentException(message)

37:     }
38:     fun maxPixels(residentPixels: Long = 0): Long {
39:         val residentBytes = residentPixels.coerceIn(0, Long.MAX_VALUE / 4) * 4
