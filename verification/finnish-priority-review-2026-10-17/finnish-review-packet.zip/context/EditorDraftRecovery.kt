33:     var autosaveBlocked=false
34:     var lastAutosaveError: String?=null
35:     var recoveryNotice: String?=null
36:     fun preserveFailedDraft(reason: String) {
37:         try {
38:             autosave.preserveForRecovery(retainOriginal=true)
39:             recoveryNotice=ui(R.string.ui_a_separate_recovery_copy_has_been_kept_use,reason)
40:             draftStatus=ui(R.string.ui_previous_draft_kept_for_recovery)
41:         } catch(_: Exception) {
42:             autosaveBlocked=true
43:             lastAutosaveError=ui(R.string.ui_the_previous_draft_could_not_be_preserved_separately)
44:             draftStatus=ui(R.string.ui_autosave_paused_use_save)
45:             recoveryNotice=ui(R.string.ui_autosave_is_paused_to_protect_that_draft_use,reason)
46:         }
47:     }

48:     try {
49:         val document: PaintDocument
50:         document = PaintDocument(historyDirectory = File(context.cacheDir,"classic-history"),
51:             allocationGuard = { w,h -> checkSize(w,h) }).also {owner=it}
52:         var recovered: JSONObject?=null
53:         var restored=false

26: internal fun recoverEditor(context: Context,autosave: AutosaveStore): AutosaveStore.Recovery<RecoveredEditor> = autosave.recover {
27:     var owner: PaintDocument?=null
28:     fun checkSize(w: Int,h: Int) {ImageMemoryPolicy.forDevice(context).check(w,h,owner?.residentPixels ?: 0)}
29:     var filename=ui(R.string.ui_untitled)
30:     var textSettings=TextSettings()
31:     var savedTarget: SavedTarget?=null
32:     var draftStatus=ui(R.string.ui_draft_not_saved_yet)

76:             document.tolerance=recovered.optDouble("tolerance",0.0).toFloat()
77:             document.watercolorStrength=recovered.optInt("watercolor_strength",50).coerceIn(1,100)
78:             document.strokeSmoothing=recovered.optBoolean("stroke_smoothing")
79:             document.antialiasing=recovered.optBoolean("antialiasing",false)
80:             document.sprayRadius=recovered.optDouble("spray_radius",document.strokeWidth*2.0).toFloat().coerceIn(1f,100f)
81:             if (recovered.optBoolean("dirty")) document.edited()
82:             draftStatus=ui(R.string.ui_draft_restored);restored=true
83:         } catch (_: Exception) { recovered=null;preserveFailedDraft(ui(R.string.ui_the_previous_draft_could_not_be_restored)) }
84:           catch (_: OutOfMemoryError) { recovered=null;preserveFailedDraft(ui(R.string.ui_the_previous_draft_needs_more_memory_to_reopen)) }
85:         if (!restored) {
86:             val recovery=File(context.filesDir,"classic-recovery.png")
87:             if (recovery.isFile) try {
88:                 val bounds=BitmapFactory.Options().apply { inJustDecodeBounds=true }
89:                 BitmapFactory.decodeFile(recovery.path,bounds);checkSize(bounds.outWidth,bounds.outHeight)
90:                 BitmapFactory.decodeFile(recovery.path,BitmapFactory.Options().apply { inMutable=true;inScaled=false })?.let {

91:                     document.replace(it)
92:                     val old=context.getSharedPreferences("classic",Context.MODE_PRIVATE)
93:                     filename=old.getString("filename",ui(R.string.ui_recovered_image)) ?: ui(R.string.ui_recovered_image)
94:                     if (old.getBoolean("dirty",false)) document.edited()
95:                     restored=true;draftStatus=ui(R.string.ui_draft_restored)
96:                 }
97:             } catch (_: Exception) { } catch (_: OutOfMemoryError) { }
98:         }
99: 
100:         RecoveredEditor(document,recovered,restored,filename,textSettings,savedTarget,draftStatus,
101:             autosaveBlocked,lastAutosaveError,recoveryNotice)
102:     } catch(error: Throwable) {owner?.close();throw error}
103: }

58:             savedTarget=SavedTarget.read(recovered.optJSONObject("save_target"))
59:             document.background=recovered.optInt("background",Color.WHITE)
60:             document.replace(draft.image)
61:             draft.history?.let {document.restoreHistory(it)}
62:             if(draft.historyFailed) {
63:                 autosave.preserveForRecovery(retainOriginal=true)
64:                 recoveryNotice=ui(R.string.ui_history_unavailable34)
65:             }
66:             draft.floating?.let { image ->
67:                 val r=recovered!!.getJSONArray("floating_rect")
68:                 document.restoreFloatingSelection(image,RectF(r.getDouble(0).toFloat(),r.getDouble(1).toFloat(),r.getDouble(2).toFloat(),r.getDouble(3).toFloat()),recovered!!.optDouble("floating_rotation",0.0).toFloat(),SelectionOutline.read(recovered!!.optJSONArray("selection_outline")))
69:             }
70:             document.restoreImageCredits(recovered.optJSONObject("image_credits"))
71:             filename=recovered.optString("filename",ui(R.string.ui_recovered_image))
72:             document.foreground=recovered.optInt("foreground",Color.BLACK)

73:             document.strokeWidth=recovered.optDouble("stroke_width",5.0).toFloat()
74:             document.cornerRadius=recovered.optDouble("corner_radius",16.0).toFloat().coerceAtLeast(0f)
75:             document.brushTip=recovered.optInt("brush_tip");document.shapeStyle=recovered.optInt("shape_style")

23:     val recoveryNotice: String?
24: )
25: 
