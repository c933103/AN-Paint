28:             if (points.length()>=4) result.put(JSONObject().put("closed",measure.isClosed).put("points",points))
29:         } while (measure.nextContour())
30:         return result
31:     }
32:     fun read(contours: JSONArray?): Path? {
33:         if (contours==null || contours.length()==0) return null
34:         require(contours.length()<=128) { ui(R.string.ui_invalid_selection_outline) }
35:         var count=0
36:         return Path().apply {
37:             for (i in 0 until contours.length()) {
38:                 val contour=contours.getJSONObject(i);val points=contour.getJSONArray("points")
39:                 require(points.length()>=4 && points.length()%2==0)
40:                 count+=points.length()/2;require(count<=4096)
41:                 fun coordinate(index: Int)=points.getDouble(index).toFloat().also { require(it.isFinite()) }
42:                 moveTo(coordinate(0),coordinate(1))
