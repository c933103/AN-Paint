from pathlib import Path
import json,hashlib,zipfile,re
O=Path(__file__).resolve().parent;S=O/'source';checks=[]
for filename in ('focused-normal','focused-optimized','host-normal','host-optimized','ico-optimized-retry'):
 text=(O/(filename+'.log')).read_text();m=re.search(r'^Ran (\d+) tests in ([\d.]+)s$',text,re.M)
 if not m:raise RuntimeError('Unfinished '+filename)
 status='passed' if re.search(r'^OK$',text,re.M) else 'failed'
 checks.append({'check':filename,'status':status,'tests':int(m[1]),'seconds':float(m[2]),'log':filename+'.log'})
checks.extend([
 {'check':'Initial optimized aggregate','status':'failed','tests':918,'failure_count':5,'diagnostic':'host-optimized-initial-diagnostic.json','limit':'Complete initial raw log was inadvertently overwritten; captured failure details are preserved and explicitly distinguished.'},
 {'check':'Full AAPT2 compile/exact-script mirrors/link','status':'passed','commands':'resource-check/commands.json'},
 {'check':'Supplementary changed Kotlin/API35 test compilation','status':'passed','commands':'kotlin-compile.json','limit':'Fresh resource symbols and existing compiled dependencies; not full Gradle/runtime'},
 {'check':'Complete catalogue structure','status':'passed','log':'catalogue-validation.log'},
 {'check':'Full-source/review evidence validation','status':'passed','logs':['review-validation-normal.log','review-validation-optimized.log']},
 {'check':'Remote source content/type/mode equality','status':'passed','receipt':'remote-tree-verification.json'}
])
summary={'source_revision':'b6a99b41c4390ca6a412e3a1938eb913c59509fb','application_head':'69fe1495d4468fc028cf1bc30bdac35e70e6cdf0','application_tree':'c723db3d5e2c3202ea24c021f6a3e3574e840a83','checks':checks,'optimized_retry_environment':{'JAVA_TOOL_OPTIONS':'-XX:-UsePerfData','scope':'Local diagnostic retry only; no production/workflow/assertion changes.'},'not_run_locally':['Full Gradle/Robolectric/lint build: distribution download Network is unreachable','Installed emulator/device/TalkBack','APK/signature/source-delivery acceptance'],'hosted':{'status':'in_progress','run_id':39070781922,'run_url':'https://github.com/c933103/AN-Paint/actions/runs/39070781922','pull_request':'https://github.com/c933103/AN-Paint/pull/126','draft':True}}
(O/'test-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files=['README.md','test-summary.json','finnish-p0-p1-review.json','corrections.json','decisions.tsv','prior-receipts.json','independent-review.md','claim-check.json','base-tree.json','source-manifest.json','candidate-files.json','candidate-tree.txt','baseline-finnish.xml','application.patch','remote-tree-verification.json','review-validation.json','review-validation-normal.log','review-validation-optimized.log','verify_review.py','prepare_review.py','pairs.py','pairs.json','pairs.txt','focused-normal.log','focused-optimized.log','host-normal.log','host-normal.exit','host-optimized.log','host-optimized.exit','host-optimized-initial.exit','host-optimized-initial-diagnostic.json','ico-optimized-retry.log','ico-optimized-retry.exit','catalogue-validation.log','compile.log','compile.exit','kotlin-compile.log','kotlin-compile.json','verify_compile.py','resource-check/commands.json','resource-check/compile.log','resource-check/compile-mirrors.log','resource-check/link.log','gradle-attempt.log','gradle-attempt.exit','make_packet.py']
files += [str(p.relative_to(O)) for p in sorted((O/'context').glob('*.kt'))]
files += ['source/'+p for p in ['AGENTS.md','CI.md','TRANSLATING.md','translations/STRING_IMPORTANCE.md','translations/string-importance.json','Paintroid/src/main/res/values/strings.xml','Paintroid/src/main/res/values-fi/strings.xml','Paintroid/src/test/java/org/catrobat/paintroid/local/FinnishPriorityWordingTest.kt','tools/test_finnish_priority_wording.py','tools/fixtures/current_localization/finnish_priority_current_wording.json']]
manifest={p:hashlib.sha256((O/p).read_bytes()).hexdigest()for p in files}
(O/'packet-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');files.append('packet-manifest.json')
with zipfile.ZipFile(O/'finnish-review-packet.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(O/p,p)
with zipfile.ZipFile(O/'finnish-review-packet.zip') as z:
 for p,sha in manifest.items():
  if hashlib.sha256(z.read(p)).hexdigest()!=sha:raise RuntimeError('Packet mismatch '+p)
(O/'packet.sha256').write_text(hashlib.sha256((O/'finnish-review-packet.zip').read_bytes()).hexdigest()+'  finnish-review-packet.zip\n')
print('Archive files',len(files),'bytes',(O/'finnish-review-packet.zip').stat().st_size)
