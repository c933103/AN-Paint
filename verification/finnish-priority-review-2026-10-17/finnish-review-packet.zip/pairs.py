from pathlib import Path
import json,re,xml.etree.ElementTree as E,hashlib
O=Path(__file__).resolve().parent;S=O/'source'
def cat(path):
 return {e.tag+'/'+e.get('name'):{'value': ''.join(e.itertext()) if e.tag=='string' else {q.get('quantity'):''.join(q.itertext()) for q in e},'attrs':dict(e.attrib)} for e in E.parse(path).getroot() if e.tag in ('string','plurals')}
en=cat(S/'Paintroid/src/main/res/values/strings.xml');eo=cat(S/'Paintroid/src/main/res/values-fi/strings.xml');pri=json.load(open(S/'translations/string-importance.json'))
files={str(p.relative_to(S)):p.read_text().splitlines() for p in S.rglob('*') if p.suffix in ('.kt','.java','.xml','.html','.js') and '/main/' in str(p) and '/res/values' not in str(p) and '/res/drawable' not in str(p)}
pairs=[];ctx={}
for tier in pri['tiers']:
 if tier['id'] not in ('P0','P1'):continue
 for key in tier['keys']:
  name=key.split('/')[1];refs=[]
  for f,ls in files.items():
   for i,line in enumerate(ls):
    if re.search(r'(?:R\.(?:string|plurals)\.|@(?:string|plurals)/)'+re.escape(name)+r'\b',line):refs.append({'path':f,'line':i+1});ctx.setdefault(f,[]).append((i,name))
  pairs.append({'n':len(pairs)+1,'tier':tier['id'],'key':key,'english':en[key],'finnish':eo.get(key),'refs':refs})
(O/'pairs.json').write_text(json.dumps(pairs,ensure_ascii=False,indent=2)+'\n')
(O/'pairs.txt').write_text('\n\n'.join(f"{r['n']} {r['tier']} {r['key']}\nEN: {r['english']['value']}\nFI: {r['finnish']['value'] if r['finnish'] else None}\nCALLS: "+', '.join(Path(x['path']).name+':'+str(x['line']) for x in r['refs']) for r in pairs)+'\n')
for f,locs in ctx.items():
 seen=set();out=[]
 for i,name in locs:
  rg=range(max(0,i-6),min(len(files[f]),i+9));chunk=[f'{j+1}: {files[f][j]}' for j in rg if j not in seen];seen.update(rg)
  if chunk:out.append('\n'.join(chunk))
 p=O/'context'/Path(f).name;p.parent.mkdir(exist_ok=True);p.write_text('\n\n'.join(out)+'\n')
print('pairs',len(pairs),'missing',sum(r['finnish'] is None for r in pairs),'no refs',sum(not r['refs'] for r in pairs))
