"""Read-only audit of the exact PR43 release APK's Korean canonical/private tables."""
from pathlib import Path
import hashlib, json, re, subprocess, sys, xml.etree.ElementTree as ET

apk, source, out = map(Path, sys.argv[1:])
tool = Path('/workspace/shared/anpaint-pr34-runtime-f02c/apk/verification-tools/aapt2')
expected_tool = 'd1096e11aba9c974644369ee3c50d239acac3f3428ffa928e5b9c14dfb7a57de'
assert hashlib.sha256(tool.read_bytes()).hexdigest() == expected_tool
out.mkdir(parents=True, exist_ok=True)
for mode in ('configurations', 'resources'):
    with (out / f'{mode}.txt').open('w') as stream:
        subprocess.run([str(tool), 'dump', mode, str(apk)], check=True, stdout=stream)
assert 'b+ko+Kore+KR+anpaint' in (out / 'configurations.txt').read_text().splitlines()
text = (out / 'resources.txt').read_text()
matched = []
tiff = None
for block in re.split(r'(?m)^    resource ', text)[1:]:
    header, values = block.split('\n', 1)
    groups = re.split(r'(?m)^      \(([^\n)]*)\) ', values)
    configs = {groups[i]: groups[i+1].rstrip() for i in range(1, len(groups)-1, 2)}
    canonical = 'b+ko+Kore+KR'
    variant = canonical + '+anpaint'
    if canonical in configs or variant in configs:
        assert configs.get(canonical) == configs.get(variant), header
        matched.append({'resource': header, 'compiled_value_sha256': hashlib.sha256(configs[canonical].encode()).hexdigest()})
    if header.split()[-1] == 'string/formats22_tiff_description':
        tiff = {canonical: configs[canonical], variant: configs[variant]}
nodes = ET.parse(source).getroot()
assert len(matched) == len(nodes) == 695
expected = next(n.text for n in nodes if n.attrib.get('name') == 'formats22_tiff_description')
assert expected == 'RGB 한 페이지를 貯藏합니다. 壓縮은 픽셀을 바꾸지 않고 파일 크기를 줄일 수 있습니다. 壓縮하지 않은 TIFF로 貯藏하려면 끄세요.'
assert tiff and all(json.loads(v) == expected for v in tiff.values()), tiff
result = {
    'head': '4f9082aa687a5c36b559061bcc10d0e39331610f',
    'tested_merge': '73fff41dee17c49a972825c90bdcd88e38287911',
    'source_tree': '04a84df1535297f13a314c521b55647f6d15a678',
    'run_id': 38049772357,
    'apk_sha256': hashlib.sha256(apk.read_bytes()).hexdigest(),
    'canonical_and_variant_equal_resource_count': len(matched),
    'canonical_xml_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'aapt2_sha256': expected_tool,
    'resources_dump_sha256': hashlib.sha256((out/'resources.txt').read_bytes()).hexdigest(),
    'configurations_dump_sha256': hashlib.sha256((out/'configurations.txt').read_bytes()).hexdigest(),
    'tiff_compiled_values': tiff,
    'matching_resources': matched,
    'limits': 'Compiled-resource equality is not installed localized TIFF-dialog rendering or native-speaker acceptance.'
}
(out / 'packaged-resources-verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
print('All 695 compiled canonical/private entries match; both contain the exact qualified Hanja TIFF clause.')
