# PR43 and standalone C023 integrated-source preparation

10 October 2026. This is bounded source/host preparation, not current-base Android, Codex, native-language or merge acceptance. No existing PR source ref is changed by this evidence publication.

## Exact inputs and candidate trees

- Frozen prior PR34 dependency: `5703a61394791f18e9f2597272d908d9840599af`.
- Frozen PR43 head: `4f9082aa687a5c36b559061bcc10d0e39331610f`, tree `04a84df1535297f13a314c521b55647f6d15a678`.
- Standalone C023 commit: `13edc0e81af1ca1561ee2dabedc17959cd85adc0`, tree `23a3a102a58c3c18402225a41a1399a049ecac48`, sole parent frozen PR43.
- PR34/PR41 composition input: tree `6d6b90c1999d9e771970ab08e4c275e999c446ca`, based on PR34 `aa266c2cc8538a04724d06d3b207873c89c342d1` and PR41 `2e512e0c7817cd66a3ec54ca567fc154ea6c83b2`. The actual published PR34 integration commit was independently fetched and verified as `739a3dcf1a59785d98a5f5a00f4b76a1b00e6472`, with this exact tree and ordered parents `aa266c2c` and actual develop `a758daceda1d4fc37c605e50715f892557da9fc8`. Its combined release/API30+35 run [38073935029](https://github.com/c933103/AN-Paint/actions/runs/38073935029) is pending; publication is not merge acceptance.
- PR43-only composed tree: `15211fc67f84ca09ec4647cc9eab7d6ead3a7146`.
- Combined PR43 + C023 composed tree: `a9077243b9d5d601c86b872b1a03cb78bcc36dea`.

The original 43-path PR43 delta and exact 14-path C023 source/evidence increment apply without conflicts. Every touched preimage and resulting mode/blob equals its original reviewed delta. There were no conflict resolutions or additional semantic edits. The combined candidate has 1,485 paths, of which 1,430 input-partition paths remain unchanged; the incremental delta has 55 paths, with no deletions or mode changes. C023's increment consists of five source/test paths and nine original evidence paths, preserved exactly.

The production delta is the original 37 TIFF-description substitutions plus C023's one-line `багасгана` → `багасгаж магадгүй` replacement. C023 remains separately attributable. No other production resource or implementation is altered by these overlays.

## Preservation and replay

- Original 37-entry fixture SHA256: `9cead98f8f826c5c853f4b0dc6cd6b80f8760274770a00f600c690d44fba0ac1`.
- Independent one-entry C023 fixture SHA256: `d2dcbbeaef13c80ae9dfe4d1ec9595c8ba82cbe92d057479f5b25e4deba3d6c4`.
- Original Copy-credit historical scope SHA256: `0dcb4ec97a3a2033d197ece7b77b43f55054fb4c806b02f377880eb31c8171bc`.
- Existing Android instrumentation sources, runner, workflow, exact-script generation and packaged-resource assertion files are byte-identical to the partition input.
- Every prior verification file inherited from that input remains byte-identical.

The archived `composition-manifest.json` gives the mode, Git blob and origin of all 1,485 paths. `check_composition.py` checks exact before/after identities and preserves every unrelated path. Four binary-capable patches were reapplied through independent Git indexes and reproduced their intended trees: PR43 on partition, C023 on PR43-partition, both increments on partition, and the complete integration from frozen original PR43. The large last patch retains 17 inherited whitespace lines in immutable PR34 log evidence; the new 55-path incremental diff passes whitespace checks.

The original PR43 212 embedded negative controls and eight separate C023 controls remain in the tests. These reject unrelated resources, original-TIFF reversions/corruption/deletion/duplication, emoji prefix loss, altered fixture scope, and C023 reversion/corruption/deletion/duplication or unrelated content.

## Fresh local receipts

Full host suite: **483 tests passed in 162.796 seconds**, with zero failures, errors or skips. Command: `python3 -m unittest discover -s tools -p 'test_*.py' -v`. Deliberately rejected fake instrumentation summaries in the log are host negative controls, not executed device failures.

Focused TIFF/Copy-credit checks passed all 26 methods in normal (0.692 s), `-O` (0.861 s) and `PYTHONOPTIMIZE=1` (0.713 s) modes. This includes all nine separate C023 host methods. Canonical catalogue structural validation, shell syntax, Python compilation and incremental diff checks passed.

Actual-history PR7/PR9 replay passed in all three interpreter modes, with identical output SHA256 `aef671a270f61d1168f71ee3d9c2d4abc52dc344357edd65e0f88737d71b4c5b`. Comparison with the input-partition replay shows exactly 12 differences, all current-catalogue SHA256 values changed by original PR43 substitutions. The historical comparisons, recorded receipt pins, guards and status conclusions are unchanged. This is a new current-source replay, not a relabeling of the prior output.

There is no local Android SDK, adb or installed Gradle. These are host/source and fake-ADB tests. They do not compile or run Kotlin, build APKs, execute instrumentation, run lint, or inspect rendered pixels. The original nine F01 JVM methods and the two C023 methods are all preserved; all 11 still need execution on the final published source.

## Current-base acceptance still required

The source inventory is unchanged from the input partition:

- API30: 73 native + 15 ordinary + 3 gallery + 2 + 2 vertical = 95 installed methods. The app union is 22, with the existing one SDK-suppressed method and explicit restart exclusions.
- API35: 74 native + 16 ordinary + 3 gallery + 2 + 2 vertical + 1 seed + 1 verify = 99 installed methods. The app union is 25.
- App instrumentation source SHA256 stays `d8e7d5179f36028d9c25532f357ca08f062a95d046db08a415c570cd8ce1446c`.
- Existing API35 inner ceilings total 930 seconds before overhead versus the unchanged 900-second outer step; job cap remains 25 minutes. No timeouts, thresholds or assertions were relaxed. Ordinary/gallery margin targets remain 30/20 seconds.

Before a PR43 ref update, verify the actual integrated PR34 commit and its complete tree, coordinate the target branch, and reproduce this composition if source differs. Preserve frozen PR43 and standalone C023 ancestry as separate evidence. After exact-source publication and remote path/mode/blob readback, request fresh Codex review and applicable release-configured API30/API35 CI. Require all 11 F01 JVM methods, both 26-locale loops, full host/JVM/lint, all seven generation probes, independent compiled resource/APK/source binding, every composed installed phase, original Korean/font/navigation assertions, all original 32+64 locale images and eight reachability receipts, and actual-pixel review. Inspect real elapsed times and diagnose inadequate margin; standalone passes do not establish this combined acceptance.

Original PR43 attempt 1 release-build timeout and earlier Hanja routing failure remain failures. Attempt 2 run 38049772357 and its successful 775-JVM/original-nine-F01/seven-generator/API30+35 evidence remain scoped to frozen PR43, never the new candidate. PR34/PR41 standalone failures and passes are likewise retained with their original scope.

The original 475 register rows / 3 structural completions / 472 pending, 12 probable and four uncertain language findings remain unchanged/open. No native-speaker, complete-language, installed TIFF-dialog visual/accessibility or broad localization acceptance is claimed. The standalone C023 source/host proposal and its original evidence remain a distinct increment, not a rewrite of the frozen 37-entry scope or historical findings.
