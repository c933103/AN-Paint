from pathlib import Path
import json,zipfile,hashlib,re,xml.etree.ElementTree as ET
O=Path(__file__).resolve().parent;H=O/'hosted';p=H/'regression.zip'
artifacts=json.loads((O/'artifacts.json').read_text())
a=next(x for x in artifacts if x['name'].startswith('regression-'))
digest=hashlib.sha256(p.read_bytes()).hexdigest();assert a['digest']=='sha256:'+digest
assert a['workflow_run']['id']==39094504880 and a['workflow_run']['head_sha']=='3a88bfea931c5fad9b4d8d3d71da34a2a0609376'
counts={k:0 for k in ('tests','failures','errors','skipped')};suites=[];affected=[]
with zipfile.ZipFile(p)as z:
 names=[n for n in z.namelist()if '/test-results/testDebugUnitTest/TEST-'in n and n.endswith('.xml')]
 assert names
 for n in names:
  root=ET.fromstring(z.read(n));assert root.tag=='testsuite'
  cases=root.findall('testcase');assert len(cases)==int(root.attrib['tests'])
  for k in counts:counts[k]+=int(root.attrib.get(k,0))
  assert not any(c.find(k)is not None for c in cases for k in ('failure','error','skipped')),n
  suites.append({'name':root.attrib['name'],'tests':len(cases)})
  if n.endswith('TEST-org.catrobat.paintroid.local.CropCounterpartGuidanceTest.xml'):
   (H/Path(n).name).write_bytes(z.read(n))
   affected=[{'name':c.attrib['name'],'seconds':float(c.attrib['time'])}for c in cases]
source=(O.parent/'source/Paintroid/src/test/java/org/catrobat/paintroid/local/CropCounterpartGuidanceTest.kt').read_text()
expected=set(re.findall(r'@Test\s+fun\s+(\w+)\(',source));assert {c['name']for c in affected}==expected
assert all(counts[k]==0 for k in ('failures','errors','skipped'))
receipt={'source_commit':'3a88bfea931c5fad9b4d8d3d71da34a2a0609376','source_tree':'38f4130f0452db1fab1477d0362cee0304d2fced','artifact_id':a['id'],'artifact_name':a['name'],'artifact_sha256':digest,'run_id':39094504880,'junit':counts,'suite_count':len(suites),'affected_source_methods':len(expected),'affected_methods':affected}
(H/'junit-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
