from pathlib import Path
import json,zipfile,hashlib,io
O=Path(__file__).resolve().parent;H=O/'hosted';p=H/'apk-and-source.zip'
a=next(x for x in json.loads((O/'artifacts.json').read_text()) if x['name'].startswith('apk-and-source-'))
digest=hashlib.sha256(p.read_bytes()).hexdigest();assert a['digest']=='sha256:'+digest
with zipfile.ZipFile(p) as z:
 info=json.loads(z.read('build/delivery/build-info.json'));apk=z.read('app/build/outputs/apk/debug/app-debug.apk');src=z.read('build/delivery/AN-Paint-source.zip')
 assert info['commit']=='3a88bfea931c5fad9b4d8d3d71da34a2a0609376' and str(info['run_id'])=='39094504880'
 assert hashlib.sha256(apk).hexdigest()==info['apk_sha256'] and hashlib.sha256(src).hexdigest()==info['source_sha256']
 with zipfile.ZipFile(io.BytesIO(apk)) as az:
  candidates=[n for n in az.namelist()if n.endswith('.zip') and 'source' in n.lower()];assert len(candidates)==1,candidates;assert az.read(candidates[0])==src
 tree=json.loads((O.parent/'remote-tree.json').read_text());entries=[e for e in tree['tree']if e['type']=='blob'];matched=[];missing=[]
 with zipfile.ZipFile(io.BytesIO(src)) as sz:
  for e in entries:
   name='AN-Paint/'+e['path']
   if name not in sz.namelist():missing.append(e['path']);continue
   b=sz.read(name);assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==e['sha'],e['path']
   assert ('100755' if (sz.getinfo(name).external_attr>>16)&0o100 else '100644')==e['mode'],e['path'];matched.append(e['path'])
 assert sorted(missing)==['.gitignore','.idea/codeStyles/Project.xml','colorpicker/.gitignore'],missing
 assert len(matched)==1206
 receipt={'commit':info['commit'],'run_id':int(info['run_id']),'artifact_id':a['id'],'artifact_sha256':digest,'apk_sha256':info['apk_sha256'],'source_sha256':info['source_sha256'],'hashes_match_build_info':True,'embedded_source_matches_corresponding_archive':True,'reviewed_tree':tree['sha'],'signing':info['signing'],'tracked_source_files_examined':len(entries),'matched_payload_files':len(matched),'archive_omissions':missing,'scope':'Exact source/payload binding only; CI debug key, no upgrade-signature or installed Italian acceptance.'}
 (H/'build-info.json').write_text(json.dumps(info,indent=2)+'\n');(H/'build-binding.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
