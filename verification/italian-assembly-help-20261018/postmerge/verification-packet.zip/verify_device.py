from pathlib import Path
import json,sys,hashlib,zipfile
O=Path(__file__).resolve().parent;W=O.parent/'source';R=O/'combined-extracted';H=O/'hosted'
a=next(x for x in json.loads((O/'artifacts.json').read_text()) if x['name'].startswith('emulator-api-35-'))
digest=hashlib.sha256((H/'combined.zip').read_bytes()).hexdigest();assert a['digest']=='sha256:'+digest
assert a['workflow_run']['id']==39094504880 and a['workflow_run']['head_sha']=='3a88bfea931c5fad9b4d8d3d71da34a2a0609376'
with zipfile.ZipFile(H/'combined.zip')as z:
 for n in z.namelist():
  p=Path(n);assert not p.is_absolute() and '..'not in p.parts
 z.extractall(R)
sys.path.insert(0,str(W/'tools'))
from app_instrumentation_matrix import verify_app_reports,read_app_reports
from run_android_instrumentation import declared_tests,source_tests_sha256
appsource=W/'app/src/androidTest';native=W/'Paintroid/src/androidTest'
selected=declared_tests(appsource,sdk_level=35)
app=verify_app_reports(selected,35,read_app_reports(R,35),source_tests_sha256(appsource),declared_tests(appsource)-selected)
assert app['success'] and app['inventory_validated'] and app['completed_tests']==len(selected)
native_report=json.loads((R/'Paintroid/androidTest-results/summary.json').read_text())
assert native_report['success'] and native_report['returncode']==0 and not native_report['timed_out'] and not any(native_report[k]for k in ('missing','unexpected','errors'))
assert native_report['source_tests_sha256']==source_tests_sha256(native)
cases={(t['classname'],t['name'])for t in native_report['cases']};assert cases==declared_tests(native,sdk_level=35)
assert all(t['status']=='passed'for t in native_report['cases']) and len(cases)==len(native_report['cases'])
identity=json.loads((R/'composed-device-identity.json').read_text());build=json.loads((H/'build-binding.json').read_text())
assert identity['commit']==build['commit'] and int(identity['run_id'])==build['run_id']
assert identity['apk_sha256']==build['apk_sha256'] and identity['source_sha256']==build['source_sha256'] and identity['source_tests_sha256']==source_tests_sha256(appsource)
assert identity['device_sdk']==35 and identity['build_variant']=='debug' and identity['group_run_attempts']=={'core':2,'position':1} and identity['composed_in_run_attempt']==2
reports=[]
for p in sorted(R.rglob('summary.json')):
 if 'androidTest-results'not in p.parts and 'accepted-credit-restart'not in p.parts:continue
 r=json.loads(p.read_text());assert r['success'] and not r['timed_out'] and not any(r[k]for k in ('missing','unexpected','errors'))
 reports.append({'path':str(p.relative_to(R)),'expected':r['expected_tests'],'completed':r['completed_tests'],'seconds':r['elapsed_seconds']})
receipt={'commit':identity['commit'],'run_id':int(identity['run_id']),'attempt':2,'artifact_id':a['id'],'artifact_sha256':digest,'identity':identity,'reports':reports,'native_completed':len(cases),'app_completed':len(selected),'source_bound_app_inventory_reverified':True,'capture_review':'Not independently revalidated in this bounded Help correction; ordinary hosted gates retained unchanged.','limits':['No independent visual acceptance of ordinary-language captures','No installed Italian or TalkBack acceptance']}
(H/'app-inventory-reverified.json').write_text(json.dumps(app,indent=2)+'\n');(H/'device-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
