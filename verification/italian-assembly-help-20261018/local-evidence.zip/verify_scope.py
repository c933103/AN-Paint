from pathlib import Path
import json,subprocess,xml.etree.ElementTree as ET,sys,hashlib,stat,re
O=Path(__file__).resolve().parent; W=O/'source';sys.path.insert(0,str(W/'tools'))
from test_crop_counterpart_guidance import require_complete, HELP
expected=json.loads((W/'Paintroid/src/test/resources/crop-counterparts/expected.json').read_text())['locales']['it']
old=subprocess.check_output(['git','show','HEAD:Paintroid/src/main/res/values-it/strings.xml'],cwd=W).decode();before=ET.fromstring(old);after=ET.parse(W/'Paintroid/src/main/res/values-it/strings.xml').getroot()
try: require_complete(before,expected)
except ValueError as e: error=str(e)
else: raise AssertionError('Old value unexpectedly passed')
require_complete(after,expected)
for root in (before,after):root.find(f"./string[@name='{HELP}']").text='EXCLUDED_SINGLE_EDIT'
assert ET.tostring(before)==ET.tostring(after)
old_fixture=json.loads(subprocess.check_output(['git','show','HEAD:Paintroid/src/test/resources/crop-counterparts/expected.json'],cwd=W))
new_fixture=json.loads((W/'Paintroid/src/test/resources/crop-counterparts/expected.json').read_text())
old_fixture['locales']['it']['help']=new_fixture['locales']['it']['help'];assert old_fixture==new_fixture
source_text=(W/'Paintroid/src/main/res/values-it/strings.xml').read_text()
pattern=rf'(<string name="{HELP}">)(.*?)(</string>)';om=re.search(pattern,old);nm=re.search(pattern,source_text)
assert old[:om.start(2)]+source_text[nm.start(2):nm.end(2)]+old[om.end(2):]==source_text
before_paragraphs=(O/'old-help.txt').read_text().strip().split('\n\n');after_paragraphs=(O/'new-help.txt').read_text().strip().split('\n\n')
assert len(before_paragraphs)==7 and len(after_paragraphs)==8
for old_index,new_index in ((0,0),(1,1),(3,4),(5,6),(6,7)):
 assert before_paragraphs[old_index]==after_paragraphs[new_index]
assert before_paragraphs[2].replace('La prima immagine parte dall’origine.','Quando si usa l’aggancio, la prima immagine parte dall’origine.').replace('Le sovrapposizioni non sono consentite.','Le sovrapposizioni non sono consentite quando si usa l’aggancio.')==after_paragraphs[2]
assert before_paragraphs[4].replace('Le immagini successive colmano lo spazio e restano posizionate.','Le altre immagini restano posizionate; le immagini collegate possono spostarsi per colmare lo spazio.')==after_paragraphs[5]
entries=json.loads((O/'base-tree.json').read_text())['tree'];changes=[]
for e in entries:
 if e['type']!='blob': continue
 p=W/e['path'];b=p.read_bytes();actual=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();mode='100755' if p.stat().st_mode&stat.S_IXUSR else '100644';assert mode==e['mode'],e['path']
 if actual!=e['sha']:changes.append({'path':e['path'],'mode':mode,'base_sha':e['sha'],'sha':actual})
assert len(changes)==5
receipt={'base':'7ee75e4a1400587a775db420c1e1bebdbe88fa1d','base_tree':'e3ba7b23a38230f7820d148d5e99eaf364f7c20c','production_scope':'One it Help value only; every other production byte retained','paragraph_scope':'Five unchanged paragraphs plus three bounded corrections and the new Exact position paragraph','fixture_scope':'Only locales.it.help changed; crop plural and other locale fixtures identical','base_blobs_verified':1209,'executable_modes':'All preserved','old_value_negative_control':error,'changes':changes}
(O/'scope-and-negative-control.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
