import pathlib,importlib.util,sys,tempfile,json,xml.etree.ElementTree as E
O=pathlib.Path(__file__).parent;R=O.parent/'easteurope-ordinary-next';sys.path.insert(0,str(R/'tools'));import ordinary_priority_expectations as current;import translation_catalogues as C
spec=importlib.util.spec_from_file_location('v1_oracle',O/'v1-oracle-files/ordinary_priority_expectations.py');old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old);old.FIXTURE=current.FIXTURE
result=[]
for mode,tag,key in [('resource-tail','en-001','ui_no_resize_fits_decoder_memory'),('nested-plural','es-419','ui_crop_preview_images'),('wrong-type-duplicate','en-001','ui_no_resize_fits_decoder_memory')]:
 paths={t:C.catalogue_paths()[t]for t in current.reviewed_fixture()['locales']}
 with tempfile.TemporaryDirectory()as d:
  root=E.parse(paths[tag]).getroot();node=next(n for n in root if n.get('name')==key)
  if mode=='resource-tail':node.tail='FORGED EXTRA TEXT'
  elif mode=='nested-plural':E.SubElement(node[0],'b').text='FORGED EXTRA TEXT'
  else:E.SubElement(root,'plurals',{'name':key})
  p=pathlib.Path(d)/'strings.xml';E.ElementTree(root).write(p,encoding='unicode');paths[tag]=p;row={'mutation':mode}
  for name,module in [('v1',old),('v2',current)]:
   try:row[name]={'accepted':module.validate_resources(module.reviewed_fixture(),C.RES/'values/strings.xml',paths)}
   except ValueError as error:row[name]={'accepted':False,'error':str(error)}
  result.append(row)
(O/'oracle-gap-reproduction.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
