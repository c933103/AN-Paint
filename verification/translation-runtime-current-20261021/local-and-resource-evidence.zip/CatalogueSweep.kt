package org.catrobat.paintroid.classic
import java.io.File
import java.util.Base64
import java.util.Locale
fun main(args: Array<String>) {
    val token=Regex("%(\\d+)\\$[-#+ 0,(<]*(?:\\d+)?(?:\\.\\d+)?([sdfX])")
    var rows=0;var comparisons=0;var nullComparisons=0
    File(args[0]).forEachLine { line ->
        val fields=line.split('\t')
        val (label,tag,flag)=fields.take(3)
        fun decode(s: String)=String(Base64.getDecoder().decode(s),Charsets.UTF_8)
        val source=decode(fields[3]);val translated=decode(fields[4]);val formatted=flag.toBooleanStrict()
        val matches=if(formatted) token.findAll(source).toList() else emptyList()
        val values=arrayOfNulls<Any>(matches.maxOfOrNull {it.groupValues[1].toInt()} ?: 0)
        for(match in matches) values[match.groupValues[1].toInt()-1]=when(match.groupValues[2]) {
            "s" -> "%1\$999999999s <script> 100% \\\" 👩🏽‍🎨"
            "d","X" -> 307200L
            "f" -> 12.25
            else -> error("Unsupported conversion $label")
        }
        for(locale in listOf(Locale.ROOT,Locale.forLanguageTag(tag))) {
            fun compare(arguments:Array<Any?>) {
                val expected=if(!formatted || arguments.isEmpty()) translated else String.format(locale,translated,*arguments)
                val actual=LocaleText.resolve(translated,source,formatted,locale,arguments)
                check(expected==actual) {"Mismatch $label locale=$locale expected=[$expected] actual=[$actual]"}
            }
            compare(values);comparisons++
            for(index in values.indices) {
                val nullable=values.clone();nullable[index]=null;compare(nullable);nullComparisons++
            }
        }
        rows++
    }
    println("Compiled catalogue: $rows rows; $comparisons typed/literal comparisons; $nullComparisons present-null comparisons; zero mismatches or Formatter exceptions.")
}
