import re,base64,json
from pathlib import Path
root=Path(__file__).parent
text=(root/'resources-source.txt').read_text()
resources={}
for m in re.finditer(r'^    resource (\S+) (string|plurals)/(\S+)\n([\s\S]*?)(?=^    resource |^  type |\Z)',text,re.M):
 _,kind,name,body=m.groups();configs={}
 for c in re.finditer(r'^      \(([^)]*)\) ([\s\S]*?)(?=^      \(|\Z)',body,re.M):
  config,value=c.groups()
  if kind=='string': configs[config]=value.rstrip('\n')
  else:
   values={}
   for q in re.finditer(r'^        (\w+)=([\s\S]*?)(?=^        \w+=|\Z)',value,re.M):values[q[1]]=q[2].rstrip('\n')
   configs[config]=values
 resources[(kind,name)]=configs

def value(key,config,quantity='',chain=()):
 assert key not in chain,(key,chain)
 configs=resources[key]
 assert config in configs or config=='',(key,config)
 raw=configs[config]
 if isinstance(raw,dict):raw=raw.get(quantity,raw.get('other'))
 if raw.startswith('@string/'):
  target=('string',raw[8:]);targetconfig=config if config in resources[target] else ''
  return value(target,targetconfig,chain=(*chain,key))
 assert raw[0]=='"' and raw[-1]=='"',(key,config,repr(raw[:50]))
 indent=8 if key[0]=='plurals' else 6
 return raw[1:-1].replace('\n'+' '*indent,'\n')

rows=[];aliases=0;configs=set()
for (kind,name),entries in resources.items():
 if name.startswith('anpaint_source_'):continue
 src=(kind,'anpaint_source_'+name);contract=(kind,'anpaint_source_contract_'+kind+'_'+name)
 assert src in resources,(kind,name)
 for config,raw in entries.items():
  configs.add(config)
  for quantity in (raw.keys() if isinstance(raw,dict) else ['']):
   sourceq='one' if quantity=='one' else 'other' if quantity else ''
   source=value(src,'',sourceq);translated=value((kind,name),config,quantity);formatted=value(contract,'',sourceq)
   if config=='':assert source==translated,(kind,name,sourceq,repr(source),repr(translated))
   if isinstance(raw,str) and raw.startswith('@'): aliases+=1
   label=f'{config or "default"}/{kind}/{name}[{quantity}]'
   tag=config.replace('b+','').replace('+','-').replace('-r','-') or 'en'
   rows.append([label,tag,formatted,base64.b64encode(source.encode()).decode(),base64.b64encode(translated.encode()).decode()])
(root/'rows.tsv').write_text('\n'.join('\t'.join(row) for row in rows)+'\n')
summary={'compiled_rows':len(rows),'configurations':len(configs),'resolved_aliases':aliases,'source_entries':len([k for k in resources if k[1].startswith('anpaint_source_') and not k[1].startswith('anpaint_source_contract_')])}
(root/'input-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(summary)
