# PR114 current-base CI receipt

Source head: `3ff637e64b8d8931f20186fd159e75d118232e8b`  
Source tree: `c962e24433181f4006d1356c922f54b3bf207daa`  
CI merge checkout: `8f4875ee53cd9d58d79d3a99c5d74ac89e6ef554` (identical tree).

All six jobs of [run 39538234683](https://github.com/c933103/AN-Paint/actions/runs/39538234683) completed successfully:

- 1,098 hosted Python contract tests; 248.574-second phase.
- 1,311 JVM cases in 137 suites, zero failures, errors or skipped cases; 809.395-second phase under the existing 20-minute limit.
- Native dependency preparation and Android lint; zero lint issues in the XML report.
- Universal APK plus corresponding source and bound instrumentation APKs.
- API35 complete composed union: 45 app cases and 74 library cases, zero missing or unexpected cases. The two device jobs bind the same APK, source, test inventory and run.
- All 13 clean/incremental resource generation probes. The earlier local/resource archive preserves those raw results.

Focused JVM evidence includes 28 LocaleTextBoundary cases across API21/30/35, 11 formatter cases, 4 caption-prefix cases, 4 native-graphics caption cases, 16 viewport/vertical-text cases, 6 selected-locale numeric-display cases, 5 expanded Czech cases and 9 Unicode-minus cases. This includes real crop and normalization consumers, repeated actions and cancel, all 18 Ainu/Manchu percent templates, Japanese accessibility percent, aliases/plurals/literals and companion-file fallback, complete tooltip/accessibility text and Mongolian suffix shaping.

Security review completed without findings on this head. Code review was still running at this receipt. This is not merge readiness. Develop has since advanced through the independent frozen 0.0.41 release commit `1c9b71afb5f5cbde39bc5fff70630bca1a7a3419`; PR114 will be composed onto it and needs new exact-head gates. This receipt remains evidence only for the head/tree above.

## Retained evidence

- Raw JUnit XML for all 137 suites; machine-readable suite/case aggregate.
- Raw lint results and timed Python/JVM/native/lint phase logs.
- API35 raw XML/JSON/instrumentation results and source/APK identity; compact dialog, vertical-layout and composition receipts.
- Workflow/job/artifact metadata, downloaded archive hashes and the exact review-state snapshot.

Large reproducible build outputs, HTML duplicate reports, screenshots and device logcat are not duplicated in this compact archive. Original Actions artifacts have their recorded IDs and SHA-256 hashes in `ci-artifacts.json`; expiration of those artifacts does not affect the raw test receipts retained here. Test scope is the executed matrix, not a claim of every device/API or linguistic completeness. Release0.0.41 is separate and unchanged.
