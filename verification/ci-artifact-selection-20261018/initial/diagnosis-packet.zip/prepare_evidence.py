from pathlib import Path
import hashlib, json, zipfile
root=Path(__file__).resolve().parent
old=Path('/tmp/anpaint-chinese-crop-20261018/postmerge')
out=root/'evidence'
artifacts=json.loads((out/'observed-artifacts.json').read_text())
jobs=json.loads((out/'observed-jobs.json').read_text())
lookup={a['id']:a for a in artifacts}
files={12136188934:old/'failed-attempt-1/position.zip',12136049338:old/'hosted/position-attempt2.zip',12136657509:old/'hosted/core.zip'}
records=[]
for identity,file in files.items():
    data=file.read_bytes(); item=lookup[identity]
    assert item['digest']=='sha256:'+hashlib.sha256(data).hexdigest()
    with zipfile.ZipFile(file) as archive:
        receipt=json.loads(archive.read('device-identity.json'))
    matching=[j for j in jobs if j['name']=={'core':'Core emulator API 35','position':'Position dialog API 35'}[receipt['group']] and j['started_at']<=item['created_at']<=item['updated_at']<=j['completed_at']]
    assert matching
    records.append(dict(artifact=item,downloaded_identity=receipt,execution_interval_job_records=matching))
(out/'artifact-identities.json').write_text(json.dumps(records,indent=2)+'\n')
manifest=[]
with zipfile.ZipFile(out/'diagnosis-packet.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as packet:
    def add(name,data):
        packet.writestr(name,data);manifest.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
    for name in ['focused-composition.log','focused-selector.log','host-normal.log','host-optimized.log','observed-artifacts.json','observed-jobs.json','observed-selection.json','artifact-identities.json']:
        add(name,(out/name).read_bytes())
    for path in (old/'failed-attempt-2').iterdir():
        if path.is_file():add('original-failed-composer/'+path.name,path.read_bytes())
    add('local-successful-composition.json',(old/'independent-correct-composition.json').read_bytes())
    for identity,file in files.items():
        with zipfile.ZipFile(file) as archive:
            for name in archive.namelist():
                if name.endswith(('.json','.xml','instrumentation.log','install.log','startup.log')):
                    add(f'artifacts/{identity}/'+name,archive.read(name))
    add('prepare_evidence.py',Path(__file__).read_bytes())
    packet.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(out/'diagnosis-packet.zip') as packet:
    for entry in manifest:assert hashlib.sha256(packet.read(entry['path'])).hexdigest()==entry['sha256']
print(json.dumps(dict(packet_bytes=(out/'diagnosis-packet.zip').stat().st_size,entries=len(manifest),sha256=hashlib.sha256((out/'diagnosis-packet.zip').read_bytes()).hexdigest()),indent=2))
