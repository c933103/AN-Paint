from pathlib import Path
import json, shutil, sys, tempfile
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'source/tools'))
from download_selected_artifacts import download
from compose_device_reports import compose
from select_device_artifacts import select
old=Path('/tmp/anpaint-chinese-crop-20261018/postmerge')
metadata=json.loads((ROOT/'evidence/observed-artifacts.json').read_text());jobs=json.loads((ROOT/'evidence/observed-jobs.json').read_text())
sha='614f28f9f8edd489e5d13cffbe481d3b49c99d7f'
selection=select(metadata,jobs,run_id=39126110768,attempt=2,checkout=sha,head=sha,sdk=35)
files={12136657509:old/'hosted/core.zip',12136049338:old/'hosted/position-attempt2.zip'}
calls=[]
def runner(command,**kwargs):
 identity=int(command[-1].split('/')[-2]);calls.append(identity)
 with files[identity].open('rb') as source:shutil.copyfileobj(source,kwargs['stdout'])
 return SimpleNamespace(returncode=0)
with tempfile.TemporaryDirectory() as directory:
 root=Path(directory)
 for group in ['core','position']:download('c933103/AN-Paint',selection['selected'][group],root/group,runner)
 result=compose(Path('/tmp/anpaint-chinese-crop-20261018/source/app/src/androidTest'),root/'core',root/'position',35,dict(GITHUB_SHA=sha,GITHUB_RUN_ID='39126110768',GITHUB_RUN_ATTEMPT='2',BUILD_VARIANT='debug'))
 assert result['success'] and result['completed_tests']==45
 receipt=dict(scope='Local exact-ID transport fixture using original downloaded archives, not a hosted run',selected_ids=calls,composition=result)
 (ROOT/'evidence/local-exact-transport-composition.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(dict(ids=calls,app_tests=result['completed_tests'],success=result['success'])))
