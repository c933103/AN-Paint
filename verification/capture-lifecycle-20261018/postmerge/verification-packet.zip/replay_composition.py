"""Replay unchanged source composer against hashed original artifacts; scratch only."""
from pathlib import Path
import hashlib,json,sys,tempfile,zipfile
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'source/tools'))
from compose_device_reports import compose
selection=json.loads((ROOT/'combined/artifact-selection.json').read_text())
identity=json.loads((ROOT/'combined/composed-device-identity.json').read_text())
with tempfile.TemporaryDirectory(prefix='anpaint-compose-replay-') as t:
    t=Path(t)
    for group in ('core','position'):
        data=(ROOT/'hosted'/f'{group}.zip').read_bytes()
        assert 'sha256:'+hashlib.sha256(data).hexdigest()==selection['selected'][group]['digest']
        with zipfile.ZipFile(ROOT/'hosted'/f'{group}.zip') as z:
            assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in z.namelist())
            z.extractall(t/group)
    result=compose(ROOT/'source/app/src/androidTest',t/'core',t/'position',35,
        {'GITHUB_SHA':identity['commit'],'GITHUB_RUN_ID':identity['run_id'],
         'GITHUB_RUN_ATTEMPT':str(identity['composed_in_run_attempt']), 'BUILD_VARIANT':'debug'})
    expected={p.relative_to(t/'core') for p in (t/'core').rglob('*') if p.is_file()}
    actual={p.relative_to(ROOT/'combined') for p in (ROOT/'combined').rglob('*') if p.is_file()}
    assert actual-expected=={Path('artifact-selection.json')} and not expected-actual,(actual-expected,expected-actual)
    for p in expected: assert (t/'core'/p).read_bytes()==(ROOT/'combined'/p).read_bytes(),p
    receipt={'success':True,'unchanged_composer_replayed':True,
             'core_artifact_id':selection['selected']['core']['artifact_id'],
             'position_artifact_id':selection['selected']['position']['artifact_id'],
             'composed_attempt':identity['composed_in_run_attempt'],
             'all_composed_files_byte_equal':len(expected),
             'app_methods':result['completed_tests']}
    (ROOT/'terminal-evidence').mkdir(exist_ok=True)
    (ROOT/'terminal-evidence/independent-composition.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))
