"""Synthetic metadata tests, not evidence of Android execution or runtime caps."""
from copy import deepcopy
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parent / 'source' / 'tools'))
from select_device_artifacts import select
from retry_binding import bind_composition

CHECKOUT, HEAD = 'a' * 40, 'b' * 40
NAMES = ['Core emulator API 35', 'Position dialog API 35', 'Emulator API 35']


def moment(minute):
    return f'2026-10-18T12:{minute:02d}:00Z'


def job(number, group, attempt, start, end):
    return dict(id=number, name=NAMES[group], run_id=123, run_attempt=attempt,
                head_sha=HEAD, status='completed', conclusion='success',
                started_at=moment(start), completed_at=moment(end))


def artifact(number, prefix, minute):
    return dict(id=number, name=f'{prefix}-{CHECKOUT}', workflow_run=dict(id=123, head_sha=HEAD),
                expired=False, digest='sha256:' + str(number % 10) * 64,
                created_at=moment(minute), updated_at=moment(minute))


def fixture(retry=True):
    jobs = [job(1, 0, 1, 10, 20), job(2, 1, 1, 11, 21), job(3, 2, 1, 22, 25)]
    artifacts = [artifact(101, 'emulator-core-api-35', 19),
                 artifact(102, 'emulator-position-api-35', 20), artifact(103, 'emulator-api-35', 24)]
    selection = select(artifacts, jobs, run_id=123, attempt=1, checkout=CHECKOUT, head=HEAD, sdk=35)
    if retry:
        jobs += [dict(record, id=record['id'] + 10, run_attempt=2) for record in jobs[:3]]
    return dict(artifacts=artifacts, all_jobs=jobs, terminal_jobs=deepcopy(jobs[-3:]),
                run_id=123, run_attempt=2 if retry else 1, checkout=CHECKOUT, head=HEAD, sdk=35,
                selection=selection, identity=dict(commit=CHECKOUT, run_id='123', device_sdk=35,
                    composed_in_run_attempt=1, group_run_attempts={'core': 1, 'position': 1}),
                combined_artifact=deepcopy(artifacts[2]), select_artifacts=select)


def synchronize_terminal(data):
    data['terminal_jobs'] = deepcopy(data['all_jobs'][-3:])


class RetryBindingTest(unittest.TestCase):
    def assert_rejected(self, data):
        with self.assertRaises((ValueError, KeyError, TypeError)):
            bind_composition(**data)

    def test_original_and_reused_compositions_keep_original_receipts_unchanged(self):
        for retry in (False, True):
            data = fixture(retry)
            before = deepcopy(data)
            result = bind_composition(**data)
            self.assertEqual(data, before)
            self.assertEqual(result['original_selection'], data['selection'])
            self.assertEqual(result['composed_in_run_attempt'], 1)
            self.assertEqual(result['current_selection']['current_attempt'], 2 if retry else 1)
            self.assertEqual(result['jobs']['composer']['latest_job']['id'], 13 if retry else 3)

    def test_repeated_unrelated_retry_preserves_original_execution_attempt(self):
        data = fixture()
        data['all_jobs'] += [dict(row, id=row['id'] + 10, run_attempt=3) for row in data['all_jobs'][-3:]]
        data['run_attempt'] = 3
        synchronize_terminal(data)
        self.assertEqual(bind_composition(**data)['jobs']['core']['execution_attempt'], 1)

    def test_genuine_new_composition_accepts_reused_core_and_fresh_position(self):
        data = fixture()
        data['all_jobs'][-2] = job(12, 1, 2, 30, 40)
        data['all_jobs'][-1] = job(13, 2, 2, 41, 45)
        data['artifacts'] += [artifact(104, 'emulator-position-api-35', 39),
                              artifact(105, 'emulator-api-35', 44)]
        data['combined_artifact'] = deepcopy(data['artifacts'][-1])
        data['identity']['composed_in_run_attempt'] = 2
        data['identity']['group_run_attempts']['position'] = 2
        data['selection'] = select(data['artifacts'], data['all_jobs'], run_id=123, attempt=2,
                                   checkout=CHECKOUT, head=HEAD, sdk=35)
        synchronize_terminal(data)
        self.assertEqual(bind_composition(**data)['composed_in_run_attempt'], 2)

    def test_fresh_latest_execution_cannot_reuse_old_combined_receipt(self):
        for group in range(3):
            data = fixture()
            data['all_jobs'][group + 3]['started_at'] = moment(30)
            data['all_jobs'][group + 3]['completed_at'] = moment(40)
            synchronize_terminal(data)
            self.assert_rejected(data)

    def test_latest_failure_cancel_running_and_skipped_are_rejected(self):
        for group in range(3):
            for status, conclusion in [('completed', 'failure'), ('completed', 'cancelled'),
                                       ('in_progress', None), ('completed', 'skipped')]:
                with self.subTest(group=group, status=status, conclusion=conclusion):
                    data = fixture()
                    data['all_jobs'][group + 3].update(status=status, conclusion=conclusion)
                    synchronize_terminal(data)
                    self.assert_rejected(data)

    def test_ambiguous_history_or_terminal_records_fail(self):
        for index in range(6):
            data = fixture()
            data['all_jobs'].append(dict(data['all_jobs'][index], id=99))
            self.assert_rejected(data)
        data = fixture(); data['all_jobs'].append(deepcopy(data['all_jobs'][0])); self.assert_rejected(data)
        data = fixture(); data['terminal_jobs'].append(deepcopy(data['terminal_jobs'][0])); self.assert_rejected(data)

    def test_stale_missing_or_disagreeing_terminal_record_fails(self):
        data = fixture(); data['terminal_jobs'] = deepcopy(data['all_jobs'][:3]); self.assert_rejected(data)
        data = fixture(); data['terminal_jobs'].pop(); self.assert_rejected(data)
        data = fixture(); data['terminal_jobs'][0]['head_sha'] = 'c' * 40; self.assert_rejected(data)
        data = fixture(); data['all_jobs'].pop(0); self.assert_rejected(data)

    def test_combined_artifact_requires_whole_interval_and_unambiguous_identity(self):
        for mutation in [dict(created_at=moment(21)), dict(updated_at=moment(26)),
                         dict(created_at=moment(25), updated_at=moment(24)), dict(expired=True),
                         dict(digest=''), dict(name='emulator-api-35-' + 'c' * 40),
                         dict(workflow_run=dict(id=999, head_sha=HEAD)),
                         dict(workflow_run=dict(id=123, head_sha='c' * 40))]:
            with self.subTest(mutation=mutation):
                data = fixture(); data['artifacts'][2].update(mutation)
                data['combined_artifact'] = deepcopy(data['artifacts'][2])
                self.assert_rejected(data)
        data = fixture(); data['artifacts'].append(artifact(104, 'emulator-api-35', 23)); self.assert_rejected(data)
        data = fixture(); data['artifacts'].append(deepcopy(data['artifacts'][2])); self.assert_rejected(data)
        data = fixture(); data['combined_artifact']['digest'] = 'sha256:' + 'f' * 64; self.assert_rejected(data)

    def test_wrong_run_head_and_selected_artifact_digest_fail(self):
        for field, value in [('run_id', 999), ('head_sha', 'c' * 40), ('name', 'Compose app instrumentation reports')]:
            data = fixture(); data['all_jobs'][5][field] = value; synchronize_terminal(data); self.assert_rejected(data)
        for field, value in [('commit', 'c' * 40), ('run_id', '999'), ('device_sdk', 30)]:
            data = fixture(); data['identity'][field] = value; self.assert_rejected(data)
        data = fixture(); data['artifacts'][0]['digest'] = 'sha256:' + 'f' * 64; self.assert_rejected(data)

    def test_invalid_future_or_inconsistent_attempts_fail(self):
        for bad in (0, True, '1', 3):
            data = fixture(); data['identity']['composed_in_run_attempt'] = bad; self.assert_rejected(data)
            data = fixture(); data['identity']['group_run_attempts']['core'] = bad; self.assert_rejected(data)
        for bad in (0, True, '2', 3):
            data = fixture(); data['all_jobs'][-1]['run_attempt'] = bad; synchronize_terminal(data); self.assert_rejected(data)
        data = fixture(); data['identity']['group_run_attempts']['core'] = 2; self.assert_rejected(data)
        data = fixture(); data['selection']['current_attempt'] = 2; self.assert_rejected(data)
        data = fixture(); data['identity']['group_run_attempts']['extra'] = 1; self.assert_rejected(data)

    def test_copied_records_cannot_be_relabelled_as_fresh_executions(self):
        data = fixture()
        data['identity']['composed_in_run_attempt'] = 2
        data['selection'] = select(data['artifacts'], data['all_jobs'], run_id=123, attempt=2,
                                  checkout=CHECKOUT, head=HEAD, sdk=35)
        self.assert_rejected(data)
        data['identity']['group_run_attempts'] = {'core': 2, 'position': 2}
        self.assert_rejected(data)

    def test_groups_must_finish_before_composer_begins(self):
        data = fixture(False)
        data['all_jobs'][2]['started_at'] = moment(20)
        synchronize_terminal(data)
        self.assert_rejected(data)


if __name__ == '__main__':
    unittest.main(verbosity=2)
