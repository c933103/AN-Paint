"""Scratch-only binding of a composed receipt across unrelated Actions retries.

Use the unchanged production select_device_artifacts.select as select_artifacts.
Inputs must be complete, unmodified API catalogues collected after terminal run
success. This verifies metadata provenance; callers must still verify downloaded
archive digests, exact source/APK identity, reports, actual composition and caps.
"""
from datetime import datetime, timezone
import re


def require(condition, message):
    if not condition:
        raise ValueError(message)


def positive(value, label):
    require(type(value) is int and value > 0, f'Invalid {label}')
    return value


def timestamp(value):
    require(isinstance(value, str) and value.endswith('Z'), 'UTC timestamp required')
    parsed = datetime.fromisoformat(value[:-1] + '+00:00')
    require(parsed.tzinfo == timezone.utc, 'UTC timestamp required')
    return parsed


def interval(record):
    start, end = timestamp(record['started_at']), timestamp(record['completed_at'])
    require(start <= end, 'Inverted job interval')
    return start, end


def successful(record):
    require(record.get('status') == 'completed' and record.get('conclusion') == 'success',
            f"Job is not successful: {record.get('name')}")
    return interval(record)


def bind_composition(*, artifacts, all_jobs, terminal_jobs, run_id, run_attempt,
                     checkout, head, sdk, selection, identity, combined_artifact,
                     select_artifacts):
    """Return a separate receipt without modifying the embedded original receipt.

    An original execution is its exact-name record at its recorded execution
    attempt. Current copied job IDs/record attempts may differ, but the original
    and latest successful execution intervals must be identical. A genuine later
    execution requires a genuine later composed receipt, not re-labeling an old one.
    """
    positive(run_id, 'run ID'); positive(run_attempt, 'terminal attempt')
    require(type(sdk) is int and sdk in (30, 35), 'Unsupported SDK')
    for sha in (checkout, head):
        require(isinstance(sha, str) and re.fullmatch(r'[0-9a-f]{40}', sha), 'Invalid exact SHA')
    names = {'core': f'Core emulator API {sdk}', 'position': f'Position dialog API {sdk}',
             'composer': f'Emulator API {sdk}'}
    record_keys = ('id', 'name', 'run_id', 'run_attempt', 'head_sha', 'status',
                   'conclusion', 'started_at', 'completed_at')
    by_id, histories = {}, {group: {} for group in names}
    for job in all_jobs:
        job_id = positive(job.get('id'), 'job ID')
        attempt = positive(job.get('run_attempt'), 'job record attempt')
        require(job_id not in by_id, 'Duplicate job ID in raw history')
        require(job.get('run_id') == run_id and job.get('head_sha') == head,
                'Wrong run or source in raw job history')
        require(attempt <= run_attempt, 'Future job record attempt')
        by_id[job_id] = job
        for group, name in names.items():
            if job.get('name') == name:
                require(attempt not in histories[group], f'Ambiguous {group} job attempt')
                histories[group][attempt] = job
    terminal_by_name, terminal_ids = {}, set()
    for job in terminal_jobs:
        job_id = positive(job.get('id'), 'terminal job ID')
        require(job_id not in terminal_ids, 'Duplicate terminal job ID')
        terminal_ids.add(job_id)
        require(job_id in by_id, 'Terminal job absent from raw history')
        require(all(job.get(key) == by_id[job_id].get(key) for key in record_keys),
                'Terminal job disagrees with raw history')
        if job.get('name') in names.values():
            require(job['name'] not in terminal_by_name, 'Ambiguous terminal job name')
            terminal_by_name[job['name']] = job
    latest = {}
    for group, history in histories.items():
        require(bool(history), f'Missing {group} history')
        latest[group] = history[max(history)]
        require(terminal_by_name.get(names[group], {}).get('id') == latest[group]['id'],
                f'Terminal {group} job is not the latest raw record')
        successful(latest[group])

    composed_attempt = positive(identity.get('composed_in_run_attempt'), 'composed attempt')
    require(composed_attempt <= run_attempt, 'Future composed attempt')
    require(identity.get('commit') == checkout and identity.get('run_id') == str(run_id)
            and identity.get('device_sdk') == sdk, 'Wrong composed identity')
    attempts = identity.get('group_run_attempts')
    require(isinstance(attempts, dict) and set(attempts) == {'core', 'position'},
            'Exact execution-attempt groups required')
    for group, attempt in attempts.items():
        positive(attempt, f'{group} execution attempt')
        require(attempt <= composed_attempt, 'Group execution is later than composition')

    args = dict(run_id=run_id, checkout=checkout, head=head, sdk=sdk)
    original_selection = select_artifacts(artifacts,
        [job for job in all_jobs if job['run_attempt'] <= composed_attempt],
        attempt=composed_attempt, **args)
    require(selection == original_selection, 'Embedded selection differs from original raw history')
    current_selection = select_artifacts(artifacts, all_jobs, attempt=run_attempt, **args)

    originals = {}
    for group, attempt in dict(attempts, composer=composed_attempt).items():
        require(attempt in histories[group], f'Missing original {group} execution record')
        original = histories[group][attempt]
        original_interval = successful(original)
        require(successful(latest[group]) == original_interval,
                f'Latest {group} executed again; old composition cannot stand in')
        # A copied record cannot masquerade as a fresh execution merely by
        # changing the claimed attempt in the embedded receipt/identity.
        for earlier_attempt, earlier in histories[group].items():
            if earlier_attempt < attempt and earlier.get('started_at') == original['started_at'] \
                    and earlier.get('completed_at') == original['completed_at']:
                raise ValueError(f'Claimed {group} execution attempt is a later copied record')
        originals[group] = original
    composer_start, composer_end = successful(originals['composer'])
    for group in ('core', 'position'):
        old, new = original_selection['selected'][group], current_selection['selected'][group]
        require(old['job_record_run_attempt'] >= attempts[group], 'Selection predates group execution')
        require((timestamp(old['job_started_at']), timestamp(old['job_completed_at']))
                == interval(originals[group]), 'Selected interval differs from group execution')
        require(interval(originals[group])[1] <= composer_start, 'Group completed after composer began')
        ignored = {'job_id', 'job_record_run_attempt'}
        require({k: v for k, v in old.items() if k not in ignored}
                == {k: v for k, v in new.items() if k not in ignored},
                'Latest artifact selection differs beyond copied job metadata')

    artifact_ids, candidates = set(), []
    combined_name = f'emulator-api-{sdk}-{checkout}'
    for artifact in artifacts:
        artifact_id = positive(artifact.get('id'), 'artifact ID')
        require(artifact_id not in artifact_ids, 'Duplicate artifact ID')
        artifact_ids.add(artifact_id)
        if artifact.get('name') != combined_name:
            continue
        workflow = artifact.get('workflow_run', {})
        require(workflow.get('id') == run_id and workflow.get('head_sha') == head,
                'Wrong combined artifact run or source')
        created, updated = timestamp(artifact['created_at']), timestamp(artifact['updated_at'])
        require(created <= updated, 'Inverted combined artifact interval')
        if composer_start <= created <= updated <= composer_end:
            candidates.append(artifact)
    require(len(candidates) == 1 and candidates[0] == combined_artifact,
            'Expected exactly the selected combined artifact inside original composer interval')
    require(combined_artifact.get('expired') is False and isinstance(combined_artifact.get('digest'), str)
            and re.fullmatch(r'sha256:[0-9a-f]{64}', combined_artifact['digest']),
            'Nonexpired combined artifact with SHA-256 required')
    return dict(run_id=run_id, terminal_attempt=run_attempt, composed_in_run_attempt=composed_attempt,
        checkout=checkout, workflow_head=head, device_sdk=sdk,
        combined_artifact_id=combined_artifact['id'], combined_artifact_digest=combined_artifact['digest'],
        combined_created_at=combined_artifact['created_at'], combined_updated_at=combined_artifact['updated_at'],
        original_selection=original_selection, current_selection=current_selection,
        jobs={group: {'execution_attempt': originals[group]['run_attempt'],
                      'original_job': {key: originals[group].get(key) for key in record_keys},
                      'latest_job': {key: latest[group].get(key) for key in record_keys}}
              for group in names})
