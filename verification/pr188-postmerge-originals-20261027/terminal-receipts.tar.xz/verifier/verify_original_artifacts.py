from pathlib import Path
import json,zipfile,hashlib,sys,xml.etree.ElementTree as E,collections
root=Path(__file__).resolve().parent
art=root/'original-artifacts'; lane=root.parent/'pt-es-hu-p0-p1-20261027'
sha=lambda b:hashlib.sha256(b).hexdigest()
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
base=json.loads((lane/'base-tree.json').read_text()); final=json.loads((lane/'final-tree-readback.json').read_text())
expected={x['path']:x for x in base['tree'] if x['type']=='blob'}
expected.update({x['path']:x for x in final['changes']})
sourcezip=zipfile.ZipFile(root/'AN-Paint-source.zip'); missing=[];bad=[]
for name,x in expected.items():
 try:data=sourcezip.read('AN-Paint/'+name)
 except KeyError:missing.append(name);continue
 if blob(data)!=x['sha']:bad.append(name)
assert missing==['.gitignore','.idea/codeStyles/Project.xml','colorpicker/.gitignore'] and not bad,(missing,bad)
assert len(expected)==1405
# Extract only exact source-bound test inventories and verifier modules, no dependency trees.
work=root/'inventory-source';work.mkdir(exist_ok=True)
for name in expected:
 if name.startswith(('app/src/androidTest/','Paintroid/src/androidTest/')) or (name.startswith('tools/') and name.endswith('.py')):
  path=work/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(sourcezip.read('AN-Paint/'+name))
sys.path.insert(0,str(work/'tools'))
from run_android_instrumentation import declared_tests,source_tests_sha256,parse_protocol
from app_instrumentation_matrix import verify_reports
union=root/'union-extracted'
with zipfile.ZipFile(art/'union.zip') as z:z.extractall(union)
appdir=work/'app/src/androidTest';paintdir=work/'Paintroid/src/androidTest'
coverage=verify_reports(appdir,union,35)
assert coverage['success'] and coverage['declared_tests']==coverage['completed_tests']==47
raw_reports=[]
for s in sorted(union.rglob('summary.json')):
 if s.name!='summary.json':continue
 d=json.loads(s.read_text())
 if 'cases' not in d:continue
 log=s.parent/'instrumentation.log'
 assert log.exists(),str(log)
 identities={(x['classname'],x['name']) for x in d['cases']}
 r=parse_protocol(log.read_text(),identities,returncode=d['returncode'],timed_out=d['timed_out'])
 assert r['success'] and r['completed_tests']==d['completed_tests'],str(s)
 raw_reports.append({'path':str(s.relative_to(union)),'tests':len(identities)})
paint=json.loads((union/'Paintroid/androidTest-results/summary.json').read_text())
assert {(x['classname'],x['name']) for x in paint['cases']}==declared_tests(paintdir,sdk_level=35)
assert paint['source_tests_sha256']==source_tests_sha256(paintdir)
assert paint['completed_tests']==74
info=json.loads(zipfile.ZipFile(art/'apk-source.zip').read('build/delivery/build-info.json'))
ident=json.loads((union/'composed-device-identity.json').read_text())
assert info['commit']==ident['commit']=='1126b650216478c422997dcd1236ca6cc780e4e3'
assert info['source_sha256']==ident['source_sha256']==sha((root/'AN-Paint-source.zip').read_bytes())
with zipfile.ZipFile(art/'apk-source.zip') as z:assert sha(z.read('app/build/outputs/apk/debug/app-debug.apk'))==info['apk_sha256']==ident['apk_sha256']
with zipfile.ZipFile(art/'instrumentation.zip') as z:assert sha(z.read('app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk'))==ident['test_apk_sha256']
assert source_tests_sha256(appdir)==ident['source_tests_sha256']
reg=zipfile.ZipFile(art/'regression.zip'); totals=collections.Counter();new=[];suites=[]
for n in reg.namelist():
 if '/test-results/' in n and n.endswith('.xml'):
  e=E.fromstring(reg.read(n));suites.append(n)
  for k in ['tests','failures','errors','skipped']:totals[k]+=int(e.attrib.get(k,0))
  assert not e.findall('.//failure') and not e.findall('.//error')
  if 'PortugueseSpanishPriorityWordingTest.xml' in n:new=[x.attrib['name'] for x in e.findall('testcase')]
assert totals==dict(tests=1423,failures=0,errors=0,skipped=0) and len(new)==6
assert not E.fromstring(reg.read('app/build/reports/lint-results-debug.xml')).findall('issue')
with zipfile.ZipFile(art/'probes.zip') as z:
 probes=json.loads(z.read('summary.json'))
 assert probes['success'] and probes['tree']==final['tree']
 for p in probes['probes']:
  assert sha(z.read(p['name']+'.log'))==p['log_sha256']
  assert (p['exit_code']==0)==p['expected_success']
artifact_files={'core':12725659008,'position':12725457370,'union':12725723533,'regression':12726041560,'apk-source':12725112572,'instrumentation':12724758728,'probes':12725360705}
metadata={x['id']:x for x in json.loads((root/'artifacts-metadata.json').read_text())['artifacts']}
verified_artifacts=[]
for stem,aid in artifact_files.items():
 b=(art/(stem+'.zip')).read_bytes();m=metadata[aid]
 assert sha(b)==m['digest'].removeprefix('sha256:') and len(b)==m['size_in_bytes']
 verified_artifacts.append({'id':aid,'name':m['name'],'sha256':sha(b),'size_bytes':len(b)})
jobs=json.loads((root/'jobs-terminal.json').read_text())
assert len(jobs)==6 and all(x['conclusion']=='success' and x['status']=='completed' for x in jobs)
result={
 'artifact_digests_verified':verified_artifacts,'terminal_jobs':[{k:j[k] for k in ['id','name','status','conclusion','run_id']} for j in jobs],
 'schema':1,'pr':188,'head':'1126b650216478c422997dcd1236ca6cc780e4e3','tree':final['tree'],'tested_merge':info['commit'],'run_id':40485214055,
 'source_archive_sha256':info['source_sha256'],'source_tree_blobs_verified':len(expected)-len(missing),'source_archive_omitted_repository_metadata':missing,'missing_non_metadata_source_files':[],'mismatched_source_files':bad,
 'jvm':dict(totals, suites=len(suites), new_portuguese_spanish_methods=new), 'lint_issues':0,
 'api35':{'paintroid':74,'app':47,'app_inventory_recomputed_from_exact_source':True,'paintroid_inventory_recomputed_from_exact_source':True,'raw_instrumentation_reports_reparsed':raw_reports,'complete_union_revalidated':True,'missing':[],'unexpected':[],'suppressed':[],'deferred':[],'app_source_tests_sha256':source_tests_sha256(appdir),'paintroid_source_tests_sha256':source_tests_sha256(paintdir)},
 'resource_probes':{'count':len(probes['probes']),'original_log_hashes_match':True,'all_expected_outcomes_match':True,'intentional_rejection':'06-reserved-app-variant-rejected'},
 'apk_sha256':info['apk_sha256'],'app_test_apk_sha256':ident['test_apk_sha256'],
 'limitations':['Hosted API35 evidence does not certify native linguistic fluency, TalkBack usability, all devices, or every locale layout.','Existing colour scope remains preview-rail reachability and Cancel only for API35 en-US/hu 2x 640x320 mdpi, with separate IME/Back/footer lifecycle; not universal 2x or simultaneous whole-dialog/IME fit.','Merge review/approval remains root-owned; release pause and other explicit project holds unchanged.']}
(root/'independent-terminal-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['api35','limitations']},indent=2))
print('API35 original raw reports',len(raw_reports),'all source-bound 74+47 exact inventory verified')
