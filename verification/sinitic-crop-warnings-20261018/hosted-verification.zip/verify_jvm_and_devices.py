"""Verify downloaded exact-source hosted receipts; no production files are changed."""
from pathlib import Path
import hashlib,json,re,sys,zipfile,xml.etree.ElementTree as ET
O=Path(__file__).resolve().parent
W=Path(sys.argv[1])
expected=json.loads((O/'expected-source-methods.json').read_text())
artifacts=json.loads((O/'artifacts.json').read_text())['artifacts']
RUN=39135477086;HEAD=expected['head'];CHECKOUT='4974d24129aa2505854835a02bdd1ad4277a895b'
def archive(prefix,filename):
 candidates=[a for a in artifacts if a['name'].startswith(prefix)]
 if len(candidates)!=1: raise ValueError(f'Ambiguous/missing artifact: {prefix}')
 a=candidates[0];p=O/filename
 if a['digest']!='sha256:'+hashlib.sha256(p.read_bytes()).hexdigest():raise ValueError('Artifact digest mismatch')
 if a['workflow_run']['id']!=RUN or a['workflow_run']['head_sha']!=HEAD:raise ValueError('Artifact source mismatch')
 return a,zipfile.ZipFile(p)
def write(name,value):(O/name).write_text(json.dumps(value,indent=2)+'\n')
if (O/'regression.zip').exists():
 a,z=archive('regression-and-lint-','regression.zip');counts={k:0 for k in ['tests','failures','errors','skipped']};suites=[];related={}
 for name in z.namelist():
  if '/test-results/testDebugUnitTest/TEST-' not in name or not name.endswith('.xml'):continue
  root=ET.fromstring(z.read(name));cases=root.findall('testcase');suite=root.attrib['name'];suites.append(suite)
  if len(cases)!=int(root.attrib['tests']):raise ValueError('Inconsistent test count')
  for k in counts:counts[k]+=int(root.attrib.get(k,0))
  if any(c.find(k)is not None for c in cases for k in ['failure','error','skipped']):raise ValueError('Failed/skipped JVM method '+suite)
  short=suite.split('.')[-1]
  if short in expected['jvm_suites']:
   methods=[c.attrib['name'] for c in cases]
   if len(methods)!=len(set(methods)) or set(methods)!=set(expected['jvm_suites'][short]):raise ValueError('JVM method inventory differs '+short)
   related[short]=sorted(methods)
 if set(related)!=set(expected['jvm_suites']):raise ValueError('Missing required relevant JVM suite')
 if not suites or any(counts[k]for k in ['failures','errors','skipped']):raise ValueError('Incomplete or failing JVM receipts')
 python=z.read('build/reports/ci-phases/python.log').decode()
 matches=re.findall(r'Ran (\d+) tests in [\d.]+s\s+OK',python)
 if matches!=['976']:raise ValueError('Hosted Python suite not established')
 receipt={'head':HEAD,'checkout':CHECKOUT,'tree':expected['tree'],'artifact':a,'counts':counts,'suites':len(suites),'source_bound_methods':related,'hosted_python':976}
 write('junit-receipt.json',receipt);print('JVM',counts,'suites',len(suites),'bound',{k:len(v)for k,v in related.items()})
if (O/'combined.zip').exists():
 a,z=archive('emulator-api-35-','combined.zip');R=O/'combined';R.mkdir(exist_ok=True)
 for n in z.namelist():
  if Path(n).is_absolute() or '..' in Path(n).parts:raise ValueError('Unsafe report archive path')
 z.extractall(R);sys.path.insert(0,str(W/'tools'))
 from app_instrumentation_matrix import verify_app_reports,read_app_reports
 from run_android_instrumentation import declared_tests,source_tests_sha256
 appsrc=W/'app/src/androidTest';nativesrc=W/'Paintroid/src/androidTest'
 selected=declared_tests(appsrc,sdk_level=35)
 app=verify_app_reports(selected,35,read_app_reports(R,35),source_tests_sha256(appsrc),declared_tests(appsrc)-selected)
 if not app['success']or not app['inventory_validated']or app['completed_tests']!=len(selected):raise ValueError('Incomplete app union')
 native=json.loads((R/'Paintroid/androidTest-results/summary.json').read_text())
 if not native['success']or native['returncode']!=0 or native['timed_out']or any(native[k]for k in ['missing','unexpected','errors']):raise ValueError('Native failure')
 if native['source_tests_sha256']!=source_tests_sha256(nativesrc):raise ValueError('Native source mismatch')
 cases={(t['classname'],t['name'])for t in native['cases']}
 if cases!=declared_tests(nativesrc,sdk_level=35)or len(cases)!=len(native['cases'])or any(t['status']!='passed'for t in native['cases']):raise ValueError('Native inventory mismatch')
 identity=json.loads((R/'composed-device-identity.json').read_text());build=json.loads((O/'build-binding.json').read_text())['build_info']
 if identity['commit']!=CHECKOUT or int(identity['run_id'])!=RUN or identity['device_sdk']!=35 or identity['build_variant']!='debug':raise ValueError('Wrong composition identity')
 for key in ['apk_sha256','source_sha256']:
  if identity[key]!=build[key]:raise ValueError('Device/build content mismatch')
 if identity['source_tests_sha256']!=source_tests_sha256(appsrc):raise ValueError('App source mismatch')
 receipt={'head':HEAD,'tree':expected['tree'],'artifact':a,'identity':identity,'native_completed':len(cases),'app_completed':len(selected),'app_inventory':app,'scope':'Complete ordinary API35 union. The changed-locale crop cases are JVM tests, not new installed linguistic/layout acceptance.'}
 write('device-receipt.json',receipt);print('Device native',len(cases),'app',len(selected),'complete union bound')
