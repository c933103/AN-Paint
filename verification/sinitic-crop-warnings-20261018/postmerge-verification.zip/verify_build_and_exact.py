from pathlib import Path
import hashlib,zipfile,io,json,subprocess
O=Path(__file__).resolve().parent;W=Path('/tmp/anpaint-sinitic-crop-20261018');B=O/'build';B.mkdir(exist_ok=True)
HEAD='3681194d9499cdbf8ce6004a3b993b1472380436';TREE='8f5e51ffbbdee2f80c9e916aa6a1c6d969239b84';RUN='39137365965'
with zipfile.ZipFile(O/'apk-and-source.zip')as z:
 info=json.loads(z.read('build/delivery/build-info.json'));src=z.read('build/delivery/AN-Paint-source.zip');apk=z.read('app/build/outputs/apk/debug/app-debug.apk')
 assert info['commit']==HEAD and info['run_id']==RUN and info['build_variant']=='debug'
 assert hashlib.sha256(src).hexdigest()==info['source_sha256']and hashlib.sha256(apk).hexdigest()==info['apk_sha256']
 (B/'app-debug.apk').write_bytes(apk)
 for n in z.namelist():
  if n.startswith('verification-tools/'):
   p=B/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(n));p.chmod(0o755)
with zipfile.ZipFile(io.BytesIO(apk))as z:
 embedded=[n for n in z.namelist()if 'source'in n.lower()and n.endswith('.zip')];assert len(embedded)==1 and z.read(embedded[0])==src
 abis=sorted({n.split('/')[1]for n in z.namelist()if n.startswith('lib/')});assert abis==['arm64-v8a','armeabi-v7a','x86','x86_64']
assert subprocess.check_output(['git','write-tree'],cwd=W).decode().strip()==TREE
entries=[dict(zip(['mode','sha','stage','path'],line.split(None,3)))for line in subprocess.check_output(['git','ls-files','--stage'],cwd=W).decode().splitlines()]
(O/'source-tree.json').write_text(json.dumps({'tree':TREE,'entries':entries},indent=2)+'\n')
missing=[];matched=0
with zipfile.ZipFile(io.BytesIO(src))as z:
 for e in entries:
  n='AN-Paint/'+e['path']
  if n not in z.namelist():missing.append(e['path']);continue
  b=z.read(n);assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==e['sha'],e['path']
  assert ('100755'if(z.getinfo(n).external_attr>>16)&0o100 else '100644')==e['mode'],e['path'];matched+=1
assert sorted(missing)==['.gitignore','.idea/codeStyles/Project.xml','colorpicker/.gitignore']
receipt={'head':HEAD,'tree':TREE,'build_info':info,'embedded_source_equal':True,'matched_source_blobs':matched,'source_metadata_omissions':missing,'abis':abis}
(O/'build-binding.json').write_text(json.dumps(receipt,indent=2)+'\n')
with zipfile.ZipFile(O/'exact-script.zip')as z:
 s=json.loads(z.read(next(n for n in z.namelist()if n.endswith('summary.json'))));assert s['success']and s['tree']==TREE and s['commit']==HEAD and len(s['probes'])==9
 for p in s['probes']:
  assert p['exit_code']==0 and hashlib.sha256(z.read(next(n for n in z.namelist()if n.endswith(p['name']+'.log')))).hexdigest()==p['log_sha256']
 (O/'exact-script-summary.json').write_text(json.dumps(s,indent=2)+'\n')
print('Build source:',matched,'matching blobs; embedded source equals external; all four ABIs. Exact script:',len(s['probes']),'successful probes.')
for cmd,name in [(['java','-jar',str(B/'verification-tools/apksigner.jar'),'verify','--verbose','--print-certs',str(B/'app-debug.apk')],'apk-signature.log'),([str(B/'verification-tools/zipalign'),'-c','-P','16','-v','4',str(B/'app-debug.apk')],'apk-alignment.log')]:
 with(O/name).open('w')as out:subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,check=True)
print('APK signature and 16KiB alignment checks passed.')
