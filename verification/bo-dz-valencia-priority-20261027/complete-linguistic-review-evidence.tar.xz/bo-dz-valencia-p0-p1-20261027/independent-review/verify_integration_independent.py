import sys,json,hashlib,copy,xml.etree.ElementTree as E
from pathlib import Path
P=Path(__file__).resolve().parents[1];R=P/'integration-source';B=Path('eo-ga-gd-p0-p1-20261027/composition202/source').resolve()
sys.path.insert(0,str(R/'tools'))
import tibetan_dzongkha_valencian_priority_expectations as h
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
base={r['path']:r for r in json.loads((P/'integration-base-tree.json').read_text())['tree'] if r['type']=='blob'}
for name,row in base.items():
 p=B/name;assert blob(p.read_bytes())==row['sha'];assert ('100755'if p.stat().st_mode&0o111 else'100644')==row['mode']
m=json.loads((P/'integration-source-delta.json').read_text());delta={r['path']:r for r in m['changed_paths']}
for name,row in {**base,**delta}.items():
 p=R/name;assert blob(p.read_bytes())==row['sha'],name
 assert ('100755' if p.stat().st_mode&0o111 else '100644')==row['mode'],name
for name,row in delta.items():assert sha(R/name)==row['sha256'],name
assert len(set(base)|set(delta))==1454 and len(delta)==17
mapping=json.loads((P/'independent-review/combined-integration-map.json').read_text())
n=0;counts={}
def reject(fn):
 global n
 try:fn()
 except ValueError:n+=1;return
 raise AssertionError('mutation accepted')
for tag,l in mapping['locales'].items():
 assert sha(P/'independent-review'/l['ledger'])==l['ledger_sha256']
 d=h.bound_fixture(tag);root=E.parse(R/d['catalogue_path']).getroot();nodes={x.get('name'):x for x in root};old={x.get('name'):x for x in E.parse(B/d['catalogue_path']).getroot()}
 def resource(node):
  o={'value':node.text if node.tag=='string' else {x.get('quantity'):x.text for x in node},'attributes':node.attrib}
  if node.tag=='plurals':o['children_attributes']={x.get('quantity'):x.attrib for x in node}
  return o
 assert d['original_catalogue']=={k:resource(v) for k,v in old.items()}
 assert set(d['values'])==set(l['integration_values']);assert d['holds']==l['held_priority_identities']
 for key,row in d['values'].items():
  for k,v in row.items():
   if k=='display':assert v==l['accepted_display_values'][key]
   else:assert v==l['integration_values'][key][k],(tag,key,k)
 for key,v in l['accepted_resource_text_values'].items():
  node=nodes[key];assert (node.text if node.tag=='string' else {x.get('quantity'):x.text for x in node})==v
 h.require_catalogue(tag,root,d)
 for key,row in d['values'].items():
  expected={'value':row['reviewed_value'],'attributes':row['reviewed_attributes']}
  if row['type']=='plurals':expected['children_attributes']=row['reviewed_children_attributes']
  for mode in ['missing','text','attribute','child','tail']:
   x=copy.deepcopy(nodes[key])
   if mode=='missing':x=None
   elif mode=='text':x.text='FORGED'
   elif mode=='attribute':x.set('unreviewed','true')
   elif mode=='child':E.SubElement(x,'forged')
   else:x.tail='FORGED'
   reject(lambda:h.require_resource_shape(x,row['type'],expected))
 for mode in ['extra','missing','rootattribute','roottext']:
  x=copy.deepcopy(root)
  if mode=='extra':E.SubElement(x,'string',name='unreviewed')
  elif mode=='missing':x.remove(x[0])
  elif mode=='rootattribute':x.set('unreviewed','true')
  else:x.text='FORGED'
  reject(lambda:h.require_catalogue(tag,x,d))
 forged=copy.deepcopy(d);key=next(iter(d['values']));forged['values'][key]['reviewed_value']='FORGED';x=copy.deepcopy(nodes[key]);x.text='FORGED'
 reject(lambda:h.require_edited_resource(tag,key,x,forged))
 for key in h.SHARED_KEYS if tag=='ca-ES-valencia' else ():
  h.require_shared_row(tag,key,d)
  for field in ['source','previous_target','type','reviewed_attributes','reviewed_value','display']:
   f=copy.deepcopy(d);f['values'][key][field]='FORGED';reject(lambda:h.require_shared_row(tag,key,f))
  reject(lambda:h.require_shared_row(tag,key,d,historical_value='old'))
  reject(lambda:h.require_shared_row(tag,key,d,already_present=True))
 counts[tag]={'edits':len(d['values']),'retained':len(d['context']),'holds':len(d['holds'])}
result={'base_commit':m['base_commit'],'manifest_sha256':sha(P/'integration-source-delta.json'),'verified_leaves':1454,'delta_paths':17,'counts':counts,'independent_rejected_mutations':n,'limits':['JVM execution belongs to author lane; no compiled/device claim from this script.']}
(P/'independent-review/integration-independent-checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
