from pathlib import Path
import json,sys
P=Path(__file__).resolve().parents[1];R=P/'integration-source';B=P.parent/'eo-ga-gd-p0-p1-20261027/composition202/source';sys.path.insert(0,str(R/'tools'))
import tibetan_dzongkha_valencian_priority_expectations as h
mapping=json.loads((P/'independent-review/combined-integration-map.json').read_text());windows=set()
for tag,l in mapping['locales'].items():
 d=json.loads((P/'independent-review'/l['ledger']).read_text())
 for row in d['rows']+d['dependencies']:
  for c in row['direct_consumers']:
   lines=(R/c['path']).read_text().splitlines();assert '\n'.join(lines[c['start_line']-1:c['end_line']])==c['context'];windows.add((c['path'],c['line']))
p='Paintroid/src/test/java/org/catrobat/paintroid/local/TaggedColourImportTest.kt';old=(B/p).read_text();new=(R/p).read_text();a=new.index('    private fun boDzValBoundFixture');b=new.index('    @Test fun everyOfferedLanguage',a);new=new[:a]+new[b:]
new=new.replace('        addBoDzVal(expected,boDzValExpectations())\n        assertEquals(100,expected.length())\n','').replace('        val historicalInheritedCatalogues = mapOf("ca-ES-valencia" to "ca")\n        assertEquals("ca", historicalInheritedCatalogues["ca-ES-valencia"])\n        val inheritedCatalogues = historicalInheritedCatalogues.filterKeys { it != "ca-ES-valencia" }','        val inheritedCatalogues = mapOf("ca-ES-valencia" to "ca")').replace('assertEquals(0, inherited)','assertEquals(1, inherited)').replace('// 171 offered - 100 exact current values - 0 inherited.','// 171 offered - 99 exact current values - 1 inherited.')
assert new==old
for bad in ['forged',None,'']:
 try:h.current_sampled_modality_value('bo',bad)
 except ValueError:pass
 else:raise AssertionError('Historical predecessor was not rejected')
for tag in ['dz','ca-ES-valencia','unrelated']:assert h.current_sampled_modality_value(tag,'untouched')=='untouched'
main=(R/'Paintroid/src/test/java/org/catrobat/paintroid/local/TibetanDzongkhaValencianPriorityWordingTest.kt').read_text()
assert 'assertEquals("Primer pla",ui(R.string.ui_fg))' in main
assert 'assertEquals("Fons",ui(R.string.ui_bg))' in main
print('414 exact caller windows; full GA tagged JVM inverse restored; three BO historical predecessor negatives; exact retained FG/BG final literals')
