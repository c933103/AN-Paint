from pathlib import Path
import collections,copy,hashlib,json,re,sys,xml.etree.ElementTree as E
B=Path(__file__).resolve().parents[1]; O=B/'independent-review'; S=B.parent/'yo-zu-xh-p0-p1-20261027/source';sys.path.insert(0,str(S/'tools'))
import translation_catalogues as tc
from test_slovak_slovenian_catalan_priority_wording import token_contract
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=B/'candidate-public/ca-ES-valencia-complete-author-packet.json';q=B/'candidate-public/ca-ES-valencia-adjacent-dependencies.json';d=json.loads(p.read_text());dep=json.loads(q.read_text());rows=d['rows']+dep['rows'];assert len(d['rows'])==341 and len(dep['rows'])==15
assert len({r['identity']for r in rows})==356
assert sha(p)=='bf52d99433d700743eb7b882863ba5f8abb400b3892cb3a5d18547feca74a1b7'
assert sha(q)=='3ff8b894ae62045fbdc014ecd7a9c72d202f29416551a891176bae4b16c95800'
assert d['source_commit']=='b225631aa4609d9d0c64513982f56cb39d864125'
def node(e):
 if e is None:return None
 out={'value':e.text if e.tag=='string'else{c.get('quantity'):c.text for c in e},'attributes':e.attrib}
 if e.tag=='plurals':out['children_attributes']={c.get('quantity'):c.attrib for c in e}
 return out
en={e.tag+'/'+e.get('name'):e for e in E.parse(S/'Paintroid/src/main/res/values/strings.xml').getroot()};cur={e.tag+'/'+e.get('name'):e for e in E.parse(S/d['catalogue_path']).getroot()}
priority={key:t['id']for t in json.loads((S/'translations/string-importance.json').read_text())['tiers']for key in t['keys']if t['id']in('P0','P1')};assert set(priority)=={r['identity']for r in d['rows']}
refs=collections.defaultdict(list); contexts=set(); ids={r['identity']for r in rows}
for f in (S/'Paintroid/src/main').rglob('*'):
 if f.suffix not in('.kt','.java','.xml')or'/res/values'in str(f):continue
 for i,line in enumerate(f.read_text().splitlines()):
  for kind,key in re.findall(r'R\.(string|plurals)\.([A-Za-z0-9_]+)\b',line):
   if kind+'/'+key in ids:refs[kind+'/'+key].append((str(f.relative_to(S)),i+1))
review=[]; holds=[]; edits={};raw={};limitations=[]
for orig in rows:
 r=copy.deepcopy(orig);ident=r['identity'];key=ident.split('/')[1]
 for fld,n in [('english',en[ident]),('current',cur.get(ident))]:
  x=r[fld];assert (None if x is None else {k:v for k,v in x.items()if k!='value_json_sha256'})==node(n),(ident,fld)
  r[fld]=node(n)
 if ident in priority:assert r['tier']==priority[ident]
 assert sorted((c['path'],c['line'])for c in r['direct_consumers'])==sorted(refs[ident]),ident
 for c in r['direct_consumers']:
  actual=(S/c['path']).read_text().splitlines();assert '\n'.join(actual[c['start_line']-1:c['end_line']])==c['context'];contexts.add((c['path'],c['line'],c['start_line'],c['end_line'],c['context']))
 if r.get('author_disposition')=='hold-absent':
  assert r['current']is None and (not r['direct_consumers']or key in {'ui_fg','ui_bg'})and r.get('proposal')is None
  holds.append(ident);r.update(decision='hold_absent',new_acceptance_credit=0,rationale='Exact existing absence retained: no current direct route establishes this route/state-sensitive message, or a new compact FG/BG abbreviation has not been justified by measured button layout. No added English fallback or fabricated behavior.');review.append(r);continue
 v=r['proposal'];a=r['proposed_attributes'];target={'value':v,'attributes':a}
 if isinstance(v,dict):
  assert set(v)=={'one','many','other'};target['children_attributes']=r['proposed_children_attributes'];assert target['children_attributes']=={q:{'quantity':q}for q in ('one','many','other')}
 vals=v if isinstance(v,dict)else{'string':v}
 for quantity,text in vals.items():
  e=r['english']['value'];e=e.get(quantity,e['other'])if isinstance(e,dict)else e
  assert not tc.android_string_errors(text),(ident,tc.android_string_errors(text))
  assert not tc.format_string_errors(text,a.get('formatted')!='false'),ident
  if not text.startswith('@string/'):
   assert token_contract(text)==token_contract(e),(ident,'tokens');assert re.findall(r'\\+n',text)==re.findall(r'\\+n',e),(ident,'newline')
 changed=target!=r['current'];limited=not r['direct_consumers']
 r.update(decision='accept_candidate'if changed else 'accept_retained',reviewed_value=v,reviewed_attributes=a,new_acceptance_credit=1,rationale='Independent full-value comparison of action/object, preservation versus loss, polarity, conditions, counts, paths and menu-label consistency, with exact original/current/caller binding. No native-human or installed-device certification.')
 if limited:limitations.append(ident);r['rationale']+=' No active direct caller: wording-only acceptance, no route or layout certification.'
 if isinstance(v,dict):r['reviewed_children_attributes']=target['children_attributes'];r['rationale']+=' Catalan CLDR48 cardinal one at integer1; many at nonzero multiples of one million; other otherwise for ordinary integer counts. Regional runtime inheritance requires exact Android verification. Full quantities preserve preview/dimensions/application/count/possible movement of attached images; many uses d’imatges.'
 if key in ('ui_choose_a_smaller_output_copy_the_source_images','ui_no_resize_fits_decoder_memory'):assert 'd’eixida' in v and 'de eixida'not in v
 raw[key]=v
 if changed:edits[key]={k:r[k]for k in ['identity','tier','english','current','reviewed_value','reviewed_attributes','decision','rationale','direct_consumers']};edits[key]['type']=ident.split('/')[0];edits[key]['source']=edits[key].pop('english');edits[key]['previous_target']=edits[key].pop('current')
 if changed and isinstance(v,dict):edits[key]['reviewed_children_attributes']=r['reviewed_children_attributes']
 review.append(r)
assert len(holds)==8 and d['counts']['exact_absent_holds']==8
assert raw['ui_save_a5d0d9']=='"Guarda…"'and raw['ui_save']=='"Guarda"'
assert raw['ui_paste']=='"Apega"'
def display(v,seen=()):
 if isinstance(v,dict):return{q:display(t,seen)for q,t in v.items()}
 if v.startswith('@string/'):
  k=v[8:];assert k not in seen;return display(raw[k],seen+(k,))
 if v.startswith('"')and v.endswith('"'):v=v[1:-1]
 return re.sub(r'\\(u[0-9a-fA-F]{4}|.)',lambda m:chr(int(m[1][1:],16))if m[1].startswith('u')else{'n':'\n','r':'\r','t':'\t'}.get(m[1],m[1]),v)
assert display(raw['ui_crop_preview_images']['other']).count(chr(10))==1 and chr(92)+'n'not in display(raw['ui_crop_preview_images']['other'])
out={'source_commit':d['source_commit'],'source_tree':d['source_tree'],'locale':'ca-ES-valencia','catalogue_path':d['catalogue_path'],'rows':review[:341],'dependencies':review[341:],'accepted_resource_text_values':raw,'accepted_display_values':{k:display(v)for k,v in raw.items()},'integration_values':edits,'held_priority_identities':holds,'wording_only_or_route_limited_identities':limitations,'original_author_packet_sha256':sha(p),'original_dependencies_sha256':sha(q),'references':['https://raw.githubusercontent.com/KDE/kate/master/po/ca@valencia/kate.po','https://www.upv.es/entidades/spnl/wp-content/uploads/2024/04/Llenguatge-especialitat-informatic-Recomanacions-Us.pdf','https://www.unicode.org/cldr/charts/48/supplemental/language_plural_rules.html'],'verification':{'source_current_pairs':356,'priorities':341,'companions':15,'unique_direct_consumer_windows':len(contexts),'full_values_read_including_retained':356,'new_accepted_resource_credit':len(raw)},'limits':['Bounded independent model linguistic and static source review, not native-human approval.','No Android/JVM/device execution, screenshot, installed layout or TalkBack certification.','CLDR48 Catalan one/many/other rules checked; actual ca-ES-valencia Android dispatch still requires verification.','Eight exact held absences remain unchanged.']}
f=O/'ca-ES-valencia-complete-review.json';f.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');summary={'locale':'ca-ES-valencia','priority':341,'P0':92,'P1':249,'companions':15,'accepted_resources':len(raw),'accepted_priority':333,'edits':len(edits),'accepted_retained':len(raw)-len(edits),'held_absent':len(holds),'held_present':0,'ledger':f.name,'ledger_sha256':sha(f),'wording_or_route_limited':len(limitations),'direct_consumer_windows':len(contexts)};(O/'ca-ES-valencia-complete-review-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
