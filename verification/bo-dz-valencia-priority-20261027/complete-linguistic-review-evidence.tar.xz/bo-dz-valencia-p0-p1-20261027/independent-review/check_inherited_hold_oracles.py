from pathlib import Path
import json,sys,xml.etree.ElementTree as E
P=Path(__file__).resolve().parents[1];S=P/'integration-source';sys.path.insert(0,str(S/'tools'))
import tibetan_dzongkha_valencian_priority_expectations as h
english={x.get('name'):x for x in E.parse(S/'Paintroid/src/main/res/values/strings.xml').getroot()}
parent={x.get('name'):x for x in E.parse(S/'Paintroid/src/main/res/values-ca/strings.xml').getroot()}
checked=[]
for tag in h.TAGS:
 d=h.bound_fixture(tag);local={x.get('name'):x for x in E.parse(S/d['catalogue_path']).getroot()}
 for key,entry in d['held_display'].items():
  node=local.get(key);origin='direct-held'
  if node is None and tag=='ca-ES-valencia':node=parent.get(key);origin='parent-ca'
  if node is None:node=english[key];origin='default-English'
  assert entry['type']==node.tag
  assert entry['display']==h.decode_android(node.text),(tag,key,entry['display'],node.text)
  checked.append({'tag':tag,'key':key,'resolution':origin,'display':entry['display']})
(P/'independent-review/inherited-hold-oracle-checks.json').write_text(json.dumps(checked,ensure_ascii=False,indent=2)+'\n')
print('Verified',len(checked),'held display oracles against direct/parent/default source')
