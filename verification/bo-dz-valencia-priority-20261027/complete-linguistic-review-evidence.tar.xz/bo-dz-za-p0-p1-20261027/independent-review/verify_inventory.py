from pathlib import Path
import hashlib,json,re,collections,xml.etree.ElementTree as E
B=Path(__file__).resolve().parents[1];S=B.parent/'yo-zu-xh-p0-p1-20261027/source';O=B/'independent-review';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
blobs={r['path']:r for r in json.loads((B.parent/'ceb-nds-csb-p0-p1-20261027/base-tree.json').read_text())['tree']if r['type']=='blob'}
for path,r in blobs.items():
 p=S/path;raw=p.read_bytes();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==r['sha'];assert('100755'if p.stat().st_mode&0o111 else'100644')==r['mode']
bind=json.loads((B/'candidate-public/source-bindings.json').read_text())
for r in bind['bindings']:assert sha(S/r['path'])==r['sha256']and blobs[r['path']]['sha']==r['git_blob_sha1']
def obj(n):return None if n is None else{'value':''.join(n.itertext()),'attributes':n.attrib}
EN={e.tag+'/'+e.get('name'):e for e in E.parse(S/'Paintroid/src/main/res/values/strings.xml').getroot()};tiers={k:t['id']for t in json.loads((S/'translations/string-importance.json').read_text())['tiers']for k in t['keys']if t['id']in('P0','P1')};refs=collections.defaultdict(list)
for base in('Paintroid/src/main','app/src/main'):
 for p in(S/base).rglob('*'):
  if p.suffix not in('.kt','.java','.xml')or'/res/values'in str(p):continue
  for i,line in enumerate(p.read_text().splitlines()):
   for kind,k in re.findall(r'R\.(string|plurals)\.([A-Za-z0-9_]+)\b',line):refs[kind+'/'+k].append((str(p.relative_to(S)),i+1))
summary={};windows=set()
for tag in('bo','dz','za'):
 p=B/f'candidate-public/{tag}-complete-inventory.json';d=json.loads(p.read_text());assert d['source_commit']=='b225631aa4609d9d0c64513982f56cb39d864125';assert set(tiers)=={r['identity']for r in d['rows']};cur={e.tag+'/'+e.get('name'):e for e in E.parse(S/d['catalogue_path']).getroot()}
 for r in d['rows']:
  ident=r['identity'];assert r['tier']==tiers[ident]and {k:v for k,v in r['english'].items() if k!='value_json_sha256'}==obj(EN[ident])and (None if r['current']is None else {k:v for k,v in r['current'].items()if k!='value_json_sha256'})==obj(cur.get(ident));assert sorted((c['path'],c['line'])for c in r['direct_consumers'])==sorted(refs[ident])
  for c in r['direct_consumers']:
   lines=(S/c['path']).read_text().splitlines();assert '\n'.join(lines[c['start_line']-1:c['end_line']])==c['context'];windows.add((c['path'],c['line'],c['start_line'],c['end_line']))
 summary[tag]={'all_priority_pairs':341,'present':sum(r['current']is not None for r in d['rows']),'inventory_sha256':sha(p),'new_acceptance_credit':0}
out={'source_commit':bind['source_commit'],'source_tree':bind['source_tree'],'all_blobs_modes_verified':len(blobs),'bound_files_verified':len(bind['bindings']),'unique_priority_caller_windows':len(windows),'locales':summary,'scope':'Independent structural/source preflight only. Does not accept proposed or retained language wording; author packets and whole-message/companion review remain required.'};(O/'inventory-source-preflight.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
