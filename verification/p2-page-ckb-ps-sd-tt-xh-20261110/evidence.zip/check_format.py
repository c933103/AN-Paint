import base64, json, pathlib, re, sys
sys.path.insert(0, 'tools')
from current_localization_contracts import current_display

w = pathlib.Path('/workspace/shared/anpaint-p2-more-evidence')
p = json.load(open(w / 'inputs.json'))
accepted = json.load(open(w / 'review.json'))['accepted']
zeros = dict(line.split() for line in (w / 'locale-digits.txt').read_text().splitlines())
cases = {
    'formats22_page_description': [['PDF', 'test %1$d · 東京.pdf', 1], ['TIFF', 'image.tiff', 2], ['PDF', '', 4096], ['TIFF', 'red\n%3$d.tif', 5]],
    'formats22_page_range': [[1], [4096]],
    'formats22_loading_page': [[1, 1], [2, 6], [4096, 4096]],
    'formats22_page_dimensions': [[1, 1, 1, 1], [2, 3, 1024, 768], [4096, 4096, 1000000, 65535]],
    'formats22_preview_unavailable': [[''], ['خرابی · ошибка · त्रुटि'], ['first\nsecond'], ['%1$s 100%']],
    'formats22_pdf_page_count': [[1], [4096]],
}
b64 = lambda x: base64.b64encode(x.encode()).decode()
rows = []
for locale, values in accepted.items():
    zero = ord(zeros[locale])
    for key, variants in cases.items():
        if key not in values:
            continue
        template = current_display(locale, key)
        for args in variants:
            def expected_slot(match):
                value = args[int(match[1]) - 1]
                if match[2] == 'd':
                    return ''.join(chr(zero + ord(c) - ord('0')) if '0' <= c <= '9' else c for c in str(value))
                return str(value)
            expected = re.sub(r'%([0-9]+)[$]([ds])', expected_slot, template)
            tokens = ['d:' + str(x) if isinstance(x, int) else 's:' + b64(x) for x in args]
            rows.append('\t'.join([locale, key, b64(template), b64(expected), *tokens]))
(w / 'format-cases.tsv').write_text('\n'.join(rows) + '\n')
(w / 'format-case-count.txt').write_text(str(len(rows)) + '\n')
print(f'{len(rows)} temporary exact-output cases from accepted changed XML values only; numeric glyphs independently probed')
