import base64,copy,hashlib,json,pathlib,subprocess,xml.etree.ElementTree as ET
D=pathlib.Path(__file__).resolve().parent;ROOT=D.parent/'next-repo'
p=json.loads((D/'serbian-candidate-review.json').read_text());review=json.loads(pathlib.Path('/workspace/scratch/bbca2890f602/serbian-independent-20261029/review.json').read_text())
changed=[]
for rr in review['rows']:
 rows=p['locales'][rr['tag']]['priority' if rr['group']=='priority' else 'dependencies'];r=next(r for r in rows if r['key']==rr['key'])
 if r['candidate']!=rr['original_candidate']:raise ValueError('review binding')
 if rr['final_candidate']!=r['candidate']:changed.append((rr['tag'],rr['key']));r['candidate']=rr['final_candidate']
if changed!=[('sr-Cyrl','commons_svg_original_size_too_large')]:raise ValueError(changed)
(D/'serbian-candidate-review-successor.json').write_text(json.dumps(p,ensure_ascii=False,indent=2))
base={e.attrib['name']:e.text for e in ET.parse(ROOT/'Paintroid/src/main/res/values/strings.xml').getroot() if e.tag=='string'}
cases=[];java=[];used={}
def literal(s):return json.dumps(s,ensure_ascii=False)
for tag,l in p['locales'].items():
 current={e.attrib['name']:e.text for e in ET.parse(ROOT/('Paintroid/src/main/res/values-b+'+tag.replace('-','+')+'/strings.xml')).getroot() if e.tag=='string'}
 status={r['key']:r['status'] for r in l['priority']+l['dependencies']}
 for r in l['priority']+l['dependencies']:
  if r['candidate'] is not None:current[r['key']]=r['candidate']
 def display(k):
  v=current.get(k,base[k]);fallback=k not in current
  if v.startswith('@string/'):return display(v[8:])
  if len(v)>1 and v[0]==v[-1]=='"':v=v[1:-1]
  v=v.replace('\\n','\n').replace("\\'","'").replace('\\"','"')
  used[tag+'/'+k]={'key':k,'locale':tag,'display':v,'scope':status.get(k,'outside-priority companion; not newly reviewed'),'english_fallback':fallback}
  return v
 def R(k,*args):
  s=literal(display(k))
  if not args:return s
  a=[x[1] if isinstance(x,tuple) else (literal(x) if isinstance(x,str) else str(x)+('L' if isinstance(x,int) else '')) for x in args]
  return 'String.format(Locale.forLanguageTag('+literal(tag)+'),'+s+','+','.join(a)+')'
 def V(expr):return ('expression',expr)
 def case(group,name,expr,keys):
  i=len(cases);cases.append({'locale':tag,'group':group,'case':name,'keys':keys});java.append('System.out.println('+str(i)+'+"\\t"+Base64.getEncoder().encodeToString(('+expr+').getBytes(StandardCharsets.UTF_8)));')
 def simple(group,k,*args):case(group,k,R(k,*args),[k])
 for k in ['ui_the_full_image_and_working_buffers_exceed_the','ui_codec_resize_memory_floor','ui_sampled_resize_memory_explanation','ui_assembly_source_memory_floor','ui_no_resize_fits_decoder_memory']:simple('memory',k)
 simple('memory','ui_d_d_pixels_2f_mp_exceeds_the_current',12000,8000,96.0,24.0)
 simple('memory','ui_the_decoder_and_editing_buffers_need_about_the','384 MiB','256 MiB')
 simple('memory','ui_current_safe_editing_budget_s_up_to_2f','256 MiB',24.0)
 simple('memory','ui_original_decoded_image_rgba_4_bytes_pixel_estimated','12000 × 8000 px','366 MiB','512 MiB')
 estimate=R('ui_copy_decoded_image_at_this_size_estimated_loading','1 × 1 px','4 B','384 MiB')+'+"\\n"+'+R('ui_no_resize_fits_decoder_memory')
 case('memory','native-minimum-output-floor',estimate,['ui_copy_decoded_image_at_this_size_estimated_loading','ui_no_resize_fits_decoder_memory'])
 for suffix in ['still','poster']:
  for exact in [True,False]:
   frames=literal('4') if exact else R('formats22_at_least_frames',4)
   case('import','animation-'+suffix+('-exact' if exact else '-lower-bound'),R('formats22_animation_message','PNG',V(frames))+'+"\\n\\n"+'+R('formats22_animation_'+suffix),['formats22_animation_message','formats22_at_least_frames','formats22_animation_'+suffix])
 simple('import','formats22_animation_unknown','PNG')
 for k in ['colour_unsupported_icc_model','commons_svg_original_size_too_large','commons_svg_original_size_unavailable','formats22_import_limit']:simple('import',k)
 for k in ['save20_title','save20_file_name','save20_file_format','ui_choose_location','ui_save','ui_save_explanation23','ui_export_as23','ui_export_explanation23','ui_share_explanation34','ui_export_did_not_save23','ui_save_your_changes','ui_keep_editing23','ui_discard_changes23']:simple('save-controls',k)
 for k in ['ui_autosave_is_paused_to_protect_that_draft_use','ui_a_separate_recovery_copy_has_been_kept_use']:simple('save-recovery',k,V(R('ui_the_previous_draft_needs_more_memory_to_reopen')))
 for k in ['ui_recovery_copy_exported_extract_canvas_png_from_the','ui_menu_file','ui_export_recovery_copy','ui_load_image']:simple('save-recovery',k)
 for k in ['ui_crop_image','ui_apply_crop','ui_crop_preview_drag_an_edge_or_corner_drag','ui_the_crop_must_contain_at_least_one_pixel','ui_keeps_pixels_at_the_top_left_smaller_canvas','ui_scales_the_image_unlock_the_ratio_to_stretch']:simple('crop',k)
 for unit in ['ui_pixels_6ec9c2','ui_percent_fd8671']:
  for k in ['ui_width_in','ui_height_in']:case('crop',k+'-'+unit,R(k,V(R(unit))),[k,unit])
 for edge in ['ui_left','ui_top','ui_right','ui_bottom']:
  for k in ['ui_trim_in_pixels','ui_trim_in_percent']:case('crop',k+'-'+edge,R(k,V(R(edge))),[k,edge])
 for k in ['ui_expand_tool_category','ui_collapse_tool_category']:case('accessibility',k,R(k,V(R('ui_drawing23')),V(R('ui_pencil'))),[k,'ui_drawing23','ui_pencil'])
 simple('crop','ui_d_d_px_d_pixels_2f_mp',12000,8000,96000000,96.0)
src='import java.util.*; import java.nio.charset.StandardCharsets; class SerbianRender { public static void main(String[] a) { '+''.join(java)+' } }'
(D/'SerbianRender.java').write_text(src)
r=subprocess.run(['java',str(D/'SerbianRender.java')],text=True,capture_output=True,check=True)
for line in r.stdout.splitlines():
 i,b=line.split('\t',1);cases[int(i)]['rendered']=base64.b64decode(b).decode()
out={'packet_original_sha256':hashlib.sha256((D/'serbian-candidate-review.json').read_bytes()).hexdigest(),'packet_successor_sha256':hashlib.sha256((D/'serbian-candidate-review-successor.json').read_bytes()).hexdigest(),'scope':'Complete individual strings and actual consumer compositions. Control sequences are separate controls, not invented concatenations. Host Java Locale formatting + finite XML display model; NOT Android runtime/layout acceptance. English P2 fallbacks explicitly retained.','cases':cases,'supporting_values':list(used.values())}
(D/'serbian-composed-renderings.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps({'cases':len(cases),'supporting_values':len(used),'successor_sha256':out['packet_successor_sha256'],'fallbacks':[k for k,v in used.items() if v['english_fallback']]},indent=2))
