import hashlib, json, pathlib, re, sys, zipfile, xml.etree.ElementTree as E

p = pathlib.Path(__file__).parent
m = json.loads((p/'verification-input.json').read_text())
gates = json.loads((p/'terminal-gates.json').read_text())
assert gates['run']['status'] == 'completed' and gates['run']['conclusion'] == 'success'
assert gates['run']['head_sha'] == m['head'] and gates['run']['id'] == m['run']
assert gates['run']['run_attempt'] == 1 and gates['run']['event'] == 'pull_request'
required = {'Verify recent same-tree PR evidence', 'Build APK and corresponding source', 'Regression tests and lint', 'Exact-script resource generation', 'Position dialog API 35', 'Core emulator API 35', 'Emulator API 35'}
assert {j['name'] for j in gates['jobs']['jobs']} == required
assert all(j['status'] == 'completed' and j['conclusion'] == 'success' and j['head_sha'] == m['head'] for j in gates['jobs']['jobs'])
reviews = json.loads((p/'final-review.json').read_text())
summary = [x for x in reviews if '<!-- codex-review-state:v1 ' in x['body']]
assert len(summary) == 1 and summary[0]['user']['login'] == 'chatgpt-codex-connector[bot]'
marker = json.loads(re.search(r'<!-- codex-review-state:v1 (.*?) -->', summary[0]['body'])[1])
assert marker['code_review'] == {'commit_sha': m['head'], 'has_any_findings': False, 'has_unresolved_findings': False, 'status': 'completed'}
assert marker['security_review']['commit_sha'] == m['head'] and marker['security_review']['status'] == 'completed'
archives = {}
for kind, a in m['artifacts'].items():
    raw = (p/(kind+'.zip')).read_bytes()
    assert 'sha256:'+hashlib.sha256(raw).hexdigest() == a['digest'], kind
    assert not a['expired'] and a['workflow_run']['id'] == m['run'] and a['workflow_run']['head_sha'] == m['head']
    assert m['checkout'] in a['name']
    z = zipfile.ZipFile(p/(kind+'.zip')); names = z.namelist()
    assert len(names) == len(set(names)) and z.testzip() is None
    assert all(not pathlib.PurePosixPath(n).is_absolute() and '..' not in pathlib.PurePosixPath(n).parts for n in names)
    archives[kind] = z
exact = json.loads(archives['exact'].read('summary.json'))
assert exact['success'] and exact['commit'] == m['checkout'] and exact['tree'] == m['tree'] and len(exact['probes']) == 13
for q in exact['probes']:
    assert (q['exit_code'] == 0) == q['expected_success']
    assert hashlib.sha256(archives['exact'].read(q['name']+'.log')).hexdigest() == q['log_sha256']
reg = archives['regression']; obs = json.loads(reg.read('build/reports/ci-phases/observed-inputs.json'))
assert obs['commit'] == m['checkout'] and obs['run_id'] == str(m['run']) and obs['attempt'] == '1'
counts = {k: 0 for k in ['tests','failures','errors','skipped']}
xmls = [n for n in reg.namelist() if '/test-results/testDebugUnitTest/TEST-' in n and n.endswith('.xml')]
for n in xmls:
    node = E.fromstring(reg.read(n))
    for k in counts: counts[k] += int(node.get(k, 0))
assert counts['tests'] > 0 and not sum(counts[k] for k in ['failures','errors','skipped'])
pm = re.search(r'Ran (\d+) tests in [\d.]+s\s+OK(?: \(skipped=(\d+)\))?\s*$', reg.read('build/reports/ci-phases/python.log').decode()); assert pm
comp = archives['composition']; identity = json.loads(comp.read('composed-device-identity.json'))
assert identity['commit'] == m['checkout'] and identity['run_id'] == str(m['run']) and identity['device_sdk'] == 35 and identity['build_variant'] == 'debug'
assert identity['composed_in_run_attempt'] == 1 and identity['group_run_attempts'] == {'core':1, 'position':1}
build = json.loads(archives['apk-source'].read('build/delivery/build-info.json'))
instrumentation = json.loads((p/'instrumentation-digests.json').read_text())
assert identity['apk_sha256'] == build['apk_sha256'] and identity['source_sha256'] == build['source_sha256']
assert identity['test_apk_sha256'] == instrumentation['apk_sha256']['app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk']
root = p/'composition'
for n in comp.namelist():
    if n.endswith('/'): continue
    f = root/n; f.parent.mkdir(parents=True, exist_ok=True); f.write_bytes(comp.read(n))
sys.path.insert(0, str(p/'source/tools'))
from app_instrumentation_matrix import verify_app_reports, read_app_reports
from run_android_instrumentation import declared_tests, source_tests_sha256
source = p/'source/app/src/androidTest'; eligible = declared_tests(source, sdk_level=35)
app = verify_app_reports(eligible, 35, read_app_reports(root, 35), source_tests_sha256(source), declared_tests(source)-eligible)
assert app['source_tests_sha256'] == identity['source_tests_sha256'] and app['completed_tests'] == app['selected_tests'] == app['sdk_eligible_tests']
native = json.loads(comp.read('Paintroid/androidTest-results/summary.json'))
assert native['success'] and native['completed_tests'] == native['expected_tests'] and not any(native[k] for k in ['missing','unexpected','errors'])
assert all(c['status'] == 'passed' for c in native['cases'])
result = {'verified':True, 'head':m['head'], 'checkout':m['checkout'], 'tree':m['tree'], 'run':m['run'], 'attempt':1, 'artifact_digests':{k:a['digest'] for k,a in m['artifacts'].items()}, 'exact_probes':13, 'python_passes':int(pm[1])-int(pm[2] or 0), 'python_skips':int(pm[2] or 0), 'jvm':counts, 'jvm_xml_files':len(xmls), 'native_api35':native['completed_tests'], 'app_api35':app['completed_tests'], 'identity':identity, 'limits':'Independent source-bound archive/report verification, not a new device run, native-human review or exhaustive pixel/layout certification. CI debug signing only; no release.'}
(p/'independent-verification.json').write_text(json.dumps(result, indent=2)+'\n')
(p/'fresh-app-validator.json').write_text(json.dumps(app, indent=2)+'\n')
with zipfile.ZipFile(p/'verified-results.zip', 'w', zipfile.ZIP_DEFLATED, 9) as out:
    for name in ['independent-verification.json','verification-input.json','verify-complete.py','verify-available.py','available-verification.json','exact.zip','terminal-gates.json','final-review.json','tested-source.json','instrumentation-digests.json','fresh-app-validator.json','position-verification.json','regression-verification.json']:
        out.write(p/name, name)
    for n in xmls+[n for n in reg.namelist() if n.startswith('build/reports/ci-phases/') and not n.endswith('/')]: out.writestr('regression/'+n, reg.read(n))
    for n in comp.namelist():
        if n.endswith('.json'): out.writestr('composition/'+n, comp.read(n))
print(json.dumps(result, indent=2))
