import hashlib,io,json,pathlib,zipfile
p=pathlib.Path(__file__).parent
def sha(data):return hashlib.sha256(data).hexdigest()
def archive(path,digest):
 b=path.read_bytes();assert sha(b)==digest
 z=zipfile.ZipFile(io.BytesIO(b));names=z.namelist();assert len(set(names))==len(names)
 assert all(not pathlib.PurePosixPath(n).is_absolute() and '..' not in pathlib.PurePosixPath(n).parts for n in names)
 assert z.testzip() is None
 return z
z=archive(p/'apk-source.zip','e466049e149691ffea5a67c1f6047464070176ed60cb93533cfaf0e4c81627fa')
info=json.loads(z.read('build/delivery/build-info.json'))
assert info['commit']=='5e231000d3291bafcf7eba0c27f4c57bf574ffa2' and info['run_id']=='42964894448' and info['build_variant']=='debug'
apk=z.read('app/build/outputs/apk/debug/app-debug.apk');source=z.read('build/delivery/AN-Paint-source.zip')
assert sha(apk)==info['apk_sha256'] and sha(source)==info['source_sha256']
with zipfile.ZipFile(io.BytesIO(apk)) as a:assert a.read('assets/local-source/AN-Paint-source.zip')==source
s=zipfile.ZipFile(io.BytesIO(source));tree=json.load(open(p/'tested-tree.json'));assert not tree['truncated'] and tree['sha']=='a275820307774369d0796d4ab1c03d35cbd82494'
blobs=[e for e in tree['tree'] if e['type']=='blob'];missing=[];matched=[]
for e in blobs:
 n='AN-Paint/'+e['path']
 if n not in s.namelist():missing.append(e['path']);continue
 b=s.read(n);assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==e['sha'],e['path'];matched.append(e['path'])
assert missing==['.gitignore','.idea/codeStyles/Project.xml','colorpicker/.gitignore']
exact=archive(p/'exact.zip','e54c0049f063067e2f701489cbda142d8c4ee91d1287b410e0c79627e05e9825')
summary=json.loads(exact.read('summary.json'))
assert summary['success'] and summary['commit']==info['commit'] and summary['tree']==tree['sha'] and len(summary['probes'])==13
for q in summary['probes']:
 assert (q['exit_code']==0)==q['expected_success']
 assert sha(exact.read(q['name']+'.log'))==q['log_sha256']
result={'verified':True,'run':42964894448,'head':'79cbd92fa338b6c82e61f6aa083ff8e6f0e1b7be','checkout':info['commit'],'tree':tree['sha'],'apk_source_artifact':13830951918,'artifact_sha256':'e466049e149691ffea5a67c1f6047464070176ed60cb93533cfaf0e4c81627fa','apk_sha256':info['apk_sha256'],'source_sha256':info['source_sha256'],'embedded_source_equals_standalone':True,'tracked_blobs':len(blobs),'matching_tracked_source_members':len(matched),'source_bundle_omissions':missing,'omissions_note':'Existing Gradle/Ant exclusions for VCS ignore files and IDE settings. No included tracked source blob differs.','exact_script_artifact':13831017378,'exact_script_probes':len(summary['probes']),'signing':info['signing'],'limits':'Artifact identity and report verification only. Other required CI is still pending; no merge/release or installed linguistic acceptance claim.'}
(p/'available-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
