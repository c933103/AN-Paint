# Status/control translation context

Base is develop e2ed367a9459907effcfb5f877c7dd86ef56a8f7, tree 287767b1e2d5566947d31cb3a3734054ca4835fb. The 25 candidate identities are absent from the four offered canonical catalogues and from those catalogues at each of the eight held application heads. Existing complete XML nodes and attributes are not to be changed.

The complete source and candidate values are in inputs.json and candidate.json. The actual consumers were read at this source:

- ImageResizeDialog.kt:26–58 and AssemblyActivity.kt:303–312. The budget is available working memory. The status is conditional on the existing memory policy, not a guarantee of successful decoding or saving.
- SaveOptionsDialog.kt:76–91. Lossless mode is a checkbox labelled with the current format name through the single positional %1$s string argument. It does not mean a free or smaller file.
- AssemblyActivity.kt:184–197. Files/Documents guidance follows failure of ACTION_OPEN_DOCUMENT and its ACTION_GET_CONTENT fallback. Names are descriptive with the source English labels retained; Android vendor labels may vary. No promise that enabling one always fixes access.
- MediaGalleryActivity.kt:331–347. The whole download URL must satisfy the provider policy. Rejection can include non-host aspects; translations must not reduce this to a host-only restriction. The other error is exhaustion of the bounded redirect loop, not evidence of an outage or compromised provider.
- AssemblyActivity.kt:151–157. Unavailable time replaces a missing image modification timestamp. It does not refer to waiting time or a timeout.
- ClassicPaintActivity.kt:776 and 818–826. Pixel tapping belongs to the colour-picker instruction. Tool option is the single-choice setting dialog title.
- AssemblyActivity.kt:88 and output flow. Edit in Paint names the Paint editing action, not an export format.

Terminology choices follow the surrounding catalogues: Hindi औज़ार and पिक्सेल; Bengali টুল, পিক্সেল and ক্ষতিহীন; Marathi साधन, दृश्यबिंदू and मेमरी; Gujarati સાધન, પિક્સેલ and મેમરી. Existing wording is contextual input, not an approval oracle. No external primary terminology source was consulted.

Independent model review is required before integration. Neither that review nor generic checks constitute native-human certification, exhaustive installed layout/glyph/speech/device acceptance or a release. Older held actions, withdrawn acceptance and recheck obligations remain unchanged.
