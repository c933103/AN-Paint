import hashlib,io,json,pathlib,zipfile
p=pathlib.Path(__file__).parent
def sha(data):return hashlib.sha256(data).hexdigest()
def archive(path,digest):
 b=path.read_bytes();assert sha(b)==digest
 z=zipfile.ZipFile(io.BytesIO(b));names=z.namelist();assert len(set(names))==len(names)
 assert all(not pathlib.PurePosixPath(n).is_absolute() and '..' not in pathlib.PurePosixPath(n).parts for n in names)
 assert z.testzip() is None
 return z
z=archive(p/'apk-source.zip','4b022f89433b2f427fa80d1fa5ee5fe790ef9086cc4f5cf2aa60ced06ed3419e')
info=json.loads(z.read('build/delivery/build-info.json'))
assert info['commit']=='51552b6af55aae035f2c9e6fea87c99036966d94' and info['run_id']=='42959591225' and info['build_variant']=='debug'
apk=z.read('app/build/outputs/apk/debug/app-debug.apk');source=z.read('build/delivery/AN-Paint-source.zip')
assert sha(apk)==info['apk_sha256'] and sha(source)==info['source_sha256']
with zipfile.ZipFile(io.BytesIO(apk)) as a:assert a.read('assets/local-source/AN-Paint-source.zip')==source
s=zipfile.ZipFile(io.BytesIO(source));tree=json.load(open(p/'tested-tree.json'));assert not tree['truncated'] and tree['sha']=='287767b1e2d5566947d31cb3a3734054ca4835fb'
blobs=[e for e in tree['tree'] if e['type']=='blob'];missing=[];matched=[]
for e in blobs:
 n='AN-Paint/'+e['path']
 if n not in s.namelist():missing.append(e['path']);continue
 b=s.read(n);assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==e['sha'],e['path'];matched.append(e['path'])
assert missing==['.gitignore','.idea/codeStyles/Project.xml','colorpicker/.gitignore']
exact=archive(p/'exact.zip','b70eee76cba738837ba89c26d01b0cfd344afd5b0fdf5ac933c06991c70e6ecb')
summary=json.loads(exact.read('summary.json'))
assert summary['success'] and summary['commit']==info['commit'] and summary['tree']==tree['sha'] and len(summary['probes'])==13
for q in summary['probes']:
 assert (q['exit_code']==0)==q['expected_success']
 assert sha(exact.read(q['name']+'.log'))==q['log_sha256']
result={'verified':True,'run':42959591225,'head':'984ae0731e566dda68d25d79feb29eaca153bc19','checkout':info['commit'],'tree':tree['sha'],'apk_source_artifact':13828767676,'artifact_sha256':'4b022f89433b2f427fa80d1fa5ee5fe790ef9086cc4f5cf2aa60ced06ed3419e','apk_sha256':info['apk_sha256'],'source_sha256':info['source_sha256'],'embedded_source_equals_standalone':True,'tracked_blobs':len(blobs),'matching_tracked_source_members':len(matched),'source_bundle_omissions':missing,'omissions_note':'Existing Gradle/Ant exclusions for VCS ignore files and IDE settings. No included tracked source blob differs.','exact_script_artifact':13827794409,'exact_script_probes':len(summary['probes']),'signing':info['signing'],'limits':'Artifact identity and report verification only. Other required CI is still pending; no merge/release or installed linguistic acceptance claim.'}
(p/'available-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
