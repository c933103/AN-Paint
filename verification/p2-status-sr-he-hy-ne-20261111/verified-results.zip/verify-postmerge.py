import json,pathlib,hashlib,zipfile
p=pathlib.Path(__file__).parent;x=json.loads((p/'postmerge-receipt.json').read_text());m=json.loads((p/'postmerge-metadata.json').read_text());a=json.loads((p/'fresh-artifact-metadata.json').read_text());merge=json.loads((p/'merge.json').read_text())
wanted={'reused':True,'repository_id':1362702425,'merge':'e2ed367a9459907effcfb5f877c7dd86ef56a8f7','base':'51ca0b7abf9b6ba824411ebea98b74d39672859d','head':'984ae0731e566dda68d25d79feb29eaca153bc19','checkout':'51552b6af55aae035f2c9e6fea87c99036966d94','tree':'287767b1e2d5566947d31cb3a3734054ca4835fb','pull_request':429,'run_id':42959591225,'run_attempt':1,'build_variant':'debug','device_sdk':35}
for k,v in wanted.items():assert x[k]==v,(k,x[k])
assert merge['sha']==x['merge'] and merge['tree']['sha']==x['tree'] and [p['sha'] for p in merge['parents']]==[x['base'],x['head']]
assert len(m['jobs']['jobs'])==7 and sum(j['conclusion']=='skipped' for j in m['jobs']['jobs'])==6 and sum(j['conclusion']=='success' for j in m['jobs']['jobs'])==1
assert m['runs']['workflow_runs'][0]['id']==42962455517 and m['runs']['workflow_runs'][0]['conclusion']=='success'
byid={q['id']:q for q in a['artifacts']}
for k,q in x['artifacts'].items():
 f=byid[q['artifact_id']];assert all(f[z]==q[z] for z in ['name','digest']);assert not f['expired'] and f['workflow_run']['id']==x['run_id'] and f['workflow_run']['head_sha']==x['head']
assert x['review']['comment_id']==6787052578 and x['review']['head']==x['head'] and x['review']['app_id']==1144995 and x['review']['bot_id']==199175422
z=zipfile.ZipFile(p/'postmerge.zip');assert z.testzip() is None and z.namelist()==['prior-evidence.json'];digest=hashlib.sha256((p/'postmerge.zip').read_bytes()).hexdigest();assert digest=='9ce53669190aba90bec0dcb718109d74f48a3d6e2aa8ed1b08903551db8e9497'
r={'verified':True,'merge':x['merge'],'tree':x['tree'],'postmerge_run':42962455517,'receipt_artifact':13829144857,'receipt_sha256':digest,'original_run':x['run_id'],'original_checkout':x['checkout'],'original_attempt':1,'six_original_artifact_metadata_matched':True,'fresh_preflight_jobs':1,'downstream_skips':6,'scope':'Verified bounded same-tree original-experiment reuse. Six downstream jobs skipped, not rerun. Original APK/source, instrumentation, regression, exact-script and composed-device bytes were independently checked before merge. The workflow also checked original core/position bytes; no separate redownload of those was performed in this follow-up.'}
(p/'postmerge-verification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
with zipfile.ZipFile(p/'verified-results.zip','a',zipfile.ZIP_DEFLATED,9) as out:
 for name in ['postmerge-metadata.json','postmerge.zip','verify-postmerge.py','fresh-artifact-metadata.json','postmerge-verification.json']:out.write(p/name,name)
b=(p/'verified-results.zip').read_bytes();print('Final packet',len(b),hashlib.sha256(b).hexdigest(),len(zipfile.ZipFile(p/'verified-results.zip').namelist()))
