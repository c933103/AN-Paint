from pathlib import Path
import json,hashlib,shutil,xml.etree.ElementTree as E
B=Path(__file__).resolve().parent;H=B.parent/'ha-ig-ln-p0-p1-20261027';S=B/'source'
base=json.loads((H/'source-remote-tree.json').read_text());assert base['sha']=='8ffc6e1b1692f882843a76bbf42bf5a3adb3267c'
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
for r in base['tree']:
 if r['type']!='blob':continue
 p=H/'source'/r['path'];assert blob(p.read_bytes())==r['sha'],r['path'];q=S/r['path'];q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
(B/'integration-base-tree.json').write_text(json.dumps(base,indent=2)+'\n')
eng={e.get('name'):e for e in E.parse(S/'Paintroid/src/main/res/values/strings.xml').getroot()}
def val(e):return {'value':{c.get('quantity'):c.text for c in e} if e.tag=='plurals' else e.text,'attributes':e.attrib}
results=[]
for loc in ('yo','zu','xh'):
 p=B/f'independent-review/{loc}-complete-independent-review.json';r=json.loads(p.read_text());packet=B/f'candidate-public/{loc}-complete-author-packet.json';dep=B/f'candidate-public/{loc}-adjacent-dependencies.json'
 assert hashlib.sha256(packet.read_bytes()).hexdigest()==r['packet_sha256'];assert hashlib.sha256(dep.read_bytes()).hexdigest()==r['dependencies_sha256']
 inv=json.loads(packet.read_text());cur={e.get('name'):e for e in E.parse(S/inv['catalogue_path']).getroot()};accepted={};edits={};absent=[];present={};contexts=set()
 for row in r['rows']+r['dependencies']:
  k=row['identity'].split('/',1)[1];ev=val(eng[k]);assert ev['value']==row['english']['value'] and ev['attributes']==row['english']['attributes'];actual=val(cur[k]) if k in cur else None
  assert actual==({a:row['current'][a]for a in ('value','attributes')}if row['current']is not None else None),(loc,k,actual,row['current'])
  for w in row['direct_consumers']:
   lines=(S/w['path']).read_text().splitlines();assert '\n'.join(lines[w['start_line']-1:w['end_line']])==w['context'];contexts.add((w['path'],w['start_line'],w['end_line']))
  if row['decision'].startswith('accept'):
   accepted[k]=row['reviewed_value'];assert row['reviewed_value']==row['proposal']
   if actual!={'value':row['reviewed_value'],'attributes':row['reviewed_attributes']}:edits[k]={'previous_target':row['current'],'reviewed_value':row['reviewed_value'],'reviewed_attributes':row['reviewed_attributes']}
  elif row['decision']=='hold_absent':assert actual is None;absent.append(k)
  else:
   assert row['decision']=='hold_present_terminology' and actual is not None
   present[k]={'type':row['identity'].split('/')[0],'target':actual['value'],'attributes':actual['attributes']}
 assert len(accepted)==(342 if loc=='xh'else 346) and len(absent)==10 and len(present)==(4 if loc=='xh'else 0)
 assert len(edits)==(318 if loc=='xh'else 346)
 out={'locale':loc,'catalogue_path':inv['catalogue_path'],'rows':r['rows'],'dependencies':r['dependencies'],'accepted_resource_text_values':accepted,'integration_values':edits,'held_absent':sorted(absent),'held_present':present,'wording_only_or_route_limited_identities':[x['identity']for x in r['rows']if x['decision'].endswith('wording_only')],'provenance':{'independent_receipt_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'original_source':r['source_commit'],'integration_source':'f9e125d9ee65c7c52e5af76a76f0c8b706aac48f','additional_linguistic_credit_from_rebind':0}}
 (B/f'independent-review/{loc}-integration-ledger.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');results.append({'locale':loc,'accepted':len(accepted),'typed_edits':len(edits),'retained_accepted':len(accepted)-len(edits),'held_absent':absent,'held_present':present,'exact_caller_windows':len(contexts)})
(B/'integration-parent-rebind-author.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n');print(results)
