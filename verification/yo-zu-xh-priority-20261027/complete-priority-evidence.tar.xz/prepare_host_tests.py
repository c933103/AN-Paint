from pathlib import Path
import json,pprint
B=Path(__file__).resolve().parent;S=B/'source';d=json.loads((S/'tools/fixtures/current_localization/yoruba_zulu_xhosa_priority_wording.json').read_text());locs=d['locales']
constants={
'HELD_PRESENT':{k:v['held_present']for k,v in locs.items()},
'UNCHANGED':{k:set(v['unchanged_accepted'])for k,v in locs.items()},
'PREDECESSORS':{k:v['predecessors']for k,v in locs.items()},
'OUTSIDE_REVIEW':{k:v['outside_review']for k,v in locs.items()},
'ATTRIBUTE_EXCEPTIONS':{k:v['target_attribute_exceptions']for k,v in locs.items()},
'EDIT_COUNTS':{k:len(v['changed'])for k,v in locs.items()},
'PRIORITY_STATUS':{k:v['priority_status']for k,v in locs.items()},
'WORDING_ONLY':{k:set(v['wording_only'])for k,v in locs.items()}}
code='\n\n'.join(k+' = '+pprint.pformat(v,width=115,sort_dicts=True)for k,v in constants.items())
s=(B/'priority_host_test_template.py').read_text().replace('# GENERATED_ACCEPTED_PARTITIONS',code)
(S/'tools/test_yoruba_zulu_xhosa_priority_wording.py').write_text(s)
print('fixture bytes',len((S/'tools/fixtures/current_localization/yoruba_zulu_xhosa_priority_wording.json').read_bytes()))
