"""Integrate final independently accepted complete maps only; preserve all unrelated XML bytes."""
from pathlib import Path
from collections import Counter
import hashlib,json,re,xml.etree.ElementTree as E
from xml.sax.saxutils import escape
B=Path(__file__).resolve().parent;S=B/'source'
HOLDS={'formats22_derived_exported','ui_save_as','ui_save_as_jpeg','ui_save_as_jpeg_xl','ui_save_as_png','ui_foreground_background_colour_palette','ui_pinch_and_pan_mode','ui_main23','ui_fg','ui_bg'}

def node(e):
 return {'type':e.tag,'target':({n.get('quantity'):n.text for n in e} if e.tag=='plurals' else e.text),'attributes':e.attrib}

def write_node(typ,key,value,attrs):
 a=' '.join(k+'="'+escape(v,{'"':'&quot;'})+'"' for k,v in attrs.items())
 if typ=='string':return '<string '+a+'>'+escape(value)+'</string>'
 return '<plurals '+a+'>\n'+''.join('        <item quantity="'+q+'">'+escape(v)+'</item>\n'for q,v in value.items())+'    </plurals>'

def main():
 english={e.get('name'):e for e in E.parse(S/'Paintroid/src/main/res/values/strings.xml').getroot()}
 manifest=json.loads((S/'translations/string-importance.json').read_text());priority={k for t in manifest['tiers'] if t['id']in('P0','P1')for k in t['keys']}
 data={'schema_version':1,'scope':'Complete source-bound priority wording, ten exact absent holds per language, four inherited Xhosa terminology holds without acceptance credit, and fifteen atomic typed companions per locale. Independent full ledgers remain on the evidence ref. No native-human, installed-layout or dormant runtime-context claim.','sources':{},'locales':{}}
 proof=[]
 for loc in ('yo','zu','xh'):
  receipt=json.loads((B/f'independent-review/{loc}-integration-ledger.json').read_text())
  assert receipt['locale']==loc and {r['identity']for r in receipt['rows']}==priority
  accepted=receipt['accepted_resource_text_values'];edits=receipt['integration_values'];rows={r['identity'].split('/',1)[1]:r for r in receipt['rows']+receipt['dependencies']}
  assert len(accepted)==(342 if loc=='xh' else 346) and set(accepted)==set(rows)-HOLDS-set(receipt['held_present'])
  for k in accepted:
   assert rows[k]['decision'].startswith('accept'),(loc,k,rows[k]['decision'])
  p=S/receipt['catalogue_path'];raw=p.read_text();before=E.fromstring(raw);beforemap={e.get('name'):node(e)for e in before}
  original=B/'original-catalogues'/f'{loc}.xml';original.parent.mkdir(exist_ok=True);assert not original.exists();original.write_bytes(p.read_bytes())
  for k,r in edits.items():
   typ=rows[k]['identity'].split('/')[0];old=beforemap.get(k);previous=r.get('previous_target')
   # Final receipts use a complete previous node object or explicit null, never inferred text.
   if old is None:assert previous is None
   else:
    assert isinstance(previous,dict) and old['target']==previous['value'] and old['attributes']==previous['attributes'],(loc,k)
   val=accepted[k];assert val==r['reviewed_value'];attrs=r.get('reviewed_attributes') or r.get('attributes') or r.get('proposed_attributes') or rows[k].get('proposed_attributes') or english[k].attrib
   if old is not None and old['target']==val and old['attributes']==attrs:raise ValueError('Unchanged value labelled edit: '+loc+'/'+k)
   replacement=write_node(typ,k,val,attrs)
   if old is not None:
    pat=r'<'+typ+r'\b(?=[^>]*\bname="'+re.escape(k)+r'")[^>]*>.*?</'+typ+'>'
    raw,count=re.subn(pat,lambda _:replacement,raw,flags=re.S);assert count==1
   else:raw=raw.replace('</resources>','    '+replacement+'\n</resources>')
  after=E.fromstring(raw);aftermap={e.get('name'):node(e)for e in after};actual={k for k in set(beforemap)|set(aftermap)if beforemap.get(k)!=aftermap.get(k)};assert actual==set(edits)
  assert not HOLDS & set(aftermap)
  for k,v in receipt['held_present'].items():assert aftermap[k]==v
  for k in accepted:assert aftermap[k]['target']==accepted[k]
  p.write_text(raw)
  for k in rows:
   src=node(english[k]);src['source']=src.pop('target')
   if k in data['sources']:assert data['sources'][k]==src
   else:data['sources'][k]=src
  locale={'catalogue_path':receipt['catalogue_path'],'accepted':accepted,'changed':sorted(edits),'predecessors':{k:beforemap[k]for k in edits if k in beforemap},'unchanged_accepted':sorted(set(accepted)-set(edits)), 'target_attribute_exceptions':{k:aftermap[k]['attributes']for k in accepted if aftermap[k]['attributes']!={'name':k}},'held_absent':sorted(HOLDS),'held_present':receipt['held_present'],'priority_status':{r['identity']:r['decision']for r in receipt['rows']},'wording_only':receipt['wording_only_or_route_limited_identities'],'outside_review':{k:v for k,v in beforemap.items()if k not in rows},'catalogue_identities':sorted(e.tag+'/'+e.get('name')for e in after)}
  data['locales'][loc]=locale;proof.append({'locale':loc,'catalogue_before':len(before),'catalogue_after':len(after),'new':len(set(aftermap)-set(beforemap)),'corrected':len(actual&set(beforemap)),'unchanged':len(beforemap)-len(actual&set(beforemap)),'actual_edits':len(actual),'partition':dict(Counter(rows[k]['tier']for k in actual)),'resource_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 (S/'tools/fixtures/current_localization/yoruba_zulu_xhosa_priority_wording.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
 (B/'priority-integration-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof)
if __name__=='__main__':main()
