from pathlib import Path
import json
B=Path(__file__).resolve().parent;H=B.parent/'ha-ig-ln-p0-p1-20261027';S=B/'source'
def adapt(s):
 for a,b in [('hausa_igbo_lingala','yoruba_zulu_xhosa'),('HausaIgboLingala','YorubaZuluXhosa'),('Hausa/Igbo/Lingala','Yoruba/Zulu/Xhosa'),('HA_IG_LN','YO_ZU_XH'),('ha_ig_ln','yo_zu_xh'),("('ha','ig','ln')","('yo','zu','xh')"),("{'ha','ig','ln'}","{'yo','zu','xh'}"),('listOf("ha","ig","ln")','listOf("yo","zu","xh")')]:s=s.replace(a,b)
 return s
s=adapt((H/'source/tools/hausa_igbo_lingala_priority_expectations.py').read_text().split('# Finite current successors')[0]);(S/'tools/yoruba_zulu_xhosa_priority_expectations.py').write_text(s)
s=adapt((H/'priority_host_test_template.py').read_text())
s=s.replace("    expected=names-HOLDS|DEPENDENCIES\n    for tag,locale in data['locales'].items():","    for tag,locale in data['locales'].items():\n        expected=(names-HOLDS|DEPENDENCIES)-set(HELD_PRESENT[tag])\n        if locale.get('held_present')!=HELD_PRESENT[tag]:raise ValueError('Exact inherited terminology holds differ')")
s=s.replace("typed|={row['type']+'/'+k for k,row in OUTSIDE_REVIEW[tag].items()}","typed|={row['type']+'/'+k for k,row in (OUTSIDE_REVIEW[tag]|HELD_PRESENT[tag]).items()}")
s=s.replace("tag in ('ha','ln')","tag in ('zu','xh')")
s=s.replace("for key,row in locale['outside_review'].items():","for key,row in (locale['outside_review']|locale['held_present']).items():")
s=s.replace("'wording-limit','extra-catalogue'","'wording-limit','held-present','extra-catalogue'")
s=s.replace("elif mode=='wording-limit':b['wording_only'].pop()","elif mode=='wording-limit':b['wording_only'].pop()\n                elif mode=='held-present':\n                    if not b['held_present']:continue\n                    b['held_present'][next(iter(b['held_present']))]['target']='unreviewed' ")
(B/'priority_host_test_template.py').write_text(s)
s=adapt((H/'prepare_host_tests.py').read_text()).replace("'UNCHANGED':", "'HELD_PRESENT':{k:v['held_present']for k,v in locs.items()},\n'UNCHANGED':")
(B/'prepare_host_tests.py').write_text(s)
s=adapt((H/'source/Paintroid/src/test/java/org/catrobat/paintroid/local/HausaIgboLingalaPriorityWordingTest.kt').read_text())
s=s.replace('(tag=="ha" && count==1) || (tag=="ln" && count in 0..1)','(tag=="xh" && count==1) || (tag=="zu" && count in 0..1)').replace('// CLDR: Hausa one=1; Lingala one=0/1; Igbo only other.','// CLDR: Xhosa one=1; Zulu one=0/1; Yoruba only other.')
(S/'Paintroid/src/test/java/org/catrobat/paintroid/local/YorubaZuluXhosaPriorityWordingTest.kt').write_text(s)
s=adapt((H/'apply_shared_guard_additions.py').read_text()).replace("import JV_SU_KY_ADDITIONS,","import HA_IG_LN_ADDITIONS,").replace("import YO_ZU_XH_ADDITIONS, JV_SU_KY_ADDITIONS,","import YO_ZU_XH_ADDITIONS, HA_IG_LN_ADDITIONS,")
# Existing HA integration is retained. New finite projection is inserted beside it.
s=s.replace('assertEquals(90, expected.length())','assertEquals(93, expected.length())').replace('assertEquals(93, expected.length())\'\'\'','assertEquals(96, expected.length())\'\'\'')
s=s.replace('assertEquals(80, fallbacks) // 171 offered - 90 exact current values - 1 inherited.','assertEquals(77, fallbacks) // 171 offered - 93 exact current values - 1 inherited.')
s=s.replace("s.replace(old,'assertEquals(77, fallbacks) // 171 offered - 93 exact current values - 1 inherited.')","s.replace(old,'assertEquals(74, fallbacks) // 171 offered - 96 exact current values - 1 inherited.')")
s=s.replace('val haIgLnPriority','val yoZuXhPriority').replace('haIgLnPriority.getJSONObject','yoZuXhPriority.getJSONObject')
s=s.replace("if tag in data or row['previous_target'] is not None or not row['changed']:\n            raise ValueError('Yoruba/Zulu/Xhosa tagged colour predecessor differs: '+tag)","if (tag in data or row['previous_target'] is not None or not row['changed']\n                or row['source'] != ET.parse(catalogues.RES / 'values/strings.xml').find(\"./string[@name='\"+TAGGED_COLOUR_KEY+\"']\").text or row['attributes'] != {'name':TAGGED_COLOUR_KEY}):\n            raise ValueError('Yoruba/Zulu/Xhosa tagged colour predecessor/source/attributes differ: '+tag)")
(B/'apply_shared_guard_additions.py').write_text(s)
