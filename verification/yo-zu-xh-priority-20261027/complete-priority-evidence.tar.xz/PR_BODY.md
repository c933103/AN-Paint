## Complete successive three-language P0 + P1 unit

Stacked on PR197 `f9e125d9ee65c7c52e5af76a76f0c8b706aac48f`. Own change is 15 paths; preceding units earn no new wording credit.

- Each language accounts for all **92 P0 + 249 P1 identities**, plus **15 atomic companions**. Yoruba and Zulu each have 331 accepted priority values, 10 precise absent holds, and 15 accepted companions.
- Xhosa has 327 accepted priority values and 15 accepted companions: **318 typed edits** (317 additions and the exact Keep-editing correction), **24 accepted retained values**, **10 absent holds and four inherited terminology holds**. The inherited Free Select / Palette / Preview / Rotate values remain exact with no acceptance credit. The inherited Dither label is retained and its new GIF explanation is paired explicitly.
- **1,010 total typed edits** = 346 Yoruba + 346 Zulu + 318 Xhosa. All original English/current values and 414 unique caller windows per language rebound exactly to the published parent. All 93 inherited fixture blobs remain unchanged.
- Full values, placeholders, newlines, attributes, typed identity sets, corrected predecessors and all plural children are strict. Yoruba uses other only; Zulu integer 0/1 uses one; Xhosa integer 1 uses one. Actual crop tests cover 0/1/2/3.
- Independent complete integration and **2,933 invalid-mutation rejections**, including all 1,036 accepted scalar/plural children, 1,023 dispositions, inherited terminology holds, 66 finite shared guards, exact two-option successors and eight exact AppLanguage outputs.

## Tests and finite current successors

Fifteen JVM methods exercise compiled complete resources and real dimensions, crop, save/encoder controls, animation counts, memory admission, text alignment, cancellation, swap and reversible Commit/Undo/Redo pixels. The inherited method design was delta-reviewed, not counted as a wholly new design. Shared memory/SVG/colour additions require exact predecessor/source/attribute contracts without changing frozen historical evidence.

Only Yoruba/Zulu current metadata changes from not-started to partial-priority-reviewed. Original zero-coverage rows remain immutable and strict, and all prior HA/IG/LN/Sundanese successor and platform identity checks remain. Xhosa is an existing catalogue, not a newly added locale. All three remain incomplete with default-English fallback.

Both final full local suites pass **1,583 tests each**, ordinary and optimized; 10 new focused plus 39 shared focused tests pass. Initial local setup and mutation-probe errors were diagnosed and fixed before these final runs; diagnostics remain evidence, not waived failures.

Source commit `1b4269c32748cc300491da54ddee6cdfaf9e7c5e`, tree `28ada9cbc9cf3c7509dbed764ebb7e245e064b8f`, sole parent `f9e125d9ee65c7c52e5af76a76f0c8b706aac48f`. All 1,443 remote source blobs and executable modes read back exact before CI.

Hosted compilation, original APK/source binding, JVM and mandatory API35 evidence remain fresh exact-head gates. Static model review does not certify native-human fluency, installed layouts or TalkBack. No release; all existing pauses and exact project holds remain. Durable full review/test evidence follows on its dedicated evidence branch. Root retains ordered merge ownership.
