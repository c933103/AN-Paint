from pathlib import Path
import json
B=Path(__file__).resolve().parent;H=B.parent/'ha-ig-ln-p0-p1-20261027';S=B/'source'
p=S/'tools/yoruba_zulu_xhosa_priority_expectations.py';s=p.read_text();s+='\n# Two exact empty-option successors; Xhosa is an inherited catalogue, not a new option.\nYO_ZU_OPTION_TAGS=frozenset({\'yo\',\'zu\'})\n'
block=(H/'source/tools/hausa_igbo_lingala_priority_expectations.py').read_text().split('# Finite current successors')[1]
block=block.replace("names={'ha':'Hausa','ig':'Igbo','ln':'Lingála'}","names={'yo':'Yorùbá','zu':'isiZulu'}").replace('tag not in TAGS','tag not in YO_ZU_OPTION_TAGS').replace('Hausa/Igbo/Lingala','Yoruba/Zulu')
s+='# Finite current successors'+block;p.write_text(s)
p=S/'tools/test_language_option_additions.py';s=p.read_text();s=s.replace('from hausa_igbo_lingala_priority_expectations import TAGS', 'from yoruba_zulu_xhosa_priority_expectations import YO_ZU_OPTION_TAGS, PRIORITY_OPTION_STATUS as YO_ZU_OPTION_STATUS, require_priority_option_successor as require_yo_zu_option_successor\nfrom hausa_igbo_lingala_priority_expectations import TAGS')
s=s.replace("PRIORITY_OPTION_STATUS if tag in PRIORITY_OPTION_TAGS else", "YO_ZU_OPTION_STATUS if tag in YO_ZU_OPTION_TAGS else PRIORITY_OPTION_STATUS if tag in PRIORITY_OPTION_TAGS else")
anchor="            if row['tag'] in PRIORITY_OPTION_TAGS:"
block='''            if row['tag'] in YO_ZU_OPTION_TAGS:
                tag=row['tag'];root=require_yo_zu_option_successor(row,path.read_text())
                self.assertEqual([],catalogues.validate_catalogue(tag))
                missing_strings=source_strings-{n.get('name')for n in root if n.tag=='string'}
                missing_plurals=source_plurals-{n.get('name')for n in root if n.tag=='plurals'}
                self.assertTrue(missing_strings);self.assertFalse(missing_plurals)
                self.assertEqual([f"{tag}: missing {len(missing_strings)} strings: {', '.join(sorted(missing_strings)[:20])}"],catalogues.validate_catalogue(tag,require_complete=True))
                continue
'''
assert anchor in s;s=s.replace(anchor,block+anchor,1)
s=s.replace("        xml = (ROOT / row['catalogue']).read_text()\n        require_untranslated_option(row, xml)","        current_xml = (ROOT / row['catalogue']).read_text()\n        with self.assertRaises(ValueError):require_untranslated_option(row,current_xml)\n        # The frozen zero-coverage row is still strict; current accepted values are separately bound.\n        xml = '<resources/>'\n        require_untranslated_option(row, xml)")
start=s.index('    def test_only_exact_full_priority_values_supersede_three_original_empty_options');end=s.index("if __name__ == '__main__':",start)
block=s[start:end].replace('three_original_empty_options','two_remaining_original_empty_options').replace('PRIORITY_OPTION_TAGS','YO_ZU_OPTION_TAGS').replace('require_priority_option_successor','require_yo_zu_option_successor')
s=s[:end]+block+s[end:];p.write_text(s)
p=S/'translations/language-options.json';d=json.loads(p.read_text())
for row in d['options']:
 if row['tag'] in ('yo','zu'):assert row['translation_status']=='not-started';row['translation_status']='partial-priority-reviewed'
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
p=S/'Paintroid/src/test/java/org/catrobat/paintroid/local/AppLanguageTest.kt';s=p.read_text();start=s.index('fun sixNewOptionsKeepTheirIdentity');end=s.index('fun furtherOptionsIncluding',start);part=s[start:end];anchor='''            } else {
                assertEquals("File",wrapped.getString(R.string.ui_menu_file))''';assert anchor in part
new=''
for tag in ('yo','zu'):
 d=json.loads((B/f'independent-review/{tag}-integration-ledger.json').read_text())['accepted_resource_text_values'];new+='            } else if (tag == "'+tag+'") {\n'
 for key in ['ui_menu_file','ui_brush','ui_save','language20_translation_note']:
  v=d[key].replace('\\n','\n');new+='                assertEquals('+json.dumps(v,ensure_ascii=False).replace('$','\\$')+',wrapped.getString(R.string.'+key+'))\n'
new+=anchor;part=part.replace(anchor,new,1);s=s[:start]+part+s[end:];p.write_text(s)
