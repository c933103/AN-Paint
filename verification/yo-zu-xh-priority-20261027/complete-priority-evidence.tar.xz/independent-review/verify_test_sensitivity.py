from pathlib import Path
import sys,json,hashlib,copy,xml.etree.ElementTree as E,unittest,re,collections
from unittest.mock import patch
r=Path(__file__).resolve().parents[1];s=r/'source';b=r.parent/'ha-ig-ln-p0-p1-20261027/source';sys.path.insert(0,str(s/'tools'))
import test_yoruba_zulu_xhosa_priority_wording as g
import yoruba_zulu_xhosa_priority_expectations as h
import test_current_localization_contracts as c
import memory_warning_source_review as m
f=g.require_shape(g.fixture(h.NAME));counts=collections.Counter()
def reject(group,fn):
 try:fn()
 except (ValueError,AssertionError):counts[group]+=1;return
 raise AssertionError('accepted invalid mutation '+group)
for tag,loc in f['locales'].items():
 for identity in loc['priority_status']:
  x=copy.deepcopy(f);x['locales'][tag]['priority_status'][identity]='accept_unbounded';reject('priority-disposition',lambda:g.require_shape(x))
 for identity in loc['wording_only']:
  x=copy.deepcopy(f);x['locales'][tag]['wording_only'].remove(identity);reject('wording-only-credit',lambda:g.require_shape(x))
 for change in ['extra','alias','predecessor']:
  x=copy.deepcopy(f);q=x['locales'][tag]
  if change=='extra':q['catalogue_identities'].append('string/unreviewed')
  elif change=='alias':q['accepted']['ui_save']='@string/ui_cancel'
  else:q['predecessors']['ui_save']={'type':'string','target':'fake','attributes':{'name':'ui_save'}}
  reject('fixture-shape',lambda:g.require_shape(x))
 root=E.parse(g.catalogues.catalogue_paths()[tag]).getroot()
 for key,target in loc['accepted'].items():
  source=f['sources'][key];node=root.find(f"./{source['type']}[@name='{key}']")
  for childindex in range(len(node)) if source['type']=='plurals' else [None]:
   changed=copy.deepcopy(node);child=changed if childindex is None else changed[childindex];child.text=(child.text or '')+' corrupted';sample=E.Element('resources');sample.append(changed)
   reject('complete-target',lambda:g.require_complete(sample,key,source,target,loc['target_attribute_exceptions'].get(key,{'name':key})))
 for key,held in loc['held_present'].items():
  x=copy.deepcopy(f);x['locales'][tag]['held_present'][key]['target']='changed';reject('held-present-fixture',lambda:g.require_shape(x))
  sample=E.Element('resources');node=E.SubElement(sample,held['type'],held['attributes']);node.text=held['target']+' changed';reject('held-present-source',lambda:g.require_complete(sample,key,{'type':held['type'],'source':held['target']},held['target'],held['attributes']))
 for key in m.KEYS:
  assert m.current_source_expectation(key,tag,None)==h.current_row(tag,key)['target'];reject('shared-memory',lambda:m.current_source_expectation(key,tag,'old'))
  for field,value in [('source','BAD'),('attributes',{'name':key,'formatted':'false'}),('previous_target','BAD'),('changed',False)]:
   original=m.yo_zu_xh_row
   def row(t,k):return dict(original(t,k),**{field:value}) if (t,k)==(tag,key) else original(t,k)
   with patch.object(m,'yo_zu_xh_row',side_effect=row):reject('shared-memory',lambda:m.current_source_expectation(key,tag,None))
 for key in c.EXPECTED_KEYS[c.FAMILIES[2]]|{c.TAGGED_COLOUR_KEY}:
  for field,value in [('source','BAD'),('attributes',{'name':key,'formatted':'false'}),('previous_target','BAD'),('changed',False)]:
   original=c.yo_zu_xh_row
   def row(t,k):return dict(original(t,k),**{field:value}) if (t,k)==(tag,key) else original(t,k)
   with patch.object(c,'yo_zu_xh_row',side_effect=row):reject('shared-svg-colour',c.current_tagged_colour_data if key==c.TAGGED_COLOUR_KEY else lambda:c.wording_fixture(c.FAMILIES[2]))
rows=json.loads((s/'tools/fixtures/language_option_additions_20261012.json').read_text())['languages']
for tag in h.YO_ZU_OPTION_TAGS:
 old=next(x for x in rows if x['tag']==tag);root=E.parse(s/old['catalogue']).getroot();xml=E.tostring(root,encoding='unicode');h.require_priority_option_successor(old,xml)
 for i,node in enumerate(root):
  for child in range(len(node)) if node.tag=='plurals' else [None]:
   d=copy.deepcopy(root);t=d[i] if child is None else d[i][child];t.text=(t.text or '')+' corrupted';reject('option-complete-target',lambda:h.require_priority_option_successor(old,E.tostring(d,encoding='unicode')))
 for row in rows:
  if row['tag']!=tag:reject('option-exact-locale',lambda:h.require_priority_option_successor(row,xml))
 for field,val in [('translation_status','complete'),('linguistic_review','accepted'),('fallback','translated'),('source_strings_present',346),('source_plurals_present',1),('name','wrong'),('catalogue','wrong')]:
  d=copy.deepcopy(old);d[field]=val;reject('option-predecessor',lambda:h.require_priority_option_successor(d,xml))
 for mode in ('missing','extra','attribute','duplicate'):
  d=copy.deepcopy(root)
  if mode=='missing':d.remove(d[0])
  elif mode=='extra':E.SubElement(d,'string',name='extra').text='extra'
  elif mode=='duplicate':d.append(copy.deepcopy(d[0]))
  else:d[0].set('bad','true')
  reject('option-xml-shape',lambda:h.require_priority_option_successor(old,E.tostring(d,encoding='unicode')))
before=json.loads((b/'translations/language-options.json').read_text());after=json.loads((s/'translations/language-options.json').read_text());expected=copy.deepcopy(before);changes=[]
def change(x):
 if isinstance(x,dict):
  if x.get('tag') in h.YO_ZU_OPTION_TAGS:assert x['translation_status']=='not-started';x['translation_status']='partial-priority-reviewed';changes.append(x['tag'])
  for v in x.values():change(v)
 elif isinstance(x,list):
  for v in x:change(v)
change(expected);assert after==expected and set(changes)==h.YO_ZU_OPTION_TAGS and len(changes)==2
jvm=(s/'Paintroid/src/test/java/org/catrobat/paintroid/local/AppLanguageTest.kt').read_text()
for tag in h.YO_ZU_OPTION_TAGS:
 block=jvm.split('else if (tag == "'+tag+'") {')[1].split('} else')[0];pairs=re.findall(r'assertEquals\("((?:\\.|[^"\\])*)",wrapped.getString\(R.string.(\w+)\)\)',block);assert len(pairs)==4
 for value,key in pairs:assert json.loads('"'+value+'"')==h.display(tag,key)
old=(b/'Paintroid/src/test/java/org/catrobat/paintroid/local/HausaIgboLingalaPriorityWordingTest.kt').read_text();newpath=s/'Paintroid/src/test/java/org/catrobat/paintroid/local/YorubaZuluXhosaPriorityWordingTest.kt';new=newpath.read_text()
expected=old.replace('HausaIgboLingala','YorubaZuluXhosa').replace('hausa_igbo_lingala','yoruba_zulu_xhosa').replace('listOf("ha","ig","ln")','listOf("yo","zu","xh")').replace('(tag=="ha" && count==1) || (tag=="ln" && count in 0..1)','(tag=="xh" && count==1) || (tag=="zu" && count in 0..1)').replace('// CLDR: Hausa one=1; Lingala one=0/1; Igbo only other.','// CLDR: Xhosa one=1; Zulu one=0/1; Yoruba only other.');assert new==expected
bs=chr(92);assert h._display(bs+'n')=='\n' and h._display(bs+bs+'n')==bs+'n';assert h._display('"a'+bs+'"b"')=='a"b'
result=unittest.TextTestRunner(verbosity=1).run(unittest.defaultTestLoader.loadTestsFromModule(g));assert result.wasSuccessful()
out={'result':'PASS','independent_negative_probes':dict(counts),'total_independent_negative_probes':sum(counts.values()),'focused_new_host_tests':result.testsRun,'exact_option_status_changes':sorted(changes),'jvm_sha256':hashlib.sha256(newpath.read_bytes()).hexdigest(),'jvm_methods':len(re.findall(r'@Test\s+fun',new)),'jvm_review':'Full normalized delta equals accepted HA/IG/LN actual-consumer suite except new trio/fixture and exact CLDR quantity mapping. No assertion removals. YOother-only,ZUone0/1,XHone1 checked in actual0/1/2/3 selection flow.','limits':'Independent non-mutating sensitivity and static assertion checks only; owner full aggregates and hosted compile/runtime remain distinct.'}
(r/'independent-review/test-sensitivity-review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
