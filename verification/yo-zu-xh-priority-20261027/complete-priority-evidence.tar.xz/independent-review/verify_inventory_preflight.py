from pathlib import Path
import json,hashlib,xml.etree.ElementTree as E
r=Path(__file__).resolve().parents[1];s=r/'source';load=lambda p:json.loads(p.read_text());bindings=load(r/'candidate-public/source-bindings.json');base={x['path']:x for x in load(r/'base-tree.json')['tree']if x['type']=='blob'}
for x in bindings['bindings']:
 raw=(s/x['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==x['sha256'];assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==x['git_blob_sha1']==base[x['path']]['sha']
def idx(p):return {n.tag+'/'+n.get('name'):{'value':n.text,'attributes':n.attrib}for n in E.parse(p).getroot()}
en=idx(s/'Paintroid/src/main/res/values/strings.xml');results={};callers=set()
questions={'ui_keep_editing23':'Current literal English Cancel rather than localized Keep editing; author complete safety-return label with actual prompt context.','ui_free_form_select':'Check full technical free-form selection sense against exact selection tool; do not infer a defect merely from everyday senses of lwasimahla.','ui_palette':'Check colour-palette term against actual swatch consumer rather than generic collection wording; primary terminology/context needed before change.','ui_preview':'Check image preview semantics and existing technical terminology; no print-only defect claim solely from literal analysis.','ui_rotate':'Check rotation-specific action against actual rotate dialog; no synonym replacement without complete contextual evidence.'}
for tag in ['yo','zu','xh']:
 d=load(r/f'candidate-public/{tag}-complete-inventory.json');cur=idx(s/d['catalogue_path']);present=[]
 assert len(d['rows'])==341
 for x in d['rows']:
  key=x['identity'];assert {k:x['english'][k]for k in ['value','attributes']}==en[key];assert ({k:x['current'][k]for k in ['value','attributes']}if x['current'] else None)==cur.get(key)
  for c in x['direct_consumers']:
   lines=(s/c['path']).read_text().splitlines();assert lines[c['start_line']-1:c['end_line']]==c['context'].split('\n');callers.add((c['path'],c['line']))
  if x['current']:
   short=key.split('/')[1];present.append(dict(x,independent_preflight='complete_existing_value_read_not_final_acceptance',review_note=questions.get(short,'Preserve exact quote wrappers/case/valid terminology unless complete author candidate and source-context review justify semantic correction. Dormant keys remain wording-only.')))
 results[tag]={'inventory':341,'present_values_read':len(present),'missing':341-len(present),'existing_rows':present}
out={'result':'PASS-source-bound-preflight','source_commit':bindings['source_commit'],'locales':results,'source_bound_files':len(bindings['bindings']),'unique_caller_windows':len(callers),'limits':'28 existing Xhosa priority values fully read; Yoruba/Zulu empty. No blanket language acceptance, source edits, lexical defect allegations based solely on everyday glosses, or native-reader certification. Full341 author/reviewer scope remains.'};(r/'independent-review/inventory-preflight.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print({t:{k:v for k,v in d.items()if k!='existing_rows'}for t,d in results.items()})
