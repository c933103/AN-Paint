from pathlib import Path
import json,hashlib,xml.etree.ElementTree as E
r=Path(__file__).resolve().parents[1];s=r/'source';b=r.parent/'ha-ig-ln-p0-p1-20261027/source';load=lambda p:json.loads(p.read_text());fpath=s/'tools/fixtures/current_localization/yoruba_zulu_xhosa_priority_wording.json';f=load(fpath);tree=load(r/'integration-base-tree.json');base={x['path']:x for x in tree['tree']if x['type']=='blob'};assert tree['sha']=='8ffc6e1b1692f882843a76bbf42bf5a3adb3267c'
blob=lambda raw:hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def cat(path):
 out={}
 for e in E.parse(path).getroot():
  identity=e.tag+'/'+e.get('name');assert identity not in out
  if e.tag=='plurals':
   assert all(c.tag=='item' and c.attrib=={'quantity':c.get('quantity')} and len(c)==0 for c in e);v={c.get('quantity'):c.text for c in e};assert len(v)==len(e)
  else:assert len(e)==0;v=e.text
  out[identity]={'value':v,'attributes':e.attrib}
 return out
en=cat(s/'Paintroid/src/main/res/values/strings.xml');counts={};contexts=set()
for tag in ['yo','zu','xh']:
 rp=r/f'independent-review/{tag}-complete-independent-review.json';rev=load(rp);ledger=load(r/f'independent-review/{tag}-integration-ledger.json');assert ledger['rows']==rev['rows'] and ledger['dependencies']==rev['dependencies'];assert ledger['provenance']['independent_receipt_sha256']==hashlib.sha256(rp.read_bytes()).hexdigest();rel=ledger['catalogue_path'];assert blob((b/rel).read_bytes())==base[rel]['sha'];before=cat(b/rel);after=cat(s/rel);accepted={x['identity']:x for x in rev['rows']+rev['dependencies']if x['decision'].startswith('accept')};changes={k for k in before.keys()|after.keys()if before.get(k)!=after.get(k)};assert changes=={k for k,x in accepted.items()if before.get(k)!={'value':x['reviewed_value'],'attributes':x['reviewed_attributes']}}
 fl=f['locales'][tag];assert set(fl['changed'])=={k.split('/')[1]for k in changes};assert fl['priority_status']=={x['identity']:x['decision']for x in rev['rows']};assert set(fl['unchanged_accepted'])=={k.split('/')[1]for k in accepted.keys()-changes}
 assert set(fl['wording_only'])=={x['identity']for x in rev['rows']if x['decision'].endswith('wording_only')}
 assert fl['predecessors']=={k.split('/')[1]:{'type':k.split('/')[0],'target':v['value'],'attributes':v['attributes']}for k,v in before.items()if k in changes}
 for x in rev['rows']+rev['dependencies']:
  identity=x['identity'];kind,key=identity.split('/');assert before.get(identity)==({k:x['current'][k]for k in ['value','attributes']}if x['current']else None);assert {k:x['english'][k]for k in ['value','attributes']}==en[identity]
  assert f['sources'][key]=={'type':kind,'source':en[identity]['value'],'attributes':en[identity]['attributes']}
  for c in x['direct_consumers']:
   cp=s/c['path'];assert blob(cp.read_bytes())==base[c['path']]['sha'];ls=cp.read_text().splitlines();assert ls[c['start_line']-1:c['end_line']]==c['context'].split('\n');contexts.add((c['path'],c['start_line'],c['end_line']))
  if identity in accepted:
   assert after[identity]=={'value':x['reviewed_value'],'attributes':x['reviewed_attributes']};assert fl['accepted'][key]==x['reviewed_value']
   if identity in changes:assert ledger['integration_values'][key]=={'previous_target':x['current'],'reviewed_value':x['reviewed_value'],'reviewed_attributes':x['reviewed_attributes']}
  elif x['decision']=='hold_absent':assert identity not in after and key in fl['held_absent']
  else:
   assert x['decision']=='hold_present_terminology';assert after[identity]==before[identity];assert fl['held_present'][key]=={'type':kind,'target':before[identity]['value'],'attributes':before[identity]['attributes']};assert key not in fl['accepted']
 assert set(fl['held_absent'])=={x['identity'].split('/')[1]for x in rev['rows']if x['decision']=='hold_absent'}
 assert set(fl['catalogue_identities'])==set(after)
 for k in before.keys()-changes:assert after[k]==before[k]
 assert fl['outside_review']=={k.split('/')[1]:{'type':k.split('/')[0],'target':v['value'],'attributes':v['attributes']}for k,v in before.items()if k not in accepted and k.split('/')[1]not in fl['held_present']}
 counts[tag]={'exact_typed_edits':len(changes),'priority_accepted':sum(x['decision'].startswith('accept')for x in rev['rows']),'atomic_companions':15,'held_absent':10,'held_present':len(fl['held_present']),'retained_accepted':len(accepted.keys()-changes),'unchanged_prior_xml':len(before.keys()-changes)}
fixtures=[p for p in base if p.startswith('tools/fixtures/')];assert all(blob((s/p).read_bytes())==base[p]['sha']for p in fixtures)
delta={x['path']:x for x in load(r/'source-delta.json')};changed={p for p in base if blob((s/p).read_bytes())!=base[p]['sha']};assert changed==set(delta)&set(base)
for p,v in delta.items():assert blob((s/p).read_bytes())==v['sha']
out={'result':'PASS','base_tree':tree['sha'],'counts':counts,'total_typed_edits':sum(v['exact_typed_edits']for v in counts.values()),'unique_caller_windows':len(contexts),'historical_fixture_blobs_unchanged':len(fixtures),'current_localization_subset':sum(p.startswith('tools/fixtures/current_localization/')for p in fixtures),'source_delta_paths':len(delta),'fixture_sha256':hashlib.sha256(fpath.read_bytes()).hexdigest(),'limits':'Independent complete receipts rebound to actual source/fixture/edited-retained-held partitions. No duplicate linguistic credit; hosted compilation/runtime and native-human certification not claimed.'}
(r/'independent-review/integrated-priority-review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
