from pathlib import Path
import json,hashlib,re,collections
r=Path(__file__).resolve().parents[1];p=r/'candidate-public/yo-complete-author-packet.json';d=json.loads(p.read_text());inv=json.loads((r/'candidate-public/yo-complete-inventory.json').read_text());original={x['identity']:x for x in inv['rows']};rows=[]
revisions={'save20_gif_description':'Complete gradient smoothing must mean smooth rather than easy transition; jointly bind forthcoming exact dither control.','ui_recovery_copy_exported_extract_canvas_png_from_the':'Retain conditional any floating selection (if present), not guaranteed existence.','ui_not_enough_memory_for_this_operation_the_assembly':'Explicit source-file retention (pa…mọ́), not only lack of damage (kò bàjẹ́).','gallery_credit_too_large':'Explicit previous drawing and credits retention, not only lack of damage.','ui_d_d_pixels_2f_mp_exceeds_the_current':'Reserve space for image transforms specifically, not generic edits; retain full4 arguments, safe budget, bitmap allocation and no automatic resize.'}
token=re.compile(r'%(?:\d+\$)?[-#+ 0,(<]*(?:\d+)?(?:\.\d+)?[a-zA-Z]')
for x in d['rows']:
 if x['tier']!='P0':continue
 o=original[x['identity']]
 for k in ['english','current','direct_consumers']:assert x[k]==o[k]
 key=x['identity'].split('/')[1];value=x.get('proposal')
 if value is None:decision='hold_absent';reason='Original explicit absent hold retained; no invented target.'
 elif key in revisions:decision='revision_requested';reason=revisions[key]
 else:decision='accept_active'if x['direct_consumers']else'accept_wording_only';reason='Complete Yoruba value independently read against full English and actual caller context. Model-only technical idiom acceptance; dependencies/control references require final atomic binding, no native-human certification.'
 if value is not None:
  assert sorted(token.findall(value))==sorted(token.findall(x['english']['value']));assert value.count('\\n')==x['english']['value'].count('\\n')
 rows.append(dict(x,decision=decision,reviewed_value=value if decision.startswith('accept_')else None,reviewed_attributes=x['english']['attributes']if decision.startswith('accept_')else None,reason=reason))
assert len(rows)==92
out={'scope':'Full92 P0 only; remaining249P1 and15 companions stay pending. No source mutation, no whole-language/native/installed-UI claim.','input_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'input_snapshot':d,'rows':rows,'counts':dict(collections.Counter(x['decision']for x in rows)),'control_bindings_pending':['File/Save/Undo/Load exact P1 controls','complete GIF dither companion','atomic companion/quality/format complete review']};(r/'independent-review/yo-p0-independent-review.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(out['counts'])
