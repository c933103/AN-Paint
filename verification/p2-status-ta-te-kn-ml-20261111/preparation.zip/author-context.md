# Status/control translation context

Base: develop 755f25524b5e676b9d0f2a33ef65ba46aa815065, tree a275820307774369d0796d4ab1c03d35cbd82494. All 378 materialized tracked files match the fresh Git tree. Four offered canonical catalogues have eight status/control gaps each. All 32 candidates are absent from each of eight unchanged held heads, proved with 12 hash-verified immutable blobs across 32 head/catalogue pairs. Existing nodes must remain unchanged.

The complete source and candidate values are in inputs.json and candidate.json. The actual consumers were read at this source:

- ImageResizeDialog.kt:26–58 and AssemblyActivity.kt:303–312. The budget is available working memory. The status is conditional on the existing memory policy, not a guarantee of successful decoding or saving.
- SaveOptionsDialog.kt:76–91. Lossless mode is a checkbox labelled with the current format name through the single positional %1$s string argument. It does not mean a free or smaller file.
- AssemblyActivity.kt:184–197. Files/Documents guidance follows failure of ACTION_OPEN_DOCUMENT and its ACTION_GET_CONTENT fallback. Names are descriptive with the source English labels retained; Android vendor labels may vary. No promise that enabling one always fixes access.
- MediaGalleryActivity.kt:331–347. The whole download URL must satisfy the provider policy. Rejection can include non-host aspects; translations must not reduce this to a host-only restriction. The other error is exhaustion of the bounded redirect loop, not evidence of an outage or compromised provider.
- AssemblyActivity.kt:151–157. Unavailable time replaces a missing image modification timestamp. It does not refer to waiting time or a timeout.
- ClassicPaintActivity.kt:776 and 818–826. Pixel tapping belongs to the colour-picker instruction. Tool option is the single-choice setting dialog title.
- AssemblyActivity.kt:88 and output flow. Edit in Paint names the Paint editing action, not an export format.

Terminology follows surrounding catalogues: Tamil கருவி/படத்துணுக்கு/நினைவகம்; Telugu పనిముట్టు/చిణువు/మెమరీ; Kannada ಸಾಧನ/ಪಿಕ್ಸೆಲ್/ಮೆಮೊರಿ; Malayalam ഉപകരണം/പിക്സൽ/മെമ്മറി. Existing strings are contextual input, not approval oracles. No external primary terminology source has been consulted. Android Files/Documents labels vary by vendor.

Independent full-value model review is needed, with no native-human, complete installed UI, glyph/layout/speech/device or release claim. All older holds, recheck obligations and explicit #395/#400 restrictions are unchanged.
