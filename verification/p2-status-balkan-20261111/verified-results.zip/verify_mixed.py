import hashlib,json,pathlib,re,zipfile,xml.etree.ElementTree as E
p=pathlib.Path(__file__).parent
m=json.load(open(p/'verification-input.json'));selected=json.load(open(p/'selected-artifacts.json'))
archives={}
for kind,a in {**m['artifacts'],**selected}.items():
 f=p/(kind+'.zip');assert a['digest']=='sha256:'+hashlib.sha256(f.read_bytes()).hexdigest(),kind
 assert m['checkout'] in a['name'] and a['workflow_run']['id']==m['run']
 z=zipfile.ZipFile(f);names=z.namelist();assert len(set(names))==len(names)
 assert all(not pathlib.PurePosixPath(n).is_absolute() and '..' not in pathlib.PurePosixPath(n).parts for n in names)
 archives[kind]=z
exact=json.loads(archives['exact'].read('summary.json'))
assert exact['success'] and exact['commit']==m['checkout'] and exact['tree']==m['tree'] and len(exact['probes'])==13
for q in exact['probes']:
 assert (q['exit_code']==0)==q['expected_success']
 assert hashlib.sha256(archives['exact'].read(q['name']+'.log')).hexdigest()==q['log_sha256']
reg=archives['regression'];obs=json.loads(reg.read('build/reports/ci-phases/observed-inputs.json'))
assert obs['commit']==m['checkout'] and obs['run_id']==str(m['run']) and obs['attempt']=='1'
counts={k:0 for k in ['tests','failures','errors','skipped']}
xmls=[n for n in reg.namelist() if '/test-results/testDebugUnitTest/TEST-' in n and n.endswith('.xml')]
for n in xmls:
 node=E.fromstring(reg.read(n))
 for k in counts:counts[k]+=int(node.get(k,0))
assert counts['tests']>0 and not sum(counts[k] for k in ['failures','errors','skipped'])
log=reg.read('build/reports/ci-phases/python.log').decode();pm=re.search(r'Ran (\d+) tests in [\d.]+s\s+OK(?: \(skipped=(\d+)\))?\s*$',log);assert pm
comp=archives['composition'];identity=json.loads(comp.read('composed-device-identity.json'))
assert identity['commit']==m['checkout'] and identity['run_id']==str(m['run'])
assert identity['device_sdk']==35 and identity['build_variant']=='debug'
assert identity['composed_in_run_attempt']==2 and identity['group_run_attempts']=={'core':1,'position':2}
app=json.loads(comp.read('app/coverage.json'));native=json.loads(comp.read('Paintroid/androidTest-results/summary.json'))
assert app['success'] and app['inventory_validated'] and app['completed_tests']==app['selected_tests']==app['sdk_eligible_tests']
assert not app['explicitly_excluded_tests'] and app['source_tests_sha256']==identity['source_tests_sha256']
assert native['success'] and native['completed_tests']==native['expected_tests'] and not any(native[k] for k in ['missing','unexpected','errors'])
assert all(c['status']=='passed' for c in native['cases'])
receipt=json.loads(comp.read('artifact-selection.json'));assert receipt['run_id']==m['run'] and receipt['current_attempt']==2 and receipt['checkout']==m['checkout']
terminal=json.load(open(p/'attempt2-terminal.json'));original=json.load(open(p/'attempt1-terminal.json'))
jobs={j['name']:j for j in terminal['jobs']['jobs']};old={j['name']:j for j in original['jobs']['jobs']}
for group,a in selected.items():
 rec=receipt['selected'][group];job=jobs['Core emulator API 35' if group=='core' else 'Position dialog API 35']
 assert rec['artifact_id']==a['id'] and rec['digest']==a['digest'] and rec['job_id']==job['id']
 assert rec['job_started_at']==job['started_at'] and rec['job_completed_at']==job['completed_at']
 assert job['started_at']<=a['created_at']<=a['updated_at']<=job['completed_at'] and job['conclusion']=='success'
 rawid=json.loads(archives[group].read('device-identity.json'))
 assert rawid['commit']==m['checkout'] and rawid['run_id']==str(m['run']) and rawid['run_attempt']==('1' if group=='core' else '2')
 assert rawid['source_tests_sha256']==identity['source_tests_sha256']
for name,j in jobs.items():
 if name not in ['Position dialog API 35','Emulator API 35']:
  assert j['started_at']==old[name]['started_at'] and j['completed_at']==old[name]['completed_at']
  assert j['conclusion']==old[name]['conclusion']=='success'
assert old['Position dialog API 35']['conclusion']=='failure' and old['Emulator API 35']['conclusion']=='failure'
assert terminal['run']['run_attempt']==2 and terminal['run']['conclusion']=='success' and len(jobs)==7 and all(j['conclusion']=='success' for j in jobs.values())
result={'verified':True,'checkout':m['checkout'],'tree':m['tree'],'run':m['run'],'attempt':2,'artifact_digests':{k:a['digest'] for k,a in {**m['artifacts'],**selected}.items()},'exact_probes':13,'python_passes':int(pm[1])-int(pm[2] or 0),'python_skips':int(pm[2] or 0),'jvm':counts,'jvm_xml_files':len(xmls),'native_api35':native['completed_tests'],'app_api35':app['completed_tests'],'identity':identity,'actual_group_attempts':{'core':1,'position':2},'carried_original_successes':5,'new_successful_executions':['Position dialog API 35','Emulator API 35'],'limits':'Independent source-bound archive/report verification, not a new device run, native-human review or exhaustive pixel/layout certification.'}
(p/'independent-verification.json').write_text(json.dumps(result,indent=2)+'\n')
with zipfile.ZipFile(p/'verified-results.zip','w',zipfile.ZIP_DEFLATED,9) as out:
 for name in ['independent-verification.json','verification-input.json','selected-artifacts.json','verify_mixed.py','attempt1-terminal.json','attempt2-terminal.json','tested-source.json','position-setup-failure.json','exact.zip']:out.write(p/name,name)
 for n in xmls+[n for n in reg.namelist() if n.startswith('build/reports/ci-phases/') and not n.endswith('/')]:out.writestr('regression/'+n,reg.read(n))
 for group in ['composition','core','position']:
  for n in archives[group].namelist():
   if n.endswith('.json'):out.writestr(group+'/'+n,archives[group].read(n))
print(json.dumps(result,indent=2))
