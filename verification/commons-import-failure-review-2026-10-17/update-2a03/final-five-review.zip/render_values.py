from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
import json
P=Path(__file__).resolve().parent;entries=json.loads((P/'final-five-reviewed.json').read_text())['entries']
fonts={'ain-Kana':ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',25,index=0,layout_engine=ImageFont.Layout.RAQM),'ain-Latn':ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',24,layout_engine=ImageFont.Layout.RAQM),'mnc-Mong':ImageFont.truetype(str(P.parent/'source/Paintroid/src/main/assets/fonts/notosansmongolian.ttf'),38,layout_engine=ImageFont.Layout.RAQM)}
label=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',20)
im=Image.new('RGB',(1400,1150),'white');d=ImageDraw.Draw(im);y=25
for e in entries:
 d.text((24,y),e['tag']+' / '+e['key'],font=label,fill='black');y+=40;f=fonts[e['tag']];line=''
 for w in e['localized'].split(' '):
  candidate=line+' '+w if line else w
  if d.textlength(candidate,font=f)>1320:
   d.text((24,y),line,font=f,fill='black');y+=70 if e['tag']=='mnc-Mong' else 42;line=w
  else:line=candidate
 if line:d.text((24,y),line,font=f,fill='black');y+=70 if e['tag']=='mnc-Mong' else 42
 y+=30
im.crop((0,0,1400,y+20)).save(P/'local-font-render.png')
print('Rendered exact values locally with RAQM; no Android layout claim.')
