from pathlib import Path
import json,hashlib,re,unicodedata,xml.etree.ElementTree as ET,collections
from fontTools.ttLib import TTFont
P=Path(__file__).resolve().parent;B=P.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
x=json.loads((P/'final-five-reviewed.json').read_text()); entries=x['entries']; contract={e['key']:e for e in json.loads((B/'message-contract.json').read_text())}
held=json.loads((B/'language-holds-corrections/remaining-holds.json').read_text())['entries']; old={(e['tag'],e['key']):e for e in held}
assert len(entries)==5 and {(e['tag'],e['key']) for e in entries}==set(old)
for k,p in [('source_contract_sha256',B/'message-contract.json'),('input_remaining_holds_sha256',B/'language-holds-corrections/remaining-holds.json'),('input_corrections_reviewed_sha256',B/'language-holds-corrections/corrections-reviewed.json')]:assert x[k]==sha(p.read_bytes()),k
expected={
('ain-Latn','commons_metadata_field_too_large'):'Commons kor noka kar kur kor rehe newa uesere oruspe: a=uk a sine itaksay kor tanneru anak, sineatki a tanneru kasu.',
('ain-Kana','commons_metadata_field_too_large'):'Commons コㇿ ノカ カㇻ クㇽ コㇿ レヘ ネワ ウエセレ オルㇱペ: アウㇰ ア シネ イタㇰサイ コㇿ タンネル アナㇰ, シネアッキ ア タンネル カス.',
('ain-Latn','commons_download_original_mismatch'):'Commons kor cinuyep a=ranke rusuy sekor a=ye itak anak, mosma hoski cinuyep kor URL or un suy a=eikra.',
('ain-Kana','commons_download_original_mismatch'):'Commons コㇿ チヌイェㇷ゚ アランケ ルスイ セコㇿ アイェ イタㇰ アナㇰ, モㇱマ ホㇱキ チヌイェㇷ゚ コㇿ URL オㇿ ウン スイ アエイㇰラ.',
('mnc-Mong','commons_download_original_mismatch'):'Commons ᠴᡳ ᠪᡳᡨᡥᡝ ᠪᡝ ᠠᠯᡳᠮᡝ ᡤᠠᡳᡵᡝ ᠪᡝ ᠪᠠᡳᡵᡝ ᡤᡳᠰᡠᠨ ᠪᡝ, ᡤᡡᠸᠠ ᡩᠠ ᠪᡳᡨᡥᡝ\u202fᡳ URL ᡩᡝ ᡤᡠᡵᡳᠪᡠᡥᡝ.'}
dump=(P/'android-validation/resources-dump.txt').read_text();seen=[]
for e in entries:
 k=(e['tag'],e['key']);t=e['localized'];assert t==expected[k]
 assert t!=old[k]['localized'] and e['previous_held_value']==old[k]['localized']
 assert e['previous_held_utf8_sha256']==sha(old[k]['localized'].encode())
 assert e['english']==contract[e['key']]['english'] and e['source_english_sha256']==sha(e['english'].encode())
 assert e['contract_context']==contract[e['key']]['context']
 assert e['final_localized']==t and e['final_utf8_sha256']==sha(t.encode())
 assert e['implementation_snippet_sha256']==sha(e['implementation_context']['exact_source'].encode())
 assert e['implementation_context']['exact_source'] in (B/'source'/e['implementation_context']['path']).read_text()
 assert all(e[k] is True for k in ['integration_approved','eligible_for_integration','accepted_translation_credit'])
 assert e['ship_ready'] is False and e['blocking_uncertainty'] is None
 assert e['grammar_analysis'] and e['semantic_equivalence'] and e['back_translation'] and e['review_reason']
 assert all(s in x['references'] for s in e['source_reference_ids'])
 assert ET.fromstring(e['xml_element']).text==t
 root=ET.parse(P/'resources'/e['resource_path']).getroot()
 assert [s.text for s in root if s.attrib.get('name')==e['key']]==[t]
 assert t in dump
 assert '\ufffd' not in t and not any(unicodedata.category(c)=='Cc' for c in t)
 assert not any(unicodedata.category(c)=='Cf' for c in t)
 assert unicodedata.is_normalized('NFC',t)
 assert not re.search(r'%(?:\d+\$)?[a-zA-Z]',t)
 seen.append({'tag':e['tag'],'key':e['key'],'final_utf8_sha256':sha(t.encode()),'codepoints':len(t),'utf8_bytes':len(t.encode()),'nfc':True,'nnbsp_count':t.count('\u202f')})
assert sum(len(ET.parse(p).getroot()) for p in (P/'resources').rglob('strings.xml'))==5
assert len(list((P/'resources').rglob('strings.xml')))==3
M=json.loads((P/'ainu-word-mapping.json').read_text())
for key in ['commons_metadata_field_too_large','commons_download_original_mismatch']:
 l=expected[('ain-Latn',key)];k=expected[('ain-Kana',key)]
 tokens=re.findall(r'[A-Za-z=]+|[^A-Za-z=]',l)
 assert all(w in M for w in tokens if re.fullmatch(r'[A-Za-z=]+',w))
 assert ''.join(M.get(w,w) for w in tokens)==k
# Separate orthographic reading for each Manchu word, not a generic transliterator.
mt={'Commons':'Commons','ci':'ᠴᡳ','bithe':'ᠪᡳᡨᡥᡝ','be':'ᠪᡝ','alime':'ᠠᠯᡳᠮᡝ','gaire':'ᡤᠠᡳᡵᡝ','baire':'ᠪᠠᡳᡵᡝ','gisun':'ᡤᡳᠰᡠᠨ','gūwa':'ᡤᡡᠸᠠ','da':'ᡩᠠ','i':'ᡳ','URL':'URL','de':'ᡩᡝ','guribuhe':'ᡤᡠᡵᡳᠪᡠᡥᡝ'}
m=next(e for e in entries if e['tag']=='mnc-Mong'); roman=m['transliteration']; script=''.join(mt.get(w,w) for w in re.findall(r'[A-Za-zū]+|[^A-Za-zū]',roman)).replace('ᠪᡳᡨᡥᡝ ᡳ URL','ᠪᡳᡨᡥᡝ\u202fᡳ URL')
assert script==m['localized'];assert script.count('\u202f')==1
fontpath=B/'source/Paintroid/src/main/assets/fonts/notosansmongolian.ttf';cmap=TTFont(fontpath).getBestCmap()
assert all(ord(c) in cmap for c in script if 0x1820<=ord(c)<=0x18aa)
kfont=Path('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc');kcmap=TTFont(kfont,fontNumber=0).getBestCmap()
assert all(ord(c) in kcmap for e in entries if e['tag']=='ain-Kana' for c in e['localized'] if ord(c)>127)
checks=['Exact five-entry held input scope; all new values differ substantively','Contract, prior packet, previous value, English and implementation-source hashes bound','Independent full expected values, XML round trips, three accepted-only resource files','All five exact values in Android aapt2 compiled/linked resource dump','Two complete Ainu script pairs match explicit lexical correspondence','Manchu script matches independent word reading and expected genitive separator','NFC, no replacements/format controls or unexpected placeholders','Manchu glyph coverage in repository font; Kana glyph coverage in local Noto CJK font']
out={'result':'pass','accepted':5,'held':0,'checks':checks,'entries':seen,'font_checks':[{'role':'Repository Manchu font','path':str(fontpath),'sha256':sha(fontpath.read_bytes())},{'role':'Local Kana rendering font, not evidence of Android font selection','path':str(kfont),'sha256':sha(kfont.read_bytes())}],'limitations':['Language acceptance rests on cited lexical/grammatical analysis, not on these mechanical tests.','Android compile/link/dump is resource-only. Full application, host suites and device layout belong to integration.','Local glyph/render checks are not Android device screenshots or a native-speaker certification.']}
(P/'validation.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('PASS: 5 corrected values; 8 validation groups; 3 accepted-only XML files.')
