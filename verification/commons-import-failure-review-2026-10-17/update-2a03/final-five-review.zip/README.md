# Final five Commons error translations

Result: five substantive language corrections accepted for integration; no linguistic hold remains in this five-entry packet. This is a new review of rewritten language, not a mechanical approval of the prior drafts.

## What changed

- Ainu, both scripts, field-too-large: an already received individual attribution text item exceeds a pre-established length. The old writing-place and user-writing-allowance expressions are gone. The transitive exceed predicate makes the reference length an upper threshold in this error statement; it does not require every valid field to have the exact same length.
- Ainu, both scripts, download mismatch: the explicit message saying one wants to download the Commons file is sent again to a different original-file URL. The topicalized message is the matrix send object's referent. The file belongs to the embedded download clause.
- Manchu, download mismatch: the explicit request-message for receiving the file from Commons is transferred to a different original-file URL. Nested participial accusatives distinguish the receiving event, its file object, and the outer request-message object.

`final-five-reviewed.json` contains every complete resource value, exact previous/final UTF-8 and English/implementation hashes, per-entry back-translation, grammar analysis, semantic equivalence checks, orthography review, and source citations. Its source-assisted language review is independent of the previous held packet. A separate integration worker also checked the recast meanings; this is not presented as native-speaker certification.

The accepted-only XML files are under `resources/Paintroid/src/main/res/` and contain exactly five values across three locale files. They are additions to the existing source catalogue, not replacements for entire catalogue files.

## Validation

Run, in this directory:

1. `python validate_android.py`
2. `python validate_packet.py`
3. `python render_values.py`

Passed: aapt2 compile/link/dump, all five exact values in the linked resource table, five-entry input scope and source/contract hashes, prior/new exact hashes, XML round trips, both Ainu full-value script correspondences, separate Manchu word-by-word script reading, NFC/control/placeholder checks, and target-script glyph coverage. Eight grouped checks are recorded in `validation.json`.

The exact local RAQM rendering was visually inspected: no replacement boxes, clipped final lines or broken genitive separator were observed in that rendering. `local-font-render.png` is a local font check, not an Android screenshot. No full application build, host-suite pass, Android layout pass or release readiness is claimed by this packet.

## Primary language evidence

The full source list and its bounded claims are in the reviewed packet. In particular:

- National Ainu Museum Tamura/Kayano entries establish `uk`, `sine`, `sineatki`, `kasu`, `rusuy`, `ye`, `itak`, `sekor`, `anak`, `eikra`, `suy`, `mosma`, `un` and the past marker `a`.
- The `anak` entry itself illustrates a topicalized object with a transitive indefinite-person verb. This supports the request as the sent object, not merely a topic inferred from English.
- Itak-uoeroskip supplies contemporary file/download/licence/text terminology and the length noun. Productive full-message composition is identified as such; no verbatim historic Internet sentence is asserted.
- Möllendorff's 1892 primary grammar establishes case marking, participial noun modification and the irregular forms `gaire` and `baire`.
- Gorelova, printed p500 (PDF page525), supports nested accusative-marked participial object clauses governed by requesting.
- The Qing triglot index, printed p213 (PDF page218), gives the broader movement/transfer senses of `guribumbi`; the Kokushikan primary-document index independently attests past `guribuhe`.

`source-provenance.json` binds inspected source captures to hashes. Raw third-party research captures under `sources/` are temporary inputs and are excluded from the deliverable manifest. The packet carries concise source-based analysis and links rather than copies of whole reference works.

## Integration boundary

No source catalogue, remote branch or pull request was changed by this worker. Integration should append only these five reviewed values, retain all prior accepted work, and run the project's full host/application/device gates. `ship_ready` therefore remains false for each entry despite language-integration acceptance.
