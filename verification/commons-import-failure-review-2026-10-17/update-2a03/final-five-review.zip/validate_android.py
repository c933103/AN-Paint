"""Compile/link/dump the reviewed additions in a minimal resource-only APK."""
from pathlib import Path
import json, html, shutil, subprocess
P=Path(__file__).resolve().parent
AAPT=Path('/workspace/shared/an96-resource-repair/verification-tools/aapt2')
SDK=Path('/workspace/shared/passengercount-restart-race-20261017/investigation/sdk-platform/android-35/android.jar')
B=P/'android-validation';R=B/'res';(R/'values').mkdir(parents=True,exist_ok=True)
for d in (P/'resources/Paintroid/src/main/res').iterdir():shutil.copytree(d,R/d.name,dirs_exist_ok=True)
c=json.loads((P.parent/'message-contract.json').read_text())
(R/'values/strings.xml').write_text('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n'+''.join('    <string name="'+v['key']+'">'+html.escape(v['english'])+'</string>\n' for v in c)+'</resources>\n')
(B/'AndroidManifest.xml').write_text('<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="org.example.commonsreview"><uses-sdk android:minSdkVersion="21" android:targetSdkVersion="35"/><application/></manifest>\n')
commands=[
('version.log',[str(AAPT),'version']),
('compile.log',[str(AAPT),'compile','--dir',str(R),'-o',str(B/'compiled.zip')]),
('link.log',[str(AAPT),'link','-o',str(B/'resources.apk'),'--manifest',str(B/'AndroidManifest.xml'),'-I',str(SDK),str(B/'compiled.zip')]),
('resources-dump.txt',[str(AAPT),'dump','resources',str(B/'resources.apk')])]
results=[]
for filename,args in commands:
 p=subprocess.run(args,text=True,capture_output=True)
 (B/filename).write_text(p.stdout+p.stderr)
 results.append({'command':args,'exit_code':p.returncode,'log':str((B/filename).relative_to(P))})
 if p.returncode:raise RuntimeError(results[-1])
(B/'commands.json').write_text(json.dumps(results,indent=2)+'\n')
print('Android resource-only compile/link/dump: PASS. No application or device test claimed.')
