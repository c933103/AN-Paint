from pathlib import Path
import json,hashlib,xml.etree.ElementTree as E,collections,sys
P=Path(__file__).resolve().parents[1];S=P/'source';O=P/'independent-review';sys.path.insert(0,str(S/'tools'))
import translation_catalogues as c
from test_slovak_slovenian_catalan_priority_wording import token_contract
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def cat(path):
 root=E.parse(S/path).getroot();result={}
 for x in root:
  identity=x.tag+'/'+x.attrib['name'];assert identity not in result
  if x.tag=='plurals':
   assert all(n.tag=='item' and set(n.attrib)=={'quantity'} and not list(n)for n in x)
   value={n.attrib['quantity']:n.text for n in x};assert len(value)==len(x)
  else:assert not list(x);value=x.text
  result[identity]={'value':value,'attributes':dict(x.attrib)}
 return result
def bare(x):return None if x is None else {k:x[k]for k in ['value','attributes']}
def unquote(v):return v[1:-1]if v.startswith('"')and v.endswith('"')else v
def display(v,local):
 if isinstance(v,dict):return {q:display(x,local)for q,x in v.items()}
 if v.startswith('@string/'):return display(local['string/'+v[8:]]['value'],local)
 return unquote(v).replace('\\n','\n').replace("\\'", "'").replace('\\"','"')
EN=cat('Paintroid/src/main/res/values/strings.xml');tax=json.load(open(S/'translations/string-importance.json'));priority={k:t['id']for t in tax['tiers']if t['id']in ['P0','P1']for k in t['keys']};assert collections.Counter(priority.values())=={'P0':92,'P1':249}
holds={'string/'+k for k in ['formats22_derived_exported','ui_save_as','ui_save_as_jpeg','ui_save_as_jpeg_xl','ui_save_as_png','ui_foreground_background_colour_palette','ui_pinch_and_pan_mode','ui_main23']}
dep_holds={'string/'+k for k in ['ui_common_in','ui_common_in_pixels','ui_each_px_px_percent_is_relative_to_the']}
bindings={x['path']:x['git_blob_sha1']for x in json.load(open(P/'candidate-public/source-bindings.json'))['bindings']};paths={'Paintroid/src/main/res/values/strings.xml','translations/string-importance.json'};results={};summ={};allmaps={}
for tag in ['be','mk','sq']:
 packet=json.load(open(P/f'candidate-public/{tag}-complete-author-packet.json'));supp=json.load(open(P/f'candidate-public/{tag}-adjacent-controls-supplement.json'));local=cat(packet['catalogue_path']);paths.add(packet['catalogue_path']);assert {r['identity']:r['tier']for r in packet['rows']}==priority
 for path,b in supp['consumer_bindings'].items():
  assert path not in bindings or bindings[path]==b['git_blob'];bindings[path]=b['git_blob']
 deps=packet['outside_priority_dependencies']+supp['rows'];assert len(deps)==22 and len({r['identity']for r in deps})==22
 feedback={}
 for path in O.glob(f'{tag}-p[01]-feedback-v1.json'):
  f=json.load(open(path))
  for r in f['rows']:
   if r['decision']=='revise':feedback[r['identity']]=r
 present_holds={'string/ui_discard'}if tag in ['mk','sq']else set();out=[];dout=[];resource={};edits={};merged=dict(local)
 for r in packet['rows']+deps:
  identity=r['identity'];key=identity.split('/')[1];assert bare(r['english'])==EN[identity],(tag,identity,'English');old=bare(r['current']);assert old==local.get(identity),(tag,identity,'old');v=r.get('proposal')
  for call in r['direct_consumers']:
   paths.add(call['path']);lines=(S/call['path']).read_text().split('\n');assert call['context']=='\n'.join(lines[call['start_line']-1:call['end_line']]),(tag,identity,'context');assert key in lines[call['line']-1],(tag,identity,'line')
  if identity in holds|present_holds|dep_holds:
   assert v is None,(tag,identity,'held proposal');assert (old is not None)==(identity in present_holds),(tag,identity,'held presence')
   decision='hold_present_unchanged'if old else'hold_absent';reason='Exact no-current-consumer/unknown composition hold retained, not a blanket priority freeze. Generic Discard object context remains unresolved where current adds changes.'
   row={**r,'decision':decision,'reviewed_value':None,'rationale':reason,'confidence':'Unresolved context; no acceptance.'}
  else:
   if v is None:assert old is not None;v=old['value']
   if isinstance(v,str)and old and isinstance(old['value'],str)and unquote(old['value'])==unquote(v):v=old['value']
   attrs=old['attributes']if old and old['value']==v else EN[identity]['attributes']
   if identity in feedback:
    assert v==feedback[identity]['reviewed_proposal'],(tag,identity,'feedback not adopted')
   vals=v if isinstance(v,dict)else{'string':v};src=EN[identity]['value']if isinstance(v,dict)else{'string':EN[identity]['value']}
   if isinstance(v,dict):assert set(v)==({'one','few','many','other'}if tag=='be'else{'one','other'})
   for q,text in vals.items():
    canonical=src.get(q,src.get('other'));assert text and not c.android_string_errors(text),(tag,identity,q,'Android');assert not c.format_string_errors(text,attrs.get('formatted')!='false'),(tag,identity,q,'format')
    if not text.startswith('@string/'):
     assert token_contract(text)==token_contract(canonical),(tag,identity,q,'tokens');assert text.count('\\n')==canonical.count('\\n'),(tag,identity,q,'newline')
   if key in ['ui_quality','ui_strength']:assert attrs.get('formatted')=='false' and '(%)'in v
   changed=old!={'value':v,'attributes':attrs};active=bool(r['direct_consumers'])
   decision=('accept_new_active'if active else'accept_new_wording_only')if old is None else'accept_current_correction'if changed else'accept_current_bounded'if active else'accept_current_wording_only'
   reason='Complete value checked with exact source/current, clauses, actual consumer slots, numerical grammar, command labels and Android structure.'if active else'Complete source-only wording accepted; no direct current consumer or installed behavior claim. This context limit also applies to corrections.'
   if identity in feedback:reason=feedback[identity]['rationale']
   if key=='ui_crop_preview_images':reason='Every complete plural child reviewed; all three typed integers and literal newline exact, attached-image movement remains conditional. Count-label constructions avoid inflection across arbitrary counts; Albanian singular/plural complete. CLDR categories corroborated, Android runtime still pending.'
   if key in ['save20_gif_description','save20_dither']:reason='Full GIF behaviour/limitation wording and exact paired dithering checkbox reviewed together. BE/MK upstream imaging terminology corroborates retained labels; SQ explicit technical loan accepted at moderate technical confidence, no native attestation invented.'
   if key in ['ui_expand_tool_category','ui_collapse_tool_category']:reason='Full category/selected-tool/disclosure action checked; agreement attaches to explicit tool noun, with all five adjacent tool names reviewed.'
   if key in ['ui_fg','ui_bg']:reason='Bounded compact colour-role wording checked against localized accessibility labels; no claim of unaided visual recognition, layout or native-user usability.'
   row={**r,'decision':decision,'reviewed_value':v,'reviewed_attributes':attrs,'rationale':reason,'confidence':'Medium model linguistic judgment; high exact source/format/caller binding. No native-human certification.'}
   if identity in feedback:row['review_history']={'initial_decision':'revise','feedback_file':f'{tag}-p'+('0'if identity in {x['identity']for x in json.load(open(O/f'{tag}-p0-feedback-v1.json'))['rows']}else'1')+'-feedback-v1.json','author_second_check':'Exact adopted proposal independently read back.'}
   resource[key]=v;merged[identity]={'value':v,'attributes':attrs}
   if changed:edits[key]={'identity':identity,'type':identity.split('/')[0],'tier':r['tier'],'source':bare(r['english']),'previous_target':old,'reviewed_value':v,'reviewed_attributes':attrs,'decision':'accept','rationale':reason,'direct_consumers':r['direct_consumers']}
  (out if identity in priority else dout).append(row)
 assert len(out)==341 and sum(r['decision'].startswith('hold')for r in out)==(8 if tag=='be' else 9)
 assert len(dout)==22 and sum(r['decision'].startswith('hold')for r in dout)==3
 result={'source_commit':packet['source_commit'],'source_tree':packet['source_tree'],'locale':tag,'catalogue_path':packet['catalogue_path'],'scope':'Full92 P0 plus249 P1 independent complete-value review;22 explicitly enumerated adjacent dependencies,19 accepted and3 unknown-composition holds. No prior complete independent acceptance recovered or invented.','rows':out,'dependencies':dout,'accepted_resource_text_values':resource,'accepted_display_values':{k:display(v,merged)for k,v in resource.items()},'integration_values':edits,'counts':dict(collections.Counter(r['decision']for r in out)),'dependency_counts':dict(collections.Counter(r['decision']for r in dout)),'feedback_provenance':{x.name:hashlib.sha256(x.read_bytes()).hexdigest()for x in O.glob(f'{tag}-*feedback*.json')},'value_encoding':'Exact raw Android text/aliases/quotes retained where unchanged; every plural child complete and explicitly typed. Target/source/previous attributes bound independently.','limits':['No native-human, whole-language, installed layout or accessibility runtime certification.','Dormant wording acceptance does not resolve runtime/visual context. Fixed user pauses/freeze remain untouched.','All accepted edits currently unapplied; author owns exact-map integration and runtime verification.','No app resources modified by reviewer.']}
 results[tag]=result;allmaps[tag]=edits;summ[tag]={'priority':result['counts'],'dependencies':result['dependency_counts'],'edits':len(edits),'accepted':len(resource)}
verified={}
for path in paths:
 assert path in bindings,('missing source binding',path);assert blob((S/path).read_bytes())==bindings[path],('source drift',path);verified[path]=bindings[path]
for tag,result in results.items():(O/f'{tag}-complete-review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(O/'accepted-edit-maps.json').write_text(json.dumps(allmaps,ensure_ascii=False,indent=2)+'\n');(O/'complete-review-verification.json').write_text(json.dumps({'result':'PASS','source_commit':packet['source_commit'],'source_tree':packet['source_tree'],'verified_source_blobs':verified,'locales':summ,'scope':'All1,023 priority rows and66 adjacent dependency rows complete-value read, exact current/English/attrs/token/newline and every caller window verified. No Android runtime execution claimed.'},ensure_ascii=False,indent=2)+'\n');print(json.dumps(summ,indent=2));print('Verified',len(verified),'source blobs')
