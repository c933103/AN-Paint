from pathlib import Path
import json,hashlib
B=Path(__file__).resolve().parents[1]
sets={
'be':{
'language20_app_language':('Мова праграмы','Restores explicit App qualifier; the dialog selects the application language, not an unspecified/system language.'),
'ui_fit_entire_canvas_in_view':('Упісаць усё палатно ў вобласць прагляду','Full accessibility description must name the entire canvas and viewport, not merely the image/window label; actual fit control frames the canvas.'),
'ui_fit_image':('Упісаць відарыс','Source-only dormant label: remove unsupported window destination without inventing a current caller. Remains wording-only, not runtime-context acceptance.'),
'ui_scales_the_image_unlock_the_ratio_to_stretch':('Маштабуе відарыс. Зніміце фіксацыю суадносін бакоў, каб незалежна змяняць шырыню і вышыню.','Unlocked dimensions may shrink or grow independently; neutral change preserves both cases instead of enlargement-only wording.'),
'ui_swap_foreground_background':('Памяняць месцамі колеры пярэдняга плана і фону','Dormant source explicitly identifies foreground and background; restore both objects rather than generic swap-colours wording. Wording-only, no invented caller.'),
'ui_no_readable_image_data':('Няма даных відарыса, якія можна прачытаць.','Use explicit can-be-read wording for readable image data; avoids reading-purpose adjective чытальных.')},
'mk':{
'ui_invalid_selection_outline':('Неважечка контура на изборот.','Use feminine контура and matching adjective, coherent with proposed Outline=Контура and upstream selection-outline terminology.'),
'ui_scales_the_image_unlock_the_ratio_to_stretch':('Ја менува големината на сликата. Отклучете го соодносот за независно да ги менувате ширината и висината.','Unlocked width/height may decrease as well as stretch; retain complete independent-dimensions meaning without an enlarge-only instruction.')},
'sq':{
'ui_menu_colours':('Ngjyrat','Restore plural Colors rather than singular Ngjyrë; dormant wording-only correction, distinct from active singular Color tab.'),
'ui_scales_the_image_unlock_the_ratio_to_stretch':('Ndryshon përmasat e imazhit. Zhbllokoni raportin për të ndryshuar gjerësinë dhe lartësinë në mënyrë të pavarur.','Independent dimension editing supports shrinking and growing; neutral change avoids only-stretch interpretation.')}
}
for tag,items in sets.items():
 p=B/f'candidate-public/{tag}-complete-author-packet.json';d=json.loads(p.read_text());rows=[]
 for key,(value,reason) in items.items():
  r=next(r for r in d['rows']if r['identity']=='string/'+key).copy();r.update(decision='revise',reviewed_proposal=value,rationale=reason,confidence='medium-high semantic/format; bounded model linguistic judgment')
  rows.append(r)
 out={'source_commit':d['source_commit'],'source_tree':d['source_tree'],'locale':tag,'scope':'All249 complete P1 values read including retained/held rows; exact refinements for author second-check. Full341 final dispositions follow atomic dependency readback. No native/layout certification.','candidate_packet_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'rows':rows}
 dest=B/f'independent-review/{tag}-p1-feedback-v1.json';dest.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(tag,len(rows),hashlib.sha256(dest.read_bytes()).hexdigest())
