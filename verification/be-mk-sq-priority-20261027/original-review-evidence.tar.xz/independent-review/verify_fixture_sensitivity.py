from pathlib import Path
import sys,json,hashlib,copy,collections,xml.etree.ElementTree as E
P=Path(__file__).resolve().parents[1];S=P/'source';O=P/'independent-review';sys.path.insert(0,str(S/'tools'))
import test_belarusian_macedonian_albanian_priority_wording as g
import be_mk_sq_priority_scope as scope
f=json.load(open(S/'tools/fixtures/current_localization/belarusian_macedonian_albanian_priority_wording.json'));g.checked(f)
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def cat(path):return {n.tag+'/'+n.attrib['name']:{'value':{x.attrib['quantity']:x.text for x in n}if n.tag=='plurals'else n.text,'attributes':dict(n.attrib)}for n in E.parse(path).getroot()}
mutations=[];counts={}
def reject(x,name):
 try:g.checked(x)
 except (ValueError,KeyError):mutations.append(name)
 else:raise AssertionError('Accepted corrupt fixture: '+name)
for tag in ('be','mk','sq'):
 d=json.load(open(O/f'{tag}-complete-review.json'));v=f['locales'][tag];rows={r['identity']:r for r in d['rows']+d['dependencies']};accepted={i:r for i,r in rows.items()if not r['decision'].startswith('hold')};edited={r['identity']:r for r in d['integration_values'].values()};original=cat(P/f'verified-original-catalogues/{tag}.xml')
 assert set(v['values'])==set(edited)
 assert set(v['context'])==set(accepted)-set(edited)==scope.EXPECTED_CONTEXT_KEYS[tag]
 for field in ('values','context'):
  for identity,r in v[field].items():
   reviewed=rows[identity];assert r['source']==reviewed['english']['value']and r['source_attributes']==reviewed['english']['attributes']
   assert r['target']==reviewed['reviewed_value']and r['attributes']==reviewed['reviewed_attributes']
   assert r['display']==d['accepted_display_values'][identity.split('/')[1]]
 expected_pre={i:{'target':original[i]['value'],'attributes':original[i]['attributes']}for i in edited if i in original}
 assert scope.EXPECTED_PREDECESSORS[tag]==expected_pre
 assert {i:{'target':r['previous_target'],'attributes':r['previous_attributes']}for i,r in v['values'].items()if r['previous_target']is not None}==expected_pre
 expected_held={i:{'target':r['current']['value']if r['current']else None,'attributes':r['current']['attributes']if r['current']else r['english']['attributes']}for i,r in rows.items()if r['decision'].startswith('hold')}
 assert scope.EXPECTED_HELD[tag]==expected_held and set(v['held'])==set(expected_held)
 expected_preserved={i:{'target':r['value'],'attributes':r['attributes']}for i,r in original.items()if i not in rows}
 assert scope.EXPECTED_PRESERVED[tag]==expected_preserved and set(v['preserved'])==set(expected_preserved)
 parts=collections.defaultdict(list)
 for r in d['rows']:
  limit='held-unaccepted'if r['decision'].startswith('hold')else'active-bounded-static'if r['direct_consumers']else'dormant-wording-only; caller/context acceptance unresolved'
  parts[r['decision']+' | '+limit].append(r['identity'])
 assert {k:set(a)for k,a in parts.items()}=={k:set(a)for k,a in v['priority_partitions'].items()}=={k:set(a)for k,a in scope.EXPECTED_PRIORITY_PARTITIONS[tag].items()}
 # Each context identity and each predecessor gets an independent negative, not only the first dictionary item.
 for identity in v['context']:
  x=copy.deepcopy(f);x['locales'][tag]['context'].pop(identity);reject(x,tag+'/'+identity+'/missing-context')
 for identity in expected_pre:
  for kind in ('forged','as-addition','attribute'):
   x=copy.deepcopy(f);r=x['locales'][tag]['values'][identity]
   if kind=='forged':r['previous_target']+=' forged'
   elif kind=='as-addition':r['previous_target']=None;r['previous_attributes']=None
   else:r['previous_attributes']['unexpected']='true'
   reject(x,tag+'/'+identity+'/'+kind)
 for identity in v['held']:
  x=copy.deepcopy(f);x['locales'][tag]['held'][identity]['decision']='accept';reject(x,tag+'/'+identity+'/held-credit')
 for group,identities in parts.items():
  x=copy.deepcopy(f);x['locales'][tag]['priority_partitions'][group+' changed']=x['locales'][tag]['priority_partitions'].pop(group);reject(x,tag+'/'+group+'/context-credit')
 counts[tag]={'priority':len(d['rows']),'dependencies':len(d['dependencies']),'edits':len(edited),'accepted_unchanged':len(v['context']),'bound_corrected_predecessors':len(expected_pre),'held_present_absent':len(expected_held),'outside_review_preserved':len(expected_preserved)}
 print(tag,counts[tag],flush=True)
history=json.load(open(P/'historical-fixture-bindings.json'))
for path,r in history.items():
 b=(S/path).read_bytes();assert blob(b)==r['git_blob']and hashlib.sha256(b).hexdigest()==r['sha256'],path
paths=['tools/test_belarusian_macedonian_albanian_priority_wording.py','tools/be_mk_sq_priority_scope.py','tools/belarusian_macedonian_albanian_priority_expectations.py','tools/fixtures/current_localization/belarusian_macedonian_albanian_priority_wording.json','Paintroid/src/test/java/org/catrobat/paintroid/local/BelarusianMacedonianAlbanianPriorityWordingTest.kt']
receipt={'result':'PASS','scope':'Independent exact full review/fixture equality, whole retained complements, predecessor/source/attribute binding, exact context/hold/status partitions and full catalogue scope. Historical fixtures preserved exactly.','counts':counts,'independent_rejected_mutations':len(mutations),'historical_fixtures_byte_verified':len(history),'focused_host':{'normal':'pending completion','optimized':'pending completion'},'jvm_static_review':{'methods':12,'complete_read':True,'actual_API_consumers_checked':True,'hosted_compile_runtime_pending':True},'limits':['No local SDK/Gradle compilation or installed runtime/layout/TalkBack certification.','Full aggregate and shared historical guard follow-through remain author-owned.'],'files':{p:hashlib.sha256((S/p).read_bytes()).hexdigest()for p in paths}}
(O/'integrated-fixture-test-review.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps(receipt,indent=2),flush=True)
