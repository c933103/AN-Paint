from pathlib import Path
import json,hashlib,xml.etree.ElementTree as E,re
P=Path(__file__).resolve().parents[1];S=P/'source';O=P/'independent-review';bindings={r['path']:r['git_blob_sha1']for r in json.load(open(P/'candidate-public/source-bindings.json'))['bindings']}
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def cat(p):
 root=E.parse(p).getroot();out={}
 for x in root:
  key=x.tag+'/'+x.attrib['name'];assert key not in out
  if x.tag=='plurals':
   assert all(n.tag=='item'and set(n.attrib)=={'quantity'}and not list(n)for n in x);v={n.attrib['quantity']:n.text for n in x};assert len(v)==len(x)
  else:assert not list(x);v=x.text
  out[key]={'value':v,'attributes':dict(x.attrib)}
 return out
def frag(s,key):
 typ,k=key.split('/');m=re.search(r'<'+typ+r'\b(?=[^>]*\bname="'+re.escape(k)+r'")[^>]*>.*?</'+typ+r'>',s,re.S);return None if m is None else m.group()
rows=[]
for tag in ('be','mk','sq'):
 d=json.load(open(O/f'{tag}-complete-review.json'));path=d['catalogue_path'];orig=P/f'verified-original-catalogues/{tag}.xml';assert blob(orig.read_bytes())==bindings[path]
 before=cat(orig);after=cat(S/path);delta={k for k in before.keys()|after.keys()if before.get(k)!=after.get(k)};edits={r['identity']:r for r in d['integration_values'].values()};assert delta==set(edits)
 for key,r in edits.items():assert before.get(key)==r['previous_target']and after[key]=={'value':r['reviewed_value'],'attributes':r['reviewed_attributes']},(tag,key)
 for key in before.keys()-delta:assert frag(orig.read_text(),key)==frag((S/path).read_text(),key),(tag,key,'untouched node')
 for r in d['rows']+d['dependencies']:
  if r['decision']=='hold_absent':assert r['identity']not in after
  if r['decision']=='hold_present_unchanged':assert before[r['identity']]==after[r['identity']]
 for key,v in d['accepted_resource_text_values'].items():assert after[('plurals/'if isinstance(v,dict)else'string/')+key]['value']==v
 rows.append({'locale':tag,'before_blob':bindings[path],'after_blob':blob((S/path).read_bytes()),'after_sha256':hashlib.sha256((S/path).read_bytes()).hexdigest(),'edits':len(delta),'unchanged_original_nodes_byte_identical':len(before.keys()-delta),'before_count':len(before),'after_count':len(after)})
out={'result':'PASS','source_parent':d['source_commit'],'source_tree':d['source_tree'],'locales':rows,'total_exact_edits':sum(r['edits']for r in rows),'scope':'Independent original Git-blob bound XML readback; exact accepted maps, held-present/absent identities, every unrelated original XML node byte-preserved. No runtime proof.'};(O/'integrated-xml-readback.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
