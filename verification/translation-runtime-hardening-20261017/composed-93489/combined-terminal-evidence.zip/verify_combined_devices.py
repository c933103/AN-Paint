from pathlib import Path
import sys,json,shutil
B=Path(__file__).resolve().parent;S=B/'combined-source';sys.path.insert(0,str(S/'tools'))
from app_instrumentation_matrix import verify_reports
from run_android_instrumentation import source_tests_sha256,declared_tests
R=B/'combined-device-composed'
for folder in ['combined-device-core','combined-device-position']:shutil.copytree(B/folder,R,dirs_exist_ok=True)
app=verify_reports(S/'app/src/androidTest',R,35)
assert app['success'];native=json.loads((R/'Paintroid/androidTest-results/summary.json').read_text())
expected=declared_tests(S/'Paintroid/src/androidTest',sdk_level=35);actual={(x['classname'],x['name']) for x in native['cases']}
assert native['success'] and native['device_sdk']==35 and not native['timed_out']
assert actual==expected and native['source_tests_sha256']==source_tests_sha256(S/'Paintroid/src/androidTest')
assert not(native['missing'] or native['unexpected'] or native['errors']);assert all(x['status']=='passed' for x in native['cases'])
summary={'source_head':'93489b4138e84f73356302a1e75a5cb377954e88','hosted_merge':'bcad0b45e6b9fbcd979f2a46f1e9863d2596aa38','device_sdk':35,'native_expected_and_completed':len(actual),'app_composed_result':app,'total_completed':len(actual)+app['completed_tests'],'artifact_digests':{'core':'74f36515c9b36173a63216f8f8532d827fb0a6edb25589c23b98a9e4697978a8','position':'3663b5f3b85874089f29d974ad57ef3c183f1269d7de982c9036dbb97bf201ec'}}
(B/'combined-device-verification.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
