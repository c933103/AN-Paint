from pathlib import Path
import hashlib,json,re,xml.etree.ElementTree as ET
B=Path(__file__).resolve().parent;H=B/'combined-hosted-regression';S=B/'combined-source'
j=json.loads((H/'summary.json').read_text());assert (j['suites'],j['tests'],j['failures'],j['errors'],j['skipped'])==(114,1127,0,0,0)
expected=set()
for p in (S/'Paintroid/src/test/java').rglob('*.kt'):
 text=p.read_text()
 if re.search(r'@Test\b',text):expected.add(re.search(r'^package\s+(\S+)',text,re.M)[1]+'.'+p.stem)
assert expected=={s['name'] for s in j['suite_results']}
r=json.loads((H/'Paintroid/build/reports/jvm-preparation/debug.json').read_text());assert r['target']==':Paintroid:testDebugUnitTest' and r['scheduledTests']==[]
assert r['target'] not in r['scheduledTasks'];assert all(x in r['scheduledTasks'] for x in r['directDependencies']);assert r['resolvedInputFileCount']>0
required=[':Paintroid:compileDebugKotlin',':Paintroid:compileDebugUnitTestKotlin',':Paintroid:compileDebugJavaWithJavac',':Paintroid:compileDebugUnitTestJavaWithJavac',':Paintroid:generateSourceTextResources']
assert all(x in r['scheduledTasks'] for x in required)
log=(H/'build/reports/ci-phases/jvm.log').read_text()
for x in required:assert f'> Task {x} UP-TO-DATE' in log,x
assert '> Task :Paintroid:testDebugUnitTest\n' in log
phases={}
for p in (H/'build/reports/ci-phases').glob('*.time'):
 d=dict(line.split('=',1) for line in p.read_text().splitlines());assert d['exit_status']=='0';phases[p.stem]=float(d['real_seconds'])
assert phases['jvm-prepare']<360 and phases['jvm']<720
lint=ET.parse(H/'app/build/reports/lint-results-debug.xml').getroot();assert not lint.findall('issue')
resources=json.loads((B/'combined-exact-resource/summary.json').read_text());assert resources['success'] and resources['tree']=='2c61c517f00d800bd5cc0ff1bf8f783a9b687a56'
for p in resources['probes']:
 assert hashlib.sha256((B/'combined-exact-resource'/(p['name']+'.log')).read_bytes()).hexdigest()==p['log_sha256']
 assert (p['exit_code']==0)==p['expected_success']
for f,sha in resources['probes'][1]['source_text_sha256'].items():assert hashlib.sha256((B/'combined-generated/sourceTextResources'/f).read_bytes()).hexdigest()==sha
captures=[json.loads(p.read_text()) for p in (H/'Paintroid/build/reports/commons-import-failures').glob('*.json')];assert len(captures)==60 and all(x['all_characters_laid_out'] for x in captures)
for x in captures:
 if x['horizontal_scroll_required'] and x['scroll_x']>0:assert x['scroll_x']==x['max_scroll_x']
comparison=json.loads((B/'combined-delivery/source-comparison.json').read_text());assert comparison['changed']==[] and comparison['mode_mismatches']==[];assert sorted(comparison['missing'])==['.gitignore','.idea/codeStyles/Project.xml','colorpicker/.gitignore']
report={'source_head':'93489b4138e84f73356302a1e75a5cb377954e88','hosted_merge':'bcad0b45e6b9fbcd979f2a46f1e9863d2596aa38','tree':'2c61c517f00d800bd5cc0ff1bf8f783a9b687a56','junit_suites':114,'junit_tests':1127,'test_source_file_inventory_matches':True,'failures':0,'errors':0,'skipped':0,'preparation_tasks':len(r['scheduledTasks']),'direct_dependencies':len(r['directDependencies']),'input_file_count':r['resolvedInputFileCount'],'scheduled_tests':r['scheduledTests'],'phase_seconds':phases,'lint_issues':0,'resource_probes':len(resources['probes']),'commons_capture_metadata_complete':len(captures),'included_corresponding_source_files':1188,'corresponding_source_metadata_omissions':comparison['missing'],'claims':'Counts and timing bind only this exact run, not future caps or universal device/linguistic safety. Native controls and viewports are distinct from installed physical-device/TalkBack coverage.'}
(B/'combined-hosted-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
