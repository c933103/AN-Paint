from pathlib import Path
import subprocess,time,json,hashlib
B=Path(__file__).resolve().parent;R=B/'combined-source';manifest={p:e['sha256'] for p,e in json.loads((B/'combined-source-manifest.json').read_text())['files'].items()};results=[]
assert all(hashlib.sha256((R/p).read_bytes()).hexdigest()==h for p,h in manifest.items())
for label,cmd in [('normal',['python3','-m','unittest','discover','-s','tools','-p','test_*.py','-v']),('optimized',['python3','-O','-m','unittest','discover','-s','tools','-p','test_*.py'])]:
 start=time.monotonic()
 with (B/f'host-combined-{label}.log').open('w') as out:p=subprocess.run(cmd,cwd=R,stdout=out,stderr=subprocess.STDOUT)
 result={'label':label,'exit_code':p.returncode,'seconds':time.monotonic()-start,'command':cmd,'snapshot_sha256':hashlib.sha256((B/'combined-source-manifest.json').read_bytes()).hexdigest()};results.append(result);(B/'host-combined-results.json').write_text(json.dumps(results,indent=2)+'\n');print(result,flush=True)
assert all(hashlib.sha256((R/p).read_bytes()).hexdigest()==h for p,h in manifest.items())
