from pathlib import Path
import hashlib,json,shutil,os
B=Path(__file__).resolve().parent;OUT=B/'combined-source';A=B/'review-511-source';C=Path('/workspace/shared/anpaint-commons-errors-20261017/source')
def tree(name):return {x['path']:x for x in json.loads((B/name).read_text())['tree'] if x['type']=='blob'}
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
base=tree('base-38d4-tree.json');p111=tree('pr111-204374-tree.json');p114=tree('concurrent-511-tree.json');chosen={};overlap=[]
assert not OUT.exists(),'Do not overwrite a candidate snapshot'
for path in sorted(p111.keys()|p114.keys()):
 before=base.get(path,{}).get('sha'); l=p111.get(path);r=p114.get(path)
 lc=(l or {}).get('sha')!=before;rc=(r or {}).get('sha')!=before
 if lc and rc and l!=r:overlap.append(path)
 selected=l if lc else r
 if selected is None:continue
 source=C if lc else A
 data=(source/path).read_bytes();assert blob(data)==selected['sha'],path
 target=OUT/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);target.chmod(int(selected['mode'],8)&0o777)
 chosen[path]={'origin':'111' if lc else '114','sha':selected['sha'],'mode':selected['mode']}
assert overlap==['Paintroid/src/main/java/org/catrobat/paintroid/classic/VerticalText.kt','Paintroid/src/main/res/values-ja/strings.xml'],overlap
ja='Paintroid/src/main/res/values-ja/strings.xml';old='%1$sの切り詰め量（百分率）';new='%1$sの切り詰め量（%%）';s=(OUT/ja).read_text();assert s.count(old)==1 and new in (A/ja).read_text();(OUT/ja).write_text(s.replace(old,new));chosen[ja]['origin']='111 Commons entries + 114 percent symbol restoration'
patches={'checker-root-fix':['tools/check_translation_boundaries.py','tools/test_translation_boundaries.py'],'ci-preparation-fix':['Paintroid/build.gradle','.github/workflows/android.yml','tools/ci_run_timed.sh','tools/test_ci_check_phases.py','CI.md'],'vertical-composition':['Paintroid/src/main/java/org/catrobat/paintroid/classic/VerticalText.kt','Paintroid/src/test/java/org/catrobat/paintroid/local/VerticalCaptionSafetyTest.kt']}
for dirname,paths in patches.items():
 for path in paths:
  (OUT/path).write_bytes((B/dirname/path).read_bytes());chosen[path]['origin']=dirname
for path,entry in chosen.items():
 data=(OUT/path).read_bytes();entry['sha']=blob(data);entry['sha256']=hashlib.sha256(data).hexdigest();entry['size']=len(data)
report={'parents':{'111':'20437482b1d3d8ffe409f9f6ee366cb7c5abf7a7','114':'511f9607c7889a5acd2e6f79dc96e484cb37bf5a','common_base':'38d4cbef9fff10bcb758f36b1908c4b87958d3d9'},'explicit_overlaps':overlap,'files':chosen}
(B/'combined-source-manifest.json').write_text(json.dumps(report,indent=2)+'\n')
print('Prepared',len(chosen),'files; intentional overlap:',overlap)
