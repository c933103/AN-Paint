from pathlib import Path
import subprocess,json
B=Path(__file__).resolve().parent;R=B/'combined-source';T=B/'combined-compile-check';T.mkdir(exist_ok=True)
D=Path('/workspace/shared/anpaint-commons-errors-20261017/compile-check/deps');deps=':'.join(str(p) for p in D.glob('*.jar'));sdk='/workspace/shared/passengercount-restart-race-20261017/investigation/sdk-platform/android-35/android.jar';cp=deps+':'+sdk
main=R/'Paintroid/src/main/java';symbol=B/'combined-resource-check/symbols';out=T/'classes';tests=T/'tests';steps=[]
def run(label,args):
 p=subprocess.run(args,text=True,capture_output=True);(T/f'{label}.log').write_text(p.stdout+p.stderr);steps.append({'label':label,'command':args,'exit_code':p.returncode});(T/'commands.json').write_text(json.dumps(steps,indent=2)+'\n');print(label,p.returncode,p.stdout[-500:]+p.stderr[-1500:],flush=True);return p.returncode==0
kotlin=['java','-cp',deps,'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-jvm-target','17','-Xstring-concat=inline']
if not run('kotlin-main',kotlin+['-classpath',cp,'-d',str(out),*[str(p) for p in main.rglob('*.kt')],*[str(p) for p in main.rglob('*.java')],*[str(p) for p in symbol.rglob('*.java')]]):raise SystemExit(1)
if not run('java-main',['java','-m','jdk.compiler/com.sun.tools.javac.Main','-source','17','-target','17','-proc:none','-classpath',str(out)+':'+cp,'-d',str(out),*[str(p) for p in main.rglob('*.java')],*[str(p) for p in symbol.rglob('*.java')]]):raise SystemExit(1)
local=R/'Paintroid/src/test/java/org/catrobat/paintroid/local'
if not run('kotlin-focused-tests',kotlin+['-Xfriend-paths='+str(out),'-classpath',str(out)+':'+cp,'-d',str(tests),*[str(p) for p in local.glob('*.kt') if p.name != 'GalleryExternalLinkTest.kt'],*[str(p) for p in local.glob('*.java')]]):raise SystemExit(1)
if not run('java-test-helper',['java','-m','jdk.compiler/com.sun.tools.javac.Main','-source','17','-target','17','-proc:none','-classpath',str(out)+':'+str(tests)+':'+cp,'-d',str(tests),*[str(p) for p in local.glob('*.java')]]):raise SystemExit(1)
run('pure-junit',['java','-cp',str(out)+':'+str(tests)+':'+cp,'org.junit.runner.JUnitCore','org.catrobat.paintroid.local.LocaleTextTest','org.catrobat.paintroid.local.CaptionPrefixSearchTest','org.catrobat.paintroid.local.VerticalRunConstructionTest'])
