# VerticalText composition independent review

Bounded local review of the proposed PR114 composition with PR111 baseline 20437482. Compared the supplied exact111 VerticalText.kt against the local vertical-composition candidate and concurrent 511f9607. No application source edits or external mutations were made.

## Result

No concrete composition regression was found. The candidate preserves 511's completed-substring clustering, builder-based tokenization and incremental mixed wrapping. It retains 20437482's linear run construction and unchanged NNBSP suffix splits for both mixed and sideways orientations. The factored suffix predicate is applied to complete runs and incremental measurement. Previous-cluster state is carried across wrapping tokens and reset with a new column; the tokenization keeps NNBSP together with its following Mongolian suffix, supplying the required lookahead. Width flushes complete the same shaping runs as whole bounds.

The caption native oracle adds Commons+NNBSP and a suffix token after a separate breakable-space token. Its trimming preserves NNBSP, NBSP and figure space. Existing caption assertions remain. VerticalRunConstructionTest and MongolianSuffixShapingTest are byte-identical to their supplied PR111 source copies. RibbonWidgets/cache and prefix-search code are not altered by this two-file composition.

## Independently executed checks

- Fresh production and renamed exact20437482 baseline compile against API35 and Kotlin 1.9.24, plus the unchanged run-construction test: success.
- VerticalRunConstructionTest: 3 JUnit tests pass.
- 6,000 seeded Unicode strings: exact cluster and run equivalence versus 20437482 in all 3 orientations. Includes combining marks, ZWJ, variation selectors, supplementary characters, emoji tags/modifiers, regional indicators, nonbreaking spaces and isolated UTF-16 surrogates. Four additional long inputs reconstruct without text loss.
- 37,500 modeled wrapLabel comparisons: all match exact20437482, across 3 directions and 5 heights; sample alphabet includes Commons+NNBSP and a suffix after a separate space.
- 8,100 additional modeled wrapLabel comparisons over 9 focused suffix/nonbreaking fixtures, 3 directions and heights 1 through 300: all match exact20437482.
- 31 incremental-versus-whole bounds comparisons: all pass, including cross-token preceding state, Mongolian roots that must remain joined, upright predecessors, repeated suffixes, NBSP and figure-space controls.
- Disposable negative-control copies validate sensitivity: removing suffix splitting from the incremental measurer causes 12 direct-measurement and 48 wrap mismatches; removing only previous-token state causes 4 direct-measurement and 12 wrap mismatches. Both are detected. The actual candidate has zero mismatches.

## Reproduction and limits

Logs, helper sources, synthetic measurement stubs and exact source hashes are in vertical-composition-review/. The baseline is mechanically renamed BaselineVerticalText with duplicate enums removed; its original SHA256 is 39281c9e1397341d06d57b434d4dfea5cb1f3980d153defa9a2eb99c3d5ff326. The two diagnostic copies are mechanically renamed and replace only MixedLineMeasurement's split expression with false or a within-token predecessor lookup. They never modify the candidate.

The modeled measurement backend replaces Paint, RectF, TextPaint, Layout and StaticLayout only in a disposable test classpath. It includes non-additive widths and constant per-layout padding, testing state and run composition. These results do not establish Android font shaping or native pixels. This reviewer did not run native Robolectric graphics, installed UI layout or API21–27 paint cache behavior. Exact composed-head hosted native tests remain required. No universal time/heap guarantee for platform shaping or arbitrary caller text is claimed.

Reviewed candidate SHA256:
- VerticalText.kt: 3e886b5d845e61e267bb8e6b4ae7d4842b9fcd090819f80ce369cc7dab709dbc
- VerticalCaptionSafetyTest.kt: 94ad9068933a334867b8cfe41e5c1a3938909f56cafb4195bf730e15979ebced
