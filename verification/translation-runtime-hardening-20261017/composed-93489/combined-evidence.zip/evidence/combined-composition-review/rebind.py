from pathlib import Path
import hashlib,json,re
B=Path(__file__).resolve().parents[2]
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
oldfile=B/'combined-source-manifest-v1.json';newfile=B/'combined-source-manifest.json'
assert sha(oldfile.read_bytes())=='b9fde8eed9e47deea23806f7c71aaa1f37b5dce38a09e84c0327f201c689cfdf'
assert sha(newfile.read_bytes())=='ae735e674e109b2e57e1bd4fd3666dfec7c8d12b16d4cc3aa308aed9d3330c56'
old,new=[json.loads(f.read_text()) for f in [oldfile,newfile]]
assert {k:v for k,v in old.items() if k!='files'}=={k:v for k,v in new.items() if k!='files'}
assert old['files'].keys()==new['files'].keys()
p='tools/test_ci_timeout_budget.py'
changed=[p for p,v in old['files'].items() if v!=new['files'][p]]
assert changed==[p],changed
for path,e in new['files'].items():
 f=B/'combined-source'/path;b=f.read_bytes();mode='100755' if f.stat().st_mode&0o111 else '100644'
 assert (blob(b),sha(b),len(b),mode)==(e['sha'],e['sha256'],e['size'],e['mode']),path
b=(B/'combined-source'/p).read_bytes()
assert b==(B/'ci-preparation-fix'/p).read_bytes()
assert sha(b)=='f425766ca81e2d473a4bd416f54e8ed5fa30c0b23e5218580578c947be6f06ac'
assert len(b)==12793
assert new['files'][p]['mode']==old['files'][p]['mode']=='100644'
receipt=(B/'ci-preparation-review.md').read_text()
assert '- `tools/test_ci_timeout_budget.py`: SHA256 `'+sha(b)+'`; 12793 bytes.' in receipt
print('PASS: exact original and final manifest hashes; parent metadata and complete 1191-file path set unchanged')
print('PASS: only tools/test_ci_timeout_budget.py changed; all other 1190 manifest entries identical')
print('PASS: all 1191 current file blobs/SHA256/sizes/modes independently match final manifest')
print('PASS: timeout-test bytes/hash/size/mode match accepted sixth-file CI candidate and reviewer hash receipt')
print('No heavy tests or source mutations performed; prior composition acceptance carries forward to final manifest')
