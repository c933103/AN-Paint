from pathlib import Path
import hashlib,json,collections,xml.etree.ElementTree as E
B=Path(__file__).resolve().parents[2];C=B/'combined-source';P=Path('/workspace/shared/anpaint-commons-errors-20261017/source')
m=json.loads((B/'combined-source-manifest.json').read_text());files=m['files']
def digest(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def tree(n):return {x['path']:x for x in json.loads((B/n).read_text())['tree'] if x['type']=='blob'}
def sig(e):return (e['sha'],e['mode']) if e else None
base=tree('base-38d4-tree.json');a=tree('pr111-204374-tree.json');b=tree('concurrent-511-tree.json')
for p,e in files.items():
 data=(C/p).read_bytes();mode='100755' if (C/p).stat().st_mode&0o111 else '100644'
 assert (blob(data),digest(data),len(data),mode)==(e['sha'],e['sha256'],e['size'],e['mode']),p
expected={};overlaps=[]
for p in base.keys()|a.keys()|b.keys():
 before,left,right=[sig(t.get(p)) for t in [base,a,b]]
 if left==right:selected=left
 elif left==before:selected=right
 elif right==before:selected=left
 else:overlaps.append(p);continue
 if selected:expected[p]=selected
assert sorted(overlaps)==sorted(m['explicit_overlaps'])
assert set(files)==set(expected)|set(overlaps)
for p,e in files.items():
 if e['origin'] in ('111','114'):
  assert sig(e)==expected[p],p
  source=P if e['origin']=='111' else B/'review-511-source'
  assert (C/p).read_bytes()==(source/p).read_bytes(),p
print(f"PASS: {len(files)} file blobs/SHA256/sizes/modes; complete three-way path union and all unpatched selections; {len(overlaps)} exact declared overlaps")
resources=[p for p in a if p.startswith('Paintroid/src/main/res/') and p.endswith('.xml') and sig(a[p])!=sig(base.get(p))]
ja='Paintroid/src/main/res/values-ja/strings.xml'
for p in resources:
 if p!=ja:assert (C/p).read_bytes()==(P/p).read_bytes(),p
assert len(resources)==62
print('PASS: 61 of 62 PR111 changed resource files retained byte-for-byte; Japanese checked separately')
def values(path):
 out={}
 for e in E.parse(path).getroot():
  key=(e.tag,e.get('name'));assert key not in out,(path,key)
  out[key]=(dict(e.attrib),''.join(e.itertext()))
 return out
j111,j114,jc=[values(path/ja) for path in [P,B/'review-511-source',C]]
commons=jc.keys()-j114.keys()
assert len(commons)==9 and all(k[1].startswith('commons_') for k in commons)
assert j114.keys()<=jc.keys() and all(jc[k]==v for k,v in j114.items())
assert all(jc[k]==j111[k] for k in commons)
assert [k for k in jc.keys()|j111.keys() if jc.get(k)!=j111.get(k)]==[('string','ui_trim_in_percent')]
assert (C/ja).read_text()==(P/ja).read_text().replace('%1$sの切り詰め量（百分率）','%1$sの切り詰め量（%%）')
print('PASS: Japanese exactly nine unchanged Commons additions plus one literal-percent restoration; all remaining values unchanged')
for locale in ['pl','cs']:
 p=f'Paintroid/src/main/res/values-{locale}/strings.xml';old,new=values(B/'review-511-source'/p),values(C/p)
 assert sig(b[p])==sig(base[p]),p
 assert old.keys()<=new.keys() and all(new[k]==v for k,v in old.items())
 assert new.keys()-old.keys()==commons
 assert (C/p).read_bytes()==(P/p).read_bytes()
 print(f'PASS: {locale}: all {len(old)} current common-base/PR114 entries retained exactly; only nine PR111 Commons entries added')
known={
 'Paintroid/src/main/java/org/catrobat/paintroid/classic/VerticalText.kt':'3e886b5d845e61e267bb8e6b4ae7d4842b9fcd090819f80ce369cc7dab709dbc',
 'Paintroid/src/test/java/org/catrobat/paintroid/local/VerticalCaptionSafetyTest.kt':'94ad9068933a334867b8cfe41e5c1a3938909f56cafb4195bf730e15979ebced',
 'tools/check_translation_boundaries.py':'3c2668d4e4f08c33a2f7ba3be0717e34d54e6960dc366eb43934adff659d6f08',
 'tools/test_translation_boundaries.py':'ffab036d7f603506398a168d98dc176872f07bef88c8f94288caa83f82cc1c09'}
patches={}
for p,e in files.items():
 if e['origin'] in ('checker-root-fix','ci-preparation-fix','vertical-composition'):
  assert (C/p).read_bytes()==(B/e['origin']/p).read_bytes(),p
  patches[p]=e
for p,h in known.items():assert files[p]['sha256']==h,p
assert len(patches)==9
print('PASS: nine patch files match their separate candidates; all four previously frozen reviewer hashes match')
extras=sorted(str(p.relative_to(C)) for p in C.rglob('*') if p.is_file() and str(p.relative_to(C)) not in files)
assert all('/__pycache__/' in p and p.endswith('.pyc') for p in extras),extras
print(f'Unmanifested local files: {len(extras)} Python bytecode cache files only; excluded from source manifest')
print('Origins:',dict(collections.Counter(e['origin'] for e in files.values())))
print('Manifest SHA256:',digest((B/'combined-source-manifest.json').read_bytes()))
(B/'evidence/combined-composition-review/patch-hashes.json').write_text(json.dumps(patches,indent=2)+'\n')
