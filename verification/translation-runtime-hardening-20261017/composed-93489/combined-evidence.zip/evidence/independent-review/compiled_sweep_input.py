from pathlib import Path
import re,json,base64,collections,sys,hashlib
p=Path(sys.argv[1]);dest=Path(sys.argv[2]);dump=p.read_text();records={};idnames={}
for m in re.finditer(r'^    resource (0x[0-9a-f]+) (\S+)\n(.*?)(?=^    resource |^  type |\Z)',dump,re.M|re.S):
 name=m[2];idnames[m[1]]=name
 if not name.startswith(('string/','plurals/')):continue
 configs={}
 for c in re.finditer(r'^      \(([^\n)]*)\) (.*?)(?=^      \([^\n)]*\) |\Z)',m[3],re.M|re.S):
  body=c[2].rstrip('\n');config=c[1]
  if name.startswith('string/'):
   text=body.replace('\n      ','\n');configs[config]=text
  else:
   forms={}
   for f in re.finditer(r'^        (zero|one|two|few|many|other)=(.*?)(?=^        (?:zero|one|two|few|many|other)=|\Z)',body,re.M|re.S):
    forms[f[1]]=f[2].rstrip('\n').replace('\n        ','\n')
   assert len(forms)==int(re.search(r'size=(\d+)',body)[1]),(name,config,forms)
   configs[config]=forms
 records[name]=configs
aliases=0;alias_fallbacks=[]
def resolve(name,config='',quantity=None,seen=()):
 global aliases
 assert name not in seen,(name,seen)
 defs=records[name]
 if config not in defs:
  alias_fallbacks.append((name,config));config=''
 raw=defs[config]
 if quantity is not None:raw=raw[quantity if quantity in raw else 'other']
 if raw.startswith('@'):
  aliases+=1;target=raw[1:];target=idnames.get(target,target);return resolve(target,config,None,seen+(name,))
 assert raw.startswith('"') and raw.endswith('"'),(name,config,raw[:100])
 return raw[1:-1]
rows=[]
for name,configs in records.items():
 kind,key=name.split('/')
 if key.startswith('anpaint_source_'):continue
 for config,raw in configs.items():
  for quantity in raw if kind=='plurals' else [None]:
   source=resolve(kind+'/anpaint_source_'+key,'',quantity)
   formatted=resolve(kind+'/anpaint_source_contract_'+kind+'_'+key,'',quantity)
   assert formatted in ('true','false'),(name,formatted)
   candidate=resolve(name,config,quantity)
   rows.append(dict(key=key,kind=kind,config=config,quantity=quantity,source=source,translation=candidate,source_formatted=formatted=='true'))
dest.with_suffix('.json').write_text(json.dumps(rows,ensure_ascii=False,indent=1))
with dest.with_suffix('.tsv').open('w') as f:
 for i,r in enumerate(rows):f.write('\t'.join([str(i),base64.b64encode(r['source'].encode()).decode(),base64.b64encode(r['translation'].encode()).decode(),str(r['source_formatted']).lower()])+'\n')
summary=dict(rows=len(rows),configs=len(set(r['config'] for r in rows)),by_kind=dict(collections.Counter(r['kind'] for r in rows)),default_rows=sum(r['config']=='' for r in rows),alias_resolutions=aliases,alias_fallbacks=alias_fallbacks,dump_sha256=hashlib.sha256(p.read_bytes()).hexdigest())
dest.with_suffix('.summary.json').write_text(json.dumps(summary,indent=2));print(summary)
