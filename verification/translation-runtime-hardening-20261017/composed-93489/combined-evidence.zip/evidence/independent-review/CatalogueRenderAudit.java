import java.nio.file.*;
import java.util.*;
import java.lang.reflect.*;
import java.nio.charset.StandardCharsets;
public class CatalogueRenderAudit {
 public static void main(String[] args) throws Exception {
  Class<?> cls=Class.forName("org.catrobat.paintroid.classic.LocaleText");Object self=cls.getField("INSTANCE").get(null);
  Method parse=cls.getDeclaredMethod("tokens",String.class);parse.setAccessible(true);
  Method resolve=cls.getDeclaredMethod("resolve",String.class,String.class,boolean.class,Locale.class,Object[].class);
  int total=0, formatted=0, plain=0, mismatch=0, invalid=0, nullSamples=0, nullMismatches=0; boolean testNull=args.length>1 && args[1].equals("--null-samples");
  for(String line:Files.readAllLines(Path.of(args[0]),StandardCharsets.UTF_8)) {
   String[] r=line.split("\t",-1);String src=new String(Base64.getDecoder().decode(r[1]),StandardCharsets.UTF_8),tr=new String(Base64.getDecoder().decode(r[2]),StandardCharsets.UTF_8);
   boolean fmt=Boolean.parseBoolean(r[3]);List<?> ts=(List<?>)parse.invoke(self,src);Object[] vals=new Object[0];
   if(fmt) {
    if(ts==null) throw new AssertionError("invalid source "+r[0]);
    TreeMap<Integer,String> conversions=new TreeMap<>();
    for(Object t:ts) {Method im=t.getClass().getDeclaredMethod("getIndex"), cm=t.getClass().getDeclaredMethod("getConversion");im.setAccessible(true);cm.setAccessible(true);Integer i=(Integer)im.invoke(t);if(i!=null) conversions.put(i,(String)cm.invoke(t));}
    if(!conversions.isEmpty()) { vals=new Object[conversions.lastKey()+1];for(var e:conversions.entrySet()) {String c=e.getValue().toLowerCase(Locale.ROOT);vals[e.getKey()]=c.matches("[doxc]")?Integer.valueOf(17):c.matches("[efga]")?Double.valueOf(1.25):c.startsWith("t")?new Date(1000):"arg_"+e.getKey()+"_%q_𡨸";} }
   }
   total++;String expected;
   if(fmt && vals.length>0) {formatted++;try{expected=String.format(Locale.ROOT,tr,vals);}catch(IllegalFormatException ex){invalid++;System.out.println(r[0]+"\tINVALID_JAVA_FORMAT\t"+ex.getClass().getSimpleName());continue;}}
   else {plain++;expected=tr;}
   String actual=(String)resolve.invoke(self,tr,src,fmt,Locale.ROOT,vals);
   if(!actual.equals(expected)){mismatch++;System.out.println(r[0]+"\tRENDER_MISMATCH\t"+Base64.getEncoder().encodeToString(actual.getBytes(StandardCharsets.UTF_8)));}
   if(testNull && fmt && vals.length>0) {
    List<Object[]> samples=new ArrayList<>();samples.add(new Object[vals.length]);
    if(vals.length>1) for(int n=0;n<vals.length;n++){Object[] sample=vals.clone();sample[n]=null;samples.add(sample);}
    for(Object[] sample:samples) for(boolean forceFallback:new boolean[]{false,true}) {
     String expectedNull=String.format(Locale.ROOT,forceFallback?src:tr,sample);
     String actualNull=(String)resolve.invoke(self,forceFallback?"invalid %99$q":tr,src,fmt,Locale.ROOT,sample);
     nullSamples++;if(!expectedNull.equals(actualNull)){nullMismatches++;if(nullMismatches<=25)System.out.println(r[0]+"\tNULL_MISMATCH\tforcedFallback="+forceFallback);}
    }
   }
  }
  System.err.println("total="+total+" formatted="+formatted+" plain="+plain+" mismatches="+mismatch+" invalid_java_formats="+invalid+" null_samples="+nullSamples+" null_mismatches="+nullMismatches);
  if(mismatch!=0 || invalid!=0 || nullMismatches!=0)throw new AssertionError("Catalogue rendering comparison failed");
 }
}
