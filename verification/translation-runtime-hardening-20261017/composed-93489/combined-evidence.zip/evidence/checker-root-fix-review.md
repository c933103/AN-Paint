# Explicit source-root discovery fix: independent review

Read-only review of the local two-file correction relative to exact 511f9607. No application or remote source was edited by this reviewer. Final reviewed file hashes and actual test logs are in the adjacent checker-root-fix-review directory.

Result: the bounded discovery correction passes, with no concrete remaining finding in this delta.

The walker now keeps ancestors needed to reach explicitly configured production roots beneath build output. Root and configured paths normalize consistently, including equivalent ../ spellings. check_repository rejects configured paths resolving outside the repository. Conventional build/generated discovery remains intact; newly traversed custom-source ancestors do not expose unrelated sibling generated directories. Existing test-source exclusions are preserved.

The initial draft still omitted existing equivalent ../ paths, and could expose an unrelated generated sibling along a newly traversed ancestor. Both observations were reported and repaired before final acceptance.

Independent execution:
- All six policy tests pass.
- Ten additional CLI controls pass: direct and equivalent source roots; absolute and relative repository roots; exact rejection of the configured bad formatter; success for a literal template; continued detection in conventional build/generated; exclusion of unrelated build and test siblings; rejection of existing external and symlink-escaping configured roots.

This review covers source discovery and its regression controls. It does not certify the lexical policy checker as a type checker or universal translation-safety proof. The coordinating worker owns broader generator/policy execution, integration, final source binding and any publication. The patch remains a local proposed correction at this receipt; no remote update is implied.
