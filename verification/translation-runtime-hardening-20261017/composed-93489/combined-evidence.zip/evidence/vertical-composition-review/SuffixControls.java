import java.util.*;import java.lang.reflect.*;
public class SuffixControls {
 static Class<?> paint,dir,orientation;static Object p,mixed,lr;
 static Class<?> c(String name)throws Exception{return Class.forName("org.catrobat.paintroid.classic."+name);}
 static Object measurement(String name)throws Exception{Class<?> cl=c(name+"$MixedLineMeasurement");Constructor<?> co=cl.getDeclaredConstructor(paint);co.setAccessible(true);return co.newInstance(p);}
 static float add(Object obj,String s)throws Exception{Method a=obj.getClass().getDeclaredMethod("append",String.class),h=obj.getClass().getDeclaredMethod("height");a.setAccessible(true);h.setAccessible(true);a.invoke(obj,s);return (Float)h.invoke(obj);}
 static float bound(String s)throws Exception{Class<?> cl=c("VerticalText");Object r=cl.getMethod("bounds",String.class,paint,dir,orientation,float.class).invoke(cl.getField("INSTANCE").get(null),s,p,lr,mixed,1f);return (Float)r.getClass().getMethod("height").invoke(r);}
 public static void main(String[] args)throws Exception {
  paint=Class.forName("android.graphics.Paint");p=paint.getConstructor().newInstance();dir=c("TextDirection");orientation=c("GlyphOrientation");lr=dir.getEnumConstants()[2];mixed=orientation.getEnumConstants()[0];
  List<List<String>> fixtures=List.of(List.of("Commons\u202fᠤᠨ"," ","ᠮᠡᠳᠡᠭᠡ"),List.of("A"," ","\u202fᠤᠨ"," ","B"),List.of("A"," "," ","\u202fᠤᠨ"),List.of("漢","\u202fᠤᠨ"),List.of("ᠠ\u202fᠤᠨ"," ","B"),List.of("A\u00a0ᠤᠨ"," ","B"),List.of("A\u2007ᠤᠨ"," ","B"),List.of("A\u202fᠤᠨ"," ","C\u202fᠤᠨ","字","D\u202fᠤᠨ"),List.of("\u202fᠤᠨ"," ","A"));
  int checks=0,badSuffix=0,badPrevious=0;
  for(List<String> tokens:fixtures){Object now=measurement("VerticalText"),none=measurement("NoSuffixVerticalText"),prev=measurement("NoPreviousVerticalText");String s="";for(String token:tokens){s+=token;float expected=bound(s),actual=add(now,token),a=add(none,token),b=add(prev,token);if(expected!=actual)throw new AssertionError("incremental mismatch "+tokens+" prefix="+s+" expected="+expected+" actual="+actual);if(expected!=a)badSuffix++;if(expected!=b)badPrevious++;checks++;}}
  if(badSuffix==0 || badPrevious==0)throw new AssertionError("controls insensitive");
  int wraps=0,suffixWraps=0,previousWraps=0;Class<?> base=c("BaselineVerticalText"),now=c("VerticalText"),none=c("NoSuffixVerticalText"),prev=c("NoPreviousVerticalText");Method bm=base.getMethod("wrapLabel",String.class,paint,float.class,dir),nm=now.getMethod("wrapLabel",String.class,paint,float.class,dir),sm=none.getMethod("wrapLabel",String.class,paint,float.class,dir),pm=prev.getMethod("wrapLabel",String.class,paint,float.class,dir);
  for(List<String> ts:fixtures)for(Object d:dir.getEnumConstants())for(float h=1;h<=300;h++){String s=String.join("",ts);Object e=bm.invoke(base.getField("INSTANCE").get(null),s,p,h,d),a=nm.invoke(now.getField("INSTANCE").get(null),s,p,h,d);if(!e.equals(a))throw new AssertionError("suffix wrap mismatch "+ts+" height="+h+" direction="+d);if(!e.equals(sm.invoke(none.getField("INSTANCE").get(null),s,p,h,d)))suffixWraps++;if(!e.equals(pm.invoke(prev.getField("INSTANCE").get(null),s,p,h,d)))previousWraps++;wraps++;}
  if(suffixWraps==0 || previousWraps==0)throw new AssertionError("wrapping controls insensitive");
  System.out.println("suffix/cross-token direct measurement comparisons="+checks+"; wrapped output comparisons versus 20437482="+wraps+"; all pass under model (not native shaping)");
  System.out.println("mutant negative controls: omitted suffix measurement mismatches="+badSuffix+" wrap mismatches="+suffixWraps+"; omitted previous-token state measurement mismatches="+badPrevious+" wrap mismatches="+previousWraps+"; both detected");
 }
}
