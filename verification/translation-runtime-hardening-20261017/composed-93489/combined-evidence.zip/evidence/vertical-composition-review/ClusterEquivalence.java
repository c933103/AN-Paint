import java.lang.reflect.*;import java.util.*;
public class ClusterEquivalence {
 static List<Object> runShape(Object obj, Method method,String text,Object orientation)throws Exception {
  List<Object> output=new ArrayList<>();for(Object run:(List<?>)method.invoke(obj,text,orientation)){Method a=run.getClass().getDeclaredMethod("getText"),b=run.getClass().getDeclaredMethod("getUpright");a.setAccessible(true);b.setAccessible(true);output.add(List.of(a.invoke(run),b.invoke(run)));}return output;
 }
 public static void main(String[]args)throws Exception {
  Class<?> now=Class.forName("org.catrobat.paintroid.classic.VerticalText"),old=Class.forName("org.catrobat.paintroid.classic.BaselineVerticalText"),or=Class.forName("org.catrobat.paintroid.classic.GlyphOrientation");Object n=now.getField("INSTANCE").get(null),o=old.getField("INSTANCE").get(null);
  Method nc=now.getMethod("clusters",String.class),oc=old.getMethod("clusters",String.class),nr=now.getDeclaredMethod("runs",String.class,or),orr=old.getDeclaredMethod("runs",String.class,or);nr.setAccessible(true);orr.setAccessible(true);
  String[] alphabet={"a","V"," ","\n","\t","\u202f","\u00a0","\u2007","\u200d","\u0301","\u0903","\u20dd","\ufe0e","\ufe0f","漢","ᠠ","👩","🏽","🎨","🇲","🇳","🇯","\udb40\udc67","\udb40\udc7f","𡨸","\ud800","\udc00","\u202e","\u202c"};Random random=new Random(511);int checked=0;
  for(int test=0;test<6000;test++) {StringBuilder sb=new StringBuilder();for(int j=random.nextInt(160);j>0;j--)sb.append(alphabet[random.nextInt(alphabet.length)]);String text=sb.toString();Object a=nc.invoke(n,text),b=oc.invoke(o,text);if(!a.equals(b))throw new AssertionError("cluster mismatch "+test);if(!String.join("",(List<String>)a).equals(text))throw new AssertionError("text lost");for(Object orientation:or.getEnumConstants())if(!runShape(n,nr,text,orientation).equals(runShape(o,orr,text,orientation)))throw new AssertionError("runs mismatch "+test);checked++;}
  for(String text:List.of("a"+"\u0301".repeat(65534),"a"+"\u200da".repeat(32767),"👩🏽‍🎨".repeat(8192),"🇲🇳🇯".repeat(8192))) {List<String> c=(List<String>)nc.invoke(n,text);if(!String.join("",c).equals(text))throw new AssertionError("long text lost");checked++;}
  System.out.println("cluster/run equivalence samples=6000; orientations=3; long exact-reconstruction cases=4; pass total="+checked);
 }
}
