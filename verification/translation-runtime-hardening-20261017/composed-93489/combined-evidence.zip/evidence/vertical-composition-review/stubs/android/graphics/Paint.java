package android.graphics;public class Paint {public float spacing=19.375f;public enum Align{LEFT,CENTER,RIGHT}public float getFontSpacing(){return spacing;}}
