package android.text;public class TextPaint extends android.graphics.Paint {public TextPaint(android.graphics.Paint p){spacing=p.spacing;}}
