# Combined-source independent composition audit

Scope: local composition/hash audit only. Inputs are PR111 20437482b1d3d8ffe409f9f6ee366cb7c5abf7a7, PR114 511f9607c7889a5acd2e6f79dc96e484cb37bf5a, and common base 38d4cbef9fff10bcb758f36b1908c4b87958d3d9. No application edits, aggregate tests or external mutations were performed.

## Result

The supplied combined-source-manifest.json, SHA256 b9fde8eed9e47deea23806f7c71aaa1f37b5dce38a09e84c0327f201c689cfdf, matches all 1,191 source files by Git blob hash, SHA256, byte size and executable mode. An independently implemented three-way selection using both blob hash and mode confirms the complete path set, every unpatched selection and exactly the two declared overlaps: VerticalText.kt and Japanese strings.xml.

- PR111 Commons resources: 61 of its 62 changed resource XML files are retained byte-for-byte. Japanese is the separately checked overlap.
- Polish: all 389 existing common-base/PR114 entries are preserved exactly; only the nine PR111 Commons entries are added.
- Czech: all 364 existing common-base/PR114 entries are preserved exactly; only the nine PR111 Commons entries are added.
- Japanese: all existing PR114 values are preserved exactly and precisely nine PR111 Commons entries are added unchanged. Relative to PR111, the only modification is ui_trim_in_percent changing the prior percent word back to the literal %% form. The entire file equals the PR111 bytes after that single replacement.
- All nine patch files match their separate candidate copies byte-for-byte. The two VerticalText composition files and two checker-discovery files also match this reviewer's earlier frozen SHA256 receipts exactly.
- The five CI-preparation files match ci-preparation-fix. The original CI reviewer refreshed its receipt at 09:10 UTC and explicitly bound its acceptance to five exact hashes/sizes/modes. All five recorded hashes and sizes independently match this combined manifest. No new Gradle execution claim is added.
- The only unmanifested local files are Python bytecode caches created during host checks. They are excluded from the source manifest.

## Evidence and limits

The adjacent combined-composition-review/ directory retains audit.py, its executed audit.log, and exact patch-hashes.json. The script checks byte identity, decoded XML attributes/text, unique resource keys, all parent selections, source modes and the intentional overlap transforms. Source manifests and parent trees beside the candidate are its provenance inputs. This is a composition/preservation audit, not a linguistic re-review, native graphics run, Gradle task-graph verification or a claim that combined-head CI passed. Existing reviewed code findings and hosted gates remain in force.

## Final one-file binding: 2026-10-17 09:21 UTC

Acceptance carries forward to final combined-source-manifest.json SHA256 ae735e674e109b2e57e1bd4fd3666dfec7c8d12b16d4cc3aa308aed9d3330c56. The original manifest is retained as combined-source-manifest-v1.json and still matches its previously recorded hash.

Independent comparison confirms exactly one changed manifest entry: tools/test_ci_timeout_budget.py. All other 1,190 entries, parent metadata, declared overlaps and the complete path set are unchanged. Every current source file again matches its final Git blob, SHA256, byte size and executable mode. No application or resource file changed.

The added sixth CI patch file is byte-identical to the CI reviewer-accepted candidate: SHA256 f425766ca81e2d473a4bd416f54e8ed5fa30c0b23e5218580578c947be6f06ac, 12,793 bytes, mode100644. Its change asserts preparation6 and JVM12, preserves job22 and Python4, and preserves the old sum38 for all other steps. The reviewer receipt records rejecting mutated caps; this rebind checks the exact accepted source and does not claim to have rerun those tests.

The earlier host aggregate failures are not erased by this composition receipt. No heavy tests were rerun for this binding. The original audit.py/audit.log record the first snapshot; rebind.py/rebind.log record the one-file transition and verify all current final source hashes. Final exact-head execution gates remain separate.
