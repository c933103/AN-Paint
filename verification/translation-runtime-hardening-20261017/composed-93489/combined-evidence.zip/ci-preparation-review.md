# JVM preparation split review

Reviewed 2026-10-17 against `review-511-source`; candidate is `ci-preparation-fix`.
Scope: the five changed files `Paintroid/build.gradle`, `.github/workflows/android.yml`, `tools/ci_run_timed.sh`, `tools/test_ci_check_phases.py`, and `CI.md`.

## Result

No blocking lifecycle or producer-dependency defect found by source review. The correction is suitable for exact-source hosted verification. This is not a claim that Gradle/AGP execution or the new combined runtime has passed.

- `Paintroid/build.gradle:213-229`: Debug and release lookups are deferred through closures. Preparation follows `Test.taskDependencies`, including explicit dependencies and inferred input producers. It consumes the selected Test's complete declared input-file collection rather than only its runtime classpath or outputs. No Test-provider mapping introduces the Test itself as an input producer.
- `Paintroid/build.gradle:230-240`: A real task action ensures input resolution/fingerprinting; the output receipt is deliberately not an up-to-date output declaration, so this small action runs on each invocation. Existing producer tasks retain normal Gradle up-to-date checks. The receipt includes selected target, scheduled task paths, scheduled Test paths, direct producer paths, and resolved input-file count.
- `Paintroid/build.gradle:245-248`: The graph-ready guard rejects any scheduled Gradle Test before task execution, including a Test reached through a finalizer. Invoking preparation and Test together intentionally fails; CI invokes them separately.
- `.github/workflows/android.yml:83-98`: Preparation is required and bounded to six minutes. The actual full Test command and its twelve-minute cap are unchanged. The twenty-two-minute job cap at line 35, separate native phase, assertion configuration, and cache policy remain unchanged. Existing report uploads at lines 108-113 include the new receipt directory.
- `tools/ci_run_timed.sh:7,14-17`: Only the new phase name is added. Pipeline failures, command failures, timing output and exit status propagation remain intact. A later successful step cannot erase a failed preparation step's job result.
- `CI.md:68-76`: Accurately describes the separate preparation/execution phases, unchanged aggregate cap, absence of test execution during preparation, and receipt location.

## Executed local verification

Command: `PYTHONDONTWRITEBYTECODE=1 python3 -B -m unittest discover -s tools -p test_ci_check_phases.py -v`

Result: 10 tests passed in 0.370 seconds. This independently verifies exact debug/release command arguments, bounds/order, failure propagation, log-write failure handling, cache restrictions, upload coverage and source-mutation controls. The source-contract checks are supplementary, as their own comment correctly states; they do not execute AGP or prove the real task graph.

## Remaining hosted evidence

Run the candidate's actual preparation and full Test phases on a fresh checkout with no restored compiled outputs. Inspect the uploaded receipt to confirm the expected variant, no scheduled Test during preparation, and expected producer coverage. Require fresh complete JUnit results from actual execution, including all current Robolectric SDK-expanded identities. Check actual phase and aggregate timings; phase maxima do not guarantee that their sum fits the job cap. A receipt's input count alone is not an independent full-inventory proof.

The parent supplied exact511 artifact measurements of 12m0.48s combined JVM invocation, 9m32.14s actual Test task, and 1,099 passing cases with no failures. These supersede the older profile discussed during initial research, but are historical measurements, not proof of this corrected candidate. They were not independently re-derived in this bounded review.

Configuration caching is not enabled in the inspected repository. The graph callback and task/input access during the receipt action should not be presented as configuration-cache compatible without separate validation. Runtime work performed by Robolectric or tests remains under the actual Test phase deadline.

## Supporting Gradle 8.13 sources

- [Task dependency construction](https://raw.githubusercontent.com/gradle/gradle/v8.13.0/subprojects/core/src/main/java/org/gradle/api/internal/AbstractTask.java): constructor combines task inputs and explicit lifecycle dependencies; `getDependsOn()` exposes only the latter.
- [Declared input-file collection](https://raw.githubusercontent.com/gradle/gradle/v8.13.0/subprojects/core/src/main/java/org/gradle/api/internal/tasks/DefaultTaskInputs.java): `getFiles()` enumerates input file properties and their underlying producer collections, not task outputs.
- [JaCoCo agent file input](https://raw.githubusercontent.com/gradle/gradle/v8.13.0/platforms/jvm/jacoco/src/main/java/org/gradle/testing/jacoco/plugins/JacocoTaskExtension.java): the agent classpath is a distinct declared file input.
- [Task API](https://raw.githubusercontent.com/gradle/gradle/v8.13.0/subprojects/core-api/src/main/java/org/gradle/api/Task.java): documents complete task dependencies and configuration-cache restrictions for task-action access.

No reviewed source file or external state was changed. Only this separate local review report was created; no real Gradle/Android execution was attempted.

## Frozen composition binding: 2026-10-17 09:10 UTC

All five reviewed files in `combined-source` match `ci-preparation-fix` byte-for-byte and retain the same executable-bit state. The computed SHA256 values and byte lengths also match `combined-source-manifest.json`. This binds the source-review acceptance above to these exact files; it does not claim a complete composition review or additional execution coverage. No aggregate suite or JVM/Gradle execution was run for this recheck.

- `Paintroid/build.gradle`: SHA256 `fa0d56e443660b0b1835d7db4eb75143017815234ef3157ba1c7143cfc31b63d`; 13439 bytes.
- `.github/workflows/android.yml`: SHA256 `ffde149b566f76d0d5eb540dc723c83a5883834657e9f146b023f812a642fcf3`; 20665 bytes.
- `tools/ci_run_timed.sh`: SHA256 `2bfc6f05cd8c6265960f62d83125cbcb716b3817f8ca81da8a6eb4362b157dce`; 847 bytes.
- `tools/test_ci_check_phases.py`: SHA256 `d6c3d8fdf3dc85732c5bbe73c3ac1b250e7b4c9f01c56474382a5100725d71d8`; 11504 bytes.
- `CI.md`: SHA256 `4ee06775909a34f9854f67055658793784b0b969abb3fb7bf31f7e2d6885f55c`; 17135 bytes.

## Sixth-file timeout-contract correction: 2026-10-17 09:12 UTC

Accepted the bounded delta in `ci-preparation-fix/tools/test_ci_timeout_budget.py` against `review-511-source`. The former sum of per-step maxima (38 minutes) now excludes the independently asserted six-minute preparation allowance; the total therefore remains constrained to 44 minutes. The correction also explicitly requires the actual JVM step to stay at twelve minutes. The twenty-two-minute job cap, four-minute Python cap and prohibition on failure suppression remain checked. This is cancellation-policy arithmetic, not a claim that all phase maxima can fit the aggregate bound. No production timeout or assertion is relaxed.

Independently executed only the changed contract method and its pure parsing helpers: passed. Three in-memory negative controls changing preparation 6 to 7, actual JVM 12 to 13, and job 22 to 23 were each rejected. No aggregate suite or JVM/Gradle execution was run. The failed full-normal receipt remains valid failure evidence and is not superseded by this narrow check.

- `tools/test_ci_timeout_budget.py`: SHA256 `f425766ca81e2d473a4bd416f54e8ed5fa30c0b23e5218580578c947be6f06ac`; 12793 bytes.

This hash binds acceptance to the sixth-file candidate only. `combined-source` remains untouched and has not yet been rebound to this correction.
