from pathlib import Path
import subprocess,time,json,hashlib
B=Path(__file__).resolve().parent;R=B/'source';m=json.load(open(B/'review-snapshot-v7.json'));results=[]
assert all(hashlib.sha256((R/p).read_bytes()).hexdigest()==h for p,h in m.items())
commands=[('focused',['python3','-O','-m','unittest','test_app_instrumentation_matrix.ComposedDriverTest.test_both_clis_require_composed_reports_and_clear_all_receipts_in_optimized_modes','-v'],R/'tools'),('optimized-rerun',['python3','-O','-m','unittest','discover','-s','tools','-p','test_*.py'],R)]
for label,command,cwd in commands:
 start=time.monotonic()
 with (B/f'host-v7-{label}.log').open('w') as f:p=subprocess.run(command,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
 result=dict(label=label,command=command,exit_code=p.returncode,seconds=time.monotonic()-start,snapshot_sha256=hashlib.sha256((B/'review-snapshot-v7.json').read_bytes()).hexdigest());results.append(result);(B/'host-v7-rerun-results.json').write_text(json.dumps(results,indent=2)+'\n');print(result,flush=True)
 if p.returncode:break
assert all(hashlib.sha256((R/p).read_bytes()).hexdigest()==h for p,h in m.items())
