import java.util.*;import java.lang.reflect.*;
class WrapEquivalence {
 public static void main(String[]args)throws Exception {
  Class<?> c=Class.forName("org.catrobat.paintroid.classic.VerticalText"),b=Class.forName("org.catrobat.paintroid.classic.BaselineVerticalText"),d=Class.forName("org.catrobat.paintroid.classic.TextDirection");Class<?> paint=Class.forName("android.graphics.Paint");Object p=paint.getConstructor().newInstance(),a=c.getField("INSTANCE").get(null),o=b.getField("INSTANCE").get(null);
  Method na=c.getMethod("wrapLabel",String.class,paint,float.class,d),old=b.getMethod("wrapLabel",String.class,paint,float.class,d);
  String[] alphabet={"AV","office","To","again","^"," ","\t","\n","\u202f","\u00a0","\u2007","\u0301","\u200d","\ufe0f","漢","字","ᠵᠢᠷᠤᠭ\u202fᠤᠨ","👩🏽‍🎨","🇲","🇳","\ud800","\udc00","\udb40\udc67"};Random r=new Random(511);int n=0;
  for(int i=0;i<2500;i++){StringBuilder sb=new StringBuilder();for(int j=r.nextInt(70);j>0;j--)sb.append(alphabet[r.nextInt(alphabet.length)]);String s=sb.toString();for(Object dir:d.getEnumConstants())for(float h:new float[]{-1,1,38.75f,160,100000}){String expected=(String)old.invoke(o,s,p,h,dir),actual=(String)na.invoke(a,s,p,h,dir);if(!expected.equals(actual)){System.out.println("input codepoints="+s.codePoints().mapToObj(Integer::toHexString).toList());throw new AssertionError("difference "+i+" direction="+dir+" height="+h+" old="+expected+" new="+actual);}n++;}}
  System.out.println("model-measurement wrapping equivalence comparisons="+n+"; pass (not Android/native shaping)");
 }
}
