# Concurrent 511f9607 caption review

Read-only review of commit 511f9607c7889a5acd2e6f79dc96e484cb37bf5a. Scope: CaptionPrefixSearch.kt, RibbonWidgets.kt and VerticalText.kt, plus their new prefix/caption tests. No implementation edits, review requests or external mutations were performed. All 13 supplied changed Git blobs independently match the manifest; exact hashes and retained execution logs are adjacent.

## Result

No concrete long-text, Unicode, fitting or cache regression was found in this bounded review.

- CaptionPrefixSearch returns only candidates actually measured to fit. Up to 64 clusters it retains exhaustive longest-prefix selection. Above that bound it uses bounded probes/refinement, and intentionally does not promise the globally longest fitting prefix for nonmonotonic shaping. Its count/index arithmetic also handles Int.MAX_VALUE in the pure tests.
- The clusters/runs refactors retain the previous cluster-boundary and upright/sideways rules while replacing repeated string concatenation with completed substrings/builders.
- Incremental wrapping preserves the prior tokenization, nonbreaking-space rules, content detection, overflow rollback and whole sideways-run measurement. The completed-run sum and current sideways run correspond to the previous mixed bounds calculation.
- The tile cache includes complete text, direction, wrap height, available dimensions and laid-out status. It also compares relevant Paint text-measurement settings: platform comparison on API28+ and explicit shaping/font/locale/scale/flag fields below that. No missing dependency was identified by inspection.
- The new empty-caption result when even the ellipsis cannot fit is deliberate; the TextView's complete text/accessibility data is retained. It avoids knowingly drawing overflowing caption ink.

## Independently executed checks

1. Fresh compile of the production prefix and VerticalText classes plus the prior VerticalText implementation under a separate class name.
2. CaptionPrefixSearchTest: all four pure JUnit tests pass.
3. Production versus baseline clusters/runs: 6,000 seeded Unicode samples across all three glyph orientations match exactly. Corpus includes combining/spacing/enclosing marks, variation selectors, ZWJ, emoji modifiers/tags, regional indicators, NNBSP and other nonbreaking spaces, supplementary characters and isolated UTF-16 surrogates. Four additional long strings reconstruct exactly without text loss.
4. Production versus baseline wrapLabel: 37,500 comparisons pass under an explicit model measurement backend, across three directions and five heights, including mixed script/nonbreaking/whitespace sequences. The model includes non-additive widths. This tests wrapping state transitions and measurement composition; it is not Android shaping or native rendering evidence.

The baseline copy is mechanically renamed BaselineVerticalText and uses the current shared enum declarations; its original file hash is recorded. No application class was modified. The model backend replaces only the Android Paint/RectF/TextPaint/Layout/StaticLayout symbols in the disposable test classpath. Java helper sources and model stubs are retained beside the logs for reproducibility.

## Limits

This reviewer did not execute Robolectric native graphics, installed Android layout/ink, or the API21–27 Paint-comparison branch. The new VerticalCaptionSafetyTest exercises native SDK33 behavior, but its source inspection and these pure/model results do not establish that execution passed. Exact-head hosted results must supply their own outcome. The long-caption search explicitly trades globally maximal nonmonotonic fitting for bounded tested candidates. The refactor does not establish a universal time/heap bound for platform shaping or enormous caller-supplied text.

Generator/policy/Japanese resource changes and source provenance reconciliation are reviewed separately by the coordinating worker. This receipt does not override that review's findings or any existing linguistic/layout acceptance limits.
