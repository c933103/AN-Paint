"""Reproducible XML inventory; AAPT-decoded behavioral sweep is a separate control."""
from pathlib import Path
import xml.etree.ElementTree as ET,json,base64,collections,hashlib
B=Path(__file__).resolve().parent;R=B/'review-511-source';RES=R/'Paintroid/src/main/res'
source={x.get('name'):x for x in ET.parse(RES/'values/strings.xml').getroot() if x.tag in ('string','plurals')}
metadata={x.get('name'):x for x in ET.parse(B/'generated-source/sourceTextResources/values/source_text_contracts.xml').getroot()}
def raw(e):return ''.join(e.itertext())
def canonical(name,quantity=None,trail=()):
 assert name not in trail,(name,trail)
 e=source[name]
 if e.tag=='plurals':
  items={x.get('quantity'):x for x in e};e=items.get(quantity,items['other'])
 text=raw(e)
 if text.startswith('@string/'):return canonical(text[8:],trail=trail+(name,))
 return text
rows=[];empty=[];files=[]
for path in sorted(RES.glob('values*/strings*.xml')):
 if path.parent.name=='values':continue
 entries=[e for e in ET.parse(path).getroot() if e.tag in ('string','plurals')]
 files.append(str(path.relative_to(R)))
 if not entries:empty.append(str(path.relative_to(R)))
 local={e.get('name'):e for e in entries if e.tag=='string'}
 def translated(e,trail=()):
  text=raw(e)
  if text.startswith('@string/'):
   key=text[8:];assert key not in trail
   return translated(local[key],trail+(key,)) if key in local else canonical(key)
  return text
 for entry in entries:
  name=entry.get('name');assert name in source,(path,name)
  for item in (list(entry) if entry.tag=='plurals' else [entry]):
   quantity=item.get('quantity');m=metadata['anpaint_source_contract_'+entry.tag+'_'+name]
   if m.tag=='plurals':
    forms={x.get('quantity'):x for x in m};m=forms.get(quantity,forms['other'])
   rows.append(dict(locale=path.parent.name,key=name,quantity=quantity,source=canonical(name,quantity),translation=translated(item),source_formatted=m.text=='true',translation_formatted=entry.get('formatted'),file=str(path.relative_to(R))))
(B/'review-511-catalogue-input.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
with (B/'review-511-catalogue-input.tsv').open('w') as out:
 for i,r in enumerate(rows):out.write('\t'.join([str(i),base64.b64encode(r['source'].encode()).decode(),base64.b64encode(r['translation'].encode()).decode(),str(r['source_formatted']).lower()])+'\n')
report=dict(rows=len(rows),catalogue_files=len(files),nonempty_catalogues=len(set(x['locale'] for x in rows)),empty_catalogues=empty,source_formatted_false=sum(not x['source_formatted'] for x in rows),translation_formatted_false=sum(x['translation_formatted']=='false' for x in rows),input_sha256=hashlib.sha256((B/'review-511-catalogue-input.tsv').read_bytes()).hexdigest(),method='XML entity-decoded inventory with source/translation alias resolution and generated source-format inheritance; retains Android backslash escapes. Separate AAPT-decoded runtime sweep verifies packaged values.')
(B/'review-511-catalogue-inventory.json').write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items() if k!='empty_catalogues'})
