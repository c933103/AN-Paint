import java.util.*;
import org.catrobat.paintroid.classic.LocaleText;
public class Adversarial {
 public static void main(String[] args) {
  var templates=new ArrayList<String>();
  for (String run:List.of("0","1","-","+","#"," ","(","<","%","t",".","١"))
   for (String prefix:List.of("%","%1$","%1$."))
    for(String suffix:List.of("!","s","d","%1$s"))
     templates.add(prefix+run.repeat(65000)+suffix);
  long start=System.nanoTime();
  for(String text:templates){
   String result=LocaleText.INSTANCE.resolve(text,"Safe %1$s",true,Locale.ROOT,new Object[]{"argument"});
   if(!result.equals("Safe argument")) throw new AssertionError("unexpected result: "+result.substring(0,Math.min(result.length(),100)));
  }
  System.out.printf("%d long adversarial cases preserved complete fallback; elapsedMs=%.1f%n",templates.size(),(System.nanoTime()-start)/1e6);
 }
}
