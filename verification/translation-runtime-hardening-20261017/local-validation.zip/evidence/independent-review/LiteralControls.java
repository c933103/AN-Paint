import java.util.*;import java.lang.reflect.*;
public class LiteralControls {
 public static void main(String[] args)throws Exception {
  Class<?> cls=Class.forName("org.catrobat.paintroid.classic.LocaleText");Object b=cls.getField("INSTANCE").get(null);Method m=cls.getDeclaredMethod("resolve",String.class,String.class,boolean.class,Locale.class,Object[].class);int checked=0;
  String src="Safe %1$d percent. Keep unchanged.";Object[] vals={17};
  String[] valid={"Safe %1$d%%. Keep unchanged.","%% %1$d %n %%", "%1$d%1024%", "%1$d%-1024%", "%1$d%128$%", "%1$d%%".replace("%%","%%".repeat(127))};
  for(String tr:valid){String actual=(String)m.invoke(b,tr,src,true,Locale.ROOT,vals);String expected=String.format(Locale.ROOT,tr,vals);if(!expected.equals(actual))throw new AssertionError("valid literal mismatch "+tr);checked++;}
  String[] invalid={"%1$d%1025%","%1$d%.1%","%1$d%#%","%1$d%4n","%1$d%-n","%1$d%<%","%1$d%%".replace("%%","%%".repeat(128)),"%1$d%", "%1$d%q", "%1$d%2$d%%", "%1$s%%", "%1$04d%%", "No argument%%", "%1$d".repeat(2)+"%%"};
  String fallback=String.format(Locale.ROOT,src,vals);
  for(String tr:invalid){String actual=(String)m.invoke(b,tr,src,true,Locale.ROOT,vals);if(!fallback.equals(actual))throw new AssertionError("invalid literal accepted "+tr);checked++;}
  String reverse=(String)m.invoke(b,"Value %1$d percent", "Value %1$d%%",true,Locale.ROOT,vals);if(!reverse.equals("Value 17 percent"))throw new AssertionError("reverse literal removal failed");checked++;
  for(String tr:new String[]{"100% done","100% satisfied","%1$d%%","%1$d%#%"}) {String actual=(String)m.invoke(b,tr,src,false,Locale.ROOT,vals);if(!tr.equals(actual))throw new AssertionError("plain interpreted");checked++;}
  System.out.println("literal controls passed="+checked);
 }
}
