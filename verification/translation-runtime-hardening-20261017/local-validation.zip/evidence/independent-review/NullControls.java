import java.util.*;import java.lang.reflect.*;
public class NullControls {
 public static void main(String[] args)throws Exception {
  Class<?> cls=Class.forName("org.catrobat.paintroid.classic.LocaleText");Object b=cls.getField("INSTANCE").get(null);Method m=cls.getDeclaredMethod("resolve",String.class,String.class,boolean.class,Locale.class,Object[].class);int n=0;
  for(Locale locale:List.of(Locale.ROOT,Locale.forLanguageTag("ar"),Locale.forLanguageTag("tr")))
   for(String spec:List.of("s","S","d",",d","06X",".0f",".1f",".2f",".128f","1024s","b","B","h","H","c","C","tY","TY","e","g","a","o")){
    String src="Keep %1$"+spec+" unchanged.",tr="Translated %1$"+spec+".";
    Object[] vals={null};
    String expected=String.format(locale,tr,vals),actual=(String)m.invoke(b,tr,src,true,locale,vals);
    if(!expected.equals(actual))throw new AssertionError("present null candidate "+spec+" "+locale+" expected="+expected+" actual="+actual);n++;
    expected=String.format(locale,src,vals);actual=(String)m.invoke(b,"bad %99$q",src,true,locale,vals);
    if(!expected.equals(actual))throw new AssertionError("present null source "+spec+" "+locale);n++;
    actual=(String)m.invoke(b,tr,src,true,locale,new Object[0]);if(!"Keep ? unchanged.".equals(actual))throw new AssertionError("absent slot "+spec);n++;
   }
  for(String spec:List.of("d",",d","06X",".0f",".1f",".2f","c","tY")) {
    String src="Keep %1$"+spec+" unchanged.";String actual=(String)m.invoke(b,src,src,true,Locale.ROOT,new Object[]{"wrong type"});if(!"Keep ? unchanged.".equals(actual))throw new AssertionError("wrong type "+spec);n++;
  }
  Object[] mixed={null,7};String actual=(String)m.invoke(b,"%2$d %1$s %<s", "%1$s %1$s %2$d",true,Locale.ROOT,mixed);if(!"7 null null".equals(actual))throw new AssertionError("relative null/index contract "+actual);n++;
  System.out.println("null/absent/wrong-type controls passed="+n);
 }
}
