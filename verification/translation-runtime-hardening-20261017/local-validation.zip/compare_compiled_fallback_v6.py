from pathlib import Path
import re,json,hashlib,xml.etree.ElementTree as ET
B=Path(__file__).resolve().parent;dump=(B/'resource-check/dump.log').read_text();blocks={}
for m in re.finditer(r'^    resource (0x[0-9a-f]+) (\S+)\n(.*?)(?=^    resource |^  type |\Z)',dump,re.M|re.S):
 default=re.search(r'^      \(\) (.*?)(?=^      \([^\n]+\) |\Z)',m.group(3),re.M|re.S)
 blocks[m.group(2)]=(m.group(1), default.group(1).strip() if default else None)
source=ET.parse(B/'source/Paintroid/src/main/res/values/strings.xml').getroot();aliases={};records=[]
for e in source:
 name=e.tag+'/'+e.get('name');fallback=e.tag+'/anpaint_source_'+e.get('name')
 aliases[blocks[name][0]]=blocks[fallback][0]
for e in source:
 name=e.tag+'/'+e.get('name');fallback=e.tag+'/anpaint_source_'+e.get('name');value=blocks[name][1]
 if value is None:raise AssertionError(name)
 expected=re.sub(r'@string/([a-zA-Z0-9_]+)',lambda m:'@string/anpaint_source_'+m[1],value)
 expected=re.sub(r'@0x[0-9a-f]+',lambda m:'@'+aliases.get(m[0][1:],m[0][1:]),expected)
 assert expected==blocks[fallback][1],(name,expected,blocks[fallback][1])
 records.append({'source':name,'fallback':fallback})
metadata=ET.parse(B/'generated-source/sourceTextResources/values/source_text_contracts.xml').getroot()
for e in metadata:
 actual=blocks[e.tag+'/'+e.get('name')][1]
 if e.tag=='string':assert actual=='"'+e.text+'"',(e.get('name'),actual)
 else:
  for item in e:assert f'{item.get("quantity")}="{item.text}"' in actual
report={'compared':len(records),'metadata_compared':len(metadata),'status':'pass','method':'AAPT15 compiled default values equal fallback values with only source alias IDs rebound; compiled source-format metadata matches generated XML','dump_sha256':hashlib.sha256((B/'resource-check/dump.log').read_bytes()).hexdigest(),'source_snapshot_sha256':hashlib.sha256((B/'review-snapshot-v6.json').read_bytes()).hexdigest(),'entries':records}
(B/'resource-check/default-fallback-equivalence.json').write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items() if k!='entries'})
