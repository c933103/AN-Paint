from pathlib import Path
import subprocess,shutil,json,hashlib
B=Path(__file__).resolve().parent;R=B/'source';T=B/'resource-check';T.mkdir(exist_ok=True);res=T/'res'
shutil.copytree(R/'Paintroid/src/main/res',res,dirs_exist_ok=True)
for a,b in [('values-b+ko+Kore+KR','values-b+ko+Kore+KR+anpaint'),('values-b+qaa+Zsye+XV','values-b+en+Zsye+XV+anpaint')]:shutil.copytree(res/a,res/b,dirs_exist_ok=True)
for source in (B/'generated-source/sourceTextResources/values').glob('*.xml'):shutil.copy(source,res/'values'/source.name)
manifest=(R/'Paintroid/src/main/AndroidManifest.xml').read_text().replace('<manifest xmlns:android="http://schemas.android.com/apk/res/android">','<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="org.catrobat.paintroid">').replace('${applicationId}','org.catrobat.paintroid');(T/'AndroidManifest.xml').write_text(manifest)
A='/workspace/shared/passengercount-restart-race-20261017/investigation/sdk-tools/android-15/aapt2';sdk='/workspace/shared/passengercount-restart-race-20261017/investigation/sdk-platform/android-35/android.jar'
commands=[]
for label,args in [('compile',[A,'compile','--dir',str(res),'-o',str(T/'compiled.zip')]),('link',[A,'link','-o',str(T/'resources.apk'),'--manifest',str(T/'AndroidManifest.xml'),'-I',sdk,'--java',str(T/'symbols'),str(T/'compiled.zip')]),('dump',[A,'dump','resources',str(T/'resources.apk')])]:
 p=subprocess.run(args,text=True,capture_output=True);(T/(label+'.log')).write_text(p.stdout+p.stderr);commands.append({'label':label,'command':args,'exit':p.returncode});print(label,p.returncode,p.stderr[:1500]);
 if p.returncode:break
(T/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
