from pathlib import Path
import json,hashlib,copy,collections
P=Path(__file__).parent;I=Path('/tmp/seasia-priority-20261029/si-my-next-evidence');binding=json.loads((P/'independent-binding.json').read_text());revisions=json.loads((P/'si-replacements.json').read_text())
names={'si':'si-full-review-draft.json','my':'my-full-review-draft.json','za':'za-full-review-inventory.json'}
sources=[{'url':'https://raw.githubusercontent.com/mozilla-l10n/firefox-l10n/main/si/toolkit/toolkit/global/textActions.ftl','scope':'Sinhala Undo-related අහෝසි form and distinction of Undo/Redo; not all AN Paint wording.'},{'url':'https://raw.githubusercontent.com/GNOME/gimp/master/po/my.po','scope':'Bounded terminology including Undo/Redo and Rectangle select. Fuzzy/untranslated entries not approval; descriptive dithering judged against actual algorithm, not old ambiguous dictionary entry.'},{'url':'https://raw.githubusercontent.com/wikimedia/mediawiki/eb54d047e4304d48da2c11a00976c9d71c19b8a8/languages/i18n/za.json','scope':'Same za Latin-script software terms All/File/Edit/Help/Undo only.'},{'url':'https://zhuangwen.org/en/lexicon','scope':'Explicitly Nong Zhuang, not transferable wholesale to offered generic Latin za.'}]
limits=['Independent AI linguistic/static consumer review at medium confidence, not native-human fluency, installed layout/TalkBack, or whole-language acceptance.','SI/MY replace unrecovered prior drafts; this is not proof of original wording reproduction or fresh programme-wide unique credit.','Machine-bound windows are not an assertion that every possible dynamic caller was exhaustively found. Complete values were read; high-risk compositions and listed concrete consumers were manually reviewed.','Keep prior absent operational/composition holds. No promotion of held text from source-only metadata.','No source edits, merge, release, Work task, specialist or bulk171 archive restart performed.','Compiled Android resources, locale plural selection, aliases and actual app tests still require exact accepted-source execution.']
def rationale(r,tag):
 k=r['identity']
 if not r['direct_consumers']:return 'Complete source/target wording reviewed only; no direct consumer found. No caller/runtime or referent certification.'
 if 'memory' in k or 'budget' in k or k=='string/ui_d_d_pixels_2f_mp_exceeds_the_current':return 'Full conditional memory statement reviewed: estimated/current limit, impossible versus potentially-too-large resize, allocation stopping and unchanged source guarantees preserved where present. No storage/memory conflation.'
 if any(x in k for x in ['recovery','draft','autosave','history','undo_cache']):return 'Complete recovery/autosave/history statement reviewed against supplied consumers; preservation/failure/paused/ongoing clauses and menu routes kept distinct.'
 if any(x in k for x in ['animation','at_least_frames','gif','dither']):return 'Complete animation/dither value reviewed including count/first-frame/lower-bound clauses and actual GIF checkbox terminology; not a blanket codec claim.'
 if any(x in k for x in ['crop','trim','width','height','pixels','percent']):return 'Full size/crop value and unit/edge composition reviewed; retain quantity/number arguments and conditional attached-image movement, not a promise that every image moves.'
 if any(x in k for x in ['credit','colour','color','palette']):return 'Complete attribution/colour value reviewed in supplied editor/error/accessibility context, preserving unchanged-data or profile/conversion conditions where present.'
 return 'Complete source/current/submitted value read and compared with its actual supplied consumer role; no material meaning loss requiring a replacement identified in bounded AI/static review.'
for tag,filename in names.items():
 d=json.loads((I/filename).read_text());rows=[]
 for r in d['rows']:
  out={'identity':r['identity'],'tier':r['tier'],'source':r['source'],'current':r['current'],'submitted':r.get('proposed'),'direct_consumers':r['direct_consumers'],'confidence':'medium-AI-static','prior_hold':r['prior_hold']}
  proposed=r.get('proposed');k=r['identity'];out['decision']='accept';out['reviewed']=copy.deepcopy(proposed);out['rationale']=rationale(r,tag)
  if r['prior_hold'] or proposed is None:
   out.update(decision='hold',reviewed=None,confidence='unresolved',rationale='Preserve historical hold or absent unsupported full wording; no translation acceptance.')
  elif tag=='si' and k in revisions:
   out['decision']='revise';out['reviewed']={'attributes':dict(proposed['attributes']),'value':revisions[k]}
   if k in ('string/ui_percent_fd8671','string/ui_height_in','string/ui_width_in'):out['rationale']='Use unit stem and attached instrumental suffix only in composed descriptions: පික්සලවලින් / ප්‍රතිශතවලින්; standalone Percent/Pixel radio labels stay unchanged. All four composed outputs reviewed.'
   elif k.startswith('string/ui_trim_in_'):out['rationale']='Neutral edge-label prefix avoids forcing standalone වම/දකුණ into adjective grammar. Both units and all four edges retain full trim-amount meaning.'
   elif k=='string/ui_tolerance':out['rationale']='Actual fill slider controls allowed colour difference in ScanlineFill, not personal patience. Explicit colour-difference limit is a bounded descriptive UI label; not a claim of official terminology.'
   else:out['rationale']='Distinguish undoing an earlier edit from cancelling a current dialog. Use consistent අහෝසි wording in all six linked labels/cache/history/trim statements; keep Cancel අවලංගු unchanged and retain all other clauses.'
  if tag=='si' and k=='string/ui_quality':
   out.update(decision='revise',reviewed=copy.deepcopy(proposed),rationale='Preserve the complete translated label but restore source formatted=false for its literal percent; omitted attribute fails Android format-string policy.')
   out['reviewed']['attributes']['formatted']='false'
  if tag=='za':
   backed={'string/ui_all':('allmessages-filter-all','Sojmiz'),'string/ui_menu_file':('file-anchor-link','Vwnzgen'),'string/ui_menu_edit':('edit','"Gaij"'),'string/ui_menu_help':('help','"Bangcoh"'),'string/ui_undo':('editundo','"siu"')}
   if k in backed:
    key,raw=backed[k];assert proposed['value']==raw
    out.update(decision='accept',reviewed=copy.deepcopy(proposed),confidence='medium-source-backed-bounded',rationale='Same za Latin-script MediaWiki complete single-term value and context-equivalent software role; no safety prose or dialect-wide certification. Retained raw Android quotes are syntax, not part of displayed word.',primary_key=key)
   else:out.update(decision='hold',reviewed=None,confidence='unresolved',rationale='Preserve existing raw text or English fallback without acceptance. No independently sufficient context-equivalent full target wording; article Save, uncertain brush/cancel, and sparse labels do not license safety paragraphs.')
  rows.append(out)
 receipt={'source_commit':d['source_commit'],'locale':tag,'input_packet_sha256':binding[tag]['packet_sha256'],'resource_path':d['resource_path'],'resource_sha256':d['resource_sha256'],'reviewer':'independent CHAT Nordic lane, not author','counts':dict(collections.Counter(r['decision']for r in rows)),'rows':rows,'limits':limits,'primary_sources':sources,'mechanical_binding':binding[tag]}
 f=P/f'{tag}-complete-independent-review.json';f.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(tag,receipt['counts'],hashlib.sha256(f.read_bytes()).hexdigest())
