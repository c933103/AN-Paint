from pathlib import Path
import unittest,json,hashlib,sys
P=Path(__file__).parent;sys.path.insert(0,str(P/'source/tools'));import translation_catalogues as cat
class Receipts(unittest.TestCase):
 def test_full_rows_current_source_attributes_and_placeholders(self):
  for t in ('si','my','za'):
   d=json.loads((P/f'{t}-complete-independent-review.json').read_text());rows=d['rows'];self.assertEqual(356,len(rows));self.assertEqual(356,len({r['identity']for r in rows}))
   for r in rows:
    if r['decision']=='hold':self.assertIsNone(r['reviewed']);continue
    v=r['reviewed']['value'];src=r['source']['value'];s=next(iter(src.values()))if isinstance(src,dict)else src
    self.assertEqual(r['source']['attributes']['name'],r['reviewed']['attributes']['name'])
    for text in v.values()if isinstance(v,dict)else[v]:
     self.assertEqual(cat.placeholders(s),cat.placeholders(text),(t,r['identity']))
     self.assertFalse(cat.android_string_errors(text),(t,r['identity']))
     self.assertFalse(cat.format_string_errors(text,r['reviewed']['attributes'].get('formatted')!='false'),(t,r['identity']))
 def test_si_complete_compositions(self):
  d=json.loads((P/'si-complete-independent-review.json').read_text());vals={r['identity'].split('/')[1]:r['reviewed']['value']for r in d['rows']if r['reviewed']}
  for key,suffix in [('ui_width_in','පළල'),('ui_height_in','උස')]:
   for unit,display in [('ui_pixels_6ec9c2','පික්සලවලින්'),('ui_percent_fd8671','ප්‍රතිශතවලින්')]:self.assertEqual(display+' '+suffix,vals[key].replace('%1$s',vals[unit].strip('"')))
  self.assertEqual('ප්‍රතිශතය',vals['ui_percent']);self.assertEqual('"පික්සල"',vals['ui_pixels'])
  for key in ('ui_left','ui_right','ui_top','ui_bottom'):
   for template,unit in [('ui_trim_in_pixels','පික්සල'),('ui_trim_in_percent','ප්‍රතිශතය')]:self.assertEqual(vals[key]+': කප්පාදු ප්‍රමාණය ('+unit+')',vals[template].replace('%1$s',vals[key]))
 def test_holds_never_promoted_and_aliases_preserved(self):
  for t in ('si','my'):
   d=json.loads((P/f'{t}-complete-independent-review.json').read_text());self.assertEqual(7,sum(r['decision']=='hold'for r in d['rows']))
   for r in d['rows']:
    if r['prior_hold']:self.assertEqual('hold',r['decision'])
  d=json.loads((P/'my-complete-independent-review.json').read_text());r=next(r for r in d['rows']if r['identity']=='string/ui_save_a5d0d9');self.assertEqual('@string/ui_save',r['reviewed']['value'])
  d=json.loads((P/'za-complete-independent-review.json').read_text());self.assertEqual({'string/ui_all','string/ui_menu_file','string/ui_menu_edit','string/ui_menu_help','string/ui_undo'},{r['identity']for r in d['rows']if r['decision']=='accept'})
if __name__=='__main__':unittest.main()
