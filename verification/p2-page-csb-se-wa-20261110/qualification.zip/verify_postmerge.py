import hashlib,json,sys,zipfile
from pathlib import Path
w=Path('/workspace/shared/anpaint-419-qualification');repo=Path('/workspace/shared/anpaint-p2-europe-next-20261110');sys.path.insert(0,str(repo/'tools'))
from app_instrumentation_matrix import read_app_reports,verify_app_reports
from run_android_instrumentation import declared_tests,source_tests_sha256
meta=json.load(open(w/'final-metadata.json'));run=meta['postRun'];jobs=meta['postJobs']['jobs'];arts=meta['postArtifacts']['artifacts'];merge='a3e7dc938c21f8dd5699ed9f9f0d03ce1f41058c'
assert json.load(open(w/'prior-evidence.json'))['reused'] is False
assert run['id']==42857870244 and run['event']=='push' and run['run_attempt']==1
assert run['head_sha']==merge and run['status']=='completed' and run['conclusion']=='success'
assert len(jobs)==7 and all(j['conclusion']=='success' for j in jobs)
records={}
for short,prefix in [('composed','emulator-api-35-'),('position','emulator-position-api-35-')]:
 a=next(a for a in arts if a['name']==prefix+merge);data=(w/(short+'.zip')).read_bytes();assert len(data)==a['size_in_bytes'] and 'sha256:'+hashlib.sha256(data).hexdigest()==a['digest'];records[short]=a
 with zipfile.ZipFile(w/(short+'.zip')) as z:
  assert z.testzip() is None
  for n in z.namelist():assert not Path(n).is_absolute() and '..' not in Path(n).parts
  z.extractall(w/short)
root=w/'composed';source=repo/'app/src/androidTest';sdk=35
expected=declared_tests(source,sdk_level=sdk);suppressed=declared_tests(source)-expected;digest=source_tests_sha256(source)
result=verify_app_reports(expected,sdk,read_app_reports(root,sdk,'all'),digest,suppressed,'all')
archived=json.load(open(root/'app/coverage.json'));assert json.loads(json.dumps(result))=={k:v for k,v in archived.items() if k!='device_identity'}
selection=json.load(open(root/'artifact-selection.json'));ident=json.load(open(root/'composed-device-identity.json'));core=json.load(open(root/'device-identity.json'));pos=json.load(open(w/'position/device-identity.json'))
assert archived['device_identity']==ident
for d in [ident,core,pos]:
 assert d['commit']==merge and str(d['run_id'])==str(run['id']) and d['build_variant']=='debug' and d['device_sdk']==35 and d['source_tests_sha256']==digest
 for key in ['apk_sha256','source_sha256','test_apk_sha256']:assert d[key]==ident[key]
assert selection['run_id']==run['id'] and selection['checkout']==merge and selection['workflow_head']==merge and selection['current_attempt']==run['run_attempt'] and ident['composed_in_run_attempt']==run['run_attempt']
for group,jobname in [('core','Core emulator API 35'),('position','Position dialog API 35')]:
 s=selection['selected'][group];a=next(a for a in arts if a['id']==s['artifact_id']);j=next(j for j in jobs if j['id']==s['job_id']);assert j['name']==jobname and j['conclusion']=='success'
 assert a['name']==s['name'] and a['digest']==s['digest'] and a['created_at']==s['created_at'] and a['updated_at']==s['updated_at']
 assert a['workflow_run']['head_sha']==merge and a['workflow_run']['id']==run['id']
 assert j['started_at']==s['job_started_at'] and j['completed_at']==s['job_completed_at'] and j['started_at']<=a['created_at']<=j['completed_at']
 assert s['job_record_run_attempt']==j['run_attempt']==ident['group_run_attempts'][group]
native=json.load(open(root/'Paintroid/androidTest-results/summary.json'));assert native['success'] and native['expected_tests']==native['completed_tests'] and all(c['status']=='passed' for c in native['cases'])
native_source=repo/'Paintroid/src/androidTest';native_expected=declared_tests(native_source,sdk_level=35);assert native['source_tests_sha256']==source_tests_sha256(native_source) and {(c['classname'],c['name']) for c in native['cases']}==native_expected and len(native['cases'])==len(native_expected) and not native['errors'] and not native['missing'] and not native['unexpected']
output={'result':result,'source_tests_sha256':digest,'archive_metadata':records,'artifact_selection':selection,'composed_identity':ident,'core_identity':core,'position_identity':pos,'native_summary':{k:native[k] for k in ['success','expected_tests','completed_tests','errors','missing','unexpected']},'verification':'Downloaded composed and position ZIP digests and exact source-bound app union independently verified. Selected core/position artifact IDs/names/digests/job intervals and source/SDK/build/declared APK identities match fresh metadata. No local Android execution or separate redownload/byte check of large APK binaries.'}
(w/'independent-postmerge-verification.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'app_completed':result['completed_tests'],'app_selected':result['selected_tests'],'native_completed':native['completed_tests'],'phase_counts':result['phases'],'artifact_ids':{k:v['id'] for k,v in records.items()}},indent=2))
