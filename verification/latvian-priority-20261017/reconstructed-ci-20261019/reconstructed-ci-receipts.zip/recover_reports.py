from pathlib import Path,PurePosixPath
import json,zipfile,hashlib,xml.etree.ElementTree as ET
R=Path(__file__).resolve().parent; results=[]
for run_id,head,checkout in [(39076034363,'d72b43478c020f55faae9e358f57ff88b3254b0d','5f699f3ade3264b77b3e795d2c98fde51fbf9797'),(39078309138,'d47ae81a7dca1ab562ab0e8b276b13c24a374cee','d47ae81a7dca1ab562ab0e8b276b13c24a374cee')]:
 D=R/f'run-{run_id}'; meta=json.load(open(D/'github-metadata.json'));assert meta['run']['head_sha']==head and meta['run']['conclusion']=='success' and meta['run']['run_attempt']==1;assert len(meta['jobs'])==6 and all(j['conclusion']=='success' for j in meta['jobs'])
 inventories={};junit=[];phases=[]
 for label in ['regression','api35','exact-script']:
  digest=json.load(open(D/(label+'.download.json')));b=(D/(label+'.zip')).read_bytes();assert hashlib.sha256(b).hexdigest()==digest['sha256'];z=zipfile.ZipFile(D/(label+'.zip'));inv=[]
  for n in z.namelist():
   assert not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts
   data=z.read(n);keep=(label=='regression' and ((n.endswith('.xml') and '/test-results/' in n) or 'lint-results' in n and n.endswith(('.txt','.xml')))) or (label=='api35' and n.endswith(('.json','.xml','.log','.txt')) and n!='logcat.txt') or label=='exact-script'
   inv.append({'path':n,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'preserved_in_reconstruction':keep})
   if keep:
    p=D/'reports'/label/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
   if label=='regression' and n.endswith('.xml') and '/test-results/' in n:
    t=ET.fromstring(data);junit.append({'path':n,**t.attrib,'cases':[c.attrib for c in t.findall('testcase')]})
   if label=='api35' and n.endswith('/summary.json'):
    d=json.loads(data);assert d['success'] and d['returncode']==0 and not d['timed_out'] and not d['missing'] and not d['unexpected'] and not d['errors'] and d['expected_tests']==d['completed_tests'];phases.append({'path':n,'tests':d['completed_tests']})
  inventories[label]=inv
  if label=='api35':
   identity=json.loads(z.read('composed-device-identity.json'));assert identity['commit']==checkout and identity['run_id']==str(run_id) and identity['group_run_attempts']=={'core':1,'position':1} and identity['composed_in_run_attempt']==1
 totals={k:sum(int(x.get(k,0)) for x in junit)for k in ['tests','failures','errors','skipped']};assert totals=={'tests':1123,'failures':0,'errors':0,'skipped':0};assert len(junit)==120
 lv=next(s for s in junit if s['name']=='org.catrobat.paintroid.local.LatvianPriorityWordingTest');assert lv['tests']=='6' and all(lv[k]=='0'for k in ['failures','errors','skipped']);assert len(phases)==10 and sum(p['tests']for p in phases)==119
 result={'run_id':run_id,'head_sha':head,'checkout_commit':checkout,'tree':'ff1b183c1449a10f55d43489ef8d41541f11ff5c','successful_jobs':6,'attempt':1,'junit':{'suites':120,**totals,'latvian_methods':lv['cases']},'api35':{'tests':119,'phases':phases,'identity':identity},'large_apk_source_zip_bytes_downloaded':False,'apk_source_hashes_are_identity_record_observations':True}
 (D/'validation.json').write_text(json.dumps(result,indent=2)+'\n');(D/'artifact-inventories.json').write_text(json.dumps(inventories,indent=2)+'\n');(D/'junit-summary.json').write_text(json.dumps(junit,indent=2)+'\n');results.append(result)
(R/'recovery-validation.json').write_text(json.dumps({'recovered_on_utc':'2026-10-19','runs':results,'linguistic_review_credit_added':0,'installed_latvian_or_talkback_claim':False},indent=2)+'\n');print(json.dumps([{'run_id':r['run_id'],'junit':r['junit']['tests'],'latvian':len(r['junit']['latvian_methods']),'api35':r['api35']['tests']}for r in results]))
