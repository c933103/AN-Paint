# Terminal hosted evidence: Latvian priority review

[PR128](https://github.com/c933103/AN-Paint/pull/128), application head `d72b43478c020f55faae9e358f57ff88b3254b0d`.
[Hosted run611](https://github.com/c933103/AN-Paint/actions/runs/39076034363) completed successfully on its first attempt. All six jobs passed: regression/lint, exact-script resources, APK/corresponding source, API35 core, API35 position and API35 aggregate.

The checkout merge commit `5f699f3ade3264b77b3e795d2c98fde51fbf9797` has tree `ff1b183c1449a10f55d43489ef8d41541f11ff5c`, exactly matching the reviewed application tree. This evidence is added to the prior evidence commit; no source or prior evidence is changed.

- CI host suite: **931 passed**. Local normal and optimized final runs also passed 931 each, preserved in the original packet.
- JVM: **1,123 passed**, zero failures/errors/skips across 120 suites. All **six Latvian real-consumer tests passed**, including 21 pixels, complete picker/animation messages and Cancel, repeated dimension switching, every tool/category expansion state, and palette tap/hold without canvas changes.
- Lint: **no issues found**.
- API35: **119/119 tests across ten bounded phases**, with no missing/unexpected tests, errors or timeouts; source and SDK inventories retained. This is general CI coverage, not installed Latvian visual or TalkBack acceptance.
- Exact-script generation and universal APK/corresponding-source build passed. No release was published by this task.

[Hosted packet](hosted-run-611.zip), SHA-256 `2a0deac5f2208d5d40cfbb7065f44eec4f739bfbecc9a68caee89d457e55df97`, preserves complete job logs, all JUnit XML, lint output, the exact-script artifact, API35 text reports/logs, and source/artifact identity. [Manifest](hosted-manifest.json) hashes every enclosed file. Original Actions artifact digests and full API35 file inventory are included; screenshot binaries and large APK/source ZIPs are not duplicated, and no screenshot visual acceptance is asserted.

The initial independent report's input field called `remote_base_tree_sha` contains the base commit identifier; the correct base tree `d87d0431f5ebf2e0c01f7d4d0f716b89df7c1aea` is in the main ledger/validation. The packet includes a clarifying note without replacing the original report.

Original full linguistic evidence remains at [`d9e4d1f1198ad2641f27ddc4d21166c6561f37f1`](https://github.com/c933103/AN-Paint/blob/d9e4d1f1198ad2641f27ddc4d21166c6561f37f1/verification/latvian-priority-20261017/README.md): 341 reviewed priority pairs, 285 bounded accepted / 28 wording-only / 10 corrected / 18 uncertain unchanged; one historical priority receipt overlap and 340 without prior receipts, with no duplicate credit or PR56 updates.
