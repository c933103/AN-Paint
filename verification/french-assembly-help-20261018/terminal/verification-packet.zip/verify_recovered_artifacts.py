from pathlib import Path
import hashlib,io,json,re,sys,zipfile,xml.etree.ElementTree as ET
O=Path(__file__).resolve().parent;H=O/'hosted';E=O/'terminal-evidence';E.mkdir(exist_ok=True)
read=lambda name:json.loads((O/name).read_text())
pub=read('publication.json');head=pub['head'];tree=pub['tree'];run=read('terminal-run.json');jobs=read('terminal-jobs.json');review=read('review-gates.json');binding=read('ci-checkout-binding.json');artifacts=read('artifacts.json');leaves=read('remote-tree.json')['tree']
assert run['head_sha']==head and run['status']=='completed' and run['conclusion']=='success' and run['run_attempt']==1
assert len(jobs)==6 and all(j['status']=='completed' and j['conclusion']=='success'for j in jobs)
assert binding['source_head']==head and binding['source_tree']==tree and binding['pr_checkout_tree']==tree
assert review['code']['commit_sha']==head and review['code']['status']=='completed' and review['code']['has_any_findings']is False and review['code']['has_unresolved_findings']is False
def archive(prefix,name):
 a=next(a for a in artifacts if a['name'].startswith(prefix));p=H/name
 assert a['digest']=='sha256:'+hashlib.sha256(p.read_bytes()).hexdigest()
 assert a['workflow_run']['id']==run['id'] and a['workflow_run']['head_sha']==head
 return a,zipfile.ZipFile(p)
def write(name,data):
 (E/name).write_text(json.dumps(data,indent=2)+'\n')

# Reconstruct source only from the verified matching corresponding archive.
ba,bz=archive('apk-and-source-','apk-and-source.zip');info=json.loads(bz.read('build/delivery/build-info.json'));src=bz.read('build/delivery/AN-Paint-source.zip');apk=bz.read('app/build/outputs/apk/debug/app-debug.apk')
assert info['commit']==binding['pr_checkout'] and int(info['run_id'])==run['id']
assert hashlib.sha256(src).hexdigest()==info['source_sha256'] and hashlib.sha256(apk).hexdigest()==info['apk_sha256']
with zipfile.ZipFile(io.BytesIO(apk))as z:
 names=[n for n in z.namelist()if n.endswith('.zip')and 'source'in n.lower()];assert len(names)==1 and z.read(names[0])==src
missing=[];matched=0;W=O/'source'
with zipfile.ZipFile(io.BytesIO(src))as z:
 for e in leaves:
  assert e['type']=='blob' and not Path(e['path']).is_absolute() and '..'not in Path(e['path']).parts
  n='AN-Paint/'+e['path']
  if n not in z.namelist():missing.append(e['path']);continue
  b=z.read(n);assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==e['sha'],e['path']
  assert ('100755'if(z.getinfo(n).external_attr>>16)&0o100 else '100644')==e['mode'],e['path']
  p=W/e['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);p.chmod(int(e['mode'][-3:],8));matched+=1
assert sorted(missing)==['.gitignore','.idea/codeStyles/Project.xml','colorpicker/.gitignore'] and matched==1209
build={'source_commit':head,'pr_checkout':binding['pr_checkout'],'source_tree':tree,'artifact':ba,'build_info':info,'embedded_source_matches':True,'matched_source_files':matched,'source_metadata_omissions':missing}
write('build-binding.json',build)

ra,rz=archive('regression-','regression.zip');counts={k:0 for k in ('tests','failures','errors','skipped')};suites=[];related={}
for n in rz.namelist():
 if '/test-results/testDebugUnitTest/TEST-'not in n or not n.endswith('.xml'):continue
 r=ET.fromstring(rz.read(n));cases=r.findall('testcase');assert len(cases)==int(r.attrib['tests'])
 for k in counts:counts[k]+=int(r.attrib.get(k,0))
 assert not any(c.find(k)is not None for c in cases for k in ('failure','error','skipped')),n
 suites.append(r.attrib['name']);name=r.attrib['name'].split('.')[-1]
 if name in ('FrenchAssemblyHelpTest','AssemblyActivityTest','CropCounterpartGuidanceTest'):
  source=(W/f'Paintroid/src/test/java/org/catrobat/paintroid/local/{name}.kt').read_text();declared=set(re.findall(r'@Test(?:\s+@\w+(?:\([^)]*\))?)*\s+fun\s+(\w+)\(',source));methods={c.attrib['name']for c in cases};assert methods==declared
  related[name]={'source_methods':len(declared),'passed_methods':sorted(methods)};(E/Path(n).name).write_bytes(rz.read(n))
assert counts=={'tests':1130,'failures':0,'errors':0,'skipped':0} and len(suites)==121
assert len(related['FrenchAssemblyHelpTest']['passed_methods'])==3 and 'frenchCompleteHelpAndActualDragStatusUseImageAttachmentLanguage'in related['AssemblyActivityTest']['passed_methods']
python_log=rz.read('build/reports/ci-phases/python.log').decode();assert re.search(r'Ran 942 tests in [\d.]+s\n\nOK',python_log)
junit={'source_commit':head,'source_tree':tree,'artifact':ra,'counts':counts,'suite_count':len(suites),'source_bound_suites':related,'hosted_python_tests':942};write('junit-receipt.json',junit)

xa,xz=archive('exact-script-','exact-script.zip');exact=json.loads(xz.read(next(n for n in xz.namelist()if n.endswith('summary.json'))));assert exact['success'] and exact['tree']==tree and exact['commit']==binding['pr_checkout'] and len(exact['probes'])==9
for p in exact['probes']:
 assert p['exit_code']==0;assert hashlib.sha256(xz.read(next(n for n in xz.namelist()if n.endswith(p['name']+'.log')))).hexdigest()==p['log_sha256']
write('exact-script-summary.json',exact)

da,dz=archive('emulator-api-35-','combined.zip');R=O/'combined'
for n in dz.namelist():assert not Path(n).is_absolute()and '..'not in Path(n).parts
dz.extractall(R);sys.path.insert(0,str(W/'tools'))
from app_instrumentation_matrix import verify_app_reports,read_app_reports
from run_android_instrumentation import declared_tests,source_tests_sha256
appsource=W/'app/src/androidTest';native=W/'Paintroid/src/androidTest';selected=declared_tests(appsource,sdk_level=35)
app=verify_app_reports(selected,35,read_app_reports(R,35),source_tests_sha256(appsource),declared_tests(appsource)-selected)
assert app['success']and app['inventory_validated']and app['completed_tests']==len(selected)==45
n=json.loads((R/'Paintroid/androidTest-results/summary.json').read_text());assert n['success']and n['returncode']==0 and not n['timed_out']and not any(n[k]for k in ('missing','unexpected','errors'))and n['source_tests_sha256']==source_tests_sha256(native)
cases={(t['classname'],t['name'])for t in n['cases']};assert cases==declared_tests(native,sdk_level=35)and len(cases)==len(n['cases'])==74 and all(t['status']=='passed'for t in n['cases'])
identity=json.loads((R/'composed-device-identity.json').read_text());assert identity['commit']==info['commit']and int(identity['run_id'])==run['id']and identity['apk_sha256']==info['apk_sha256']and identity['source_sha256']==info['source_sha256']and identity['source_tests_sha256']==source_tests_sha256(appsource)and identity['device_sdk']==35 and identity['build_variant']=='debug'
device={'artifact':da,'identity':identity,'native_completed':74,'app_completed':45,'app_inventory':app,'scope':'Ordinary source-bound API35 union; no independent French installed layout/glyph/TalkBack acceptance'};write('device-receipt.json',device)
security_exact=review['security']['commit_sha']==head and review['security']['status']=='completed'and review['security']['has_any_findings']is False and review['security']['has_unresolved_findings']is False
checks={'source_commit':head,'source_tree':tree,'checkout_binding':binding,'run':run,'jobs':jobs,'review':review,'security_exact_head_clean':security_exact,'security_request_url':'https://github.com/c933103/AN-Paint/pull/133#issuecomment-6246166543','junit':junit,'build':build,'device':device,'exact_script_probes':9,'local_verification_observed_before_workspace_reset':{'focused':{'normal':22,'optimized':22},'full_host_final_source':{'normal':942,'optimized':942},'resources_mirrors_link':'passed','catalogue_structure':'passed','supplementary_changed_Kotlin_compilation':'passed','Gradle_Robolectric':'blocked by distribution download; Network is unreachable','raw_logs':'Initial local logs preserved on initial evidence ref. Final local raw logs were lost in a shared workspace reset after verification; final hosted Python/JVM logs remain and are included.'}}
write('checks.json',checks)
manifest=[]
with zipfile.ZipFile(E/'verification-packet.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9)as out:
 def add(n,b):out.writestr(n,b);manifest.append({'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 for n in ('publication.json','terminal-run.json','terminal-jobs.json','review-gates.json','ci-checkout-binding.json','artifacts.json','verify_recovered_artifacts.py'):add(n,(O/n).read_bytes())
 for n in rz.namelist():
  if ('/test-results/testDebugUnitTest/TEST-'in n and n.endswith('.xml'))or '/ci-phases/'in n:add('regression/'+n,rz.read(n))
 for n in dz.namelist():
  if n.endswith(('.json','.xml')):add('combined-device/'+n,dz.read(n))
 for n in xz.namelist():add('exact-script/'+n,xz.read(n))
 out.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(E/'verification-packet.zip')as z:
 for p in manifest:assert hashlib.sha256(z.read(p['path'])).hexdigest()==p['sha256']
print(json.dumps({'head':head,'jobs':len(jobs),'junit':counts,'suites':len(suites),'hosted_python':942,'source_files':matched,'exact_probes':9,'native':74,'app':45,'security_exact':security_exact,'packet_bytes':(E/'verification-packet.zip').stat().st_size},indent=2))
