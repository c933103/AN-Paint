from pathlib import Path
import json,subprocess,xml.etree.ElementTree as ET,sys,hashlib,stat,re
O=Path(__file__).resolve().parent;W=O/'source';sys.path.insert(0,str(W/'tools'))
from test_french_assembly_help import require_complete,HELP
base=json.loads((O/'base-tree.json').read_text());eng=json.loads((O/'english-tree-verified.json').read_text())
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
expected=(W/'Paintroid/src/test/resources/french-assembly-help/expected.txt').read_text().removesuffix('\n')
path='Paintroid/src/main/res/values-fr/strings.xml';old=subprocess.check_output(['git','show','HEAD:'+path],cwd=W).decode();before=ET.fromstring(old);after=ET.parse(W/path).getroot()
try:require_complete(before,expected)
except ValueError as e:error=str(e)
else:raise AssertionError('Actual old Help unexpectedly passed')
require_complete(after,expected)
for root in (before,after):root.find(f"./string[@name='{HELP}']").text='EXCLUDED_SINGLE_EDIT'
assert ET.tostring(before)==ET.tostring(after)
source_text=(W/path).read_text();pattern=rf'(<string name="{HELP}">)(.*?)(</string>)';om=re.search(pattern,old);nm=re.search(pattern,source_text)
assert old[:om.start(2)]+source_text[nm.start(2):nm.end(2)]+old[om.end(2):]==source_text
op=(O/'old-help.txt').read_text().removesuffix('\n').split('\n\n');np=(O/'new-help.txt').read_text().removesuffix('\n').split('\n\n')
assert len(op)==7 and len(np)==8
for oi,ni in ((0,0),(1,1),(3,4),(5,6),(6,7)):assert op[oi]==np[ni]
assert op[2].replace('La première image commence à l’origine.','Lors de l’alignement sur une cible, la première image commence à l’origine.').replace('Les chevauchements sont refusés.','Les chevauchements sont refusés lors de l’alignement sur une cible.')==np[2]
assert op[4].replace('Les images suivantes comblent l’espace ; elles restent placées.','Les autres images restent placées ; les images rattachées peuvent se déplacer pour combler l’espace libéré.').replace('Annuler/Rétablir restaure ces modifications.','Annuler et Rétablir permettent d’annuler ou de rétablir ces modifications.')==np[5]
changes=[];entries=[];base_by_path={e['path']:e for e in base['tree']if e['type']=='blob'}
paths=subprocess.check_output(['git','ls-files','-z'],cwd=W).decode().split('\0')[:-1]+subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=W).decode().split('\0')[:-1]
for path in paths:
 p=W/path;b=p.read_bytes();actual=blob(b);mode='100755' if p.stat().st_mode&stat.S_IXUSR else '100644';e=base_by_path.get(path)
 if e:assert mode==e['mode'],path
 if not e or actual!=e['sha']:changes.append({'path':path,'mode':mode,'base_sha':e['sha']if e else None,'sha':actual})
 entries.append({'path':path,'mode':mode,'type':'blob','sha':actual})
assert set(base_by_path)<=set(paths)
assert {c['path'] for c in changes}=={'Paintroid/src/main/res/values-fr/strings.xml','Paintroid/src/test/resources/french-assembly-help/expected.txt','Paintroid/src/test/java/org/catrobat/paintroid/local/FrenchAssemblyHelpTest.kt','tools/test_french_assembly_help.py','tools/test_assembly_no_resize_help_pr5.py'}
receipt={'base':base['sha'],'base_tree':'c0474eab8fccd272b90fb181d3989862044be7f0','production_scope':'Exactly one French full Help value; every other production byte retained','paragraph_scope':'Five unchanged paragraphs; four corrected sentences plus one new Exact position paragraph','existing_fixtures':'All unchanged, including German, Spanish, Italian and Portuguese Help/crop','base_blobs_verified':len(base_by_path),'candidate_blobs':len(entries),'executable_modes':'All preserved','old_value_negative_control':error,'changes':changes,'remaining':'Separate French main-editor manual guaranteed gap filling at line 465 is outside this single-entry scope'}
(O/'scope-and-negative-control.json').write_text(json.dumps(receipt,indent=2)+'\n');(O/'candidate-tree.json').write_text(json.dumps(entries,indent=2)+'\n')
bindings=[]
for name in ['AssemblyActivity.kt','AssemblyPlacementDialog.kt','ImageAssembly.kt']:
 p='Paintroid/src/main/java/org/catrobat/paintroid/classic/'+name;a=next(e['sha']for e in base['tree']if e['path']==p);b=next(e['sha']for e in eng['tree']if e['path']==p);assert a==b==blob((W/p).read_bytes());bindings.append({'path':p,'currentBlob':a,'englishReferenceBlob':b,'identical':True})
ref_blob=next(e['sha']for e in eng['tree']if e['path']=='Paintroid/src/main/res/values/strings.xml');assert ref_blob==blob((O/'source-reference-en.xml').read_bytes())
(O/'source-bindings.json').write_text(json.dumps({'base':base['sha'],'corrected_english_reference':eng['sha'],'reference_resource_blob':ref_blob,'consumers':bindings},indent=2)+'\n')
print(json.dumps(receipt,indent=2))
