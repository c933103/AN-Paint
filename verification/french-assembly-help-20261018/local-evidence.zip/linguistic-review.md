# French complete assembly Help linguistic/source review

Reviewed 18 October 2026, 05:03:59 UTC, against develop `702f0d8afa5bd5c950ec22ae14f29aecf4140482`. This is model-based read-only full-value linguistic/source review, not native-speaker certification or runtime/layout/glyph/physical-device evidence.

## Complete-value assessment

Paragraphs 1, 2, 5, 7 and 8 are preserved exactly from the existing value, accounting for displayed paragraph breaks and XML entity decoding. They retain the intended information and recognizable local control captions.

Paragraph 3 keeps the qualified “peuvent se déplacer” crop statement. Both new snapping qualifications refer to the same target-based interaction described immediately before them.

New paragraph 4 uses the verified caption “Position exacte” and established French position-dialog terminology. “Nombres entiers de pixels, à partir de zéro” conveys integer, nonnegative coordinates; “coin supérieur gauche” identifies the positioned point.

Paragraph 6 distinguishes remaining placed from remaining stationary. “Peuvent” is necessary because removing an explicitly positioned anchor preserves successors’ coordinates. The small grammatical clarification “Annuler/Rétablir restaure ces modifications” → “Annuler et Rétablir permettent d’annuler ou de rétablir ces modifications.” preserves both commands and behavior.

Existing “bac,” “fixation,” “image parente,” and “normalisation” are understandable domain terminology; no broader stylistic rewrite or control-caption change is needed.

## Approved bounded edits

- “La première image commence à l’origine.” becomes “Lors de l’alignement sur une cible, la première image commence à l’origine.”
- “Les chevauchements sont refusés.” becomes “Les chevauchements sont refusés lors de l’alignement sur une cible.”
- Add: “Sélectionnez une image et utilisez Position exacte pour définir les coordonnées X/Y de son coin supérieur gauche en nombres entiers de pixels, à partir de zéro. Les autres images conservent leur position et les chevauchements sont autorisés.”
- Replace the unconditional gap statement with “Les autres images restent placées ; les images rattachées peuvent se déplacer pour combler l’espace libéré.”
- Apply the Undo/Redo grammar correction above.

The full old/new text is retained beside this review. Literal XML paragraph escapes and the `&gt;` entity remain in the Android resource. The separate main-editor manual’s guaranteed gap-filling wording at line 465 remains outside this correction.

## Source references at reviewed base

- [Selected-position and snapping behavior](https://github.com/c933103/AN-Paint/blob/702f0d8afa5bd5c950ec22ae14f29aecf4140482/Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageAssembly.kt#L160-L231)
- [Conditional Unplace behavior](https://github.com/c933103/AN-Paint/blob/702f0d8afa5bd5c950ec22ae14f29aecf4140482/Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageAssembly.kt#L89-L121)
- [Integer validation](https://github.com/c933103/AN-Paint/blob/702f0d8afa5bd5c950ec22ae14f29aecf4140482/Paintroid/src/main/java/org/catrobat/paintroid/classic/AssemblyPlacementDialog.kt#L15-L65)
- [Tray dimensions](https://github.com/c933103/AN-Paint/blob/702f0d8afa5bd5c950ec22ae14f29aecf4140482/Paintroid/src/main/java/org/catrobat/paintroid/classic/AssemblyActivity.kt#L135-L158)
- [Output memory branches](https://github.com/c933103/AN-Paint/blob/702f0d8afa5bd5c950ec22ae14f29aecf4140482/Paintroid/src/main/java/org/catrobat/paintroid/classic/AssemblyActivity.kt#L283-L317)
- [French position captions and guidance](https://github.com/c933103/AN-Paint/blob/702f0d8afa5bd5c950ec22ae14f29aecf4140482/Paintroid/src/main/res/values-fr/strings.xml#L709-L713)

This accepts the complete corrected single entry within the described scope; it does not certify the whole French catalogue.
