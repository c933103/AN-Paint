import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormatSymbols;
import java.util.*;
import java.util.regex.*;
public class StackFormattingCheck {
  static String decode(String s) { return new String(Base64.getDecoder().decode(s), StandardCharsets.UTF_8); }
  static String decimal(int n, Locale locale) {
    char zero=DecimalFormatSymbols.getInstance(locale).getZeroDigit();
    StringBuilder b=new StringBuilder();
    for(char c:Integer.toString(n).toCharArray()) b.append(c>='0'&&c<='9' ? (char)(zero+c-'0') : c);
    return b.toString();
  }
  public static void main(String[] args) throws Exception {
    int rows=0,cases=0;
    Pattern token=Pattern.compile("%(\\d+)\\$(06X|d|s)");
    int[] ints={0,17,Integer.MAX_VALUE},hexes={0,0xA1B2C3,0xFFFFFF};
    String[] strings={"0","%2$06X","2,147,483,647"};
    for(String row:Files.readAllLines(Path.of(args[0]),StandardCharsets.UTF_8)) {
      String[] fields=row.split("\t",-1);Locale locale=Locale.forLanguageTag(fields[0]);String format=decode(fields[2]);
      for(int i=0;i<3;i++) {
        boolean isString=format.contains("%1$s");
        Object[] values=isString?new Object[]{strings[i]}:new Object[]{ints[i],hexes[i]};
        Matcher m=token.matcher(format);StringBuilder expected=new StringBuilder();
        while(m.find()) {
          String replacement=switch(m.group(2)) {
            case "s" -> strings[i];
            case "d" -> decimal(ints[i],locale);
            case "06X" -> {String h=Integer.toHexString(hexes[i]).toUpperCase(Locale.ROOT);yield "0".repeat(Math.max(0,6-h.length()))+h;}
            default -> throw new AssertionError();
          };
          m.appendReplacement(expected,Matcher.quoteReplacement(replacement));
        }
        m.appendTail(expected);
        String actual=String.format(locale,format,values);
        if(!actual.equals(expected.toString().replace("%%","%")))throw new AssertionError(fields[0]+" "+fields[1]+" case "+i);
        cases++;
      }
      rows++;
    }
    if(rows!=181||cases!=543)throw new AssertionError("Unexpected inventory: "+rows+"/"+cases);
    System.out.println(cases+" actual JDK exact-output cases passed across "+rows+" templates.");
  }
}
