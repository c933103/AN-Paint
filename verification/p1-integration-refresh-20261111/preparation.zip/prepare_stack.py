import copy, difflib, hashlib, json, pathlib, re, sys, unicodedata
import xml.etree.ElementTree as E
w=pathlib.Path(__file__).resolve().parent
root=w/'stack-dryrun'
sys.path.insert(0,str(root/'tools'))
import translation_catalogues as catalogue
tree=json.loads((w/'develop-tree.json').read_text())
leaves={x['path']:x for x in tree['tree'] if x['type']!='tree'}
source={x.get('name'):x for x in E.parse(root/'Paintroid/src/main/res/values/strings.xml').getroot()}
tiers={k:t['id'] for t in json.loads((root/'translations/string-importance.json').read_text())['tiers'] for k in t['keys']}
paths={p.relative_to(root).as_posix():tag for tag,p in catalogue.catalogue_paths().items()}
def blob(b):return hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()
def node(n):
 n=copy.deepcopy(n);n.tail=None;return E.tostring(n,encoding='unicode')
initial={};accepted={};stages=[];patches=[]
for number in (396,397,398):
 fs=json.loads((w/f'patches-{number}.json').read_text());changes={};total=0;prior_nodes=0
 for f in fs:
  p=f['filename'];assert p in paths and f['deletions']==0 and f['status']=='modified'
  lines=[x[1:] for x in f['patch'].splitlines() if x.startswith('+') and not x.startswith('+++')]
  assert len(lines)==f['additions'] and all(x.strip().startswith('<string ') and x.strip().endswith('</string>') for x in lines)
  assert not any(x.startswith('-') and not x.startswith('---') for x in f['patch'].splitlines())
  old=(root/p).read_text();initial.setdefault(p,old)
  if number==396 or p not in accepted:assert blob(old.encode())==leaves[p]['sha']
  before={n.get('name'):node(n) for n in E.fromstring(old)};nodes=[E.fromstring(x) for x in lines]
  for n in nodes:
   k=n.get('name');v=n.text
   assert k not in before and k not in accepted.setdefault(p,{})
   assert tiers['string/'+k]=='P1' and n.attrib==source[k].attrib
   assert v and unicodedata.normalize('NFC',v)==v
   assert catalogue.placeholders(v)==catalogue.placeholders(source[k].text)
   assert not catalogue.android_string_errors(v),(p,k,'escape')
   assert not catalogue.format_string_errors(v,n.get('formatted')!='false'),(p,k,'format')
   assert re.findall(r'\\n',v)==re.findall(r'\\n',source[k].text),(p,k,'newlines')
   accepted[p][k]={'xml':E.tostring(n,encoding='unicode'),'value':v,'attributes':n.attrib,'pr':number}
  addition=''.join(x+'\n' for x in lines);assert old.count('</resources>')==1
  final=old.replace('</resources>',addition+'</resources>')
  assert final.replace(addition,'',1)==old
  after={n.get('name'):node(n) for n in E.fromstring(final)}
  assert len(after)==len(before)+len(nodes) and all(after[k]==v for k,v in before.items())
  (root/p).write_text(final);changes[p]={'added':len(nodes),'prior_nodes_preserved':len(before),'blob':blob(final.encode())};total+=len(nodes);prior_nodes+=len(before)
  patches.extend(difflib.unified_diff(old.splitlines(True),final.splitlines(True),fromfile='a/'+p,tofile='b/'+p))
 assert total=={396:423,397:405,398:554}[number]
 stages.append({'pr':number,'new_entries':total,'prior_nodes_preserved':prior_nodes,'files':changes})
for p,old in initial.items():
 final=(root/p).read_text();assert len(E.fromstring(final))==len(E.fromstring(old))+len(accepted[p])
result={'base':'c3f58c6cbebbc3bc385b79143352ad87e4233d67','source_fix_head':'59a6a4a43396c1db402e705cbc3a16b39f564cae','stages':stages,'distinct_files':len(accepted),'entries':sum(len(x) for x in accepted.values()),'initial_nodes_preserved':sum(len(E.fromstring(x)) for x in initial.values()),'note':'Local integration preparation only. Original reviewed XML node values/attributes preserved exactly; not new linguistic review or merged credit.'}
(w/'stack-preparation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(w/'stack-original-accepted-nodes.json').write_text(json.dumps(accepted,ensure_ascii=False,indent=2)+'\n')
(w/'stack-additions.patch').write_text(''.join(patches))
print(json.dumps({k:v for k,v in result.items() if k!='stages'},indent=2))
