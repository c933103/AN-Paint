import copy, hashlib, io, json, pathlib, sys, zipfile, xml.etree.ElementTree as E
p=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(p/'stack-dryrun/tools'))
import translation_catalogues as catalogue
catalogues={tag:catalogue.catalogue_paths()[tag].relative_to(p/'stack-dryrun').as_posix() for tag in catalogue.offered_tags()}
assert len(catalogues)==171
accepted=json.loads((p/'stack-original-accepted-nodes.json').read_text())
tiers={t['id']:set(t['keys']) for t in json.loads((p/'stack-dryrun/translations/string-importance.json').read_text())['tiers']}
def archive(path):
 with zipfile.ZipFile(path) as z: return zipfile.ZipFile(io.BytesIO(z.read('build/delivery/AN-Paint-source.zip')))
def nodes(b):
 out={}
 for n in E.fromstring(b):
  n=copy.deepcopy(n);n.tail=None;out[n.get('name')]=E.tostring(n,encoding='unicode')
 return out
previous=archive(p/'qualification/apk-source.zip');out=[]
for pr in [396,397,398]:
 current=archive(p/f'pr{pr}/qualification/apk-source.zip'); changed=[];added=0;preserved=0
 assert set(previous.namelist())==set(current.namelist())
 for name in current.namelist():
  before=previous.read(name);after=current.read(name)
  if before==after: continue
  relative=name.removeprefix('AN-Paint/');assert relative in accepted,relative
  old=nodes(before);new=nodes(after);assert all(new[k]==v for k,v in old.items()),relative
  delta=set(new)-set(old);expected={k for k,v in accepted[relative].items() if v['pr']==pr}
  assert delta==expected,(relative,delta,expected)
  for k in delta: assert new[k]==accepted[relative][k]['xml'],(relative,k)
  changed.append(relative);added+=len(delta);preserved+=len(old)
 assert added=={396:423,397:405,398:554}[pr]
 counts={tier:{'present':0,'total':len(keys)*len(catalogues)} for tier,keys in tiers.items()}
 for path in catalogues.values():
  keys={n.tag+'/'+n.get('name') for n in E.fromstring(current.read('AN-Paint/'+path))}
  for tier,expected in tiers.items(): counts[tier]['present']+=len(keys&expected)
 for count in counts.values(): count['missing']=count['total']-count['present']
 out.append({'pr':pr,'changed_files':len(changed),'exact_original_additions':added,'predecessor_nodes_unchanged_in_changed_files':preserved,'all_other_source_archive_files_unchanged':True,'direct_source_key_counts_171_catalogues':counts})
 previous=current
result={'stages':out,'limits':'Source-bound archive comparisons and direct key presence, not new execution or linguistic/UI acceptance. No held key or existing wording was changed.'}
(p/'verified-source-stack.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
