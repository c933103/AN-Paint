from pathlib import Path
import json,hashlib,sys,unittest,xml.etree.ElementTree as E,re
P=Path(__file__).parent;R=Path('/workspace/scratch/bbca2890f602/nordic-fa-ir-ja-fr');sys.path.insert(0,str(R/'tools'));import translation_catalogues as cat
class Packets(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.d={t:json.loads((P/'packets'/f'{t}-complete-packet.json').read_text())for t in ['fa-IR','ja','fr']}
 def test_scope_and_all_current_source_bindings(self):
  inv=json.loads((P/'current-inventory-binding.json').read_text())
  for t,d in self.d.items():
   self.assertEqual(357,len(d['rows']));self.assertEqual(341,sum(r['tier']in('P0','P1')for r in d['rows']));self.assertEqual(8,sum(r['decision']=='hold'for r in d['rows']))
   digest=hashlib.sha256((R/d['catalogue_path']).read_bytes()).hexdigest();self.assertEqual(digest,d['catalogue_sha256']);self.assertEqual(digest,next(x['current_catalogue_sha256']for x in inv['rows']if x['tag']==t))
   actual={n.tag+'/'+n.get('name'):n for n in E.parse(R/d['catalogue_path']).getroot()if n.get('name')}
   for row in d['rows']:
    n=actual.get(row['identity']);v=None if n is None else{'attributes':n.attrib,'value':n.text if n.tag=='string'else{c.get('quantity'):c.text for c in n}}
    self.assertEqual(v,row['current_direct'])
 def test_every_consumer_window_still_matches_source(self):
  for d in self.d.values():
   self.assertEqual(494,sum(len(r['direct_consumers'])for r in d['rows']))
   for r in d['rows']:
    for w in r['direct_consumers']:self.assertEqual(w['text'],'\n'.join((R/w['path']).read_text().splitlines()[w['start_line']-1:w['end_line']]))
 def test_complete_candidates_keep_arguments_and_android_syntax(self):
  for t,d in self.d.items():
   for r in d['rows']:
    if r['candidate']is None:continue
    target=r['candidate']['value'];source=r['english']['value'];source=source['other']if isinstance(source,dict)else source
    for v in target.values()if isinstance(target,dict)else[target]:
     if v.startswith('@string/'):self.assertEqual('@string/ui_save',v);continue
     self.assertEqual(cat.placeholders(source),cat.placeholders(v),(t,r['identity']));self.assertEqual([],cat.android_string_errors(v),(t,r['identity']))
    if r['identity']=='plurals/ui_crop_preview_images':self.assertEqual({'other'}if t=='ja'else{'one','other'},set(target))
 def test_regional_inheritance_does_not_manufacture_direct_additions(self):
  d=self.d['fa-IR'];self.assertEqual(303,sum(r['decision']=='carry_generic_inheritance_no_direct_addition'for r in d['rows']))
  for r in d['rows']:
   if r['current_direct']is None:self.assertIsNone(r['proposed_direct'])
   if r['decision']=='carry_generic_inheritance_no_direct_addition':self.assertEqual(r['generic_fa'],r['candidate']);self.assertIsNotNone(r['prior_exact_generic_receipt'])
 def test_exact_french_four_edge_compositions(self):
  rows={r['identity'].split('/')[1]:r for r in self.d['fr']['rows']}
  for k,unit in [('ui_trim_in_pixels','pixels'),('ui_trim_in_percent','pourcentage')]:
   v=rows[k]['candidate']['value'].strip('"');self.assertEqual({'%1$s':1},cat.placeholders(v))
   for edge in ['ui_left','ui_top','ui_right','ui_bottom']:
    label=rows[edge]['effective_current']['value'];self.assertEqual(label+' : rognage en '+unit,v.replace('%1$s',label))
 def test_prior_narrow_memory_values_exact(self):
  for tag in ['ja','fr']:
   rows=[r for r in self.d[tag]['rows']if 'prior_memory_oracle'in r];self.assertEqual(2,len(rows))
   for r in rows:self.assertEqual(r['current_direct']['value'],r['prior_memory_oracle'])
 def test_quality_unit_requires_nonformatting_attribute(self):
  r=next(r for r in self.d['fa-IR']['rows']if r['identity']=='string/ui_quality');self.assertEqual('"کیفیت (%)"',r['candidate']['value']);self.assertEqual({'name':'ui_quality','formatted':'false'},r['candidate']['attributes'])
 def test_no_changes_or_held_values_silently_credit_review(self):
  self.assertEqual([5,0,2],[sum(r['decision']=='propose_direct_revision'for r in self.d[t]['rows'])for t in ['fa-IR','ja','fr']])
  for d in self.d.values():
   for r in d['rows']:
    self.assertEqual(0,r['new_linguistic_acceptance_credit'])
    if r['decision']=='hold':self.assertIsNone(r['candidate']);self.assertEqual(r['current_direct'],r['proposed_direct'])
if __name__=='__main__':unittest.main()
