# fa-IR / ja / fr — full author packet, independent review pending

Each complete-packet.json contains 341 P0/P1 values plus 16 necessary companions, full English/current/proposed typed values and attributes, individual dispositions and 494 exact source consumer windows. All complete values were read, not inferred from presence or substring matching. No new independent linguistic acceptance is claimed.

Pinned review source e366953d9a446f129af53a5f924688f22a31a912 / tree5580c53e62fe20400a2d1a9a8091b4d39b3d3845. Current merged develop ae7d25ca60f9852a9d936743a3c4a1833e9e24ba / de438227d759a2def5fc987600c3c1591f452f9f has identical three direct catalogues; the current171 inventory ea43d7e2ddc0502505f5c42631346c838e361a7b is independently bound in current-inventory-binding.json. Generic-fa successors are pending222/224, NOT merged regional acceptance. Rebind to final integration source before any application. Production worktree is unchanged.

## Dispositions and carry limits

- fa-IR: five proposed existing-direct revisions, 41 unchanged direct values reviewed, 303 generic-fa inherited full values carried, eight holds. No direct additions. Each inherited row includes its prior exact generic receipt; generic acceptance is not regional direct acceptance. Seven held keys have English effective fallback; held Main is directly present.
- ja: 349 unchanged direct full values reviewed, eight holds, no forced edits.
- fr: 347 unchanged direct full values reviewed, two proposed companion repairs, eight holds.
- Prior narrow SVG source pairs and two memory paragraphs each for ja/fr are explicitly bound per row. They retain their exact prior limits and zero duplicate credit, not whole-language acceptance. All unchanged values were also read in this author pass. This does not reset historical holds.
- Eight held identities per locale: formats22_derived_exported, ui_save_as, ui_save_as_jpeg, ui_save_as_jpeg_xl, ui_save_as_png, ui_foreground_background_colour_palette, ui_main23, ui_pinch_and_pan_mode. Preserve source unchanged, not silently promote dormant/context-limited text.

## Material proposals and actual contexts

fa-IR airbrush names actual SPRAY tool; flip vertical uses setScale(1f,-1f), not rotation; Undo restores history rather than correcting an action. Keep editing is negative dirty-document dismissal preserving document/history, and the proposal is intent clarity, not a destructive-callback bug. Quality is the1–100 slider, proposed percentage label also requires formatted=false. Complete replacements are in rows; no cosmetic Persian glyph normalization, image-name/format rewrite, or invented regional variants.

French crop uses standalone Gauche/Haut/Droite/Bas as %1$s. Neutral "%1$s : rognage en pixels" / "%1$s : rognage en pourcentage" repairs all four compositions without changing edge labels. Exactly one placeholder each. Japanese labels already suit their operations; Draw again returns to drawing rather than repeating a prior raster action. French Annuler for Undo is conventional and is not changed merely because Cancel shares it. Standalone units, composed width/height, crop margins, normalize-to-largest-current-size, error routes, unsaved changes, memory gates, SVG safety and plural outputs were considered against their actual consumers.

## Primary terminology and limits

GNOME GIMP Persian po/fa.po at620d4eef8358203a9bbb1cd99d905daead9df2d1 supplies non-fuzzy Undo→برگردان, Airbrush→رنگ‌پاش and Flip _Vertically→وارونی _عمودی:
https://github.com/GNOME/gimp/blob/620d4eef8358203a9bbb1cd99d905daead9df2d1/po/fa.po
These are terminology corroboration, not independent acceptance of every app sentence.
French crop terminology: https://docs.gimp.org/fr/gimp-layer-crop.html ; French manual https://docs.gimp.org/fr/ . Japanese tool terminology: https://docs.gimp.org/ja/ and https://docs.gimp.org/3.0/ja/gimp-tool-dynamics.html . These do not certify complete proposals or native-human fluency.

Eight packet tests pass normal and optimized, verifying complete source/inventory and consumer-window bindings, placeholders/Android syntax, plural categories, exact narrow memory values, no manufactured regional additions, all eight French edge compositions and quality formatted=false. These are static packet checks, not compiled resource/rendered RTL/runtime tests. Independent full-value/consumer review remains required. Do not apply production changes before it.
