"""Read-only source delta using 9ce31d05's explicit typed-key presence definition."""
import json,hashlib,subprocess,xml.etree.ElementTree as E
from pathlib import Path
R=Path('/workspace/scratch/bbca2890f602/nordic-fa-ir-ja-fr-current');P=Path(__file__).parent
oldpath=P.parent/'source-inventory-20261029/merged225/current171-source.json';old=json.loads(oldpath.read_text());commit='3b505f871ba6e52b6759be6d34bf7e4ec3995e46';tree='c39f602e4fe749339df44e874b32efb9026a1249'
assert subprocess.check_output(['git','-C',str(R),'hash-object',str(oldpath)],text=True).strip()=='6546eee2b34a63ed022e72cd0914d7c9618a7558';assert subprocess.check_output(['git','-C',str(R),'rev-parse',commit+'^{tree}'],text=True).strip()==tree
paths=['translations/string-importance.json','Paintroid/src/main/res/values/app_language_tags.xml','Paintroid/src/main/res/values/app_language_names.xml']+[r['catalogue_path']for r in old['rows']]
def blobs(ref):
 raw=subprocess.check_output(['git','-C',str(R),'cat-file','--batch'],input=('\n'.join(ref+':'+p for p in paths)+'\n').encode());out={};offset=0
 for path in paths:
  end=raw.index(b'\n',offset);header=raw[offset:end].decode().split();assert header[1]=='blob';size=int(header[2]);offset=end+1;out[path]=raw[offset:offset+size];offset+=size+1
 assert offset==len(raw);return out
current=blobs(commit);prior=blobs(old['source_tree']);assert current[paths[0]]==prior[paths[0]]
keys={t['id']:set(t['keys'])for t in json.loads(current[paths[0]])['tiers']if t['id']in('P0','P1')};assert {k:len(v)for k,v in keys.items()}=={'P0':92,'P1':249};assert len(old['rows'])==len({r['tag']for r in old['rows']})==171
for path,field in [(paths[1],'tag'),(paths[2],'picker_label')]:
 assert current[path]==prior[path];values=[e.text for e in E.fromstring(current[path]).find('string-array')];assert values==[r[field]for r in old['rows']]
rows=[];changed=[];key_deltas=[]
for r in old['rows']:
 path=r['catalogue_path'];data=current[path];prior_data=prior[path];assert hashlib.sha256(prior_data).hexdigest()==r['current_catalogue_sha256']
 identity=lambda b:{e.tag+'/'+e.attrib['name']for e in E.fromstring(b)if e.tag in('string','plurals')and'name'in e.attrib}
 now=identity(data);before=identity(prior_data)
 counts={t:{'present':len(ks&now),'missing':len(ks-now),'total':len(ks)}for t,ks in keys.items()};assert r['current_explicit_priority_presence']=={t:{'present':len(ks&before),'missing':len(ks-before),'total':len(ks)}for t,ks in keys.items()}
 if data!=prior_data:changed.append(r['tag'])
 if now!=before:key_deltas.append({'tag':r['tag'],'added':sorted(now-before),'removed':sorted(before-now)})
 rows.append({**{k:r[k]for k in('order','tag','picker_label','catalogue_path')},'current_catalogue_sha256':hashlib.sha256(data).hexdigest(),'current_explicit_priority_presence':counts,'current_review_acceptance_total':None})
totals={t:{'current_present':sum(r['current_explicit_priority_presence'][t]['present']for r in rows),'current_missing':sum(r['current_explicit_priority_presence'][t]['missing']for r in rows),'denominator':171*len(keys[t])}for t in keys}
assert totals==old['totals'] and not key_deltas
result={'prior_evidence_commit':'9ce31d05d0f9a101b523e254d1191df90224371d','prior_inventory_blob':'6546eee2b34a63ed022e72cd0914d7c9618a7558','prior_source_commit':old['source_commit'],'prior_source_tree':old['source_tree'],'source_commit':commit,'source_tree':tree,'definition':'Exactly prior explicit string/plurals typed-key presence intersected with unchanged P0/P1 importance sets; picker order and names byte-identical. Not linguistic acceptance or runtime fallback.','locale_count':171,'totals':totals,'presence_delta':{t:0 for t in keys},'changed_catalogue_bytes_since_prior':changed,'typed_key_deltas_since_prior':key_deltas,'rows':rows}
(P/'merged234-current171-source.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='rows'},indent=2));print('Trio:',[(r['tag'],r['current_explicit_priority_presence'])for r in rows if r['tag']in('fa-IR','ja','fr')])
