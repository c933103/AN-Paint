# Latin American Spanish (es-419): full P0+P1 linguistic review

Fresh AI linguistic review of all 341 typed priority resources: 92 P0 and 249 P1. Complete English and Latin American Spanish values were read, not sampled. All values are bound to materialized source tree `b9b148d5d8ef7c7b088500a9c177f9f59304b800`.

## Result

- 328 current scoped accepts: 299 with located static production context, 29 wording-only.
- 13 unapplied proposals: 5 P0 and 8 P1. They are not 13 equally severe bugs.
- 4 contextual grammar/meaning corrections: two tool-category gender templates, zoom wording, and the image-group pronoun Ninguna.
- 8 recommended clarity/idiom/context improvements; 1 optional capitalization change.
- 311 entries have a literal production consumer; 30 do not. One of those 30 is a wording-only proposal. No consumer reference is not proof of dead code.
- All 21 mapped prior receipts retain exact full English and localized pairs. One overlaps this batch; 20 remain outside it. Original confidence, scope, uncertainty and wording-only limits are preserved in the receipt audit.
- Current 717-entry partition: 348 current scoped/prior-bounded accepts, 13 unapplied proposals, 356 present with review unknown. Unknown is not failed or never historically reviewed.
- Only after candidate integration and exact rebinding: 361 scoped/prior-bounded entries and 356 unknown. This is not whole-language acceptance.

## Regional decisions

Retain Borrador, Configuración, Toca, mantén presionado, Agregar and simple-past status wording. Añadir, Introduce, ajustes and occasional present-perfect wording are also valid Latin American Spanish; variation from Spain is not inherently wrong, nor must every shared Spanish phrase be changed. No country-specific native-speaker certification is claimed.

## Exact proposals

### string/save20_destination_error (P0, recommended_clarity)

Current: La imagen terminada no pudo sustituir su destino.

Proposed: No se pudo reemplazar el archivo de destino con la imagen terminada.

The four codec consumers fail a temporary-file rename into a destination file. The current literal phrase treats a destination as the object replaced. Name the archivo de destino explicitly, while retaining failure rather than claiming replacement or loss. Reemplazar and the simple past are natural across Latin America.

### string/ui_d_d_pixels_2f_mp_exceeds_the_current (P0, recommended_clarity)

Current: %1$d × %2$d píxeles (%3$.2f MP) supera el límite seguro de edición actual de %4$.2f MP. AN Paint mantiene la imagen completa en memoria y reserva espacio para transformaciones y selecciones. La memoria disponible determina este límite. La operación se detuvo antes de asignar el mapa de bits sobredimensionado. No se aplicó ningún cambio de tamaño automático.

Proposed: Una imagen de %1$d × %2$d píxeles (%3$.2f MP) supera el límite seguro de edición actual de %4$.2f MP. AN Paint mantiene la imagen completa en memoria y reserva espacio para transformaciones y selecciones. La memoria disponible determina este límite. La operación se detuvo antes de asignar el mapa de bits sobredimensionado. No se aplicó ningún cambio de tamaño automático.

Give singular supera an explicit singular image subject instead of an apparent plural píxeles subject. All four numeric placeholders, memory accounting, preallocation refusal and absence of automatic resizing remain unchanged; the old wording was not evidence of a data-loss or budget-calculation defect.

### string/ui_export_explanation23 (P0, recommended_idiom)

Current: Exporta un icono, texto Base64 o arte ASCII. Exportar no cambia la imagen actual ni su destino de Guardar.

Proposed: Exporta un icono, texto Base64 o arte ASCII. La exportación no modifica la imagen actual ni su destino de guardado.

Replace the unnatural nominal phrase destino de Guardar with destino de guardado. Retain all three derived export types and the distinction between exporting and saving the current document. Do not change Latin American register or add a save-success promise.

### string/ui_higher_quality_usually_makes_a_larger_file_lossless (P0, recommended_idiom)

Current: Una calidad mayor suele producir un archivo más grande. Sin pérdida conserva todos los valores de color.

Proposed: Una calidad mayor suele producir un archivo más grande. La compresión sin pérdidas conserva todos los valores de color.

Make the compression mode the explicit subject of conserva. Suele and every colour value remain. Sin pérdida is not inherently invalid Spanish; this improves the complete explanation rather than treating the existing singular option label as an error.

### string/ui_the_image_was_saved_but_android_could_not (P0, recommended_idiom)

Current: La imagen se guardó, pero Android no pudo abrir el sistema de compartir: %1$s

Proposed: La imagen se guardó, pero Android no pudo abrir las opciones para compartir: %1$s

Opciones para compartir is idiomatic for the share chooser; sistema de compartir is clumsy. Preserve the Latin American simple past, successful save, subsequent inability to open sharing and exact diagnostic placeholder. The existing success/failure distinction was already correct.

### string/colour_truncated_metadata (P1, recommended_clarity)

Current: La imagen termina dentro de sus metadatos de color.

Proposed: El archivo de imagen está truncado en sus metadatos de color.

The consumer detects end of input while copying colour-metadata-related bytes. Make the incomplete file explicit rather than saying an image spatially ends inside metadata. Preserve the technical diagnosis without inventing a cause or recovery guarantee.

### string/ui_all (P1, recommended_context_consistency)

Current: Todo

Proposed: Todas

The only direct consumer is the image-checkbox group under Aplicar a estas imágenes. Todas explicitly refers to those feminine plural images and pairs with Ninguna. Generic Todo can mean everything, so this is contextual precision, not a reversed or nonfunctional action.

### string/ui_collapse_tool_category (P1, contextual_grammar_correction)

Current: %1$s: %2$s seleccionado. Contraer herramientas y opciones

Proposed: %1$s. Herramienta seleccionada: %2$s. Contraer herramientas y opciones

ToolCategoryButton substitutes arbitrary tool labels, including Acuarela, Línea, Elipse and Selección libre. Directly attaching masculine seleccionado produces gender disagreement. Herramienta seleccionada fixes agreement independently of the tool name, keeping both arguments and the collapse action.

### string/ui_drawing_canvas_pinch_and_move_two_fingers_to (P1, meaning_correction)

Current: Lienzo de dibujo. Pellizca y mueve dos dedos para ampliar y desplazar. El modo Navegar también permite desplazar con un dedo.

Proposed: Lienzo de dibujo. Pellizca y mueve dos dedos para hacer zoom y desplazar. El modo Navegar también permite desplazar con un dedo.

Ampliar narrows the bidirectional zoom instruction to zooming in. Hacer zoom covers enlarging and reducing, consistent with the canvas gestures and the separate Ampliar/Reducir controls. Preserve two-finger panning and one-finger Navegar panning; no TalkBack execution is claimed.

### string/ui_expand_tool_category (P1, contextual_grammar_correction)

Current: %1$s: %2$s seleccionado. Expandir herramientas y opciones

Proposed: %1$s. Herramienta seleccionada: %2$s. Expandir herramientas y opciones

The same actual tool-name substitutions as the collapse description include feminine labels. An explicit herramienta noun prevents seleccionado from disagreeing with them; both argument order and the expand action remain.

### string/ui_none (P1, contextual_grammar_correction)

Current: Ninguno

Proposed: Ninguna

The selection group names imágenes, so the pronoun referring to no selected image is feminine Ninguna, not masculine Ninguno. Only the image selection consumer was found; recheck if reused with a different referent.

### string/ui_percent (P1, optional_cosmetic)

Current: porcentaje

Proposed: Porcentaje

Capitalize the standalone unit selector to match Píxeles. Leave the separate embedded unit ui_percent_fd8671 lowercase. This is optional visual consistency, not a meaning, safety or release-blocking defect.

### string/ui_trim_expand_canvas_by_touch (P1, recommended_idiom)

Current: Recortar / ampliar lienzo con el tacto…

Proposed: Recortar / ampliar lienzo con gestos táctiles…

Con el tacto awkwardly denotes the sense of touch. Con gestos táctiles clearly describes touch input without specifying a new gesture. No literal production consumer was found, so both old and candidate assessments are wording-only and do not establish a reachable screen.

## Scope and evidence

The fresh consumer inventory contains excerpts for all located uses. Composed examples cover all 16 tool labels in both expanded/collapsed descriptions, animation frame-count composition, recovery prefixes, dimensions/units, errors and save/share states. They are static examples, not runtime tests. Nonpriority supporting strings do not receive extra key credit.

The current source has 717 translatable typed resources and three additional nontranslatable filename constants; the latter are excluded from the translation denominator. The priority batch has 341 strings and no plural resources. The remaining plural resource is outside this batch.

No source resources were edited. The complete candidate XML and unified patch are separate, unapplied artifacts. XML parsing, exact placeholder order/type/precision, literal newline counts, resource IDs/attributes and the 13-entry-only candidate delta were checked. Those structural checks do not establish linguistic quality by themselves.

Exact inspected tree: `b9b148d5d8ef7c7b088500a9c177f9f59304b800`; materialized local commit: `ddffe57016c689b2a7868c31e415dcb625f5c6b5`. The historical source commit label 4355869e is inherited from the preceding source-bound Spanish package. Later ef46e8aa/c96f9708 Fit/status changes were reported by the coordinator; their consumers were not independently re-reviewed here. Rebind this package before integration.

Original reset obligations persist. No whole-language, independent native-speaker, installed-device, rendered-layout, locale-routing or TalkBack certification. No builds, Gradle, APK, CI, runtime tests, source changes, publication or release performed.

## Package files

- per-key-review.json and per-key-review.csv: full 341-key ledger, complete values and decisions.
- findings.json: all 13 exact proposals and their severity/scope.
- candidate/Paintroid/src/main/res/values-b+es+419/strings.xml and es-419-priority-candidate.patch: unapplied candidate only.
- consumer-index.json and composed-examples.json: static evidence and complete composed examples.
- prior-receipt-audit.json: exact-pair rebinding with original receipt metadata retained.
- source-binding.json, summary.json and artifact-manifest.json: hashes, precise counts and limitations.
- priority-input.json, P0.txt and P1.txt: complete input values.
- make_review.py and finish_package.py: evidence packaging and structural-inspection scripts, not linguistic validators.
