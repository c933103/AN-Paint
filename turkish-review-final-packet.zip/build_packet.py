from pathlib import Path
import json,hashlib,xml.etree.ElementTree as ET,re,difflib,sys,collections
O=Path(__file__).resolve().parent;S=O/'source';REV='e414a4df64a56c2d8a2f374741b1f1b58fceea9b';TRACK='cc1d2718b88b9f08e25b3013ccdbc10770e7f332'
def sha(b):return hashlib.sha256(b).hexdigest()
def vh(v):return sha(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def w(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
P=json.loads((O/'pairs.json').read_text());D={int(n):(status,note) for n,status,note in [line.split('\t',2) for line in (O/'decisions.tsv').read_text().splitlines()]};assert set(D)==set(range(1,342));assert len({r['key'] for r in P})==341
C={
'ui_swap23':'Renklerin yerini değiştir',
'ui_swap_foreground_background':'Ön plan ile arka plan renklerinin yerini değiştir',
'ui_keeps_pixels_at_the_top_left_smaller_canvas':'Pikselleri sol üst köşeye hizalı olarak korur. Daha küçük tuval boyutları sağ/alt kenarın dışındaki pikselleri atar; Geri Al bunları geri getirir.',
'ui_recovery_copy_exported_extract_canvas_png_from_the':r'Kurtarma kopyası dışa aktarıldı. ZIP\'ten canvas.png dosyasını çıkarın ve Dosya > Görüntü aç ile açın. ZIP ayrıca taslak ayarlarını ve varsa yüzen seçimi içerir.',
'language20_translation_note':r'Uygulama dili\n\nÇeviriler AN Paint\'in dil kaynaklarında tutulur. Yeni veya çevrilmemiş metinler İngilizce olarak gösterilir.',
'ui_drawing_canvas_pinch_and_move_two_fingers_to':'Çizim tuvali. Yakınlaştırmak için iki parmağınızı birbirinden uzaklaştırın, uzaklaştırmak için birbirine yaklaştırın. Kaydırmak için iki parmağınızı birlikte sürükleyin. Gezinme modunda tek parmakla da kaydırabilirsiniz.',
'ui_invalid_selection_outline':'Geçersiz seçim konturu.',
'ui_the_full_image_and_working_buffers_exceed_the':'Tam görüntü ve çalışma arabellekleri geçerli güvenli sınırı aşıyor veya Android bunlar için bellek ayıramadı. Düzenlemek için bir kopyayı yeniden boyutlandırın. Özgün dosyanız değişmeden kalır.'}
assert {r['key'].split('/')[1] for r in P if D[r['n']][0]=='C'}==set(C)
trpath='Paintroid/src/main/res/values-tr/strings.xml';enpath='Paintroid/src/main/res/values/strings.xml';orig=(S/trpath).read_text();candidate=orig
from xml.sax.saxutils import escape
for k,v in C.items():
 pattern=r'(<string\b[^>]*\bname="'+re.escape(k)+r'"[^>]*>)(.*?)(</string>)'
 candidate,n=re.subn(pattern,lambda m:m[1]+escape(v)+m[3],candidate,flags=re.S);assert n==1,k
out=O/'candidate'/trpath;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(candidate)
(O/'turkish-eight-priority-corrections.patch').write_text(''.join(difflib.unified_diff(orig.splitlines(keepends=True),candidate.splitlines(keepends=True),fromfile='a/'+trpath,tofile='b/'+trpath)))
prior=json.loads((O/'prior-receipts.json').read_text());priors={r['key']:r for r in prior['receipts'] if r['tag']=='tr'}
oldlines=(S/trpath).read_text().splitlines();enlines=(S/enpath).read_text().splitlines()
def linefor(lines,name):return next(i+1 for i,l in enumerate(lines) if 'name="'+name+'"' in l)
prior_bounded={21:{'url':'https://github.com/c933103/AN-Paint/pull/86#issuecomment-6183064757','note':'Existing independently reviewed 49-locale colour-profile correction; do not claim discovery/new acceptance from this pass.'},97:{'url':'https://github.com/c933103/AN-Paint/pull/29','note':'Existing bounded source-assisted SVG-size proposal review; no native-language certification.'},98:{'url':'https://github.com/c933103/AN-Paint/pull/29','note':'Existing bounded source-assisted SVG-size proposal review; no native-language certification.'}}
entries=[]
for p in P:
 n=p['n'];name=p['key'].split('/')[1];status,note=D[n];refs=p['refs'];ctx=[]
 for ref in refs:
  f=S/ref['path'];ls=f.read_text().splitlines();i=ref['line']-1;lo=max(0,i-5);hi=min(len(ls),i+7)
  ctx.append({**ref,'source_git_blob_sha':blob(f.read_bytes()),'source_sha256':sha(f.read_bytes()),'url':f'https://github.com/c933103/AN-Paint/blob/{REV}/{ref["path"]}#L{lo+1}-L{hi}','snippet_start':lo+1,'snippet':'\n'.join(ls[lo:hi])})
 meaning='accepted_static' if status=='A' and refs else 'accepted_catalogue_semantics_only' if status=='A' else 'open_correction_proposed' if status=='C' else 'open_idiom_or_context'
 rec={**p,'source_revision':REV,'english_file':enpath,'english_line':linefor(enlines,name),'localized_file':trpath,'localized_line':linefor(oldlines,name),'english_value_sha256':vh(p['english']),'localized_value_sha256':vh(p['turkish']),'state':meaning,'linguistic_assessment':note,'meaning_confidence':'high' if status!='H' else 'unresolved','idiom_confidence':'moderate' if n in [13,27,33,79,144,160,197,249,264] else 'unresolved' if status=='H' else 'high','review_method':'AI-assisted complete source/target reading with source-bound consumer context; not native-speaker certification','consumer_context':ctx,'consumer_status':'current_production_references_found' if refs else 'no_direct_current_production_reference_found; catalogue meaning only, not live UI acceptance','layout_status':'not_run','runtime_code_safety_status':'not_certified_by_linguistic_review','prior_tracker_record':priors.get(p['key']),'prior_other_bounded_review':prior_bounded.get(n)}
 if n==64:
  old=priors[p['key']];assert old['current_english_sha256']==vh(p['english']) and old['current_localized_sha256']==vh(p['turkish']);rec['prior_receipt_hash_match']=True
 if name in C:rec['proposed_localized_value']=C[name];rec['proposed_value_sha256']=vh(C[name]);rec['candidate_state']='linguistically_proposed; independent review required before publication'
 if n==66:rec['alias_dependency']={'key':'string/ui_save','english_target':'Save','localized_target':'Kaydet','target_localized_sha256':vh('Kaydet'),'assessment':'The alias is accepted only through the checked target; no independent ellipsis defect alleged.'}
 if n in [17,173]:rec['external_sources']=[{'url':'https://lists.gnome.org/archives/commits-list/2020-January/msg05380.html','role':'GNOME official GIMP Turkish translation history attests titreme for dithering; independent terminology corroboration, not copied target prose.'}] if n==17 else [{'url':'https://support.google.com/pixelcamera/answer/14106982?hl=tr','role':'Google Turkish touch guidance confirms spreading fingers zooms in and bringing them together zooms out; semantics corroborate source span ratio.'}]
 entries.append(rec)
counts=dict(collections.Counter(r['state'] for r in entries));report={'schema_version':1,'language':'tr','language_name':'Turkish','source_revision':REV,'tracker_revision_observed':TRACK,'source_tree':json.loads((O/'develop-tree.json').read_text())['sha'],'scope':{'P0':92,'P1':249,'total':341,'canonical_total':717,'newly_missing':0},'counts':counts,'prior_evidence_policy':'Preserve one exact PR56 prior receipt and three other known bounded reviewed values. No aggregate acceptance credit is minted or tracker changed. This packet freshly assesses one Turkish priority batch; earlier PR7 whole-language claims remain withdrawn.','limits':['No whole-language approval.','No native-speaker certification.','No Android/device/layout execution.','30 keys have no direct current production reference; 27 receive catalogue-meaning-only acceptance, two retain context holds and one has an open wording proposal.','Corrections are local proposals pending independent scope/source/linguistic review.','P2/P3 entries and other languages are outside this review.','No runtime hardening credit from unmerged PR114.'],'external_sources':[{'url':'https://support.google.com/pixelcamera/answer/14106982?hl=tr','accessed':'2026-10-17','support':'Turkish zoom-in/out gesture directions.'},{'url':'https://lists.gnome.org/archives/commits-list/2020-January/msg05380.html','accessed':'2026-10-17','support':'GIMP Turkish titreme terminology for dithering.'}],'entries':entries}
w(O/'turkish-p0-p1-341-review.json',report);w(O/'turkish-corrections-and-open-items.json',{'source_revision':REV,'corrections':[r for r in entries if r['state']=='open_correction_proposed'],'uncertainties':[r for r in entries if r['state']=='open_idiom_or_context'],'outside_scope_followup':[{'key':'string/ui_pinch_to_zoom_drag_to_pan','tier':'P3','value':'Yakınlaştırmak için sıkıştırın. Kaydırmak için sürükleyin.','finding':'The same zoom-in squeeze wording occurs in optional Navigate guidance. Left unchanged because this review is P0+P1; a separately reviewed P3 companion decision would prevent contradictory instructions.'}]} )
w(O/'compact-ledger.json',[{k:r[k] for k in ['n','tier','key','english','turkish','english_value_sha256','localized_value_sha256','state','linguistic_assessment']} for r in entries]);print(json.dumps(counts));print('corrections',len(C))
