from pathlib import Path
import json,hashlib,re,difflib,xml.etree.ElementTree as ET
from xml.sax.saxutils import escape
O=Path(__file__).resolve().parent;S=O/'source';REV='e414a4df64a56c2d8a2f374741b1f1b58fceea9b';p='Paintroid/src/main/res/values-tr/strings.xml';baseline=(S/p).read_text();priority=(O/'candidate'/p).read_text()
def vh(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def patch(name,a,b): (O/name).write_text(''.join(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='a/'+p,tofile='b/'+p)))
def replace(s,k,v):
 s,n=re.subn(r'(<string\b[^>]*\bname="'+k+r'"[^>]*>)(.*?)(</string>)',lambda m:m[1]+escape(v)+m[3],s,flags=re.S)
 if n!=1:raise ValueError(k)
 return s
key='ui_pinch_to_zoom_drag_to_pan';new='Yakınlaştırmak için iki parmağınızı birbirinden uzaklaştırın; uzaklaştırmak için birbirine yaklaştırın. Kaydırmak için sürükleyin.'
def rm(file):return {e.get('name'):''.join(e.itertext()) for e in ET.parse(file).getroot()}
en=rm(S/'Paintroid/src/main/res/values/strings.xml');tr=rm(S/p)
consumer='Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt';gesture='Paintroid/src/main/java/org/catrobat/paintroid/classic/PaintCanvas.kt'
contexts=[]
for f,lo,hi in [(consumer,757,763),(gesture,651,660),(gesture,732,742)]:
 b=(S/f).read_bytes();contexts.append({'path':f,'source_git_blob_sha':blob(b),'line_start':lo,'line_end':hi,'snippet':'\n'.join(b.decode().splitlines()[lo-1:hi]),'url':f'https://github.com/c933103/AN-Paint/blob/{REV}/{f}#L{lo}-L{hi}'})
record={'schema_version':1,'source_revision':REV,'language':'tr','key':'string/'+key,'tier':'P3','included_in_341_denominator':False,'english':en[key],'turkish':tr[key],'english_value_sha256':vh(en[key]),'localized_value_sha256':vh(tr[key]),'proposed_localized_value':new,'proposed_value_sha256':vh(new),'state':'open_correction_proposed','linguistic_assessment':'The current instruction explicitly says squeeze to zoom in, but the actual gesture increases zoom when the distance between two fingers increases. Explicit spreading/closing fixes both directions and retains the separate drag-to-pan action in Navigate mode. No gesture code is changed.','consumer_context':contexts,'external_source':'https://support.google.com/pixelcamera/answer/14106982?hl=tr','limits':['Independent review required before publication.','P3 remains P3; not added to the 341-key denominator.','No device/layout/native-speaker certification.']}
(O/'p3-navigate-companion-review.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');patch('turkish-one-p3-companion.patch',baseline,replace(baseline,key,new));combined=replace(priority,key,new)
out=O/'combined-candidate'/p;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(combined);patch('turkish-nine-combined-corrections.patch',baseline,combined)
swaps={k:v for k,v in rm(O/'candidate'/p).items() if k in ['ui_swap23','ui_swap_foreground_background']};swaponly=baseline
for k,v in swaps.items():swaponly=replace(swaponly,k,v)
patch('turkish-two-swap-proposals.patch',baseline,swaponly)
r=json.loads((O/'turkish-corrections-and-open-items.json').read_text());r['outside_scope_followup']=[record];(O/'turkish-corrections-and-open-items.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
six=baseline
for row in json.loads((O/'turkish-p0-p1-341-review.json').read_text())['entries']:
 if row['state']=='open_correction_proposed' and row['key'].split('/')[1] not in swaps:six=replace(six,row['key'].split('/')[1],row['proposed_localized_value'])
patch('turkish-six-corrections.patch',baseline,six)
print('8 priority + 1 separately authorized P3 companion = 9 proposed values')
