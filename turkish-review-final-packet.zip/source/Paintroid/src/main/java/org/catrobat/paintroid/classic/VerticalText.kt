/* AN Paint contributors, 2026. GNU AGPL-3.0-or-later. */
package org.catrobat.paintroid.classic

import android.content.Context
import android.graphics.*
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.max

enum class TextDirection { HORIZONTAL, VERTICAL_RL, VERTICAL_LR }
enum class GlyphOrientation { MIXED, SIDEWAYS, UPRIGHT }

/** Shared shaping and measurements for inserted text, previews and vertical UI labels. */
internal object VerticalText {
    /** Direction depends on script, so every language written in Mong shares shaping. */
    fun uiDirection(locale: Locale=Locale.getDefault()): TextDirection = when {
        locale.script=="Mong" -> TextDirection.VERTICAL_LR
        locale.language=="lzh" -> TextDirection.VERTICAL_RL
        // The private resource alias keeps emoji columns right-to-left while
        // supplying English grammar. Ordinary en-XV remains left-to-right.
        locale.toLanguageTag()=="en-Zsye-XV-anpaint" -> TextDirection.VERTICAL_RL
        locale.language=="en" && locale.country=="XV" -> TextDirection.VERTICAL_LR
        locale.language=="qaa" && locale.script=="Zsye" && locale.country=="XV" -> TextDirection.VERTICAL_RL
        else -> TextDirection.HORIZONTAL
    }
    // Rendering follows the locale of its resource context. Android can reset
    // the process default during configuration dispatch after our activity's
    // override has already been applied; that must not turn existing UI sideways.
    @Suppress("DEPRECATION")
    fun uiLocale(context: Context): Locale {
        val configuration=context.resources.configuration
        return if(Build.VERSION.SDK_INT>=24) configuration.locales[0] else configuration.locale
    }
    fun uiDirection(context: Context): TextDirection = uiDirection(uiLocale(context))
    fun uiVertical(context: Context)=uiDirection(context)!=TextDirection.HORIZONTAL
    fun uiVertical()=uiDirection()!=TextDirection.HORIZONTAL
    fun uiTypeface(context: Context,locale: Locale=uiLocale(context)): Typeface? = LocaleTypography.typeface(context,locale)
    /** Preserve surrogate pairs, combining marks, variation selectors and emoji sequences. */
    fun clusters(text: String): List<String> {
        val result=mutableListOf<String>();var i=0;var previous=-1;var regionalCount=0
        while(i<text.length) {
            val cp=Character.codePointAt(text,i);val count=Character.charCount(cp);val part=text.substring(i,i+count)
            val type=Character.getType(cp)
            val regional=cp in 0x1f1e6..0x1f1ff
            val attach=result.isNotEmpty() && (previous==0x200d || cp==0x200d || cp in 0xfe00..0xfe0f || cp in 0xe0100..0xe01ef ||
                // UAX #29 classifies emoji tags as Extend despite their FORMAT category.
                cp in 0xe0020..0xe007f || cp in 0x1f3fb..0x1f3ff || type==Character.NON_SPACING_MARK.toInt() || type==Character.COMBINING_SPACING_MARK.toInt() ||
                type==Character.ENCLOSING_MARK.toInt() || regional && regionalCount%2==1)
            if(attach) result[result.lastIndex]+=part else result.add(part)
            regionalCount=if(regional) regionalCount+1 else 0;previous=cp;i+=count
        }
        return result
    }
    private fun upright(text: String): Boolean {
        val cp=Character.codePointAt(text,0)
        // BMP emoji, emoji presentation selectors and keycaps also stay upright;
        // checking only the supplementary emoji blocks rotates many test controls.
        if(text.indexOf('\ufe0f')>=0 || text.indexOf('\u20e3')>=0) return true
        return cp in 0x2600..0x27bf || cp in 0x231a..0x231b || cp in 0x23e9..0x23fa ||
            cp in 0x25aa..0x25ab || cp in 0x25fb..0x25fe || cp==0x25b6 || cp==0x25c0 ||
            cp==0x2b50 || cp==0x2b55 || cp in 0x2b1b..0x2b1c || cp in 0x2e80..0xa4cf || cp in 0xac00..0xd7ff || cp in 0xf900..0xfaff || cp in 0xfe10..0xfe4f ||
            cp in 0xff01..0xff60 || cp in 0x1f000..0x1ffff || cp in 0x20000..0x3ffff
    }
    private val punctuation=mapOf('、' to '︑','。' to '︒','「' to '﹁','」' to '﹂','『' to '﹃','』' to '﹄','（' to '︵','）' to '︶','【' to '︻','】' to '︼','…' to '︙')
    private data class Run(val text: String,val upright: Boolean)
    private fun runs(line: String,orientation: GlyphOrientation): List<Run> {
        val result=mutableListOf<Run>();val sideways=StringBuilder()
        fun flush() {if(sideways.isNotEmpty()) {result.add(Run(sideways.toString(),false));sideways.setLength(0)}}
        val parts=clusters(line)
        fun mongolian(cluster: String): Boolean {
            val cp=Character.codePointAt(cluster,0)
            return cp in 0x1800..0x18af && Character.isLetter(cp)
        }
        for((index,cluster) in parts.withIndex()) {
            val up=orientation==GlyphOrientation.UPRIGHT || orientation==GlyphOrientation.MIXED && upright(cluster)
            // Android assigns a Common-script NNBSP after Latin (e.g. Commons)
            // to that preceding script run. Noto's suffix substitution then
            // cannot see the Mongolian letter and draws its diagnostic N box.
            // Start this shaping run with the *unchanged* NNBSP and suffix so
            // it inherits Mongolian script. This is not a word/column break.
            val suffixBoundary=cluster=="\u202f" && index>0 && index+1<parts.size &&
                !mongolian(parts[index-1]) && mongolian(parts[index+1])
            if(up) {flush();result.add(Run(cluster,true))}
            else {if(suffixBoundary) flush();sideways.append(cluster)}
        }
        flush()
        return result
    }
    @Suppress("DEPRECATION")
    private fun layout(text: String,paint: Paint): StaticLayout {
        val p=TextPaint(paint)
        return StaticLayout(text,p,ceil(max(1f,Layout.getDesiredWidth(text,p))).toInt()+2,Layout.Alignment.ALIGN_NORMAL,1f,0f,false)
    }
    fun bounds(text: String,paint: Paint,direction: TextDirection,orientation: GlyphOrientation,spacing: Float): RectF {
        val lines=text.split('\n');val cell=paint.fontSpacing;val step=cell*spacing
        if(direction==TextDirection.HORIZONTAL) return RectF(0f,0f,lines.maxOf {layout(it,paint).width}.toFloat(),(lines.size-1)*step+cell)
        val heights=lines.map {line->runs(line,orientation).sumOf {if(it.upright) cell.toDouble() else layout(it.text,paint).width.toDouble()}.toFloat()}
        return RectF(0f,0f,(lines.size-1)*step+cell,heights.maxOrNull()?.coerceAtLeast(cell) ?: cell)
    }
    fun draw(canvas: Canvas,text: String,paint: Paint,direction: TextDirection,orientation: GlyphOrientation,
        spacing: Float=1f,alignment: Paint.Align=Paint.Align.LEFT) {
        val lines=text.split('\n');val cell=paint.fontSpacing;val step=cell*spacing
        val bounds=bounds(text,paint,direction,orientation,spacing)
        fun offset(length: Float,full: Float)=when(alignment) {Paint.Align.CENTER->(full-length)/2;Paint.Align.RIGHT->full-length;else->0f}
        if(direction==TextDirection.HORIZONTAL) {
            lines.forEachIndexed {i,line->val shaped=layout(line,paint);canvas.save();canvas.translate(offset(shaped.width.toFloat(),bounds.width()),i*step);shaped.draw(canvas);canvas.restore()}
            return
        }
        lines.forEachIndexed {i,line->
            val column=if(direction==TextDirection.VERTICAL_LR) i*step else bounds.width()-cell-i*step
            val runs=runs(line,orientation)
            val length=runs.sumOf {if(it.upright) cell.toDouble() else layout(it.text,paint).width.toDouble()}.toFloat()
            var y=offset(length,bounds.height())
            for(run in runs) {
                val shaped=layout(if(run.upright && run.text.length==1) punctuation[run.text[0]]?.toString() ?: run.text else run.text,paint)
                canvas.save()
                if(run.upright) {canvas.translate(column+(cell-shaped.width)/2,y+(cell-shaped.height)/2);shaped.draw(canvas);y+=cell}
                else {canvas.translate(column+(cell+shaped.height)/2,y);canvas.rotate(90f);shaped.draw(canvas);y+=shaped.width}
                canvas.restore()
            }
        }
    }
    /** Wrap at CJK cluster or word boundaries, never inside a joined Mongolian word. */
    fun wrapLabel(text: String,paint: Paint,height: Float,direction: TextDirection=uiDirection()): String {
        if(direction==TextDirection.HORIZONTAL) return text
        fun noBreak(char: Char)=char=='\u202f' || char=='\u00a0' || char=='\u2007'
        fun breakableSpace(char: Char)=char.isWhitespace() && !noBreak(char)
        val columns=mutableListOf<String>()
        text.split('\n').forEach {paragraph ->
            val tokens=mutableListOf<String>();var word=""
            fun flush() {if(word.isNotEmpty()) {tokens.add(word);word=""}}
            clusters(paragraph).forEach {cluster ->
                when {
                    // Kotlin considers nonbreaking spaces blank. Keep them in
                    // the word: Mongolian NNBSP also selects suffix glyph forms.
                    // Glue upright neighbors too, without changing their draw orientation.
                    cluster.length==1 && noBreak(cluster[0])->{
                        if(word.isEmpty() && tokens.lastOrNull()?.all {breakableSpace(it)}==false)
                            word=tokens.removeAt(tokens.lastIndex)
                        word+=cluster
                    }
                    upright(cluster)->{
                        if(word.lastOrNull()?.let {noBreak(it)}==true) {word+=cluster;flush()}
                        else {flush();tokens.add(cluster)}
                    }
                    cluster.isBlank()->{flush();tokens.add(" ")}
                    else->word+=cluster}
            };flush()
            var line=""
            tokens.forEach {token ->
                val candidate=line+token
                if(line.any {!breakableSpace(it)} && bounds(candidate,paint,direction,GlyphOrientation.MIXED,1f).height()>height) {
                    columns.add(line.trim {breakableSpace(it)});line=token.trimStart {breakableSpace(it)}
                } else line=candidate
            }
            columns.add(line.trim {breakableSpace(it)})
        }
        return columns.joinToString("\n")
    }
}
