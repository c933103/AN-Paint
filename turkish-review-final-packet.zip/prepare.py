from pathlib import Path
import json,hashlib,xml.etree.ElementTree as E,re
O=Path(__file__).resolve().parent;S=O/'source';T=json.loads((O/'develop-tree.json').read_text());tm={x['path']:x for x in T['tree']};roots=[S]+[Path('/workspace/shared')/x for x in ['anpaint-runtime-hardening-20261017/combined-source','anpaint-runtime-hardening-20261017/review-511-source','anpaint-runtime-hardening-20261017/source','anpaint-pl-cs-integration-20261017/source-current','anpaint-next-language-integration-20261017/source','anpaint-commons-errors-20261017/source']]
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
missing=[]
for rel,r in tm.items():
 if r['type']!='blob' or not (rel.endswith(('.kt','.java','.xml','.html','.js')) and '/main/' in rel and '/res/values' not in rel and '/res/drawable' not in rel or rel in ['CI.md','tools/translation_catalogues.py','tools/current_localization_contracts.py','translations/STRING_IMPORTANCE.md']):continue
 for root in roots:
  p=root/rel
  if p.exists() and blob(p.read_bytes())==r['sha']:
   out=S/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(p.read_bytes());break
 else:missing.append(rel)
print('missing',missing)
prior=Path('/workspace/shared/czech-review-20261017/prior-receipts-full.json').read_bytes();assert blob(prior)=='004a38a070bc4ea215a82fdd41028aac5e341f3b';(O/'prior-receipts.json').write_bytes(prior)
m=[]
for p in sorted(S.rglob('*')):
 if p.is_file():
  rel=str(p.relative_to(S));b=p.read_bytes();assert blob(b)==tm[rel]['sha'],rel;m.append({'path':rel,'git_blob_sha':blob(b),'sha256':hashlib.sha256(b).hexdigest()})
(O/'input-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
EN={e.get('name'):''.join(e.itertext()) for e in E.parse(S/'Paintroid/src/main/res/values/strings.xml').getroot()};TR={e.get('name'):''.join(e.itertext()) for e in E.parse(S/'Paintroid/src/main/res/values-tr/strings.xml').getroot()};pri=json.loads((S/'translations/string-importance.json').read_text());pairs=[]
files={str(p.relative_to(S)):p.read_text().splitlines() for p in S.rglob('*') if p.suffix in ('.kt','.java','.xml','.html','.js') and '/res/values' not in str(p)};context={}
for tier in pri['tiers'][:2]:
 for key in tier['keys']:
  name=key.split('/')[1];refs=[]
  for f,lines in files.items():
   for i,l in enumerate(lines):
    if re.search(r'R\.string\.'+re.escape(name)+r'\b',l):
     refs.append({'path':f,'line':i+1});context.setdefault(f,[]).append((i,name))
  pairs.append({'n':len(pairs)+1,'tier':tier['id'],'key':key,'english':EN[name],'turkish':TR.get(name),'refs':refs})
(O/'pairs.json').write_text(json.dumps(pairs,ensure_ascii=False,indent=2)+'\n');(O/'pairs.txt').write_text('\n\n'.join(f"{r['n']} {r['tier']} {r['key']}\nEN: {r['english']}\nTR: {r['turkish']}\nCALLS: "+', '.join(Path(x['path']).name+':'+str(x['line']) for x in r['refs']) for r in pairs)+'\n')
print('pairs',len(pairs),'source files',len(m),'without direct consumers',[r['key'] for r in pairs if not r['refs']]);
for f,locs in context.items():
 seen=set();out=[]
 for i,name in locs:
  rg=range(max(0,i-5),min(len(files[f]),i+7));chunk=[f'{j+1}: {files[f][j]}' for j in rg if j not in seen];seen.update(rg)
  if chunk:out.append('\n'.join(chunk))
 p=O/'context'/Path(f).name;p.parent.mkdir(exist_ok=True);p.write_text('\n\n'.join(out)+'\n')
