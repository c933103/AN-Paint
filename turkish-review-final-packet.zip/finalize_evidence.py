from pathlib import Path
import json,hashlib,zipfile,xml.etree.ElementTree as ET,subprocess,sys
O=Path(__file__).resolve().parent;W=O/'worktree';REV='e414a4df64a56c2d8a2f374741b1f1b58fceea9b';HEAD='5a43d2a6a90fc578319914537b7ea55e46c75070'
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def valuehash(s):return sha(json.dumps(s,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def write(name,obj):(O/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
records=json.loads((O/'turkish-corrections-and-open-items.json').read_text())['corrections'];comp=json.loads((O/'p3-navigate-companion-review.json').read_text())
fixture=json.loads((W/'tools/fixtures/current_localization/turkish_priority_current_wording.json').read_text())
def strings(p):return {n.get('name'):''.join(n.itertext()) for n in ET.parse(p).getroot() if n.tag=='string'}
old=strings(O/'source/Paintroid/src/main/res/values-tr/strings.xml');priorities=json.loads((W/'translations/string-importance.json').read_text());tiers={k:t['id'] for t in priorities['tiers'] for k in t['keys']}
adopt=[]
for k,v in fixture['values'].items():
 legacy=k=='ui_swap_foreground_background'
 adopt.append({'key':'string/'+k,'tier':tiers['string/'+k],'in_341_priority_denominator':tiers['string/'+k] in ('P0','P1'),'english':v['default'],'before_turkish':old[k],'candidate_turkish':v['tr'],'english_value_sha256':valuehash(v['default']),'before_value_sha256':valuehash(old[k]),'candidate_value_sha256':valuehash(v['tr']),'assessment':'independently reviewed complete candidate meaning against source; catalogue semantics only, no current direct consumer' if legacy else 'independently reviewed complete candidate meaning against current source consumer','method':'AI-assisted linguistic review with independent complete-value/source review; not native-speaker certification','runtime_and_layout':'not_run; neither source assertions nor successful compilation establish device fit or behavior'})
write('candidate-adoption-review.json',{'source_revision':REV,'candidate_commit':HEAD,'candidate_tree':'3c91d75c7be084077787564d68e72d58a2699ec9','priority_denominator':341,'priority_corrections':8,'outside_denominator_P3_companions':1,'records':adopt,'four_holds':['string/ui_fg','string/ui_bg','string/ui_main23','string/ui_foreground_background_colour_palette'],'prior_credits':'Unchanged prior sampled-resize memory receipt and previously bounded colour-profile/SVG reviews retained. No new aggregate tracker credit asserted.','initial_review_ledger_policy':'Original341 per-entry ledger assesses baseline values and retains its eight open correction proposals. This adoption record separately records accepted proposed candidate meanings without rewriting baseline history.'})
write('independent-candidate-check.json',{'source_revision':REV,'candidate_commit':HEAD,'result':'no material finding in bounded source/text/test review','checks':['All1178 baseline blobs/modes compared; one changed resource and two new regression files only.','Exactly nine text-only replacements; all717 resource identities/order/attributes/other values retained.','Turkish ui_swap23 formatted=false retained.','Focused14 tests pass normally and optimized independently.','All nine old values rejected; patch forward/reverse checks passed.','Four holds and previous sampled-memory value unchanged; P3 companion excluded341.'],'limits':['Source-string assertions do not execute Kotlin or independently establish Undo, archive contents, unchanged originals, gesture runtime or layout.','No native-speaker certification.']})
aapt=O/'aapt/final-worktree-tr.zip';aaptexe=Path('/workspace/shared/an96-resource-repair/verification-tools/aapt2')
write('aapt-final-receipt.json',{'candidate_commit':HEAD,'tool_version':'Android Asset Packaging Tool (aapt) 2.19-11948202','tool_sha256':sha(aaptexe.read_bytes()),'command':'aapt2 compile worktree/Paintroid/src/main/res/values-tr/strings.xml -o aapt/final-worktree-tr.zip','exit_code':0,'candidate_sha256':sha((W/'Paintroid/src/main/res/values-tr/strings.xml').read_bytes()),'candidate_git_blob_sha':blob((W/'Paintroid/src/main/res/values-tr/strings.xml').read_bytes()),'compiled_archive_sha256':sha(aapt.read_bytes()),'resource_linking':'not_run','app_build_jvm_lint_device':'not_run locally; no SDK installation detected','scope':'Complete Turkish XML compilation only, not runtime/layout acceptance'})
# Preserve the reviewed source and all original ledger files. Do not copy the full1180-file application tree into evidence.
allowed_final=['Paintroid/src/main/res/values-tr/strings.xml','tools/fixtures/current_localization/turkish_priority_current_wording.json','tools/test_turkish_priority_wording.py']
for p in allowed_final:
 dest=O/'application-candidate'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((W/p).read_bytes())
if '--package' not in sys.argv:
 print('Prepared adoption, independent check and final AAPT receipts');sys.exit()
exits=(O/'host-exits.txt').read_text();
if exits!='NORMAL_EXIT=0\nOPTIMIZED_EXIT=0\n':raise ValueError(exits)
import re
summaries={}
for label,name in [('focused-normal','focused-normal.log'),('focused-optimized','focused-optimized.log'),('host-normal','host-normal.log'),('host-optimized','host-optimized.log')]:
 text=(O/name).read_text();m=re.search(r'(?m)^Ran (\d+) tests in ([0-9.]+)s\s+OK\s*',text)
 if not m:raise ValueError('No complete success '+name)
 summaries[label]={'tests':int(m[1]),'seconds':float(m[2]),'exit_code':0,'log':name,'log_sha256':sha((O/name).read_bytes())}
write('final-test-summary.json',{'candidate_commit':HEAD,'candidate_tree':'3c91d75c7be084077787564d68e72d58a2699ec9','checks':summaries,'aapt_compile':'passed; separate receipt','jvm_build_lint_resource_link_device':'not_run locally; hosted exact-head results required','limitations':'Host resource/source assertions and AAPT2 compilation do not certify Turkish fluency, runtime behavior or layout. First test failures are preserved; no production change was made to accommodate tests.'})
# Reuse the initial artifact inventory (includes117 pinned source files), excluding its obsolete handoff.
initial=json.loads((O/'artifact-manifest.json').read_text())['files'];paths={r['path'] for r in initial if r['path'] not in {'HANDOFF.md','artifact-manifest.json'}}
paths.update(['README.md','candidate-adoption-review.json','independent-candidate-check.json','candidate-tree-check.json','candidate-full-tree-manifest.json','worktree-baseline-manifest.json','aapt-final-receipt.json','aapt-final.stdout.log','aapt-final.stderr.log','aapt/final-worktree-tr.zip','final-test-summary.json','focused-first.log','focused-second.log','focused-normal.log','focused-optimized.log','host-normal.log','host-optimized.log','host-exits.txt','prepare_candidate.py','finalize_evidence.py'])
paths.update('application-candidate/'+p for p in allowed_final)
rows=[{'path':p,'size_bytes':(O/p).stat().st_size,'sha256':sha((O/p).read_bytes()),'git_blob_sha':blob((O/p).read_bytes())} for p in sorted(paths)]
write('final-artifact-manifest.json',{'source_revision':REV,'candidate_commit':HEAD,'files':rows})
with zipfile.ZipFile(O/'turkish-review-final-packet.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(paths|{'final-artifact-manifest.json'}):z.write(O/p,p)
with zipfile.ZipFile(O/'turkish-review-final-packet.zip') as z:
 if z.testzip() is not None:raise ValueError('ZIP integrity failure')
 for r in rows:
  if sha(z.read(r['path']))!=r['sha256']:raise ValueError('ZIP SHA mismatch '+r['path'])
b=(O/'turkish-review-final-packet.zip').read_bytes();write('final-packet-receipt.json',{'candidate_commit':HEAD,'files':len(rows)+1,'size_bytes':len(b),'sha256':sha(b),'git_blob_sha':blob(b),'all_member_hashes_verified':True,'manifest':'final-artifact-manifest.json'})
print((O/'final-test-summary.json').read_text());print((O/'final-packet-receipt.json').read_text())
