from pathlib import Path
import json,hashlib,re,sys,xml.etree.ElementTree as ET,collections,subprocess,tempfile,shutil
O=Path(__file__).resolve().parent;S=O/'source';sys.path.insert(0,str(S/'tools'));import translation_catalogues as cat
REV='e414a4df64a56c2d8a2f374741b1f1b58fceea9b';TR='Paintroid/src/main/res/values-tr/strings.xml';EN='Paintroid/src/main/res/values/strings.xml'
def require(c,msg):
 if not c:raise ValueError(msg)
def vh(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def rm(p):
 nodes=list(ET.parse(p).getroot());res={e.tag+'/'+e.get('name'):e for e in nodes};require(len(nodes)==len(res),'Duplicate keys');return res
def val(e):return ''.join(e.itertext()) if e.tag=='string' else {n.get('quantity'):''.join(n.itertext()) for n in e}
T={r['path']:r for r in json.loads((O/'develop-tree.json').read_text())['tree']};manifest=json.loads((O/'input-manifest.json').read_text());require(len({r['path'] for r in manifest})==len(manifest),'Duplicate manifest path')
for r in manifest:
 b=(S/r['path']).read_bytes();require(blob(b)==r['git_blob_sha']==T[r['path']]['sha'],'Source Git hash mismatch '+r['path']);require(hashlib.sha256(b).hexdigest()==r['sha256'],'Source SHA256 mismatch')
prod={r['path'] for r in T.values() if r['type']=='blob' and '/main/' in r['path'] and r['path'].endswith(('.kt','.java','.xml','.html','.js')) and '/res/values' not in r['path'] and '/res/drawable' not in r['path']};require(prod <= {r['path'] for r in manifest},'Missing production reference-scanning file')
require(blob((O/'prior-receipts.json').read_bytes())=='004a38a070bc4ea215a82fdd41028aac5e341f3b','Prior ledger mismatch')
base=rm(S/TR);en=rm(S/EN);candidate=rm(O/'combined-candidate'/TR);priority=json.loads((S/'translations/string-importance.json').read_text());keys=[k for z in priority['tiers'] if z['id'] in ['P0','P1'] for k in z['keys']];report=json.loads((O/'turkish-p0-p1-341-review.json').read_text());rows=report['entries'];require([r['key'] for r in rows]==keys,'Row denominator/order differs');require(len(keys)==341 and len(set(keys))==341,'Bad denominator');require(report['source_revision']==REV,'Wrong source revision')
require(set(base)==set(candidate),'Resource identities changed');changes={k for k in base if val(base[k])!=val(candidate[k])};corrections={r['key']:r['proposed_localized_value'] for r in rows if r['state']=='open_correction_proposed'};comp=json.loads((O/'p3-navigate-companion-review.json').read_text());corrections[comp['key']]=comp['proposed_localized_value'];require(changes==set(corrections) and len(changes)==9,'Incorrect change scope');require(comp['tier']=='P3' and comp['included_in_341_denominator'] is False,'Companion denominator changed');require(comp['key'] in next(t for t in priority['tiers'] if t['id']=='P3')['keys'],'Companion tier changed')
for k in base:
 require(base[k].attrib==candidate[k].attrib,'Attributes changed '+k)
 for item in [base[k],candidate[k]]:
  if item.tag=='string':
   text=val(item);errors=cat.android_string_errors(text)+cat.format_string_errors(text,item.get('formatted')!='false');require(not errors,f'{k}: {errors}')
 if k in corrections:require(val(candidate[k])==corrections[k],'Candidate differs '+k)
for r in rows:
 k=r['key'];require(r['english']==val(en[k]) and r['turkish']==val(base[k]),'Source/target differs '+k);require(r['english_value_sha256']==vh(r['english']) and r['localized_value_sha256']==vh(r['turkish']),'Pair hash mismatch '+k);require(len(r['linguistic_assessment'])>25,'Missing actual assessment '+k)
 if r['state']=='open_correction_proposed':require(r['proposed_value_sha256']==vh(r['proposed_localized_value']),'Bad proposal hash')
 for c in r['consumer_context']:
  b=(S/c['path']).read_bytes();ls=b.decode().splitlines();i=c['snippet_start']-1;require(c['source_git_blob_sha']==blob(b),'Context blob mismatch');require(c['snippet']=='\n'.join(ls[i:i+len(c['snippet'].split('\n'))]),'Context lines mismatch');require(re.search(r'R\.string\.'+k.split('/')[1]+r'\b',ls[c['line']-1]),'Reference line mismatch')
 text=val(candidate[k]);source=val(en[k]);
 if text.startswith('@string/'):text=val(candidate['string/'+text.split('/',1)[1]])
 if source.startswith('@string/'):source=val(en['string/'+source.split('/',1)[1]])
 require(cat.placeholders(text)==cat.placeholders(source),'Placeholder difference '+k)
for c in comp['consumer_context']:
 b=(S/c['path']).read_bytes();require(blob(b)==c['source_git_blob_sha'],'Companion context mismatch');require(c['snippet']=='\n'.join(b.decode().splitlines()[c['line_start']-1:c['line_end']]),'Companion lines mismatch')
require(comp['english']==val(en[comp['key']]) and comp['turkish']==val(base[comp['key']]),'Companion pair mismatch')
counts=dict(collections.Counter(r['state'] for r in rows));require(counts==report['counts'],'Counts differ');require(counts=={'accepted_static':302,'accepted_catalogue_semantics_only':27,'open_correction_proposed':8,'open_idiom_or_context':4},'Unexpected dispositions')
# Explicit before/after checks are mechanical regression controls, not independent linguistic approval.
control_results=[]
for k,new in corrections.items():
 require(val(base[k])!=new,'Baseline unexpectedly corrected '+k)
 try:
  require(val(base[k])==new,'Rejected reverted value '+k)
 except ValueError:control_results.append({'key':k,'reverted_before_value_rejected':True})
 else:raise ValueError('Negative control did not reject '+k)
with tempfile.TemporaryDirectory(prefix='tr-review-patch-') as d:
 d=Path(d);(d/TR).parent.mkdir(parents=True);shutil.copy2(S/TR,d/TR)
 subprocess.run(['git','apply','--check',str(O/'turkish-nine-combined-corrections.patch')],cwd=d,check=True,capture_output=True)
 subprocess.run(['git','apply',str(O/'turkish-nine-combined-corrections.patch')],cwd=d,check=True,capture_output=True)
 require((d/TR).read_bytes()==(O/'combined-candidate'/TR).read_bytes(),'Patch does not reproduce candidate')
 subprocess.run(['git','apply','-R',str(O/'turkish-nine-combined-corrections.patch')],cwd=d,check=True,capture_output=True)
 require((d/TR).read_bytes()==(S/TR).read_bytes(),'Reverse patch differs from baseline')
result={'source_revision':REV,'source_files_verified':len(manifest),'production_scanning_files_verified':len(prod),'priority_rows':341,'priority_counts':counts,'prior_tracker_receipt_exact_match':True,'candidate_changes':sorted(changes),'unchanged_resource_identities':len(base)-len(changes),'android_syntax_all_catalogue_entries':'passed','priority_placeholder_contracts':'passed','patch_round_trip':'passed','reverted_value_negative_controls':control_results,'limits':['This validates packet integrity and resource contracts, not independent linguistic judgments.','AAPT compilation is recorded separately; no linking/runtime/device/layout acceptance.']};(O/('validation-optimized.json' if not __debug__ else 'validation-normal.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
