# Independent Cebuano candidate review

Exactly the 10 proposed corrections and 2 held identities, with their necessary current static consumers and composition companions. This is not an independent review of the 329 retained decisions or all 341 priority identities.

Outcome: accept 10 exact candidate values at medium AI confidence; revise 0 candidate values; retain both explicit holds.

Accept means a medium-confidence recommendation to use this exact candidate value within the stated static/wording scope. It is not native-human acceptance, runtime verification, release approval or a whole-locale receipt.

## Interpretation qualifications

Do not call gi- inherently completed-only; the two saving changes are explicit ongoing-state clarity. Optional gesture, destination, arrow, count and aspect-ratio choices are not ten severe bugs.

The source tree is b9b148d5d8ef7c7b088500a9c177f9f59304b800. The local source and candidate remain unchanged. No build, runtime, publication, or release action was performed.

## string/save20_destination_error

Decision: accept; confidence: medium.

English: The completed image could not replace its destination.

Current: Dili mapulihan sa nahuman nga hulagway ang destinasyon niini.

Proposed: Dili mapulihan sa nahuman nga hulagway ang file sa destinasyon niini.

Optional clarification, not a proven mistranslation. The replacement clause retains the completed image as the attempted replacement and the destination file as the object. Adding file is justified by renameTo(file/destination) and does not claim that replacement succeeded, that an old file necessarily existed, or that data was lost.

Static source: Paintroid/src/main/java/org/catrobat/paintroid/classic/BitmapFileCodec.kt:19; Paintroid/src/main/java/org/catrobat/paintroid/classic/DibCodec.kt:34; Paintroid/src/main/java/org/catrobat/paintroid/classic/IcoCodec.kt:100; Paintroid/src/main/java/org/catrobat/paintroid/classic/TextImageCodec.kt:58-64

## string/ui_keeps_pixels_at_the_top_left_smaller_canvas

Decision: accept; confidence: medium.

English: Keeps pixels at the top left. Smaller canvas dimensions discard pixels beyond the right/bottom edge; Undo restores them.

Current: Gipabilin ang mga pixel sa wala nga ibabaw. Ang mas gamay nga canvas motangtang sa mga pixel lapas sa tuo/ubos nga kilid; ang I-undo mobalik niini.

Proposed: Gipabilin ang mga pixel sa wala nga ibabaw. Ang mas gamay nga canvas motangtang sa mga pixel lapas sa tuo/ubos nga kilid; maibalik kini pinaagi sa I-undo.

The proposed final clause makes the removed pixels the things restored, with I-undo as the means. The original mobalik niini reads more like Undo returns to them/it than Undo restores them. Top-left anchoring and removal past right/bottom stay intact. maibalik kini is a suitable recoverability statement in this instruction; it is not a promise of restoration after a restart or after history is unavailable.

Static source: Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:1003-1016; Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:1025-1029; Paintroid/src/main/java/org/catrobat/paintroid/classic/PaintDocument.kt:197-215; Paintroid/src/main/java/org/catrobat/paintroid/classic/PaintDocument.kt:230-244; Paintroid/src/main/java/org/catrobat/paintroid/classic/PaintDocument.kt:423-431

## string/ui_the_draft_is_saving_try_again_shortly

Decision: accept; confidence: medium.

English: The draft is saving. Try again shortly.

Current: Gitipigan ang draft. Sulayi pag-usab sa makadiyot.

Proposed: Nagpadayon pa ang pagtipig sa draft. Sulayi pag-usab sa makadiyot.

Nagpadayon pa ang pagtipig explicitly presents saving as continuing and keeps the short-delay retry direction. The actorless saving noun phrase is natural for an operation message. Important rationale qualification: gi- does not inherently encode completed-only action, so the original Gitipigan is contextually ambiguous, not categorically ungrammatical or proof of a false success report. The proposed wording usefully removes reliance on context while editAction is blocked by autosaving.

Static source: Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:915-920; Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:1432-1436; Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:1597-1620

## string/ui_autosaving_draft

Decision: accept; confidence: medium.

English: Autosaving draft…

Current: Gi-autosave ang draft…

Proposed: Gi-autosave pa ang draft…

Adding pa gives a concise still-in-progress reading while preserving the established technical borrowing and ellipsis. Gi-autosave pa ang draft is acceptable as a compact operation status. Treat it as a clarity improvement, not a demonstration that gi- without pa necessarily means completed. The final saved state is a separate ui_draft_saved branch.

Static source: Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:679-683; Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:1606-1619

## string/ui_colour_palette_tap_for_foreground_hold_for_background

Decision: accept; confidence: medium.

English: Colour palette. Tap for foreground; hold for background. Scroll for more colours.

Current: Paleta sa kolor. I-tap para sa atubangan; pislita ug dugay para sa likod. I-scroll para sa dugang nga mga kolor.

Proposed: Paleta sa kolor. I-tap para sa atubangan; pislita ug kupti para sa likod. I-scroll para sa dugang nga mga kolor.

The two imperatives pislita ug kupti express press and hold, distinct from the brief I-tap action. Foreground/background roles and the separate scrolling instruction are preserved. This is an optional gesture-clarity change: the previous pislita ug dugay already suggests duration and is not established as wrong. kupti is a hold/grip imperative; its specific touchscreen naturalness remains a medium-confidence AI judgment rather than a native-UI certification.

Static source: Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:602-625

## string/ui_colour_tap_foreground_hold_background

Decision: accept; confidence: medium.

English: Colour #%1$s. Tap foreground, hold background.

Current: Kolor #%1$s. I-tap para sa atubangan, pislita ug dugay para sa likod.

Proposed: Kolor #%1$s. I-tap para sa atubangan, pislita ug kupti para sa likod.

The same press-and-hold construction keeps the tap-versus-long-press contrast, with %1$s still the hexadecimal colour token and the literal # outside it. The pairing maps directly to setColour(colour,false) and setColour(colour,true). Accept as the same optional clarity choice as the palette-level text, not as a separate severe defect.

Static source: Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:607-619

## string/ui_crop_preview_drag_an_edge_or_corner_drag

Decision: accept; confidence: medium.

English: Crop preview. Drag an edge or corner; drag inside to move the crop.

Current: Pasiunang tan-aw sa pag-crop. I-drag ang kilid o kanto; i-drag ang sulod aron ibalhin ang bahin nga putlon.

Proposed: Pasiunang tan-aw sa pag-crop. I-drag ang kilid o kanto; i-drag sulod sa crop aron ibalhin kini.

The proposal makes sulod sa crop the location of the drag rather than treating ang sulod as something to drag, and kini refers back to the crop. It removes the risky bahin nga putlon description, which can suggest the part to cut away. The selected rectangle is the retained source region; the inside drag translates it, while the edge/corner drag resizes it. Borrowing crop is consistent with the adjacent crop labels. No claim is made that the original always reverses the meaning.

Static source: Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt:18-44; Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt:68-69; Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt:141-150; Paintroid/src/main/java/org/catrobat/paintroid/classic/CropOverlay.kt:25-49; Paintroid/src/main/java/org/catrobat/paintroid/classic/CropOverlay.kt:66-69; Paintroid/src/main/java/org/catrobat/paintroid/classic/AssemblyRenderer.kt:95-100

## string/ui_d_d_px_d_pixels_2f_mp

Decision: accept; confidence: medium.

English: %1$d × %2$d px · Pixel count: %3$,d (%4$.2f MP)

Current: %1$d × %2$d px · %3$,d pixels (%4$.2f MP)

Proposed: %1$d × %2$d px · Gidaghanon sa mga pixel: %3$,d (%4$.2f MP)

Gidaghanon sa mga pixel is a clear total-count noun phrase and restores the explicit Pixel count label. Width, height, grouped integer count, and two-decimal megapixels retain their original typed format specifiers. The old number-plus-pixels wording was already informative; this is completeness/clarity, not a calculation fix. No width/truncation acceptance is inferred for the longer label.

Static source: Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageImport.kt:11-16; Paintroid/src/main/java/org/catrobat/paintroid/classic/DimensionControls.kt:75

## string/ui_left_arrow_collapse

Decision: accept; confidence: medium.

English: Left arrow: collapse

Current: Wala nga pana: i-collapse

Proposed: Pana paingon sa wala: i-collapse

Pana paingon sa wala describes an arrow pointing to the left more directly than Wala nga pana; the imperative i-collapse remains intact. This is optional directional clarity. There is no located literal production consumer, so this is strictly a standalone-label judgment, not acceptance of an actual keyboard action, focus behavior or visible UI.

## string/ui_scales_the_image_unlock_the_ratio_to_stretch

Decision: accept; confidence: medium.

English: Scales the image. Unlock the ratio to stretch width and height independently.

Current: Usbon ang gidak-on sa hulagway. Ablihi ang pagkandado sa katimbangan aron bulag nga mabitad ang gilapdon ug gitas-on.

Proposed: Usbon ang gidak-on sa hulagway. I-unlock ang aspect ratio aron bulag nga mausab ang gilapdon ug gitas-on.

The proposed I-unlock ang aspect ratio matches the actual I-lock ang aspect ratio control and states that width and height can change separately. The first sentence already supplies image-size scaling, so the second need not retain the literal pulling metaphor mabitad. This is a terminology/clarity preference, not evidence that katimbangan is lexically wrong: proportion is an attested sense.

Static source: Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:1003-1016; Paintroid/src/main/java/org/catrobat/paintroid/classic/DimensionControls.kt:19; Paintroid/src/main/java/org/catrobat/paintroid/classic/DimensionControls.kt:62-72

## string/ui_foreground_background_colour_palette

Decision: hold; confidence: limited.

English: Foreground %1$s, background %2$s. %3$s colour palette.

Current: Atubangan %1$s, likod %2$s. %3$s nga paleta sa kolor.

Proposed: null (unchanged hold)

Keep proposed null. The individual foreground/background slots are understandable, but the correct Cebuano linker and noun-phrase order depend on what %3$s actually supplies. Current-source literal searches locate no production caller. Other-language tests and retained resource declarations are not authoritative argument values. Do not invent expanded/collapsed or any other substitution, and do not infer that the string is dead.

Release condition: Locate an actual production consumer or authoritative intended third-argument values, then review the fully substituted palette-state descriptions.

## string/ui_pinch_and_pan_mode

Decision: hold; confidence: limited.

English: Pinch and pan mode

Current: Pag-usab sa pagpadako ug pagbalhin sa panan-aw

Proposed: null (unchanged hold)

Keep proposed null. The current phrase conveys changing magnification and moving the view, but does not explicitly express the pinch gesture or mode framing. Current-source literal searches locate no production caller that establishes the intended usage. Preserve the omission as a linguistic limitation and the consumer uncertainty as a separate limit. Do not invent a live gesture mode or silently certify the current label.

Release condition: Establish whether this legacy label is retained for an active gesture mode, then review wording that explicitly expresses pinch and pan without inventing the gesture.

## Composed contexts

### Autosaving state and edit gate

separate consumers, not a concatenated runtime string

Current: ["Gi-autosave ang draft…", "Gitipigan ang draft. Sulayi pag-usab sa makadiyot."]

Proposed: ["Gi-autosave pa ang draft…", "Nagpadayon pa ang pagtipig sa draft. Sulayi pag-usab sa makadiyot."]

Both remain in-progress; neither is a success confirmation. Source resets autosaving and uses a distinct saved/failed branch.

### Canvas-size dialog and Undo label

adjacent labels/instruction, not literal runtime concatenation

Current: ["Gidak-on sa canvas", "Gipabilin ang mga pixel sa wala nga ibabaw. Ang mas gamay nga canvas motangtang sa mga pixel lapas sa tuo/ubos nga kilid; ang I-undo mobalik niini.", "I-undo"]

Proposed: ["Gidak-on sa canvas", "Gipabilin ang mga pixel sa wala nga ibabaw. Ang mas gamay nga canvas motangtang sa mga pixel lapas sa tuo/ubos nga kilid; maibalik kini pinaagi sa I-undo.", "I-undo"]

The instruction uses the exact I-undo control term and keeps removed pixels as the restoration referent.

### Resize dialog and aspect-lock control

adjacent labels/instruction

Current: ["Usba ang gidak-on sa hulagway", "I-lock ang aspect ratio", "Usbon ang gidak-on sa hulagway. Ablihi ang pagkandado sa katimbangan aron bulag nga mabitad ang gilapdon ug gitas-on."]

Proposed: ["Usba ang gidak-on sa hulagway", "I-lock ang aspect ratio", "Usbon ang gidak-on sa hulagway. I-unlock ang aspect ratio aron bulag nga mausab ang gilapdon ug gitas-on."]

Control and explanation now share the same aspect ratio wording; unlocked width/height changes remain independent.

### Crop preview and trim explanation

contentDescription plus adjacent visible instruction, not a claim about speech order

Current: ["Pasiunang tan-aw sa pag-crop. I-drag ang kilid o kanto; i-drag ang sulod aron ibalhin ang bahin nga putlon.", "Putla gikan sa orihinal nga mga kilid. I-drag ang mga gunitanan o isulod ang mga kantidad sa ubos. Dili mausab ang orihinal nga mga file.", "I-apply ang crop"]

Proposed: ["Pasiunang tan-aw sa pag-crop. I-drag ang kilid o kanto; i-drag sulod sa crop aron ibalhin kini.", "Putla gikan sa orihinal nga mga kilid. I-drag ang mga gunitanan o isulod ang mga kantidad sa ubos. Dili mausab ang orihinal nga mga file.", "I-apply ang crop"]

Dragging within crop moves the retained rectangle. Separate edge-trim/original-file-preservation wording is not contradicted.

### Fixed palette swatch #0080FF

fully substituted static example using an actual hard-coded hex in ClassicPaintActivity.kt:607

Current: "Kolor #0080FF. I-tap para sa atubangan, pislita ug dugay para sa likod."

Proposed: "Kolor #0080FF. I-tap para sa atubangan, pislita ug kupti para sa likod."

One literal #, same foreground/background selection roles, distinct tap and long press. The original packet uses #0099FF as an illustrative well-typed value; it is not one of this hard-coded palette array.

### 1024 by 768 image-dimension description

static arithmetic and textual substitution; not Android formatter execution

Current: "1024 × 768 px · 786,432 pixels (0.79 MP)"

Proposed: "1024 × 768 px · Gidaghanon sa mga pixel: 786,432 (0.79 MP)"

Matches width*height and /1,000,000 source calculation. Comma and dot shown as illustrative formatting, not a locale-rendering receipt.

## Inherited boundaries

The packet has 22 exact-pair prior union receipts, only ui_sampled_resize_memory_explanation in priority; the other 21 are outside this priority batch. This independent 12-key review does not recreate, widen or upgrade those receipts.

mausab retained; one format-neutral colour-profile message only, not general colour-terminology or whole-Cebuano acceptance.

This independent pass read the packet cached original receipt and checked exact source pair. It did not independently re-fetch the PR comment.

Earlier withdrawn localization acceptance, including PR #3, is not restored. No new count or disjointness claim for all 341 is created by this review.

## Sources and limits

- [Michael Tanangkingsing, A Functional Reference Grammar of Cebuano (2009), printed p. 44 / PDF p. 62](https://theswissbay.ch/pdf/Books/Linguistics/Mega%20linguistics%20pack/Austronesian/Cebuano,%20A%20Functional%20Reference%20Grammar%20of%20(Tanangkingsing).pdf#page=62): Non-future gi- occurs in perfective and imperfective contexts; aspect is also expressed with particles, including pa (still). Supports a non-categorical rationale for the two autosave clarifications; does not certify the complete UI strings.
- [John U. Wolff, A Dictionary of Cebuano Visayan (1972), introduction section 6.1](https://ecommons.cornell.edu/bitstreams/d3aa3efc-365a-49f8-9c21-a696e333c9b7/download): Search-retrieved original introduction notes that passive punctual forms can cover durative meanings in ordinary usage. Corroboration only; direct web open/find was unavailable.
- [Binisaya: balik](https://www.binisaya.com/cebuano/balik): Return/give-back root senses only. Argument-structure judgment is independent AI analysis.
- [Binisaya: putol](https://www.binisaya.com/cebuano/putol): Cut/sever root senses only. Retained-region conclusion comes from source, not dictionary.
- [Binisaya: kupot](https://www.binisaya.com/cebuano/kupot): Hold/grip root meaning only. Does not establish native touchscreen wording preference.
- [Binisaya: katimbangan](https://www.binisaya.com/cebuano/katimbangan): Attested proportion sense. Avoid portraying the original ratio word as lexically incorrect.

- All accept recommendations remain medium-confidence AI-assisted judgments, not native-speaker, human-linguist or regional-user validation.
- No Android rendering, truncation, TalkBack, gesture execution, saved-data recovery or runtime behavior was tested.
- The two held values remain unchanged and unaccepted; no speculative substitution or gesture-mode consumer was invented.
- Sources support lexical or grammatical observations only; sentence-level UI judgments remain independent AI analysis.
