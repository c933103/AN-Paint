# GIF substitute: bounded second check

Verdict: **accept**.

Exact accepted value:

静态图片，最多 256 色。抖色可使颜色渐变看起来更平滑。动画 GIF 只会打开第一帧。

The complete value retains still output, the 256-colour maximum, the visual smoothing benefit and first-frame-only opening. `抖色` matches the actual `save20_dither` checkbox in `SaveOptionsDialog.kt:64`, which is shown for GIF at line 90 alongside this description selected at line 95. No remaining issue was identified in this bounded check.

Preserve the independent reviewer’s distinction: regional terminology proposals are generally locale-fit/clarity improvements, not proof the original terms are intrinsically wrong. This check concerns only the exact GIF substitute; it neither repeats the full review nor grants new priority credit.

The original author patch/archive remains unchanged. A consolidated accepted candidate must use this substitute rather than the earlier `抖动处理` version. No production source edit, build, app test, runtime/device work or publication was performed. Exact hashes and immutable source references are in the companion JSON.
