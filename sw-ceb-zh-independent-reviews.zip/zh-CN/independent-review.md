# Independent zh-CN proposal review, 21 October 2026

Receipt: ZH-CN-PRIORITY-44-INDEPENDENT-20261021

Result: 43 accept, 1 revise, 0 hold across the 44 P0/P1 proposals. Separately accept P2 Top. No source edits or builds.

## Material distinction

- Accept 43 proposed exact values; revise the GIF description to retain its adjacent checkbox terminology 抖色. No holds. Accept separate P2 Top correction.
- Only the completeness-note mismatch and Bottom layer-vs-edge label are unambiguous complete-content errors among these 44; separate Top is a third such error outside the batch. Other rows improve precision, clarity, terminology, consistency or grammar.
- Do not describe all 44 as mistranslations or the inherited regional words as intrinsically invalid. In particular 预设, 画格, 等阔, 向量物件, 点阵图, 配置内存, 色彩描述档, 解析度 and 剪贴簿 are meaningful in regional Chinese.
- The final accepted candidate must not silently use the unchanged author GIF value if this receipt is cited as acceptance. Apply the exact revised GIF value or obtain a new acceptance of any alternative.

## Per-key decisions and exact recommended values

### string/formats22_animation_message — ACCEPT (P0)

**English:** This %1$s contains %2$s frames. AN Paint edits still images and does not preserve animation.

**Current:** 此 %1$s 包含 %2$s 个画格。AN Paint 编辑静态图片，不会保留动画。

**Author proposal:** 此 %1$s 包含 %2$s 帧。AN Paint 编辑静态图片，不会保留动画。

**Recommend:** 此 %1$s 包含 %2$s 帧。AN Paint 编辑静态图片，不会保留动画。

**Assessment:** regional_terminology. Frame count and still-only/no-animation consequences are already correct. 画格 is a legitimate regional word, not a wrong unit. 帧 is the clearer Mainland convention. Both exact N and 至少 N substitutions fit the proposal.

### string/formats22_animation_poster — ACCEPT (P0)

**English:** This PNG has a separate default image. That image will be imported instead of the animated frames. Saving creates a still image.

**Current:** 此 PNG 另有预设图片。系统会汇入该图片，而不是动画画格。保存后会成为静态图片。

**Author proposal:** 此 PNG 有一张独立的默认图片。系统会导入该图片，而不是动画帧。保存后会生成静态图片。

**Recommend:** 此 PNG 有一张独立的默认图片。系统会导入该图片，而不是动画帧。保存后会生成静态图片。

**Assessment:** regional_terminology. The separate default image, precedence over animated frames, and still-image saving are preserved. 预设 legitimately means default in regional technical Chinese; it is not necessarily a user preset. 独立的默认图片 is clearer for this locale. This is not proof of an existing wrong import instruction.

### string/formats22_animation_still — ACCEPT (P0)

**English:** Only the first frame will be imported. Saving creates a still image.

**Current:** 只会汇入第一个画格。保存后会成为静态图片。

**Author proposal:** 只会导入第一帧。保存后会生成静态图片。

**Recommend:** 只会导入第一帧。保存后会生成静态图片。

**Assessment:** regional_terminology. Current meaning is already first frame only and still output. 导入/第一帧 are preferred Mainland terminology; the proposed full value is faithful.

### string/formats22_animation_unknown — ACCEPT (P0)

**English:** This %1$s is too complex to confirm whether it contains multiple frames. AN Paint will open only a still image and will not preserve any animation.

**Current:** 此 %1$s 结构过于复杂，无法确认是否包含多个画格。AN Paint 只会开启静态图片，不会保留动画。

**Author proposal:** 此 %1$s 结构过于复杂，无法确认是否包含多帧。AN Paint 只会打开静态图片，不会保留动画。

**Recommend:** 此 %1$s 结构过于复杂，无法确认是否包含多帧。AN Paint 只会打开静态图片，不会保留动画。

**Assessment:** regional_terminology. Both versions retain uncertainty about multiple frames and the unconditional lack of animation preservation. 开启 is legitimate; changing it is optional, while 帧 makes the locale idiom more familiar.

### string/formats22_ascii_description — ACCEPT (P0)

**English:** Writes plain text using light and dark characters. View it in a monospaced font. This is a visual rendition; it cannot be reopened as the original image.

**Current:** 使用明暗不同的字符写成纯文字。请以等阔字体检视。这只是视觉呈现，不能重新打开为原始图片。

**Author proposal:** 使用明暗不同的字符生成纯文本。请使用等宽字体查看。这只是视觉呈现，不能作为原始图片重新打开。

**Recommend:** 使用明暗不同的字符生成纯文本。请使用等宽字体查看。这只是视觉呈现，不能作为原始图片重新打开。

**Assessment:** regional_terminology. The current text already says plain text, monospaced viewing, and inability to reopen the original image. 等阔 is a valid regional synonym of 等宽, not a proportionally spaced font. The proposal improves Mainland idiom without changing the warning.

### string/formats22_pdf_raster_hint — ACCEPT (P0)

**English:** PDF pages are rendered at 144 dpi. Text and vector objects become pixels.

**Current:** PDF 页面会以 144 dpi 绘制。文字及向量物件会转为像素。

**Author proposal:** PDF 页面会以 144 dpi 渲染。文字和矢量对象会转换为像素。

**Recommend:** PDF 页面会以 144 dpi 渲染。文字和矢量对象会转换为像素。

**Assessment:** regional_terminology. 144 dpi and conversion of both text and vector objects to pixels are preserved. 向量物件 is meaningful regional terminology; 矢量对象 and 渲染 are better Mainland graphics terminology, not correction of a different operation.

### string/save20_destination_error — ACCEPT (P0)

**English:** The completed image could not replace its destination.

**Current:** 完成的图片无法取代目的地文件。

**Author proposal:** 无法用已生成的图片替换目标文件。

**Recommend:** 无法用已生成的图片替换目标文件。

**Assessment:** clarity_or_grammar. The codec writes a temporary image then reports failed rename to the target. The proposal identifies the completed image and target file more naturally. 目的地文件 is awkward but does not assert successful replacement.

### string/save20_gif_description — REVISE (P0)

**English:** Still image, up to 256 colours. Dithering smooths colour gradients. Animated GIFs open as their first frame.

**Current:** 静态图片，最多 256 色。抖色可令颜色渐变看起来更平滑。动画 GIF 会开启第一个画格。

**Author proposal:** 静态图片，最多 256 色。抖动处理可使颜色渐变更平滑。动画 GIF 只会打开第一帧。

**Recommend:** 静态图片，最多 256 色。抖色可使颜色渐变看起来更平滑。动画 GIF 只会打开第一帧。

**Assessment:** terminology_consistency. Revise rather than accept verbatim: retain 抖色, a legitimate imaging term and the exact adjacent checkbox label save20_dither at SaveOptionsDialog.kt:64. The proposed 抖动处理 is not false, but independently renaming the explanatory term weakens label-to-help consistency. Keep the useful 第一帧 wording and explicit only.

### string/save20_lossy_quality_description — ACCEPT (P0)

**English:** Higher quality preserves more detail and usually makes a larger file.

**Current:** 较高品质可保留更多细节，通常也会产生较大的文件。

**Author proposal:** 较高质量可保留更多细节，通常也会产生较大的文件。

**Recommend:** 较高质量可保留更多细节，通常也会产生较大的文件。

**Assessment:** terminology_consistency. 品质 is not a semantic error. 质量 matches ui_quality exactly; detail preservation and usually-larger-file caveat survive.

### string/save20_unsupported_image_colour — ACCEPT (P0)

**English:** This image uses a colour profile that AN Paint cannot convert yet. Convert it to sRGB PNG in a colour-managed editor before importing.

**Current:** 此图片使用 AN Paint 尚未能转换的色彩描述档。请先在支持色彩管理的编辑器中转换为 sRGB PNG，再导入。

**Author proposal:** 此图片使用 AN Paint 尚无法转换的颜色配置文件。请先在支持色彩管理的编辑器中将其转换为 sRGB PNG，再导入。

**Recommend:** 此图片使用 AN Paint 尚无法转换的颜色配置文件。请先在支持色彩管理的编辑器中将其转换为 sRGB PNG，再导入。

**Assessment:** regional_terminology. Complete warning is faithful: format-neutral image subject, unsupported-for-now profile conversion, colour-managed editor, sRGB PNG, conversion before import. 色彩描述档 is a legitimate regional ICC/profile term. 颜色配置文件 is an optional Mainland terminology improvement, not a new proven colour-processing defect. The old PR86 receipt remains delta-only; this independent review reads the complete pair.

### string/ui_a_separate_recovery_copy_has_been_kept_use — ACCEPT (P0)

**English:** %1$s A separate recovery copy has been kept. Use File > Export recovery copy to save its ZIP. Extract canvas.png from it and load that image to use the normal resize options if needed.

**Current:** %1$s 已保留另一份恢复副本。请使用「文件」>「导出恢复副本」将其保存为 ZIP。如有需要使用一般尺寸调整功能，请从 ZIP 解压 canvas.png，再以图片方式加载。

**Author proposal:** %1$s 已保留另一份恢复副本。请使用「文件」>「导出恢复副本」将其保存为 ZIP。如需使用常规的大小调整功能，请从 ZIP 中解压 canvas.png，再打开该图片。

**Recommend:** %1$s 已保留另一份恢复副本。请使用「文件」>「导出恢复副本」将其保存为 ZIP。如需使用常规的大小调整功能，请从 ZIP 中解压 canvas.png，再打开该图片。

**Assessment:** clarity_or_grammar. The reason prefix and successful separate preservation branch are intact. 如需使用 is grammatical and the extraction/open-image sequence still enables ordinary resizing. File and Export recovery copy menu labels match the catalogue, omitting only menu ellipsis in prose.

### string/ui_an_assembly_source_image_is_missing — ACCEPT (P0)

**English:** An assembly source image is missing.

**Current:** 图片拼接的来源图片遗失。

**Author proposal:** 图片拼接缺少一张源图片。

**Recommend:** 图片拼接缺少一张源图片。

**Assessment:** semantic_precision. The check rejects an unavailable source file, including an invalid directory relation. 缺少 avoids the stronger implication that the image was lost. 一张 is indefinite here, not a promise that exactly one file is missing. This precision improvement does not certify the filesystem cause.

### string/ui_assembly_source_memory_floor — ACCEPT (P0)

**English:** A source image needs more decoding memory than is currently available, even for a tiny output. Reducing the assembly dimensions cannot solve this. Close other documents or prepare a smaller source image before trying again. Your assembly is unchanged.

**Current:** 来源图片即使输出极小，解码仍需要超过目前可用量的内存。缩小拼合尺寸无法解决。请关闭其他文件，或先准备较小的来源图片再试。目前拼合内容没有改变。

**Author proposal:** 即使输出尺寸很小，解码一张源图片所需的内存仍超过当前可用内存。缩小拼接尺寸无法解决此问题。请关闭其他文档，或先准备较小的源图片再试。拼接内容未改变。

**Recommend:** 即使输出尺寸很小，解码一张源图片所需的内存仍超过当前可用内存。缩小拼接尺寸无法解决此问题。请关闭其他文档，或先准备较小的源图片再试。拼接内容未改变。

**Assessment:** clarity_or_grammar. Proposed syntax makes the small output distinct from the source decoding requirement. It preserves impossibility of fixing the floor by reducing assembly dimensions, both remedies, and unchanged assembly. 当前/源图片/文档/拼接 are wording refinements, not four separate errors.

### string/ui_autosave_selection_encoding_failed — ACCEPT (P0)

**English:** Autosave selection encoding failed.

**Current:** 自动保存的选择范围编码失败。

**Author proposal:** 自动保存的选区编码失败。

**Recommend:** 自动保存的选区编码失败。

**Assessment:** terminology_consistency. AutosaveStore encodes floating.png; 选区 is consistent with delete/crop selection commands. 选择范围 is intelligible and not a different selected settings item in this context.

### string/ui_cannot_create_the_undo_cache_free_some_device — ACCEPT (P0)

**English:** Cannot create the undo cache. Free some device storage and try again.

**Current:** 无法建立撤销缓存。请腾出一些设备保存空间，然后再试。

**Author proposal:** 无法创建撤销缓存。请腾出一些设备存储空间，然后再试。

**Recommend:** 无法创建撤销缓存。请腾出一些设备存储空间，然后再试。

**Assessment:** clarity_or_grammar. Failure is creation of a disk-cache directory. 存储空间 makes the intended disk-storage remedy clear. Current 保存空间 is awkward, but does not explicitly tell the user to free RAM.

### string/ui_d_d_pixels_2f_mp_exceeds_the_current — ACCEPT (P0)

**English:** %1$d × %2$d pixels (%3$.2f MP) exceeds the current safe editing budget of %4$.2f MP. AN Paint keeps the complete image in memory and reserves space for transforms and selections. Available memory determines this budget. The operation was stopped before allocating the oversized bitmap. No automatic resizing was applied.

**Current:** %1$d × %2$d 像素（%3$.2f MP）超出目前 %4$.2f MP 的安全编辑上限。AN Paint 会将完整图片保留在内存，并预留空间作变形及选择范围处理。此上限由可用内存决定。系统已在配置过大的点阵图前停止操作，并未自动调整大小。

**Author proposal:** %1$d × %2$d 像素（%3$.2f MP）超出当前 %4$.2f MP 的安全编辑上限。AN Paint 会将完整图片保留在内存中，并为变换和选区操作预留空间。此上限由可用内存决定。系统已在为过大的位图分配内存前停止操作，并未自动调整大小。

**Recommend:** %1$d × %2$d 像素（%3$.2f MP）超出当前 %4$.2f MP 的安全编辑上限。AN Paint 会将完整图片保留在内存中，并为变换和选区操作预留空间。此上限由可用内存决定。系统已在为过大的位图分配内存前停止操作，并未自动调整大小。

**Assessment:** technical_precision. All four typed arguments and all memory/no-auto-resize statements survive. 分配内存 is more explicit Mainland terminology for allocation. 配置 can legitimately denote allocation in regional technical usage; do not label the current phrase a categorical configure-vs-allocate mistranslation solely on that word. 位图/变换/选区 improve locale terminology.

### string/ui_export_explanation23 — ACCEPT (P0)

**English:** Export an icon, Base64 text or ASCII art. Exporting keeps the current image and its Save destination unchanged.

**Current:** 导出图标、Base64 文字或 ASCII 艺术。导出不会改变目前图片及其「保存」目的地。

**Author proposal:** 导出图标、Base64 文本或 ASCII 艺术。导出不会改变当前图片及其保存位置。

**Recommend:** 导出图标、Base64 文本或 ASCII 艺术。导出不会改变当前图片及其保存位置。

**Assessment:** clarity_or_grammar. All three derived export types, unchanged current image and unchanged save target survive. 保存位置 reads naturally; current 保存目的地 was awkward rather than a contrary state claim.

### string/ui_higher_quality_usually_makes_a_larger_file_lossless — ACCEPT (P0)

**English:** Higher quality usually makes a larger file. Lossless keeps every colour value.

**Current:** 较高品质通常会产生较大的文件。无损会保留每个颜色数值。

**Author proposal:** 较高质量通常会产生较大的文件。无损压缩会保留每个颜色值。

**Recommend:** 较高质量通常会产生较大的文件。无损压缩会保留每个颜色值。

**Assessment:** terminology_consistency. 质量 matches the slider label; 无损压缩 states the encoding mode explicitly. Both current and proposed values preserve usually and every colour value. Existing 无损 is a valid elliptical UI mode label.

### string/ui_recovery_copy_exported_extract_canvas_png_from_the — ACCEPT (P0)

**English:** Recovery copy exported. Extract canvas.png from the ZIP and open it with File > Load image. The ZIP also contains draft settings and any floating selection.

**Current:** 已导出恢复副本。请从 ZIP 解压 canvas.png，并使用「文件」>「打开图片」开启。ZIP 也包含草稿设置及任何浮动选择范围。

**Author proposal:** 已导出恢复副本。请从 ZIP 中解压 canvas.png，并使用「文件」>「打开图片」打开它。ZIP 也包含草稿设置及任何浮动选区。

**Recommend:** 已导出恢复副本。请从 ZIP 中解压 canvas.png，并使用「文件」>「打开图片」打开它。ZIP 也包含草稿设置及任何浮动选区。

**Assessment:** terminology_consistency. The exact canvas.png filename, ZIP extraction, File > Load image route, draft settings and any floating selection are all preserved. 选区 is clearer consistent terminology; current 开启 is valid.

### string/ui_sampled_resize_memory_explanation — ACCEPT (P0)

**English:** Estimates include the current canvas and clipboard, sampled decoding and editing buffers. Actual memory use varies. A smaller copy loses detail. The original file stays unchanged.

**Current:** 估算包括目前画布及剪贴簿、取样解码及编辑缓冲区。实际内存用量会有所不同。较小的副本会损失细节。原始文件不会改变。

**Author proposal:** 估算包括当前画布和剪贴板、采样解码及编辑缓冲区。实际内存用量会有所不同。较小的副本会损失细节。原始文件不会改变。

**Recommend:** 估算包括当前画布和剪贴板、采样解码及编辑缓冲区。实际内存用量会有所不同。较小的副本会损失细节。原始文件不会改变。

**Assessment:** regional_terminology. All estimate components, variability, lost detail and unchanged original file remain. 剪贴簿/取样 are valid regional equivalents, not evidence the previously bound complete value was wrong. This is an optional locale refinement; old complete receipt remains historically exact-bound to the old value.

### string/ui_there_is_not_enough_memory_for_this_operation — ACCEPT (P0)

**English:** There is not enough memory for this operation at the original resolution. No automatic resizing was applied.

**Current:** 内存不足，无法以原始解析度完成此操作。系统并未自动调整大小。

**Author proposal:** 内存不足，无法以原始分辨率完成此操作。系统并未自动调整大小。

**Recommend:** 内存不足，无法以原始分辨率完成此操作。系统并未自动调整大小。

**Assessment:** regional_terminology. 解析度 and 分辨率 denote the same image resolution here. Proposal is a Mainland terminology improvement; original-resolution limitation and no automatic resizing remain intact.

### string/colour_converter_unavailable — ACCEPT (P1)

**English:** The image colour converter could not start. The image was not imported.

**Current:** 无法启动图片色彩转换器。图片并未汇入。

**Author proposal:** 无法启动图片色彩转换器。图片并未导入。

**Recommend:** 无法启动图片色彩转换器。图片并未导入。

**Assessment:** regional_terminology. Current 汇入 already means import. 导入 matches broader locale vocabulary. Failure to start the converter and explicit non-import are unchanged.

### string/commons_svg_original_size_too_large — ACCEPT (P1)

**English:** The original SVG size exceeds Android bitmap dimensions. No resizing was applied.

**Current:** SVG 的原始大小超出 Android 点阵图的尺寸上限。并未调整大小。

**Author proposal:** SVG 的原始大小超出 Android 位图的尺寸上限。并未调整大小。

**Recommend:** SVG 的原始大小超出 Android 位图的尺寸上限。并未调整大小。

**Assessment:** regional_terminology. 点阵图 and 位图 denote the same bitmap here. Original SVG dimensions, Android dimension limit and no resizing remain correct. Checked the outer gallery-error composition as well.

### string/formats22_import_limit — ACCEPT (P1)

**English:** This file exceeds the 512 MiB import limit. Choose a smaller file.

**Current:** 此文件超出 512 MiB 汇入上限。请选择较小的文件。

**Author proposal:** 此文件超出 512 MiB 导入上限。请选择较小的文件。

**Recommend:** 此文件超出 512 MiB 导入上限。请选择较小的文件。

**Assessment:** regional_terminology. 512 MiB stays exact and the remedy is a smaller file, not just smaller dimensions. 汇入 is valid; 导入 is a locale-consistency refinement.

### string/language20_translation_note — ACCEPT (P1)

**English:** App language\n\nTranslations are maintained in AN Paint’s language resources. New or untranslated text appears in English.

**Current:** 此语言版本已包含 AN Paint 所有可翻译的界面文字。

**Author proposal:** 应用语言\n\n翻译内容在 AN Paint 的语言资源中维护。新增或尚未翻译的文字会以英语显示。

**Recommend:** 应用语言\n\n翻译内容在 AN Paint 的语言资源中维护。新增或尚未翻译的文字会以英语显示。

**Assessment:** genuine_content_error. Current complete Chinese makes an unsupported all-interface-text-complete claim and omits the source heading, resource-maintenance statement and English fallback. Proposed complete value restores all of these, including the two literal Android newline escapes. AppLanguage uses this entire value as the custom title.

### string/ui_android_blocked_the_file_picker — ACCEPT (P1)

**English:** Android blocked the file picker: %1$s

**Current:** Android 已封锁文件选择器：%1$s

**Author proposal:** Android 阻止打开文件选择器：%1$s

**Recommend:** Android 阻止打开文件选择器：%1$s

**Assessment:** semantic_precision. Consumers catch SecurityException from launching a picker, so 阻止打开 describes the immediate failure precisely. Existing 封锁 is stronger-sounding but not evidence of a different actual platform state. Diagnostic argument remains intact.

### string/ui_android_could_not_find_a_file_picker_enable — ACCEPT (P1)

**English:** Android could not find a file picker. Enable the Files or Documents app in Android settings, then try again.

**Current:** Android 找不到文件选择器。请在 Android 设置启用「Files」或「文件」应用，然后再试。

**Author proposal:** Android 找不到文件选择器。请在 Android 设置中启用「文件」（Files）或「文档」（Documents）应用，然后再试。

**Recommend:** Android 找不到文件选择器。请在 Android 设置中启用「文件」（Files）或「文档」（Documents）应用，然后再试。

**Assessment:** remedy_clarity. English Files and Documents are now both identifiable. Current Files/文件 can read as the same name twice, but the exact localized OEM app names were not verified; do not claim all devices label Documents 文档. Including both English names is a useful remedy-clarity improvement.

### string/ui_background_edit_colour — ACCEPT (P1)

**English:** Background %1$s. Edit colour.

**Current:** 背景 %1$s。编辑颜色。

**Author proposal:** 背景色 %1$s。编辑颜色。

**Recommend:** 背景色 %1$s。编辑颜色。

**Assessment:** terminology_consistency. Hex colour is supplied and the description belongs to the background-colour button. 背景色 is explicit and aligns with ui_background_colour. Existing 背景 is not a different background-content action in this consumer.

### string/ui_bottom — ACCEPT (P1)

**English:** Bottom

**Current:** 底层

**Author proposal:** 下

**Recommend:** 下

**Assessment:** genuine_content_error. ImageCropDialog maps this resource only to the bottom crop margin, computes it as image height minus bottom coordinate, and inserts it into trim-unit descriptions. 底层 means bottom layer, which is the wrong concept. 下 matches existing 左/右 and composes as 下裁减量（像素/百分比）. Paired Top must be tracked separately as P2.

### string/ui_choose_a_smaller_output_copy_the_source_images — ACCEPT (P1)

**English:** Choose a smaller output copy. The source images and crop settings stay at their original resolution.

**Current:** 请选择较小的输出副本。来源图片及裁剪设置会保持原有解析度。

**Author proposal:** 请选择较小的输出副本。源图片及裁剪设置会保持原有分辨率。

**Recommend:** 请选择较小的输出副本。源图片及裁剪设置会保持原有分辨率。

**Assessment:** regional_terminology. 源图片/分辨率 are preferred Mainland terms. Current 来源图片/解析度 still denote source images and resolution. Output-only reduction and original source/crop-coordinate resolution are preserved.

### string/ui_choose_a_smaller_size — ACCEPT (P1)

**English:** Choose a smaller size.

**Current:** 请选择较小的大小。

**Author proposal:** 请选择较小的尺寸。

**Recommend:** 请选择较小的尺寸。

**Assessment:** clarity_or_grammar. 尺寸 avoids the awkward 较小的大小 repetition and refers to the output dimensions. The preceding estimated-memory template ends in a newline, so this replacement composes without requiring an added separator.

### string/ui_colour_palette_tap_for_foreground_hold_for_background — ACCEPT (P1)

**English:** Colour palette. Tap for foreground; hold for background. Scroll for more colours.

**Current:** 调色板。点按设为前景色；长按设为背景色。卷动可查看更多颜色。

**Author proposal:** 调色板。点按设为前景色；长按设为背景色。滚动可查看更多颜色。

**Recommend:** 调色板。点按设为前景色；长按设为背景色。滚动可查看更多颜色。

**Assessment:** regional_terminology. 滚动 is conventional Mainland UI vocabulary; 卷动 is a legitimate regional equivalent. Tap/hold, foreground/background and more-colours meanings remain exact.

### string/ui_commit_selection — ACCEPT (P1)

**English:** Commit selection

**Current:** 确定选择范围

**Author proposal:** 确认选区

**Recommend:** 确认选区

**Assessment:** terminology_consistency. 选区 aligns with neighbouring selection actions. Consumer is applyPending -> finishSelection, which composites floating content then clears the selection, not confirmation of a settings choice. 确认选区 is acceptable as a concise commit/confirm label; this is not a claim that merely changing 选择范围 fixes a distinct functional bug.

### string/ui_crop_preview_drag_an_edge_or_corner_drag — ACCEPT (P1)

**English:** Crop preview. Drag an edge or corner; drag inside to move the crop.

**Current:** 裁剪预览。拖动边缘或角位调整大小；拖动内部以移动裁剪范围。

**Author proposal:** 裁剪预览。拖动边缘或角点调整大小；拖动内部以移动裁剪范围。

**Recommend:** 裁剪预览。拖动边缘或角点调整大小；拖动内部以移动裁剪范围。

**Assessment:** regional_terminology. 角位 is meaningful regional wording. 角点 is a natural technical Mainland alternative. Edge/corner resize versus interior move instructions remain correct, confirmed against CropPreview touch dispatch.

### string/ui_drawing_canvas_pinch_and_move_two_fingers_to — ACCEPT (P1)

**English:** Drawing canvas. Pinch and move two fingers to zoom and pan. Navigate mode also pans with one finger.

**Current:** 绘图画布。用两只手指缩放及移动以缩放和平移。「移动与缩放」模式也可用一只手指平移。

**Author proposal:** 绘图画布。用双指捏合或张开可缩放，双指拖动可平移。「移动与缩放」模式也可用单指平移。

**Recommend:** 绘图画布。用双指捏合或张开可缩放，双指拖动可平移。「移动与缩放」模式也可用单指平移。

**Assessment:** instruction_clarity. Proposal clearly distinguishes pinch/spread zoom from two-finger drag pan and preserves the exact localized Navigate label and one-finger mode exception. Static gesture code changes zoom with span and pan with focus motion. Current wording is redundant and underspecified, not a claim that two unrelated fingers are required.

### string/ui_enter_positive_canvas_dimensions_within_android_s_coordinate — ACCEPT (P1)

**English:** Enter positive canvas dimensions within Android\'s coordinate range.

**Current:** 请输入 Android 座标范围内且大于 0 的画布尺寸。

**Author proposal:** 请输入 Android 坐标范围内且大于 0 的画布尺寸。

**Recommend:** 请输入 Android 坐标范围内且大于 0 的画布尺寸。

**Assessment:** regional_terminology. 坐标 is preferred Mainland orthography; 座标 is a legitimate variant in regional Chinese. Positivity and Android coordinate limits are unchanged.

### string/ui_foreground_edit_colour — ACCEPT (P1)

**English:** Foreground %1$s. Edit colour.

**Current:** 前景 %1$s。编辑颜色。

**Author proposal:** 前景色 %1$s。编辑颜色。

**Recommend:** 前景色 %1$s。编辑颜色。

**Assessment:** terminology_consistency. Hex colour is supplied and the description belongs to the foreground-colour button. 前景色 improves explicitness and consistency; the current 前景 is understandable in this colour context.

### string/ui_invalid_selection_outline — ACCEPT (P1)

**English:** Invalid selection outline.

**Current:** 选择范围轮廓无效。

**Author proposal:** 选区轮廓无效。

**Recommend:** 选区轮廓无效。

**Assessment:** terminology_consistency. SelectionOutline validates outline contours. 选区 matches other selection commands; neither wording changes invalid into absent. Current 选择范围 is meaningful.

### string/ui_no_resize_fits_decoder_memory — ACCEPT (P1)

**English:** Even the smallest output cannot fit this image’s decoder working buffers in the current memory budget. Cancel and use a smaller source image.

**Current:** 即使使用最小输出，此图片的解码器工作缓冲区仍无法放入目前内存上限。请取消并使用较小的来源图片。

**Author proposal:** 即使输出尺寸最小，此图片的解码器工作缓冲区所需内存仍超过当前上限。请取消并使用较小的源图片。

**Recommend:** 即使输出尺寸最小，此图片的解码器工作缓冲区所需内存仍超过当前上限。请取消并使用较小的源图片。

**Assessment:** clarity_or_grammar. The old 放入…内存上限 construction is awkward. Proposed wording accurately says required memory exceeds the limit even at minimum output size, preserving cancel and smaller-source remedies. It composes after the copy/memory estimate plus the explicit newline in the consumer.

### string/ui_not_enough_memory_to_finish_opening_this_image — ACCEPT (P1)

**English:** Not enough memory to finish opening this image

**Current:** 内存不足，无法完成开启此图片

**Author proposal:** 内存不足，无法完成此图片的加载

**Recommend:** 内存不足，无法完成此图片的加载

**Assessment:** clarity_or_grammar. 无法完成开启此图片 is an awkward stacked-verb construction. The proposal naturally names incomplete image loading and preserves the memory cause. The consumer may fail during integration of decoded pixels, so 加载 is suitably broad, not a claim decoding never finished.

### string/ui_selection_dimensions_are_too_large — ACCEPT (P1)

**English:** Selection dimensions are too large.

**Current:** 选择范围尺寸过大。

**Author proposal:** 选区尺寸过大。

**Recommend:** 选区尺寸过大。

**Assessment:** terminology_consistency. PaintDocument checks transformed selection bounds. 选区 precisely matches neighbouring controls; current 选择范围 is not a whole-canvas assertion.

### string/ui_the_full_image_and_working_buffers_exceed_the — ACCEPT (P1)

**English:** The full image and working buffers exceed the current safe budget, or Android could not allocate them. Resize a copy to edit it. Your original file will stay unchanged.

**Current:** 完整图片及工作缓冲区超出目前安全上限，或 Android 无法配置所需内存。请调整一份副本的大小后再编辑。原始文件不会改变。

**Author proposal:** 完整图片及工作缓冲区超出当前安全上限，或 Android 无法分配所需内存。请调整一份副本的大小后再编辑。原始文件不会改变。

**Recommend:** 完整图片及工作缓冲区超出当前安全上限，或 Android 无法分配所需内存。请调整一份副本的大小后再编辑。原始文件不会改变。

**Assessment:** technical_precision. The two alternative causes, copy resizing and unchanged original are preserved. 分配 is more explicit Mainland allocation vocabulary; regional 配置所需内存 is not categorically wrong. This is technical precision, not proof that current text instructed the user to reconfigure memory.

### string/ui_this_file_is_not_a_supported_image_use — ACCEPT (P1)

**English:** This file is not a supported image. Use PNG, JPEG, JPEG XL, WebP, HEIC, AVIF, BMP, GIF, DIB, TIFF, ICO, PDF or Base64 image text.

**Current:** 此文件不是支持的图片。请使用 PNG、JPEG、JPEG XL、WebP、HEIC、AVIF、BMP、GIF、DIB、TIFF、ICO、PDF 或 Base64 图片文字。

**Author proposal:** 此文件不是支持的图片。请使用 PNG、JPEG、JPEG XL、WebP、HEIC、AVIF、BMP、GIF、DIB、TIFF、ICO、PDF 或 Base64 编码的图片文本。

**Recommend:** 此文件不是支持的图片。请使用 PNG、JPEG、JPEG XL、WebP、HEIC、AVIF、BMP、GIF、DIB、TIFF、ICO、PDF 或 Base64 编码的图片文本。

**Assessment:** clarity_or_grammar. Every supported format is retained. Base64 编码的图片文本 disambiguates encoded image data from text visible inside an image, consistent with TextImageCodec/ImportFiles normalization. Current Base64 context already helps the intended reading, so this is clarity rather than a newly added supported format.

### string/ui_tool_categories — ACCEPT (P1)

**English:** Tool categories. Scroll to see more tools

**Current:** 工具分类。卷动查看更多工具

**Author proposal:** 工具分类。滚动查看更多工具

**Recommend:** 工具分类。滚动查看更多工具

**Assessment:** regional_terminology. 滚动 is conventional Mainland wording; current 卷动 is meaningful. No literal production consumer was found in the frozen source, so acceptance is complete-value wording-only, not runtime reachability or accessibility certification.

## Separate P2 Top

English: Top. Current: 顶层. Recommend: 上. Verdict: ACCEPT.

Same ImageCropDialog edge map and top-coordinate trim calculation as Bottom. 顶层 denotes stacking order, not top margin. 上 matches 左/右 and recommended 下 and composes as 上裁减量（像素/百分比）. This separate P2 finding does not increase P0/P1 review credit.

## Evidence limits

- No production source changes, builds, Gradle, APK, CI, runtime, application tests, device checks, publication or release actions.
- Only temporary review receipts were written; source tree remains clean.
- No native-speaker certification, rendered layout, TalkBack pronunciation, Android resource routing or functional execution certification.
- Later ef46e8aa code is not reviewed by this receipt. Consumer binding is to b9b148d5.
- Source-only ui_tool_categories has no literal production consumer found; this does not prove unreachability.

PR86 colour evidence remains delta-only. The complete current/proposed colour value was read in this pass, not retroactively attributed to PR86.

Source tree: b9b148d5d8ef7c7b088500a9c177f9f59304b800. Full hashes, exact complete values, consumer links and classifications are in independent-receipt.json.
