# AN Paint Cebuano P0 + P1 complete-value review

Date: 21 October 2026. Language: Cebuano (ceb, values-b+ceb).

## Outcome

All 341 priority identities were reviewed as complete English/Cebuano pairs: 92 P0 and 249 P1. The catalogue contains 717 identities, but this is not a 717-value or whole-language review.

- 329 retained after this AI-assisted review: 89 P0 and 240 P1.
- 10 proposed corrections or clarity improvements, all unapplied: 3 P0 and 7 P1.
- 2 explicit P1 holds. Neither is silently accepted or patched.
- 311 identities have located direct production references; 30 have no located direct reference and are explicitly wording-only. Among the latter: 27 retained wording-only, one proposed wording-only clarification, two holds.
- Every ledger row contains the full English/current/proposed value (null proposed value on a hold), exact XML, hashes, individual linguistic reasoning, consumer references, confidence and limits. All 341 entries received individual linguistic notes, not merely token or placeholder checks.

The three most consequential candidates concern Undo restoring removed pixels, a save that is still in progress, and the crop region that will be retained rather than cut away. These are wording/interpretation risks, not evidence of observed runtime data loss. Other proposals are bounded clarity improvements; they must not be portrayed as ten severe application bugs.

## Source binding and prior evidence

The inspected local source tree is b9b148d5d8ef7c7b088500a9c177f9f59304b800, matching the parent-supplied published 4355869e2e198b5616419291cba225b018444fab tree binding. The local commit ID differs and is recorded in source-binding.json. Later develop ef46e8aa changes to Fit/status consumers were reported by the parent as resource-neutral; those changed code consumers were not re-executed or independently re-reviewed in this pinned packet.

The reset of earlier localization acceptance, including PR #3, remains in force. The 22 previous union receipts all match their complete current English/Cebuano pairs, with original confidence, scope and uncertainty preserved. Only ui_sampled_resize_memory_explanation intersects this priority batch. The other 21 include PR #64's TIFF description, which remains outside priority.

A separate fresh read of PR #86 comment https://github.com/c933103/AN-Paint/pull/86#issuecomment-6183064757 reconciled save20_unsupported_image_colour. Its exact current UTF-8 SHA-256 is 7736cdbe847e4dc2aa2d6bcb9aa23716dbebf45576a245caee63c98f2d2067cd. The original medium confidence and inherited mausab terminology limit remain. This is one narrow message, not a full-language receipt.

Thus two distinct priority identities already had bounded receipts, and 339 had no mapped prior priority receipt. Do not call this 341 entirely new entries, add overlapping receipts twice, or turn new source review into restored historic acceptance.

## Review method and confidence

The pass considered complete clauses, naturalness, grammar, technical borrowing, command versus status, state/consequence distinctions, actual static consumers and composed values. Save/Discard/Keep editing, source-copy preservation, recovery steps, original-size versus Fit, crop-versus-delete, tap-versus-hold, palette colours, tool names, numeric bounds and all placeholder arguments were specifically examined.

Retained values and proposals are medium-confidence AI-assisted judgments. No native speaker or human linguist reviewed this batch. Borrowed technical words are not automatically defects; not every stylistic alternative is necessary. In particular, katimbangan has an attested proportion sense and was not declared lexically wrong; Haw-asa has an empty/unload sense and was not replaced on a false assumption. The source-linked dictionary spot checks in language-references.json support only lexical observations, not whole-sentence or specialist-UI certification.

Consumer references and composed examples are static evidence. No direct-reference match does not prove dead code; a match does not prove visible/reachable UI. Actual rendering, TalkBack speech, truncation, native-user comprehension and runtime behavior remain unverified.

## Holds

1. ui_foreground_background_colour_palette: no current direct consumer establishes the third substitution's values. Its standalone foreground/background clauses are understandable, but composed palette-state acceptance is withheld until the actual modifier values are known.
2. ui_pinch_and_pan_mode: the current label names magnification/panning but omits the explicit pinch gesture and mode framing. No current direct consumer was found. Establish intended use before choosing a faithful gesture label; no speculative patch was supplied.

## Unapplied proposals

### P0 string/save20_destination_error

Kind: optional_clarity. Severity: low. Confidence: medium. Scope: direct_static_source.

English: The completed image could not replace its destination.

Current: Dili mapulihan sa nahuman nga hulagway ang destinasyon niini.

Proposed: Dili mapulihan sa nahuman nga hulagway ang file sa destinasyon niini.

Destination is translated literally but the consumers rename a temporary output to a destination file. The proposed clarification names that file without claiming a successful replacement or loss.

### P0 string/ui_keeps_pixels_at_the_top_left_smaller_canvas

Kind: restoration_relation_correction. Severity: medium. Confidence: medium. Scope: direct_static_source.

English: Keeps pixels at the top left. Smaller canvas dimensions discard pixels beyond the right/bottom edge; Undo restores them.

Current: Gipabilin ang mga pixel sa wala nga ibabaw. Ang mas gamay nga canvas motangtang sa mga pixel lapas sa tuo/ubos nga kilid; ang I-undo mobalik niini.

Proposed: Gipabilin ang mga pixel sa wala nga ibabaw. Ang mas gamay nga canvas motangtang sa mga pixel lapas sa tuo/ubos nga kilid; maibalik kini pinaagi sa I-undo.

The pixel-loss warning is present, but ang I-undo mobalik niini weakens the transitive restoration relation. Proposed maibalik kini pinaagi sa I-undo explicitly says the removed pixels can be restored by Undo, retaining the top-left anchor and right/bottom loss.

### P0 string/ui_the_draft_is_saving_try_again_shortly

Kind: ongoing_state_clarification. Severity: medium. Confidence: medium. Scope: direct_static_source.

English: The draft is saving. Try again shortly.

Current: Gitipigan ang draft. Sulayi pag-usab sa makadiyot.

Proposed: Nagpadayon pa ang pagtipig sa draft. Sulayi pag-usab sa makadiyot.

The current Gitipigan can be read as already kept/saved although the consumer rejects editing while autosaving. Proposed Nagpadayon pa ang pagtipig explicitly marks an operation still in progress and keeps the retry instruction.

### P1 string/ui_autosaving_draft

Kind: ongoing_state_clarification. Severity: low. Confidence: medium. Scope: direct_static_source.

English: Autosaving draft…

Current: Gi-autosave ang draft…

Proposed: Gi-autosave pa ang draft…

Gi-autosave plus ellipsis suggests activity but can also read as completed. Adding pa makes the ongoing busy state explicit without changing the borrowed autosave term or requiring a longer status label.

### P1 string/ui_colour_palette_tap_for_foreground_hold_for_background

Kind: gesture_clarity. Severity: low. Confidence: medium. Scope: direct_static_source.

English: Colour palette. Tap for foreground; hold for background. Scroll for more colours.

Current: Paleta sa kolor. I-tap para sa atubangan; pislita ug dugay para sa likod. I-scroll para sa dugang nga mga kolor.

Proposed: Paleta sa kolor. I-tap para sa atubangan; pislita ug kupti para sa likod. I-scroll para sa dugang nga mga kolor.

Both foreground/background selection and scrolling remain. Proposed pislita ug kupti makes the long-press gesture explicit; the old pislita ug dugay is understandable but less precise as an instruction.

### P1 string/ui_colour_tap_foreground_hold_background

Kind: gesture_clarity. Severity: low. Confidence: medium. Scope: direct_static_source.

English: Colour #%1$s. Tap foreground, hold background.

Current: Kolor #%1$s. I-tap para sa atubangan, pislita ug dugay para sa likod.

Proposed: Kolor #%1$s. I-tap para sa atubangan, pislita ug kupti para sa likod.

The hex slot and the different tap/hold actions remain. The same press-and-hold clarification is proposed as in the palette-level description.

### P1 string/ui_crop_preview_drag_an_edge_or_corner_drag

Kind: crop_referent_clarification. Severity: medium. Confidence: medium. Scope: direct_static_source.

English: Crop preview. Drag an edge or corner; drag inside to move the crop.

Current: Pasiunang tan-aw sa pag-crop. I-drag ang kilid o kanto; i-drag ang sulod aron ibalhin ang bahin nga putlon.

Proposed: Pasiunang tan-aw sa pag-crop. I-drag ang kilid o kanto; i-drag sulod sa crop aron ibalhin kini.

Bahin nga putlon can be understood as the part to cut away although the draggable crop rectangle is the retained region. The proposed instruction names the crop directly, preserving edge/corner dragging and inside dragging without reversing retain/remove semantics.

### P1 string/ui_d_d_px_d_pixels_2f_mp

Kind: explicit_count_label. Severity: low. Confidence: medium. Scope: direct_static_source.

English: %1$d × %2$d px · Pixel count: %3$,d (%4$.2f MP)

Current: %1$d × %2$d px · %3$,d pixels (%4$.2f MP)

Proposed: %1$d × %2$d px · Gidaghanon sa mga pixel: %3$,d (%4$.2f MP)

The current numbers and units are correct but omit the English Pixel count label. The candidate explicitly labels the total pixel count, retaining every typed placeholder and not changing the calculated value.

### P1 string/ui_left_arrow_collapse

Kind: optional_direction_clarity. Severity: low. Confidence: medium. Scope: wording_only_no_direct_consumer.

English: Left arrow: collapse

Current: Wala nga pana: i-collapse

Proposed: Pana paingon sa wala: i-collapse

Wala nga pana can be parsed less clearly than an explicit arrow pointing left. Proposed Pana paingon sa wala disambiguates direction; no direct current consumer was found, so this is wording-only precision.

### P1 string/ui_scales_the_image_unlock_the_ratio_to_stretch

Kind: optional_control_term_clarity. Severity: low. Confidence: medium. Scope: direct_static_source.

English: Scales the image. Unlock the ratio to stretch width and height independently.

Current: Usbon ang gidak-on sa hulagway. Ablihi ang pagkandado sa katimbangan aron bulag nga mabitad ang gilapdon ug gitas-on.

Proposed: Usbon ang gidak-on sa hulagway. I-unlock ang aspect ratio aron bulag nga mausab ang gilapdon ug gitas-on.

The meaning of unlocked independent width/height scaling is present. Candidate wording reuses the actual aspect ratio control term and says the dimensions can change separately instead of a literal pulling metaphor; katimbangan itself is not rejected as a lexical error.

## Artifact-only validation

The candidate XML parses and retains all 717 identities. Exactly ten priority string values differ and no non-priority value changes. All effective priority placeholder signatures match the English source; signatures are unchanged from current values across the full candidate catalogue. The ui_save_a5d0d9 alias was resolved to ui_save rather than treated as visible raw text. git apply --check confirms that the patch can apply to the pinned tree, without applying it.

These checks validate the review artifacts, not translation correctness or app behavior. No build, Gradle task, APK, CI run, application test suite, runtime/device check, production edit, publication, merge or release was performed. The source working tree remained clean. The candidate and patch are unapplied and do not establish full-priority or whole-locale acceptance.

## Files

- cebuano-p0-p1-341-review.json and cebuano-p0-p1-review.csv: full ledger.
- correction-proposals.json and holds.json: exact focused decisions.
- cebuano-priority-candidate.patch and candidate/: unapplied ten-value candidate.
- priority-input.json, source-binding.json, consumer-index.json and selected-consumer-evidence.txt: exact source/value and static consumer bindings.
- composed-examples.json: fully substituted static examples using actual located callers and companion labels, not an extra counted review batch.
- prior-union-receipts.json and pr86-narrow-receipt.json: exact prior evidence reconciliation with original limits; pr86-source-comment.json preserves the source comment.
- language-references.json: lexical reference support and retrieval limitations.
- validation.json, summary.json and SHA256SUMS.json: checks, counts and artifact integrity.
- linguistic-notes.tsv: the 341 individual review notes in manifest order.

Scripts only assemble and validate this review packet from explicit judgments. They do not mechanically establish linguistic correctness. Files are temporary handoff artifacts; no durable repository publication was performed by this reviewer.
