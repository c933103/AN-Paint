# Existing-ledger open-item review, 20 October 2026

Source: `0134e79c588a027bbd239f7685fff52b0771819f` (develop snapshot). Scope is exactly the 40 existing-ledger pairs held by the current audit, not a new catalogue-wide review.

## Results

- 18 complete current values accepted after fresh linguistic and actual-caller review. These include obsolete gallery-handler/converter findings and corrected no-credit/redirect/unit/accessibility wording.
- 7 concrete localized repairs proposed: four live processed-image counters, the dormant French seven-slot normalization hint, the dormant Japanese full-image-copy warning, and the complete dormant Japanese main-editor Help value.
- 3 additional coordinated dormant source/locale cleanups proposed: remove the unsupported universal selected-background claim from the retained legacy memory message. The matching English cleanup is mandatory for this proposal; current active resize already uses separate neutral text.
- 3 current assembly Help target values are sound against the implementation and contain already-merged repairs. Their pairing with develop's stale English remains explicitly held; PR122 is an editorial reference, not merged source.
- 3 generic-busy context holds remain until the specific caller is corrected/verified. A one-line proposed caller replacement uses the already-existing neutral operation-wait message and keeps the genuine autosaving caller unchanged.
- The original French dormant manual placement/alignment defect is resolved, but its dormant old-layout, generic-background and unconditional-gap claims prevent broad current-runtime acceptance.
- 5 specialist whole-statement idiom holds remain. No guessed replacement or acceptance is invented.

`review.json` provides all 40 full English/current/proposed values, exact-source bindings, individual decisions, rationale, production context and original receipts. `corrections.json` extracts the ten full localized proposals. `caller-corrections.json` gives the one shared caller change with its three language contexts. `historical-comments.json` preserves the exact five original GitHub review comments consulted. `validation.json` records source/value/placeholder/paragraph checks and dormant-reference searches.

The Japanese full-image-copy and complete-main-Help proposal hashes reproduce the historical independently accepted proposals (respectively `410c134c8023e6e26533c00f48d1202d70c37d77a34fa2593703a91611bef187` and `3ce9e01c572e46af6f02afdee8125ac10fa2c8c924c45dcc9c44e2e952098c45`). That corroboration is additional to this fresh full-message review, not a substitute for it.

## Important boundaries

The original processing review accepted complete replacement candidates but marked them unapplied. Later tracker prose calls the four entries “paused”; the records inspected do not themselves establish an explicit owner stop or a tool denial. Any separately verified restriction must be honored. This report makes no permission decision and has applied no repository edits.

Dormant text is not a demonstrated live UI defect. The Japanese legacy Help proposal fixes the missing Save/Save as/export/dirty-state meaning but does not certify every old layout or background statement as current. The French manual's already-corrected direction sentence is not a reason to accept its entire runtime context.

All full messages were read, including eight paragraphs in each current assembly Help and ten paragraphs in each dormant main-editor Help. Mechanical binding checks do not establish fluency. Native-speaker, installed-device/layout, runtime and whole-language acceptance are not claimed. No application or repository file was edited.

## Independent review completed

The ten proposals received independent full-message/caller review. Use `accepted-corrections.json` for integration: five accepted unchanged, one French dimension-label clause independently refined and accepted, three memory cleanups conditional on the matching English change, and the Japanese full-Help correction accepted within its preserved dormant-context limits. Original `corrections.json` remains intact because the independent receipts bind its file hash. The independent report is `/tmp/an-independent-corrections/open-independent-review.json`. The French final candidate uses « pour « %6$s » » instead of the awkward article-less « de %6$s » construction. No proposal has been applied.
