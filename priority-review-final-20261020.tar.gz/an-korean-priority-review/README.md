# Korean ko-KR P0/P1 linguistic review

Source: `0134e79c588a027bbd239f7685fff52b0771819f` in c933103/AN-Paint.
Canonical catalogue: `Paintroid/src/main/res/values-b+ko+KR/strings.xml`.

## Result

All 341 priority identities were read as complete English/Korean messages: 92 P0 and 249 P1.

- 327 current values accepted within the documented static/source-only scope.
- 10 full-string correction proposals; all 10 independently accepted unchanged. They are **not applied** to repository source by this review.
- 3 uncertainty holds because current production context is absent.
- 1 exact-current earlier sampled-memory review retained without new coverage.

Thus there are 340 new full-value review dispositions, but only 327 newly accepted current pairs. The 10 old values requiring correction and 3 uncertain values receive no current acceptance credit. The earlier sampled-memory receipt is not counted twice.

## Deliverables

- `review.json`: complete per-entry artifact, exact full English/current Korean/proposed Korean, manual linguistic rationale, disposition, placeholders, alias resolution, source hashes, source-line URLs, production caller snippets and limits.
- `review.tsv`: compact full-value companion (text fields JSON-escaped).
- `correction-proposals.json`: the ten complete proposed strings with callers and reasons.
- `summary.json`: counts and acceptance limits.
- `validation.json`: integrity checks only; not a substitute for linguistic review.
- `manual-rationales.tsv`: individually authored rationale for every identity; correction rationales are in `proposals.py` and resolved in `review.json`.
- `callers.txt`: static caller excerpts gathered for inspection.
- `source-rows.json` / `source-rows.txt`: initial paired inventory.
- `build_evidence.py`: packages judgments and verifies source/value integrity; does not translate, infer acceptance or modify the application.
- `composition-context.json`: exact out-of-scope/in-scope dependencies read for composition, with illustrative static substitutions. It grants no extra entry acceptance.

Independent proposal review: `/tmp/an-independent-corrections/korean-independent-review.json`; the per-entry independent receipt paths and SHA-256 identities are recorded in `review.json`.

## Findings

The most concrete UI issue is the main canvas accessibility instruction referring to “탐색 모드”, while the live Navigate tool is labelled “이동 및 확대·축소”. The proposed instruction uses the actual label and explains the pinch gesture in ordinary Korean. Other proposals restore explicit foreground/background **colour** labels, clarify canvas anchoring, repair awkward memory-warning grammar, and make smaller wording/spacing improvements. Severity is recorded per proposal type; these are not all equivalent functional defects.

## Explicit holds

- `string/ui_discard`: bare English “Discard” becomes “Discard changes”; no current caller proves its referent.
- `string/ui_save_as`: the Korean assumes `%1$s` is a format; no current caller establishes that token contract.
- `string/ui_main23`: “Main” becomes “기본” (basic/default); the missing section context prevents a confident judgment.

No replacement is invented for these three. A demonstrated caller or explicit intended UI role is needed.

## Scope and limits

This is manual model/source-assisted Korean review, not native-speaker certification, a whole-language certificate, or Android runtime acceptance. Thirty identities have no directly found production caller; their individual records say so. Of those, 27 have straightforward bounded source-wording acceptance and three remain uncertain. All caller/source paths and bytes are pinned to the source commit. Source-only acceptance does not prove live usage.

No P2/P3 entry is accepted by this batch. All 341 priority identities are strings, so no plural resource is in scope; Korean number-neutral wording and composed frame counts were still checked. The alias `ui_save_a5d0d9` is retained and its short target is explicitly resolved; it is not silently treated as literal translated content.

No app/repository edits, builds, installed UI tests, screenshots, TalkBack tests or publishing were performed. Structural checks establish identity, hashes and placeholder transcription only. Corrections need integration and normal source-bound resource/runtime checks before claiming the application contains the reviewed wording. Changed source or callers require reassessment.
