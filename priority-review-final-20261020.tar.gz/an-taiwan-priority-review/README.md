# Traditional Chinese (Taiwan) P0 + P1 review

Source revision: `0134e79c588a027bbd239f7685fff52b0771819f` (AN Paint develop).
Locale: `zh-TW`, `Paintroid/src/main/res/values-zh-rTW/strings.xml`.
Review date: 20 October 2026. Native chat-side source-context linguistic review.

## Result

All 341 priority identities were read in full: 92 P0 and 249 P1. They are all strings; the catalogue's plural is P2 and is outside this batch.

- 293 newly accepted complete strings with current live source caller context
- 27 newly accepted complete source-only strings, without current UI-context credit
- 1 existing exact-current bounded PR56 receipt, re-read without new coverage credit
- 18 complete correction proposals, independently accepted unchanged; none applied by this worker
- 2 source-only context holds, receiving no acceptance credit

There are 311 directly referenced production entries and 30 source-only entries in total. Source-context acceptance does not mean runtime/device verification. The entire locale is not certified complete. The 376 P2/P3 identities are not covered by this review.

The sole pre-existing overlap is `string/ui_sampled_resize_memory_explanation`. Its English/localized value hashes were checked against the current PR56 ledger. Later-cohort reconciliation reported no additional accepted zh-TW P0/P1 pairs. Withdrawn historical audit conclusions supplied no acceptance or coverage.

## Important corrections

`language20_translation_note` currently asserts that the locale contains every translatable interface string. The proposed full message restores the app-language heading, language-resource maintenance explanation, and English fallback. This is a substantive live P1 misstatement.

Other proposals replace Hong Kong-oriented 等闊/角位 and the non-Taiwan computing term 十六進制, explain the canvas pinch gesture directly, clarify returning from Navigate to drawing, translate visible FG/BG captions, repair awkward memory/trim wording, and preserve the Save… continuation ellipsis lost through an alias. Recovery instructions use Taiwan 解壓縮 and retain the ZIP/canvas.png/menu paths.

All 18 proposals were independently reviewed against actual XML and callers, accepted unchanged, and recorded in `independent-correction-review.json` (SHA-256 `73a1ea5172e37950f6d9485f66237f367f3291495fc7fe6921bd658083206ab5`). This is proposal acceptance, not proof of application or tests on a future integrated commit.

## Holds

- `string/ui_foreground_background_colour_palette`: no live caller supplies the third argument, so the grammar/meaning of the complete state-plus-palette phrase cannot be accepted.
- `string/ui_main23`: no current caller establishes what “Main” names; the current 主要 is an adjective, but selecting 主畫面 or 主選單 would invent context.

The corrected `string/ui_discard` is also source-only. The generic source label will become 捨棄 rather than the unsupported specific 捨棄變更. It does not gain live UI-context credit.

## Artifacts

- `review.json`: full per-entry English/current/proposed wording, resolved alias wording, individual linguistic decisions/rationales, direct source caller excerpts, source links, blob/value hashes and scope
- `entry-ledger.json`: the same decisions with large caller excerpts removed; suitable as a compact machine-readable ledger
- `full-entry-review.md`: readable full-string review for all 341 identities
- `proposed-corrections.json` and `.md`: all 18 complete proposals for integration
- `context-holds.json`: the two held entries
- `summary.json`: machine-readable count/scope summary
- `source-manifest.json` and `source-snapshot/`: 42 bound input files (English/Taiwan resources, manifest, instructions/prioritization and 37 caller files), including exact Git blob and SHA-256 identities
- `validation-result.json`: independent identity/reference/binding-check result
- `structural-checks.json`: per-entry proposed placeholder checks
- `validate_review.py`: read-only independent validator
- `decisions.tsv`: the manually authored entry-specific linguistic rationale set

Android escape sequences are retained in resource values and hashes. The display-wording fields resolve resource aliases but keep newline escapes visible for exact comparison. In particular, `ui_save_a5d0d9` currently resolves from `@string/ui_save` to 儲存; the proposal is the complete literal 儲存….

## Method and limits

The review read every full English/localized value, the priority definitions and current repository instructions. It examined current production callers and their surrounding operation paths: save/export/share/replacement, animation/still and PDF import, recovery/autosave/Undo, memory-budget and resize choices, crop/assembly, menu/tool/selection behavior, color controls, text styling, dimensions, numeric-entry accessibility and language selection. Composed messages were checked against supplied arguments and sibling labels, including animation “at least” frame counts, numeric limits, format names, color hex values, unit labels, category/tool labels, status fragments, and quoted recovery/menu paths. Source-only labels are explicitly separated rather than presented as current UI coverage.

The linguistic decisions are not inferred from placeholder equality or structural tests. The separate validator passed: 341 unique keys exactly equal the P0/P1 manifest, complete values match the bound Git source, file/value hashes and source lines agree, and all direct references were independently recomputed from 134 tracked production Kotlin/Java/XML files. The effective locale alias graph supplies no callers for the 30 source-only entries.

No application/repository edits, commits, publication, Android builds, emulator/device tests, runtime accessibility tests or screenshot/glyph-fit validation were performed. In particular, the new 前景/背景 swatch captions still need rendered-fit verification. Root owns applying independently accepted corrections, testing, binding to the resulting exact head and publishing the durable record. Current-text correction proposals and context holds are not counted as accepted current entries.
