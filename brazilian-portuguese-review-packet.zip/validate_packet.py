"""One-time evidence audit. Explicit failures remain active under python -O."""
from pathlib import Path
import json, hashlib, sys, stat, copy, xml.etree.ElementTree as ET
O=Path(__file__).resolve().parent; S=O/'source'; W=O/'worktree'
sys.path.insert(0,str(W/'tools'))
import translation_catalogues as catalogues
from current_localization_contracts import require_string, require_wording_shape

def check(ok,message):
    if not ok: raise ValueError(message)
def read(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def vh(v):return sha(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def strings(p):return {n.get('name'):''.join(n.itertext())for n in ET.parse(p).getroot() if n.tag=='string'}

tree=read(O/'develop-tree.json');check(not tree['truncated'],'Truncated source tree')
expected={r['path']:r for r in tree['tree']if r['type']=='blob'}
source_paths={str(p.relative_to(S))for p in S.rglob('*')if p.is_file() and '__pycache__'not in p.parts}
check(source_paths==set(expected),'Source inventory differs')
for rel,r in expected.items():
    p=S/rel;check(blob(p.read_bytes())==r['sha'],'Source identity: '+rel)
    check(('100755'if p.stat().st_mode&stat.S_IXUSR else '100644')==r['mode'],'Source mode: '+rel)
report=read(O/'brazilian-portuguese-p0-p1-341-review.json');rows=report['entries']
check(len(rows)==341 and len({r['key']for r in rows})==341,'341 unique pairs')
check([r['n']for r in rows]==list(range(1,342)),'Ordered per-entry review')
priorities=read(S/'translations/string-importance.json')
keys=[(g['id'],k)for g in priorities['tiers']if g['id']in {'P0','P1'}for k in g['keys']]
check([(r['tier'],r['key'])for r in rows]==keys,'Exact priority batch')
path='Paintroid/src/main/res/values-pt-rBR/strings.xml'; enpath='Paintroid/src/main/res/values/strings.xml'
en=strings(S/enpath);old=strings(S/path);new=strings(W/path)
translatable={n.get('name')for n in ET.parse(S/enpath).getroot()if n.tag=='string' and n.get('translatable')!='false'}
check(translatable==set(old)==set(new),'Complete translatable string catalogue')
check(len(translatable)==716 and len(ET.parse(S/path).getroot().findall('plurals'))==1,'717 canonical entries: 716 strings and one plural family')
for r in rows:
    key=r['key'].split('/')[1]
    check(r['english']==en[key] and r['portuguese']==old[key],'Complete baseline values: '+key)
    check(r['english_value_sha256']==vh(en[key]) and r['localized_value_sha256']==vh(old[key]),'Value hashes: '+key)
    check(bool(r['linguistic_assessment']) and 'not native-speaker' in r['review_method'],'Individual scope: '+key)
    for c in r['consumer_context']:
        b=(S/c['path']).read_bytes(); lines=b.decode().splitlines(); lo=c['snippet_start']-1
        check(c['source_git_blob_sha']==blob(b) and c['source_sha256']==sha(b),'Consumer identity')
        check(c['snippet']=='\n'.join(lines[lo:lo+len(c['snippet'].split('\n'))]),'Exact consumer snippet')
        check('/main/'in c['path'],'Nonproduction consumer mixed into evidence')
check(sum(r['tier']=='P0'for r in rows)==92 and sum(r['tier']=='P1'for r in rows)==249,'Tier counts')
from collections import Counter
check(dict(Counter(r['state']for r in rows))==report['counts'],'Counts')
check(sum(not r['consumer_context']for r in rows)==30,'Unreferenced scope')
receiptbytes=(O/'prior-receipts.json').read_bytes()
check(blob(receiptbytes)=='004a38a070bc4ea215a82fdd41028aac5e341f3b','Preserved PR56 receipt identity')
receipts={r['key']:r for r in json.loads(receiptbytes)['receipts']if r['tag']=='pt-BR'}
for r in rows:
    check(r['prior_tracker_record']==receipts.get(r['key']),'Prior record overwritten')
    if r['state']=='prior_exact_receipt_retained':
        check(r['prior_tracker_record']['current_english_sha256']==vh(r['english']),'Prior English stale')
        check(r['prior_tracker_record']['current_localized_sha256']==vh(r['portuguese']),'Prior target stale')
adoption=read(O/'candidate-adoption.json'); accepted=adoption['accepted_candidates']; ks={r['key'].split('/')[1]for r in accepted}
check(len(accepted)==8 and len(ks)==8,'Eight candidate corrections')
check({k for k in old if old[k]!=new[k]}==ks,'Exactly eight changed strings')
for r in accepted:
    key=r['key'].split('/')[1]
    check((r['english'],r['before'],r['after'])==(en[key],old[key],new[key]),'Candidate triple: '+key)
    check((r['before_sha256'],r['after_sha256'])==(vh(old[key]),vh(new[key])),'Candidate hash')
    check(catalogues.placeholders(en[key])==catalogues.placeholders(new[key]),'Typed arguments')
check(len(adoption['preserved_holds'])==3,'Three preserved holds')
for r in adoption['preserved_holds']:
    check(new[r['key'].split('/')[1]]==r['value'],'Hold modified')
root_old=ET.parse(S/path).getroot();root_new=ET.parse(W/path).getroot()
check([n.attrib for n in root_old]==[n.attrib for n in root_new],'Attributes or ordering changed')
for c in read(O/'supplemental-consumer-context.json'):
    b=(S/c['path']).read_bytes();lines=b.decode().splitlines()
    check(c['git_blob_sha']==blob(b) and c['sha256']==sha(b),'Supplemental file')
    for r in c['ranges']:check(r['text']=='\n'.join(lines[r['start']-1:r['end']]),'Supplemental snippet')
delta=read(O/'application-delta.json'); dp={r['path']for r in delta};check(len(delta)==4,'Four application files')
for r in delta:
    b=(W/r['path']).read_bytes();check(r['git_blob_sha']==blob(b) and r['sha256']==sha(b),'Application delta identity')
    check(not (W/r['path']).stat().st_mode&stat.S_IXUSR,'New file mode')
for rel,r in expected.items():
    p=W/rel
    if rel not in dp:check(blob(p.read_bytes())==r['sha'],'Unintended retained content: '+rel)
    check(('100755'if p.stat().st_mode&stat.S_IXUSR else '100644')==r['mode'],'Retained mode: '+rel)
# Exercise all eight old values against the exact committed fixture. No edits to the checkout.
f=read(W/'tools/fixtures/current_localization/brazilian_portuguese_priority_current_wording.json')
require_wording_shape(f,ks,{'default','pt-BR'}); rejected=[]
for key in sorted(ks):
    root=ET.parse(W/path).getroot();root.find(f"./string[@name='{key}']").text=old[key]
    try:require_string(ET.tostring(root,encoding='unicode'),key,f['values'][key]['pt-BR'],f['constraints'][key]['pt-BR'])
    except ValueError:rejected.append(key)
    else:raise ValueError('Old value negative control accepted: '+key)
result={'status':'pass','python_optimized':not __debug__,'source_revision':report['source_revision'],'source_files_verified':len(expected),'reviewed_pairs':341,'P0':92,'P1':249,'candidate_changes':8,'three_holds_preserved':True,'prior_receipt_ledger_git_blob':blob(receiptbytes),'old_value_negative_controls_rejected':rejected,'application_delta_files':4,'not_claimed':['Native-speaker approval','Whole-language acceptance','Android JVM execution','Installed runtime/layout/TalkBack acceptance']}
print(json.dumps(result,ensure_ascii=False,indent=2))
