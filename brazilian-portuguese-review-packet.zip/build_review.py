from pathlib import Path
import json, hashlib, xml.etree.ElementTree as ET, re, difflib, collections
from xml.sax.saxutils import escape

O = Path(__file__).resolve().parent
S = O / 'source'
REV = '75d56c8c9597f135799d2a3aac84c1e8aa3ee2a4'
TRACK = 'cc1d2718b88b9f08e25b3013ccdbc10770e7f332'
PATH = 'Paintroid/src/main/res/values-pt-rBR/strings.xml'
ENPATH = 'Paintroid/src/main/res/values/strings.xml'
def sha(b): return hashlib.sha256(b).hexdigest()
def vh(v): return sha(json.dumps(v, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode())
def blob(b): return hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
def write(p, x): p.write_text(json.dumps(x, ensure_ascii=False, indent=2) + '\n')

P = json.loads((O / 'pairs.json').read_text())
D = {int(n): (s, reason) for n, s, reason in (line.split('\t', 2) for line in (O / 'decisions.tsv').read_text().splitlines())}
if set(D) != set(range(1, 342)): raise ValueError('Every priority pair needs an individual disposition')
C = {
    'ui_recovery_copy_exported_extract_canvas_png_from_the': 'Cópia de recuperação exportada. Extraia canvas.png do ZIP e abra essa imagem com Arquivo > Abrir imagem. O ZIP também contém as configurações do rascunho e qualquer seleção flutuante.',
    'language20_translation_note': r'Idioma do aplicativo\n\nAs traduções são mantidas nos recursos de idioma do AN Paint. Textos novos ou não traduzidos aparecem em inglês.',
    'ui_collapse_tool_category': '%1$s. Ferramenta selecionada: %2$s. Recolher ferramentas e opções',
    'ui_expand_tool_category': '%1$s. Ferramenta selecionada: %2$s. Expandir ferramentas e opções',
    'ui_d_d_px_d_pixels_2f_mp': '%1$d × %2$d px · Quantidade de pixels: %3$,d (%4$.2f MP)',
    'ui_drawing_canvas_pinch_and_move_two_fingers_to': 'Tela de desenho. Afaste dois dedos para ampliar e aproxime-os para reduzir o zoom. Arraste os dois dedos juntos para deslocar a visualização. No modo Navegar, também é possível deslocar a visualização com um dedo.',
    'ui_none': 'Nenhuma',
    'ui_pixels_6ec9c2': 'pixels',
}
if {p['key'].split('/')[1] for p in P if D[p['n']][0] == 'C'} != set(C): raise ValueError('Correction scope drift')
original = (S / PATH).read_text()
candidate = original
for key, value in C.items():
    pattern = r'(<string\b[^>]*\bname="' + re.escape(key) + r'"[^>]*>)(.*?)(</string>)'
    candidate, count = re.subn(pattern, lambda m: m[1] + escape(value) + m[3], candidate, flags=re.S)
    if count != 1: raise ValueError(key)
out = O / 'candidate' / PATH
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(candidate)
(O / 'eight-corrections.patch').write_text(''.join(difflib.unified_diff(original.splitlines(keepends=True), candidate.splitlines(keepends=True), fromfile='a/' + PATH, tofile='b/' + PATH)))
prior = json.loads((O / 'prior-receipts.json').read_text())
priors = {r['key']: r for r in prior['receipts'] if r['tag'] == 'pt-BR'}
elines = (S / ENPATH).read_text().splitlines()
tlines = original.splitlines()
def linefor(lines, name): return next(i + 1 for i, line in enumerate(lines) if 'name="' + name + '"' in line)
entries = []
for p in P:
    n = p['n']; key = p['key'].split('/')[1]; state, reason = D[n]
    contexts = []
    for ref in p['refs']:
        f = S / ref['path']; lines = f.read_text().splitlines(); i = ref['line'] - 1
        lo, hi = max(0, i - 5), min(len(lines), i + 7)
        contexts.append({**ref, 'source_git_blob_sha': blob(f.read_bytes()), 'source_sha256': sha(f.read_bytes()),
                         'url': f'https://github.com/c933103/AN-Paint/blob/{REV}/{ref["path"]}#L{lo+1}-L{hi}',
                         'snippet_start': lo + 1, 'snippet': '\n'.join(lines[lo:hi])})
    status = ('prior_exact_receipt_retained' if state == 'R' else 'open_correction_proposed' if state == 'C' else
              'open_terminology_or_composition' if state == 'H' else 'accepted_static' if contexts else 'accepted_catalogue_semantics_only')
    r = {**p, 'source_revision': REV, 'english_file': ENPATH, 'english_line': linefor(elines, key),
         'localized_file': PATH, 'localized_line': linefor(tlines, key),
         'english_value_sha256': vh(p['english']), 'localized_value_sha256': vh(p['portuguese']),
         'state': status, 'linguistic_assessment': reason,
         'meaning_confidence': 'unresolved' if state == 'H' else 'high',
         'idiom_confidence': 'unresolved' if state == 'H' else 'moderate' if n in {13, 27, 28, 33, 43, 56, 79, 84, 144, 264, 296, 297} else 'high',
         'review_method': 'AI-assisted full source/target reading with actual static consumer context, not native-speaker certification',
         'consumer_context': contexts,
         'consumer_status': 'current_production_references_found' if contexts else 'no_direct_current_production_reference_found; catalogue meaning only',
         'layout_status': 'not_run', 'runtime_safety_status': 'not_established_by_linguistic_review',
         'prior_tracker_record': priors.get(p['key'])}
    if state == 'R':
        old = priors[p['key']]
        if old['current_english_sha256'] != vh(p['english']) or old['current_localized_sha256'] != vh(p['portuguese']): raise ValueError('Stale prior receipt')
        r['prior_receipt_hash_match'] = True
    if key in C:
        r['proposed_localized_value'] = C[key]
        r['proposed_value_sha256'] = vh(C[key])
        r['candidate_state'] = 'proposed; separate independent assessment required before publication'
    if n == 66:
        r['alias_dependency'] = {'key': 'string/ui_save', 'localized_target': 'Salvar', 'localized_target_sha256': vh('Salvar')}
    if n == 21:
        r['prior_other_bounded_review'] = {'url': 'https://github.com/c933103/AN-Paint/pull/86#issuecomment-6183064757', 'scope': 'Prior 49-locale new colour-profile error review; not a new whole-language acceptance'}
    if n in {97, 98}:
        r['prior_other_bounded_review'] = {'url': 'https://github.com/c933103/AN-Paint/pull/29', 'scope': 'Prior bounded SVG-size message review; existing evidence is not overwritten'}
    entries.append(r)
counts = dict(collections.Counter(r['state'] for r in entries))
report = {'schema_version': 1, 'language': 'pt-BR', 'language_name': 'Brazilian Portuguese', 'source_revision': REV,
          'tracker_revision_observed': TRACK, 'source_git_tree': 'a1856f32503dce470d606ee65b88a5d1c92f0995',
          'scope': {'P0': 92, 'P1': 249, 'total': 341, 'canonical_total': 717, 'missing_targets': 0},
          'counts': counts, 'prior_evidence_policy': 'Preserve one exact priority PR56 receipt and other bounded prior review references. Do not change PR56 or mint aggregate tracker credit. Earlier PR7 broad conclusions remain withdrawn.',
          'selection': 'European Portuguese, German and Spanish recent 341-entry batches were already reviewed and corrected in merged PR109/110. Brazilian Portuguese is distinct and was not covered by those batches. Current GitHub branch/PR and local packet searches found no newer complete pt-BR priority batch.',
          'limits': ['Not whole-language acceptance or native-speaker certification.', 'P2/P3 and other locales are outside scope.',
                     '30 entries lack a direct current production reference; their meaning-only or open status does not establish live UI use.',
                     'Android rendering, TalkBack, layout and installed interaction were not run during linguistic review.',
                     'PR56 remains read-only, including its upload hold; separate processing-label holds remain unchanged.',
                     'No unmerged PR114 runtime-hardening changes are borrowed.'],
          'external_sources': [{'url': 'https://help.autodesk.com/cloudhelp/2022/PTB/AutoCAD-Core/files/GUID-EA164540-48C9-4C85-8EDB-55975D89F22A.htm', 'accessed': '2026-10-17', 'role': 'Official Brazilian Portuguese graphics documentation corroborates pontilhamento for dithering. It does not certify this catalogue.'}],
          'entries': entries}
write(O / 'brazilian-portuguese-p0-p1-341-review.json', report)
write(O / 'compact-ledger.json', [{k: r[k] for k in ['n', 'tier', 'key', 'english', 'portuguese', 'state', 'linguistic_assessment']} for r in entries])
write(O / 'corrections-and-holds.json', {'source_revision': REV, 'corrections': [r for r in entries if r['state'] == 'open_correction_proposed'], 'holds': [r for r in entries if r['state'] == 'open_terminology_or_composition']})
print(json.dumps(counts))
