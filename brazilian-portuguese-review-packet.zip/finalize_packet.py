from pathlib import Path
import hashlib, json, re, shutil, zipfile, base64
O=Path(__file__).resolve().parent; W=O/'worktree'; S=O/'source'
HEAD='76807df744b990159fa62c2a68cfe7f4558b967b'
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def write(name,v):(O/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
summaries={}
for name in ['focused-normal','focused-optimized','host-normal','host-optimized']:
    b=(O/(name+'.log')).read_bytes();t=b.decode();m=re.search(r'(?m)^Ran (\d+) tests in ([0-9.]+)s\s+OK\s*',t)
    if not m:raise ValueError('No complete successful aggregate: '+name)
    summaries[name]={'tests':int(m[1]),'seconds':float(m[2]),'exit_code':0,'log':name+'.log','log_sha256':sha(b)}
write('final-test-summary.json',{'candidate_commit':HEAD,'candidate_tree':'170487fc82abd4f5ef68533aecd02325925d77f1','checks':summaries,'one_time_packet_audit':'normal and optimized passed: all 341 pairs, baseline 1,180 blobs/modes, all eight old-value controls, prior receipts and three holds','aapt2_catalogue_compile':'passed','local_android_jvm_lint_build_link_and_device':'not_run; no installed Gradle distribution/complete SDK toolchain. Hosted exact-head results required.','limits':'Source tests and resource compilation are not fluency, layout or installed interaction certification.'})
aapt=O/'validation/aapt2/values-pt-rBR_strings.arsc.flat';exe=Path('/workspace/shared/an96-resource-repair/verification-tools/aapt2');resource=W/'Paintroid/src/main/res/values-pt-rBR/strings.xml'
write('aapt2-receipt.json',{'candidate_commit':HEAD,'command':'aapt2 compile worktree/Paintroid/src/main/res/values-pt-rBR/strings.xml -o validation/aapt2','exit_code':0,'version':'Android Asset Packaging Tool (aapt) 2.19-11948202','tool_sha256':sha(exe.read_bytes()),'input_sha256':sha(resource.read_bytes()),'output_sha256':sha(aapt.read_bytes()),'scope':'Complete pt-BR XML compilation only; no resource linking, JVM execution or installed UI verification.'})
write('validation-authoring-history.json',{'discarded_checks':[{'check':'First AAPT2 path attempt','result':'Exit126 because the existing path was a directory. Corrected to the verified executable; actual compilation then passed.','retained_log':'validation/aapt2-path-attempt.log'},{'check':'First one-time packet-validator draft','result':'Incorrectly compared all English strings including three nontranslatable archive-filename constants against716 translated strings. Corrected to translatable string scope plus one plural family; catalogue itself unchanged.'},{'check':'Second one-time packet-validator draft','result':'splitlines discarded a terminal blank snippet line. Corrected snippet-length calculation to split on newline; source snippets unchanged.','retained_log':'validation/packet-draft-snippet-count-failure.log'}],'production_adjustments_for_test_failures':'none','final_validation':'normal and optimized passed'})
# Keep product changes small; evidence gets the complete reviewed consumer files, not the entire application tree.
files={
 'README.md','brazilian-portuguese-p0-p1-341-review.json','compact-ledger.json','corrections-and-holds.json','pairs.json','pairs.txt','decisions.tsv','prior-receipts.json','input-manifest.json','develop-tree.json','candidate-full-tree.json','candidate-tree-check.json','application-delta.json','eight-corrections.patch','supplemental-consumer-context.json','candidate-adoption.json','independent-test-review.json','final-test-summary.json','aapt2-receipt.json','validation-authoring-history.json','validate_packet.py','build_review.py','make_packet.py','finalize_packet.py',
 'focused-normal.log','focused-optimized.log','host-normal.log','host-optimized.log'}
files.update(str(p.relative_to(O))for p in (O/'validation').rglob('*')if p.is_file())
files.update(str(p.relative_to(O))for p in (O/'context').rglob('*')if p.is_file())
report=json.loads((O/'brazilian-portuguese-p0-p1-341-review.json').read_text())
sourcefiles={c['path']for r in report['entries']for c in r['consumer_context']}
sourcefiles.update(['Paintroid/src/main/res/values/strings.xml','Paintroid/src/main/res/values-pt-rBR/strings.xml','translations/string-importance.json','translations/STRING_IMPORTANCE.md','tools/translation_catalogues.py','tools/current_localization_contracts.py','AGENTS.md','CI.md'])
files.update('source/'+p for p in sourcefiles)
for d in json.loads((O/'application-delta.json').read_text()):
    rel='application-candidate/'+d['path'];dest=O/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((W/d['path']).read_bytes());files.add(rel)
rows=[{'path':p,'size_bytes':(O/p).stat().st_size,'sha256':sha((O/p).read_bytes()),'git_blob_sha':blob((O/p).read_bytes())}for p in sorted(files)]
write('artifact-manifest.json',{'source_revision':report['source_revision'],'candidate_commit':HEAD,'files':rows})
with zipfile.ZipFile(O/'brazilian-portuguese-review-packet.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for p in sorted(files|{'artifact-manifest.json'}):
        info=zipfile.ZipInfo(p,date_time=(2026,10,17,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=(0o100644<<16);z.writestr(info,(O/p).read_bytes())
with zipfile.ZipFile(O/'brazilian-portuguese-review-packet.zip')as z:
    if z.testzip() is not None:raise ValueError('ZIP CRC')
    for r in rows:
        if sha(z.read(r['path']))!=r['sha256']:raise ValueError('ZIP member hash: '+r['path'])
b=(O/'brazilian-portuguese-review-packet.zip').read_bytes();write('packet-receipt.json',{'candidate_commit':HEAD,'archive':'brazilian-portuguese-review-packet.zip','files':len(rows)+1,'size_bytes':len(b),'sha256':sha(b),'git_blob_sha':blob(b),'all_member_hashes_verified':True})
(O/'packet-base64.txt').write_text(base64.b64encode(b).decode())
print((O/'final-test-summary.json').read_text());print((O/'packet-receipt.json').read_text())
