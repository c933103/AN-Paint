from pathlib import Path
import json, hashlib
O=Path(__file__).resolve().parent; S=O/'source'; W=O/'worktree'
REV='75d56c8c9597f135799d2a3aac84c1e8aa3ee2a4'
def write(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
contexts=[]
for rel,ranges,meaning in [
 ('Paintroid/src/main/java/org/catrobat/paintroid/classic/PaintCanvas.kt',[(640,668),(730,782)],'Two-finger span ratio controls zoom; focus displacement controls pan; single-finger navigation uses PaintTool.ZOOM.'),
 ('Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageImport.kt',[(13,18)],'Strictly positive dimensions include a one-pixel count. Long pixel counts are formatted with Locale.ROOT.'),
 ('Paintroid/src/main/java/org/catrobat/paintroid/classic/DimensionControls.kt',[(65,91)],'Pixel summary uses ImageDimensions.describe; accessibility captions insert lowercase pixels or porcentagem.'),
 ('Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt',[(134,162)],'None unchecks image checklist; empty selection prevents Apply; feminine Nenhuma refers to imagens.')]:
 b=(S/rel).read_bytes();lines=b.decode().splitlines()
 contexts.append({'path':rel,'git_blob_sha':blob(b),'sha256':sha(b),'meaning':meaning,'ranges':[{'start':lo,'end':min(hi,len(lines)),'text':'\n'.join(lines[lo-1:hi]),'url':f'https://github.com/c933103/AN-Paint/blob/{REV}/{rel}#L{lo}-L{min(hi,len(lines))}'}for lo,hi in ranges]})
write(O/'supplemental-consumer-context.json',contexts)
c=json.loads((O/'corrections-and-holds.json').read_text())
write(O/'candidate-adoption.json',{'schema_version':1,'source_revision':REV,'review_date':'2026-10-17','method':'Separate AI-assisted full English / old pt-BR / candidate pt-BR assessment with production consumer context. No native-speaker certification.','assessment':'All eight candidate values accepted for their bounded contexts. Fixed feminine Ferramenta avoids variable-label agreement; Nenhuma matches imagens; lowercase pixels is composed midphrase; fallback note restores new/untranslated scope; gesture text distinguishes spreading/pinching and panning. Actual gesture implementation is included separately.','accepted_candidates':[{'key':r['key'],'english':r['english'],'before':r['portuguese'],'after':r['proposed_localized_value'],'before_sha256':r['localized_value_sha256'],'after_sha256':r['proposed_value_sha256']}for r in c['corrections']],'preserved_holds':[{'key':r['key'],'value':r['portuguese'],'reason':r['linguistic_assessment']}for r in c['holds']],'baseline_policy':'Keep baseline eight open_correction_proposed dispositions intact. This candidate receipt records adoption separately and does not mint PR56 credit.','limits':['All three terminology/composition holds remain open.','Current source/static linguistic acceptance only; not installed UI, layout, accessibility technology or whole-language certification.','Prior receipts and PR56 upload hold remain unchanged.']})
paths=['Paintroid/src/main/res/values-pt-rBR/strings.xml','tools/fixtures/current_localization/brazilian_portuguese_priority_current_wording.json','tools/test_brazilian_portuguese_priority_wording.py','Paintroid/src/test/java/org/catrobat/paintroid/local/BrazilianPortuguesePriorityWordingTest.kt']
write(O/'application-delta.json',[{'path':p,'mode':'100644','sha256':sha((W/p).read_bytes()),'git_blob_sha':blob((W/p).read_bytes()),'baseline_git_blob_sha':blob((S/p).read_bytes())if(S/p).exists()else None}for p in paths])
print('Added supplemental production context and separate candidate adoption; four application files.')
