143:             }
144:         }
145:     }
146: 
147:     init {
148:         contentDescription = ui(R.string.ui_drawing_canvas_pinch_and_move_two_fingers_to)
149:         isFocusable = true
150:         setLayerType(LAYER_TYPE_SOFTWARE, null)
151:     }
152: 
153:     fun selectTool(next: PaintTool) {
154:         applyPending()

574:         canvas.drawLine(top.x,top.y,grip.x,grip.y,edge)
575:         canvas.drawCircle(grip.x,grip.y,7*d,fill);canvas.drawCircle(grip.x,grip.y,7*d,edge)
576:         val direction=VerticalText.uiDirection(context)
577:         if(direction==TextDirection.HORIZONTAL) {
578:             val text=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=edge.color;textSize=11*resources.displayMetrics.scaledDensity/zoom;typeface=VerticalText.uiTypeface(context) }
579:             canvas.drawText(ui(R.string.ui_rotate),grip.x+10*d,grip.y+4*d,text)
580:         } else {
581:             // The caller is already in document coordinates. Counter-scale only
582:             // this caption so even a 1e-9 zoom uses ordinary pixel font metrics.
583:             val pixels=resources.displayMetrics.density
584:             val text=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=edge.color;textSize=11*resources.displayMetrics.scaledDensity;typeface=VerticalText.uiTypeface(context) }
585:             val viewport=RectF(rulerInset,rulerInset,width-bar,height-bar).apply {inset(4*pixels,4*pixels)}

586:             val caption=VerticalCanvasCaption(ui(R.string.ui_rotate),text,viewport.height(),direction)
587:             val screen=toScreen(grip.x,grip.y)
588:             val selection=s.geometry.bounds()
589:             val first=toScreen(selection.left,selection.top);val last=toScreen(selection.right,selection.bottom)
590:             // Include resize-box half-width, outline stroke and antialias clearance.
591:             val avoid=RectF(first.x,first.y,last.x,last.y).apply {inset(-7*pixels,-7*pixels)}
592:             val origin=caption.beside(screen,viewport,10*pixels,avoid)
