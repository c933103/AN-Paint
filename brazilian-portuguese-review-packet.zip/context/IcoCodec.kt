95:             pngFile.outputStream().buffered().use {
96:                 if (!square.compress(Bitmap.CompressFormat.PNG, 100, it))
97:                     throw IOException(ui(R.string.ui_the_encoder_did_not_finish))
98:             }
99:             temporary.outputStream().buffered().use { IcoContainer.writePng(pngFile, edge, edge, it) }
100:             if (!temporary.renameTo(file)) throw IOException(ui(R.string.save20_destination_error))
101:         } finally { icon?.recycle(); png?.delete(); temporary.delete() }
102:     }
103: }

71: 
72:     /** Fit the source into a square icon without stretching; unused space remains transparent. */
73:     fun encode(image: Bitmap, file: File, edge: Int, budget: Long) {
74:         if (edge !in exportEdges) throw IOException(ui(R.string.formats22_ico_invalid_size))
75:         val needed = image.allocationByteCount.toLong() + edge.toLong() * edge * 8 + 4L * 1024 * 1024
76:         if (needed > budget) throw IOException(ui(R.string.save20_encoding_budget))
77:         val temporary = File.createTempFile("ico-export-", ".tmp", file.absoluteFile.parentFile)
78:         var png: File? = null
79:         var icon: Bitmap? = null
80:         try {
81:             val pngFile = File.createTempFile("ico-payload-", ".png", file.absoluteFile.parentFile)
82:             png = pngFile

16: 
17:     fun isIco(file: File): Boolean = IcoContainer.isIco(file)
18: 
19:     private fun entry(file: File): IcoContainer.Entry = try { IcoContainer.best(file) }
20:     catch (error: LegacyColourMetadata.UnsupportedColour) {
21:         throw IOException(ui(R.string.save20_unsupported_image_colour), error)
22:     }
23: 
24:     fun dimensions(file: File): ImageDimensions = entry(file).let { ImageDimensions(it.width, it.height) }
25: 
26:     /** Covers bounded PNG metadata/conversion, the full source icon, ARGB rows and the target. */
27:     fun decodeWorkingBytes(file: File, size: ImageDimensions): Long {

45:                 return imported.decode(ImportPlan.create(source, size), budget)
46:             } finally { temporary.delete() }
47:         }
48:         val pixels = try { IcoContainer.decodeDib(file, selected) }
49:         catch (error: LegacyColourMetadata.UnsupportedColour) {
50:             throw IOException(ui(R.string.save20_unsupported_image_colour), error)
51:         }
52:         val decoded = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
53:         var output: Bitmap? = null
54:         try {
55:             decoded.density = Bitmap.DENSITY_NONE
56:             decoded.setHasAlpha(true)

92:             val top = (edge - height) / 2
93:             Canvas(square).drawBitmap(image, null, RectF(left, top, left + width, top + height),
94:                 Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))

31: 
32:     fun decode(file: File, size: ImageDimensions, budget: Long): Bitmap {
33:         val selected = entry(file)
34:         val source = ImageDimensions(selected.width, selected.height)
35:         if (size.width > source.width || size.height > source.height)
36:             throw IOException(ui(R.string.ui_choose_dimensions_no_larger_than_the_original))
37:         if (DECODE_SCRATCH + source.pixels * 12 + size.pixels * 4 > budget)
38:             throw IOException(ui(R.string.formats22_ico_decode_budget))
39:         if (selected.png) {
40:             val temporary = File.createTempFile("ico-input-", ".png", file.absoluteFile.parentFile)
41:             try {
42:                 temporary.outputStream().buffered().use { IcoContainer.extractPng(file, selected, it) }
