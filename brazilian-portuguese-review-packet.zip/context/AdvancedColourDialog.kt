300:             VerticalUi.panel(previewRow,112)
301:             form.addView(VerticalUi.detach(previewRow),LinearLayout.LayoutParams(-2,-2))
302:             form
303:         } else holder
304:         val dialog = EditorDialogBuilder(activity).setTitle(if(addingToPalette) ui(if(replacingPaletteColour) R.string.ui_edit_colour26 else R.string.ui_add_colour26) else if (background) ui(R.string.ui_background_colour) else ui(R.string.ui_foreground_colour)).setView(dialogContent)
305:             .setNegativeButton(ui(R.string.ui_cancel)) {_,_->preview(original)}.setOnCancelListener {preview(original)}.setPositiveButton(ui(if(addingToPalette) {if(replacingPaletteColour) R.string.ui_save else R.string.ui_add_colour26} else R.string.ui_use_colour), null).create()
306:         fun resizeHorizontalWindow() {
307:             if(VerticalText.uiVertical(activity)) return
308:             val frame=Rect();activity.window.decorView.getWindowVisibleDisplayFrame(frame)
309:             val wide=activity.resources.configuration.orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE &&
310:                 frame.width()>=dp(560)
311:             val width=if(wide) minOf(frame.width(),dp(900)) else ViewGroup.LayoutParams.WRAP_CONTENT

299:             form.addView(VerticalUi.detach(customPanel),LinearLayout.LayoutParams(dp(352),-2))

118:         listOf(ui(R.string.ui_spectrum), ui(R.string.ui_wheel)).forEachIndexed { i, name ->
119:             advancedTabs.addView(button(name, "colour_mode_${i + 1}") { selectMode(i + 1) }.apply { minHeight=dp(44);minimumHeight=dp(44) }, LinearLayout.LayoutParams(0, -2, 1f))
120:         }
121:         advanced.addView(advancedTabs)
122:         advanced.addView(surface, LinearLayout.LayoutParams(-1, dp(190)))
123:         palette.addView(label(ui(R.string.ui_basic_colours)))
124:         val basics = intArrayOf(Color.BLACK, 0xff808080.toInt(),0xff800000.toInt(),0xff808000.toInt(),0xff008000.toInt(),0xff008080.toInt(),0xff000080.toInt(),0xff800080.toInt(),
125:             Color.WHITE,0xffc0c0c0.toInt(),Color.RED,Color.YELLOW,Color.GREEN,Color.CYAN,Color.BLUE,Color.MAGENTA) +
126:             (0 until 32).map { Color.HSVToColor(floatArrayOf((it % 8) * 45f, if (it < 16) .5f else 1f, if (it % 16 < 8) 1f else .65f)) }.toIntArray()
127:         fun swatch(colour: Int, tagName: String, select: () -> Int): View = View(activity).apply {
128:             tag = tagName; contentDescription = ui(R.string.ui_colour, String.format(Locale.ROOT, "#%06X", colour and 0xffffff))
129:             swatchBackground(this, colour); isFocusable = true; isClickable = true

340:         fun changed() {refreshCustom();paletteChanged();LocaleTypography.showMessage(activity,ui(R.string.ui_added_palette23),Toast.LENGTH_SHORT,saveCustomButton)}
341:         if(paletteStore.add(value.colour)) changed() else {
342:             val entries=paletteStore.entries()
343:             EditorDialogBuilder(activity).setTitle(ui(R.string.ui_replace_palette23))
344:                 .setItems(entries.map {customLabel(it.first,it.second)}.toTypedArray()) {_,which ->paletteStore.replace(entries[which].first,value.colour);changed()}
345:                 .setNegativeButton(ui(R.string.ui_cancel),null).show()
346:         }
347:     }
348:     private fun readFields(key: String) {
349:         fun number(name: String, max: Float): Float? = uiNumber(fields[name]?.text.toString())?.toFloat()?.takeIf { it in 0f..max }
350:         try {
351:             when (key) {

130:             setOnClickListener { value.rgb(select()); sync() }
131:         }
132:         basics.toList().chunked(8).forEachIndexed { rowIndex, row ->
133:             val line = LinearLayout(activity)
134:             row.forEachIndexed { i, c -> line.addView(swatch(c, "basic_colour_${rowIndex * 8 + i}") { c }, LinearLayout.LayoutParams(0, dp(28), 1f).apply { setMargins(dp(1), dp(1), dp(1), dp(1)) }) }

241:                     }
242:                     override fun afterTextChanged(s: Editable?) = Unit
243:                 })
244:             }; fields[key] = edit; wrap.addView(edit); return wrap
245:         }
246:         advanced.addView(field("hex", ui(R.string.ui_hex_rrggbb), 0))
247:         listOf(listOf(Triple("r", R.string.ui_colour_red_range, 255),Triple("g", R.string.ui_colour_green_range, 255),Triple("b", R.string.ui_colour_blue_range, 255)),
248:             listOf(Triple("h", R.string.ui_colour_hsv_hue_range, 360),Triple("s", R.string.ui_colour_hsv_saturation_range, 100),Triple("v", R.string.ui_colour_hsv_value_range, 100)),
249:             listOf(Triple("hl", R.string.ui_colour_hsl_hue_range, 360),Triple("sl", R.string.ui_colour_hsl_saturation_range, 100),Triple("l", R.string.ui_colour_hsl_lightness_range, 100))).forEach { group ->
250:             val row = LinearLayout(activity)
251:             group.forEach { (key, label, max) -> row.addView(field(key, ui(label), max), LinearLayout.LayoutParams(0, -2, 1f)) }
252:             advanced.addView(row)

357:                 "r", "g", "b" -> value.rgb(Color.rgb( (number("r",255f) ?: return).toInt(),(number("g",255f) ?: return).toInt(),(number("b",255f) ?: return).toInt()))
358:                 "h", "s", "v" -> value.hsv(number("h",360f) ?: return,(number("s",100f) ?: return) / 100,(number("v",100f) ?: return) / 100)
359:                 "hl", "sl", "l" -> value.hsl(number("hl",360f) ?: return,(number("sl",100f) ?: return) / 100,(number("l",100f) ?: return) / 100)
360:             }
361:             fields[key]?.error = null; sync(key)
362:         } catch (_: IllegalArgumentException) { fields[key]?.error = ui(R.string.ui_invalid_colour) }
363:     }
364:     private fun sync(except: String? = null) {
365:         syncing = true
366:         val c = value.colour; val hsl = value.hsl
367:         val numbers = mapOf("r" to Color.red(c).toFloat(),"g" to Color.green(c).toFloat(),"b" to Color.blue(c).toFloat(),
368:             "h" to value.hsv[0],"s" to value.hsv[1] * 100,"v" to value.hsv[2] * 100,"hl" to hsl[0],"sl" to hsl[1] * 100,"l" to hsl[2] * 100)

108:             surface.visibility = advanced.visibility
109:             surface.wheel = mode == 2; surface.invalidate()
110:             surface.contentDescription = if (mode == 2) ui(R.string.ui_hue_and_saturation_wheel_value_slider_on_the) else ui(R.string.ui_hue_and_saturation_spectrum_lightness_slider_on_the)
111:             for (i in 0 until tabs.childCount) tabs.getChildAt(i).isSelected = i == when (mode) { 0 -> 0; 3 -> 1; else -> 2 }
112:         }
113:         listOf(Triple(ui(R.string.ui_palette), "colour_mode_0", 0), Triple(ui(R.string.ui_honeycomb), "colour_mode_3", 3), Triple(ui(R.string.ui_advanced), "colour_advanced_tab", 1)).forEach { (name, tag, mode) ->
114:             tabs.addView(button(name, tag) { selectMode(mode) }.apply { minHeight=dp(44);minimumHeight=dp(44) }, LinearLayout.LayoutParams(0, -2, 1f))
115:         }
116:         editorPanel.addView(tabs)
117:         val advancedTabs = LinearLayout(activity).apply { isBaselineAligned=false }

206:         updateCustomGrid()
207:         customPanel.addView(HorizontalScrollView(activity).apply {isFillViewport=true;addView(grid)})
208:         fixedPanel.addView(customPanel)
209:         val previewRow = LinearLayout(activity).apply { gravity = Gravity.CENTER_VERTICAL }
210:         val sampleColumn=column()
211:         sampleColumn.addView(label(ui(R.string.ui_selected_colour23)).apply {tag="selected_colour_caption"})
212:         sample = object : View(activity) {
213:             override fun onDraw(canvas: Canvas) {
214:                 val p = Paint()
215:                 p.color = value.colour; canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), p)
216:             }
217:         }.apply { tag = "new_colour_preview" }

352:                 "hex" -> {
353:                     val text = fields[key]!!.text.toString().trim()
354:                     if (!text.matches(Regex("#[0-9a-fA-F]{6}"))) { fields[key]!!.error = ui(R.string.ui_use_rrggbb); return }
355:                     value.rgb(Color.parseColor(text))
356:                 }
