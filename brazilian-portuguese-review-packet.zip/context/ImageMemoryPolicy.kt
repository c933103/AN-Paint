43:     fun check(width: Int, height: Int, residentPixels: Long = 0) {
44:         require(width > 0 && height > 0) { ui(R.string.ui_enter_positive_image_dimensions) }
45:         val pixels = width.toLong() * height.toLong()
46:         val permitted = maxPixels(residentPixels)
47:         if (pixels > permitted) throw ImageSizeException(String.format(Locale.ROOT,
48:             ui(R.string.ui_d_d_pixels_2f_mp_exceeds_the_current),
49:             width, height, pixels / 1_000_000.0, permitted / 1_000_000.0))
50:     }
51: }
52: class ImageSizeException(message: String) : IllegalArgumentException(message)

39:     fun maxPixels(residentPixels: Long = 0): Long {
40:         val residentBytes = residentPixels.coerceIn(0, Long.MAX_VALUE / 4) * 4
41:         return minOf(MAX_BITMAP_PIXELS, (workingBytes - residentBytes).coerceAtLeast(0) / 12)
42:     }
