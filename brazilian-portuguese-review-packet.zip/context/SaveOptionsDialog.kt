96:                 ImageFormat.BMP -> R.string.save20_bmp_description
97:                 ImageFormat.DIB -> R.string.formats22_dib_description
98:                 ImageFormat.TIFF -> R.string.formats22_tiff_description
99:                 ImageFormat.ICO -> R.string.formats22_ico_description
100:                 ImageFormat.BASE64 -> R.string.formats22_base64_description
101:                 ImageFormat.ASCII_ART -> R.string.formats22_ascii_description
102:                 ImageFormat.JPEG,ImageFormat.HEIC -> R.string.save20_lossy_quality_description
103:                 else -> R.string.ui_higher_quality_usually_makes_a_larger_file_lossless
104:             })
105:             explanation.visibility=if(format==ImageFormat.PNG) View.GONE else View.VISIBLE
106:         }
107:         losslessBox.setOnCheckedChangeListener {_,checked ->lossless=checked;update()}

57:             setText(ExportNames.withExtension(initialFilename.ifBlank {ui(R.string.ui_untitled)},format))
58:             contentDescription=ui(R.string.save20_file_name)
59:             selectAll()
60:         }
61:         body.addView(filename,LinearLayout.LayoutParams(-1,-2))
62:         body.addView(TextView(activity).apply {text=ui(R.string.save20_file_format)})
63:         val losslessBox=CheckBox(activity).apply {tag="export_lossless";isChecked=lossless}
64:         val ditherBox=CheckBox(activity).apply {tag="export_dither";text=ui(R.string.save20_dither);isChecked=initial.dither}
65:         val tiffCompressionBox=CheckBox(activity).apply {tag="export_tiff_compressed";text=ui(R.string.formats22_tiff_compression);isChecked=initial.tiffCompressed}
66:         val iconEdges=listOf(16,24,32,48,64,128,256)
67:         var icoSize=initial.icoSize.takeIf {it in iconEdges} ?: 256
68:         val iconControls=LinearLayout(activity).apply {orientation=LinearLayout.VERTICAL;tag="export_ico_controls"}

108:         body.addView(Spinner(activity).apply {
109:             tag="export_format";contentDescription=ui(R.string.save20_file_format)
110:             adapter=ArrayAdapter(activity,android.R.layout.simple_spinner_dropdown_item,formats.map {it.label})
111:             setSelection(formats.indexOf(format))
112:             onItemSelectedListener=object: AdapterView.OnItemSelectedListener {
113:                 override fun onNothingSelected(parent: AdapterView<*>?)=Unit
114:                 override fun onItemSelected(parent: AdapterView<*>?,view: View?,position: Int,id: Long) {
115:                     format=formats[position]

166:                 override fun beforeTextChanged(s: CharSequence?,start: Int,count: Int,after: Int)=Unit
167:                 override fun onTextChanged(s: CharSequence?,start: Int,before: Int,count: Int) {preview.text=s}
168:                 override fun afterTextChanged(s: android.text.Editable?)=Unit
169:             })
170:             field(ui(R.string.save20_file_name),nameColumn)
171:             field(ui(R.string.save20_file_format),body.findViewWithTag<Spinner>("export_format"))
172:             listOf(losslessBox,slider,ditherBox,tiffCompressionBox,iconControls,asciiControls,explanation).forEach {control ->
173:                 VerticalUi.detach(control)
174:                 if(control is LinearLayout && control !is NumericSlider) VerticalUi.panel(control,tall)
175:                 if(control is TextView) VerticalUi.caption(control,tall)
176:                 if(control is FlowTextView) control.columnHeightDp=tall
177:                 form.addView(control,LinearLayout.LayoutParams(if(control is NumericSlider) (176*d).toInt() else -2,-2).apply {setMargins((8*d).toInt(),0,(8*d).toInt(),0)})

48:         lateinit var dialog: AlertDialog
49:         val formats=ImageFormat.values().filter {share || it.isDerivedExport==export}
50:         var format=initial.format.takeIf {it in formats} ?: formats.first();var quality=initial.quality.coerceIn(1,100);var lossless=initial.lossless
51:         val body=LinearLayout(activity).apply {orientation=LinearLayout.VERTICAL;setPadding(24,12,24,12)}
52:         body.addView(TextView(activity).apply {text=ui(when {share->R.string.ui_share_explanation34;export->R.string.ui_export_explanation23;else->R.string.ui_save_explanation23})})
53:         body.addView(TextView(activity).apply {text=ui(R.string.save20_file_name)})
54:         val filename=EditText(activity).apply {
55:             tag="export_filename";setSingleLine(true)
56:             inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES

165:             filename.addTextChangedListener(object: android.text.TextWatcher {

90:             ditherBox.visibility=if(format==ImageFormat.GIF) View.VISIBLE else View.GONE
91:             tiffCompressionBox.visibility=if(format==ImageFormat.TIFF) View.VISIBLE else View.GONE
92:             iconControls.visibility=if(format==ImageFormat.ICO) View.VISIBLE else View.GONE
93:             asciiControls.visibility=if(format==ImageFormat.ASCII_ART) View.VISIBLE else View.GONE
94:             explanation.text=ui(when(format) {
95:                 ImageFormat.GIF -> R.string.save20_gif_description

189:             .setPositiveButton(ui(R.string.ui_choose_location),null)
190:             .setNegativeButton(ui(R.string.ui_cancel)) {_,_ -> cancel()}.setOnCancelListener {cancel()}.create()
191:         dialog.setOnShowListener {
192:             dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
193:                 val name=filename.text.toString()
194:                 if(!ExportNames.valid(name,format)) filename.error=ui(R.string.save20_invalid_name)
195:                 else {
196:                     confirm(SaveRequest(ExportOptions(format,quality,format.supportsLossless && lossless,ditherBox.isChecked,tiffCompressionBox.isChecked,icoSize,asciiColumns,asciiInvert.isChecked),ExportNames.withExtension(name,format)))
197:                     dialog.dismiss()
198:                 }
199:             }
200:         }

182:             legacyButton?.let {VerticalUi.caption(it,tall);form.addView(VerticalUi.detach(it))}
183:             form.addView(prose(ui(when {share->R.string.ui_share_explanation34;export->R.string.ui_export_explanation23;else->R.string.ui_save_explanation23})))
184:             form.layoutDirection=if(VerticalText.uiDirection(activity)==TextDirection.VERTICAL_RL) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
185:             form
186:         } else ScrollView(activity).apply {addView(body)}
187:         dialog=EditorDialogBuilder(activity).setTitle(if(share) ui(R.string.ui_save_and_share_41edb4) else ui(if(export) R.string.ui_export_as23 else R.string.save20_title))
188:             .setView(content)

47:     fun show(): AlertDialog {

178:             }
179:             // Credits contain original names and URLs. Keep selectable native text in a bounded
180:             // scrolling column even when the surrounding interface uses vertical text.
181:             creditsPanel?.let {form.addView(ScrollView(activity).apply {addView(VerticalUi.detach(it))},LinearLayout.LayoutParams((264*d).toInt(),(tall*d).toInt()))}

124:             val details=LinearLayout(activity).apply {orientation=LinearLayout.VERTICAL;tag="export_credit_details";visibility=View.GONE}
125:             details.addView(TextView(activity).apply {
126:                 text=imageCredits;tag="export_credit_text";setTextIsSelectable(true);textDirection=View.TEXT_DIRECTION_FIRST_STRONG
127:             })
128:             details.addView(Button(activity).apply {
129:                 text=ui(R.string.ui_copy_all);tag="export_copy_credits";isAllCaps=false
130:                 setOnClickListener {GalleryCredits.copy(activity,imageCredits)}
131:             })
132:             addView(Button(activity).apply {
133:                 text="▸ "+ui(R.string.ui_image_credits);tag="export_toggle_credits";isAllCaps=false
134:                 setOnClickListener {
135:                     val open=details.visibility!=View.VISIBLE;details.visibility=if(open) View.VISIBLE else View.GONE
