127:             val zip=ZipOutputStream(stream).apply { setLevel(0) }
128:             fun entry(name: String, action: () -> Unit) {
129:                 zip.putNextEntry(ZipEntry(name)); action(); zip.closeEntry()
130:             }
131:             entry("draft.json") { zip.write(metadataBytes) }
132:             entry("canvas.png") { if (!image.compress(Bitmap.CompressFormat.PNG,100,zip)) throw IOException(ui(R.string.ui_autosave_image_encoding_failed)) }
133:             if (floating != null) entry("floating.png") {
134:                 if (!floating.compress(Bitmap.CompressFormat.PNG,100,zip)) throw IOException(ui(R.string.ui_autosave_selection_encoding_failed))
135:             }
136:             HistoryArchive.write(zip,history)
137:             // AtomicFile logs some sync failures. Surface them before reporting durable adoption.
138:             zip.finish(); zip.flush(); stream.fd.sync(); atomic.finishWrite(stream)

142:     fun read(historyReader: ((ZipFile) -> RasterHistory.Snapshot)? = null,checkSize: (Int,Int) -> Unit): AutosaveDraft = afterPendingWrites {
143:         atomic.openRead().close() // Recover the previous complete transaction after an interrupted write.
144:         var image: Bitmap?=null; var floating: Bitmap?=null
145:         try {
146:             ZipFile(file).use { zip ->
147:                 val entry=zip.getEntry("draft.json") ?: throw IOException(ui(R.string.ui_autosave_metadata_is_missing))
148:                 require(entry.size in 1..MAX_METADATA_BYTES.toLong()) { ui(R.string.ui_invalid_autosave_metadata) }
149:                 val metadata=zip.getInputStream(entry).use { JSONObject(BoundedJson.read(it,MAX_METADATA_BYTES)) }
150:                 require(metadata.getInt("version")==1)
151:                 fun decode(name: String): Bitmap {
152:                     val e=zip.getEntry(name) ?: throw IOException(ui(R.string.ui_autosave_pixels_are_missing))
153:                     val bounds=BitmapFactory.Options().apply { inJustDecodeBounds=true }

154:                     zip.getInputStream(e).use { BitmapFactory.decodeStream(it,null,bounds) }
155:                     checkSize(bounds.outWidth,bounds.outHeight)
156:                     return zip.getInputStream(e).use {
157:                         BitmapFactory.decodeStream(it,null,BitmapFactory.Options().apply { inMutable=true; inScaled=false })
158:                     } ?: throw IOException(ui(R.string.ui_autosave_pixels_could_not_be_read))

159:                 }
160:                 image=decode("canvas.png")
161:                 if (metadata.has("floating_rect")) floating=decode("floating.png")
162:                 var failed=false
163:                 val history=try {historyReader?.invoke(zip)} catch(_: Exception) {failed=true;null}
164:                 return AutosaveDraft(image!!,floating,metadata,history,failed)

139:         } catch (error: Throwable) { atomic.failWrite(stream); throw error }
140:     }

33:     companion object {
34:         const val MAX_METADATA_BYTES = 256 * 1024
35:         private val states=ConcurrentHashMap<String,FileState>()
36:         internal fun metadataBytes(metadata: JSONObject): ByteArray {
37:             val bytes=metadata.toString().toByteArray(Charsets.UTF_8)
38:             require(bytes.size in 1..MAX_METADATA_BYTES) { ui(R.string.ui_invalid_autosave_metadata) }
39:             require(metadata.getInt("version")==1) { ui(R.string.ui_invalid_autosave_metadata) }
40:             return bytes
41:         }
42:     }
43:     val file = File(directory,"classic-autosave.zip")
44:     private val state=states.getOrPut(file.canonicalPath) {FileState()}

45:     private val atomic = AtomicFile(file)

99:     /** Move an unreadable draft aside before allowing a new autosave to replace its name. */
100:     fun preserveForRecovery(retainOriginal: Boolean = false): File = afterPendingWrites {
101:         try { atomic.openRead().close() } catch (_: IOException) { }
102:         val source=File(file.path+".bak").takeIf { it.isFile } ?: file
103:         val target=File(file.parentFile,"classic-draft-recovery-${System.currentTimeMillis()}-${java.util.UUID.randomUUID()}.zip")
104:         if (!source.isFile) throw IOException(ui(R.string.ui_the_previous_draft_could_not_be_moved_to))
105:         if(retainOriginal) {
106:             // Startup may be abandoned after recovery. Keep the source readable for the
107:             // successor until an initialized editor commits its replacement autosave.
108:             val copy=AtomicFile(target)
109:             val output=copy.startWrite()
110:             try {source.inputStream().use {it.copyTo(output)};output.fd.sync();copy.finishWrite(output)}

111:             catch(error: Throwable) {copy.failWrite(output);throw error}
112:         } else if(!source.renameTo(target)) throw IOException(ui(R.string.ui_the_previous_draft_could_not_be_moved_to))
113:         target
114:     }
115:     fun recoveryCopies(): List<File> = file.parentFile?.listFiles()?.filter {
116:         it.isFile && it.name.startsWith("classic-draft-recovery-") && it.extension=="zip"
117:     }?.sortedByDescending { it.lastModified() } ?: emptyList()
118: 
