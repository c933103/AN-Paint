32:         val sizing = DimensionControls(activity,source,suggested,"resize",true)
33:         body.addView(label(ui(R.string.ui_resize_the_copy), "resize_heading")); body.addView(sizing)
34:         val estimate = label("", "resize_estimate"); body.addView(estimate)
35:         body.addView(label(ui(if(memoryRequirements.hasNativeWork) R.string.ui_codec_resize_memory_floor else R.string.ui_sampled_resize_memory_explanation), "resize_explanation"))
36:         var accepted = false
37:         val dialog = EditorDialogBuilder(activity).setTitle(ui(R.string.ui_resize_large_image))
38:             .setView(ScrollView(activity).apply { addView(body) })
39:             .setNegativeButton(ui(R.string.ui_cancel), null).setPositiveButton(ui(R.string.ui_resize_and_load), null).create()
40:         fun target(): ImageDimensions? = sizing.dimensions?.takeIf { it.width <= source.width && it.height <= source.height }
41:         fun refresh(): Boolean {
42:             val current = policy()
43:             budget.text = String.format(Locale.ROOT, ui(R.string.ui_current_safe_editing_budget_s_up_to_2f), memoryLabel(current.workingBytes.toDouble()), current.maxPixels(residentPixels) / 1_000_000.0)

30:         val maxScale = previousAttempt?.let { it.width.toDouble() / source.width * .75 } ?: 1.0
31:         val suggested = memoryRequirements.suggestResize(source,policy(),residentPixels,maxScale) ?: ImageDimensions(1,1)

44:             val size = target()
45:             val plan = size?.let { ImportPlan.create(source,it) }

46:             val fits = plan != null && memoryRequirements.accepts(current,plan,residentPixels)
47:             val cannotResize=memoryRequirements.hasNativeWork && !memoryRequirements.accepts(current,ImportPlan.create(source,ImageDimensions(1,1)),residentPixels)
48:             estimate.text = if (size == null) ui(R.string.ui_enter_positive_dimensions_no_larger_than_the_original)
49:                 else ui(R.string.ui_copy_decoded_image_at_this_size_estimated_loading, size.describe(), memoryLabel(size.pixels * 4.0), memoryLabel(memoryRequirements.estimatedBytes(plan!!,residentPixels))) +
50:                     if (fits) ui(R.string.ui_fits_the_current_budget) else if(cannotResize) "\n"+ui(R.string.ui_no_resize_fits_decoder_memory) else ui(R.string.ui_too_large_for_the_current_budget_reduce_the)
51:             dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.isEnabled = fits
52:             return fits
53:         }
54:         sizing.changed = { refresh() }

55:         dialog.setOnDismissListener { if (!accepted) cancel() }
56:         dialog.setOnShowListener {

28:         body.addView(label(ui(R.string.ui_the_full_image_and_working_buffers_exceed_the), "resize_reason"))
29:         val budget = label("", "resize_budget"); body.addView(budget)

23:         val density = activity.resources.displayMetrics.density
24:         fun dp(n: Int) = (n * density + .5f).toInt()
25:         fun label(value: String, name: String) = TextView(activity).apply { text = value; tag = name; textSize = 14f; setPadding(0,dp(5),0,dp(5)) }
26:         val body = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20),dp(8),dp(20),dp(12)) }
27:         body.addView(label(ui(R.string.ui_original_decoded_image_rgba_4_bytes_pixel_estimated, source.describe(), memoryLabel(source.pixels * 4.0), memoryLabel(memoryRequirements.estimatedBytes(ImportPlan.create(source,source),residentPixels))), "resize_original"))
