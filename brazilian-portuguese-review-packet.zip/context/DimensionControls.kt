70:         val w = pixels(number(widthInput),original.width); val h = pixels(number(heightInput),original.height)
71:         target = if (w != null && h != null) ImageDimensions(w,h) else null
72:         showResult(); syncing = false; changed(target)
73:     }
74:     fun setDimensions(size: ImageDimensions) { target = size; display(); changed(target) }
75:     private fun showResult() { result.text = target?.describe() ?: ui(R.string.ui_enter_positive_dimensions_that_resolve_to_at_least) }
76:     private fun display() {
77:         syncing = true
78:         val unit = if (percent) "%" else "px"
79:         widthLabel.text = ui(R.string.ui_width, unit); heightLabel.text = ui(R.string.ui_height, unit)
80:         listOf(widthInput,heightInput).forEach { LocaleNumberInput.configure(it, decimal = percent) }
81:         widthInput.contentDescription = ui(R.string.ui_width_in, if (percent) ui(R.string.ui_percent_fd8671) else ui(R.string.ui_pixels_6ec9c2))

82:         heightInput.contentDescription = ui(R.string.ui_height_in, if (percent) ui(R.string.ui_percent_fd8671) else ui(R.string.ui_pixels_6ec9c2))
83:         target?.let { size ->
84:             widthInput.setText(if (percent) format(size.width * 100.0 / original.width) else size.width.toString())
85:             heightInput.setText(if (percent) format(size.height * 100.0 / original.height) else size.height.toString())

86:         }
87:         showResult(); syncing = false
88:     }

14: /** Canonical pixel dimensions survive unit changes without cumulative rounding. */
15: class DimensionControls(context: Context, val original: ImageDimensions, initial: ImageDimensions = original,
16:     prefix: String = "size", locked: Boolean = true) : LinearLayout(context) {
17:     val widthInput = EditText(context)
18:     val heightInput = EditText(context)
19:     val aspectLock = CheckBox(context).apply { text = ui(R.string.ui_lock_aspect_ratio); tag = "${prefix}_lock"; isChecked = locked }
20:     private val widthLabel = TextView(context)
21:     private val heightLabel = TextView(context)
22:     private val result = TextView(context).apply { tag = "${prefix}_result"; textSize = 13f }
23:     private var percent = false
24:     private var syncing = false
25:     private var target: ImageDimensions? = initial

26:     var changed: (ImageDimensions?) -> Unit = {}
27:     val dimensions get() = target
28:     init {
29:         orientation = VERTICAL
30:         val units = RadioGroup(context).apply { orientation = HORIZONTAL; tag = "${prefix}_units" }
31:         listOf(ui(R.string.ui_pixels), ui(R.string.ui_percent)).forEachIndexed { i, text ->
32:             units.addView(RadioButton(context).apply {
33:                 this.text = text; id = View.generateViewId(); tag = "${prefix}_${if (i == 0) "pixels" else "percent"}"; isChecked = i == 0
34:                 setOnClickListener { units.check(id); if (percent != (i == 1)) { percent = i == 1; display(); changed(target) } }
35:             },LayoutParams(0,-2,1f))
36:         }
37:         addView(units)
