20:             ImageFormat.ICO -> IcoCodec.encode(image,file,options.icoSize,budget)
21:             ImageFormat.BASE64 -> TextImageCodec.encodeBase64(image,file,budget)
22:             ImageFormat.ASCII_ART -> TextImageCodec.encodeAscii(image,file,options.asciiColumns,options.asciiInvert,budget)
23:             ImageFormat.PNG,ImageFormat.JPEG -> file.outputStream().use {
24:                 val format=if(options.format==ImageFormat.JPEG) Bitmap.CompressFormat.JPEG else Bitmap.CompressFormat.PNG
25:                 if(!image.compress(format,options.quality.coerceIn(1,100),it)) throw IOException(ui(R.string.ui_the_encoder_did_not_finish))
26:             }
27:         }
28:     }
29: }
