337:     }
338:     private fun saveOutput(file: File,uri: Uri) {
339:         setBusy(true)
340:         worker.execute {
341:             try { contentResolver.openOutputStream(uri,"wt")?.use { output -> file.inputStream().use { it.copyTo(output,64*1024) } } ?: throw IOException(ui(R.string.ui_the_selected_location_is_not_writable))
342:                 runOnUiThread { if (!isDestroyed) { setBusy(false); refresh(); LocaleTypography.showMessage(this,ui(R.string.ui_assembly_saved),Toast.LENGTH_SHORT) } }
343:             } catch (error: Exception) { runOnUiThread { if (!isDestroyed) { setBusy(false); refresh(); message(ui(R.string.ui_could_not_save_the_assembly, error.message)) } } }
344:             finally { file.delete() }
345:         }
346:     }
347:     private fun showHelp() = message(ui(R.string.ui_add_up_to_20_images_with_android_s))
348:     override fun onSaveInstanceState(outState: Bundle) { outState.putString("pending_output",pendingOutput?.name); outState.putInt("sort",sort.ordinal); outState.putString("selected",selected); super.onSaveInstanceState(outState) }

295:         }
296:     }
297:     private fun outputSizeDialog(renderer: AssemblyRenderer,toPaint: Boolean,previous: ImageDimensions? = null) {
298:         val suggested = renderer.suggested(previous)
299:         if (suggested == null) {
300:             message(ui(R.string.ui_assembly_source_memory_floor))
301:             return
302:         }
303:         val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16),dp(8),dp(16),dp(8)) }
304:         body.addView(text(ui(R.string.ui_assembly_decoded_output_estimated_editing_render_memory_at, renderer.original.describe(), memoryLabel(renderer.original.pixels*4.0), memoryLabel(renderer.estimatedBytes(renderer.original)))))
305:         body.addView(text(ui(R.string.ui_choose_a_smaller_output_copy_the_source_images)))
306:         val sizing = DimensionControls(this,renderer.original,suggested,"assembly_size",true); body.addView(sizing)

96:         val editingActions = actionRow(button(ui(R.string.ui_crop_image),"assembly_crop") { crop(false) },button(ui(R.string.ui_batch_crop),"assembly_batch_crop") { crop(true) },
97:             button(ui(R.string.ui_same_width),"assembly_same_width") { normalize(NormalizeAxis.WIDTH) },
98:             button(ui(R.string.ui_same_height),"assembly_same_height") { normalize(NormalizeAxis.HEIGHT) },
99:             button(ui(R.string.ui_unplace),"assembly_unplace") { selected?.let { assembly.unplace(it) } ?: message(ui(R.string.ui_tap_an_image_first)) },
100:             button(ui(R.string.ui_remove),"assembly_remove") { selected?.let { assembly.remove(it) } ?: message(ui(R.string.ui_tap_an_image_first)) },
101:             button(ui(R.string.ui_show_all),"assembly_fit") { board.fit(); info.text=ui(R.string.ui_shows_the_whole_assembly_image_and_output_sizes) },button(ui(R.string.ui_clear_all),"assembly_clear") { assembly.clear() })
102:         val sortRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8),0,dp(8),0) }
103:         sortRow.addView(text(ui(R.string.ui_sort_tray)))
104:         sortRow.addView(Spinner(this).apply {
105:             tag = "assembly_sort"; contentDescription = ui(R.string.ui_sort_images_by_filename_or_modification_time)
106:             adapter = ArrayAdapter(this@AssemblyActivity,android.R.layout.simple_spinner_dropdown_item,AssemblySort.values().map { it.label }); setSelection(sort.ordinal)
107:             onItemSelectedListener = object : AdapterView.OnItemSelectedListener {

349:     override fun onBackPressed() { if (!busy) finish() }

224:         fun finishBatch() {
225:             cancelImportBatch=null
226:             if(isDestroyed || isFinishing || abandoned.get()) {decoded.values.forEach {it.recycle()};items.forEach {it.file.delete()};return}
227:             previews.putAll(decoded)
228:             try {if(items.isNotEmpty()) assembly.add(items)}
229:             catch(error: Exception) {items.forEach {previews.remove(it.id)?.recycle();it.file.delete()};errors.add(error.message ?: ui(R.string.ui_could_not_store_the_assembly))}
230:             setBusy(false);refresh();if(errors.isNotEmpty()) message(errors.joinToString("\n"))
231:         }
232:         fun next(index: Int) {
233:             if(abandoned.get() || isDestroyed || isFinishing) return
234:             if(index==uris.size) {finishBatch();return}
235:             val uri=uris[index];val id=UUID.randomUUID().toString();val file=File(assembly.directory,"$id.image")

112:         if (compact()) editingActions.addView(sortRow,LinearLayout.LayoutParams(dp(280),dp(46))) else root.addView(sortRow)
113:         tray = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; tag = "assembly_thumbnails" }
114:         root.addView(HorizontalScrollView(this).apply { tag = "assembly_tray"; contentDescription = ui(R.string.ui_image_thumbnails_and_filenames_scroll_horizontally_for_more); addView(tray) },LinearLayout.LayoutParams(-1,dp(if (compact()) 108 else 154)))
115:         assembly.changed = { refresh() }; refresh(); loadMissingPreviews()
116:     }
117:     private fun perform(action: () -> Unit) { try { action() } catch (error: Exception) { message(error.message ?: ui(R.string.ui_could_not_complete_the_operation)) } catch (_: OutOfMemoryError) { message(ui(R.string.ui_not_enough_memory_for_this_operation_the_assembly)) } }
118:     private fun message(value: String) {
119:         lastError = value
120:         if (!isDestroyed && !isFinishing) EditorDialogBuilder(this).setTitle("AN Paint").setMessage(value).setPositiveButton(ui(R.string.ui_ok),null).show()
121:     }
122:     private fun setBusy(value: Boolean) { busy = value; if (::board.isInitialized) { board.isEnabled = !value; undo.isEnabled = !value && assembly.canUndo; redo.isEnabled = !value && assembly.canRedo; add.isEnabled = !value && assembly.images.size < 20 }; if (value) info.text = ui(R.string.ui_working) }
123:     private fun refresh() {

289:                 runOnUiThread {if(!isDestroyed && !isFinishing) {
290:                     setBusy(false)
291:                     if(renderer.fits(renderer.original)) makeOutput(renderer,renderer.original,toPaint) else outputSizeDialog(renderer,toPaint)
292:                 }}
293:             } catch(error: Exception) {runOnUiThread {if(!isDestroyed && !isFinishing) {setBusy(false);refresh();message(ui(R.string.ui_could_not_create_the_assembly,error.message))}}}
294:             catch(_: OutOfMemoryError) {runOnUiThread {if(!isDestroyed && !isFinishing) {setBusy(false);refresh();message(ui(R.string.ui_not_enough_memory_for_this_operation_the_assembly))}}}

319:     private fun makeOutput(renderer: AssemblyRenderer,size: ImageDimensions,toPaint: Boolean) {
320:         setBusy(true); val file = File(filesDir,"assembly-output-${UUID.randomUUID()}.png")
321:         worker.execute {
322:             try {
323:                 val image = renderer.render(size) { n,total -> runOnUiThread { if (!isDestroyed) info.text = ui(R.string.ui_rendering_images, n, total) } }
324:                 try { file.outputStream().use { if (!image.compress(Bitmap.CompressFormat.PNG,100,it)) throw IOException(ui(R.string.ui_png_encoding_failed)) } } finally { image.recycle() }
325:                 runOnUiThread {
326:                     if (isDestroyed || isFinishing) file.delete()
327:                     else {
328:                         setBusy(false); refresh()
329:                         if (toPaint) { setResult(RESULT_OK,Intent().putExtra("assembly_output",file.name)); finish() }
330:                         else { pendingOutput?.delete(); pendingOutput = file; launchPicker(Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "image/png"; putExtra(Intent.EXTRA_TITLE,ui(R.string.ui_an_paint_assembly_png)) },SAVE_ASSEMBLY) }

83:             val row = LinearLayout(this); views.forEach { row.addView(it,LinearLayout.LayoutParams(-2,dp(46))) }
84:             root.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }); return row
85:         }
86:         add = button(ui(R.string.ui_add_images),"assembly_add") { launchAdd() }
87:         actionRow(add,button(ui(R.string.ui_assembly_exact_position),"assembly_position") { exactPosition() },
88:             button(ui(R.string.ui_save_png),"assembly_save") { requestOutput(false) },button(ui(R.string.ui_edit_in_paint),"assembly_edit") { requestOutput(true) },button(ui(R.string.ui_how_to_use),"assembly_help") { showHelp() })
89:         board = AssemblyCanvas(this,assembly) { previews[it] }.apply {
90:             tag = "assembly_canvas"; onError = { message(it.message ?: ui(R.string.ui_could_not_place_the_image)) }
91:             onSelect = { id -> selected = id; for (i in 0 until tray.childCount) tray.getChildAt(i).setBackgroundColor(if (tray.getChildAt(i).tag == "assembly_item_$id") EditorColours.primaryContainer else EditorColours.surfaceContainerHigh) }; onStatus = { if (!busy) info.text = it }
92:         }
93:         root.addView(board,LinearLayout.LayoutParams(-1,0,1f))
94:         info = text(ui(R.string.ui_drag_placed_images_to_move_them_hold_and)).apply { tag = "assembly_status"; setPadding(dp(8),dp(3),dp(8),dp(3)); minLines = if (compact()) 1 else 2; maxLines = if (compact()) 1 else 2; ellipsize = TextUtils.TruncateAt.END }

55:         setOnClickListener { if (!busy) perform(action) }
56:     }
57:     override fun onCreate(savedInstanceState: Bundle?) {
58:         super.onCreate(savedInstanceState)
59:         try { assembly = ImageAssembly(File(filesDir,"image-assembly")) }
60:         catch (error: Exception) { message(ui(R.string.ui_the_saved_assembly_could_not_be_opened, error.message)); return }
61:         savedInstanceState?.getString("pending_output")?.let { name -> File(filesDir,name).takeIf { it.parentFile == filesDir && name.startsWith("assembly-output-") && it.isFile }?.let { pendingOutput = it } }
62:         sort = AssemblySort.values().getOrElse(savedInstanceState?.getInt("sort") ?: 0) { AssemblySort.NAME_ASC }
63:         selected = savedInstanceState?.getString("selected")
64:         buildInterface()
65:     }
66:     override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {

336:         }

190:     private fun launchPicker(intent: Intent,code: Int) {
191:         try { startActivityForResult(intent,code) }
192:         catch (_: ActivityNotFoundException) {
193:             if (intent.action == Intent.ACTION_OPEN_DOCUMENT) try { startActivityForResult(Intent(intent).setAction(Intent.ACTION_GET_CONTENT),code); return } catch (_: ActivityNotFoundException) { }
194:             message(ui(R.string.ui_enable_android_s_files_or_documents_app_then))
195:         } catch (error: SecurityException) { message(ui(R.string.ui_android_blocked_the_file_picker, error.message)) }
196:     }
197:     public override fun onActivityResult(requestCode: Int,resultCode: Int,data: Intent?) {
198:         super.onActivityResult(requestCode,resultCode,data)
199:         if (requestCode == ADD_IMAGES && resultCode == RESULT_OK) {
200:             val uris = data?.clipData?.let { clip -> (0 until clip.itemCount).map { clip.getItemAt(it).uri } } ?: listOfNotNull(data?.data)
201:             if (uris.isEmpty()) message(ui(R.string.ui_the_picker_returned_no_files)) else importImages(uris.distinct())

307:         val estimate = text(""); body.addView(estimate)
308:         val dialog = EditorDialogBuilder(this).setTitle(ui(R.string.ui_assembly_output_size)).setView(ScrollView(this).apply { addView(body) }).setNegativeButton(ui(R.string.ui_cancel),null).setPositiveButton(ui(R.string.ui_create_output),null).create()
309:         fun refresh() {
310:             val size = sizing.dimensions
311:             estimate.text = if (size == null) ui(R.string.ui_enter_valid_dimensions) else ui(R.string.ui_estimated_memory_current_working_budget, memoryLabel(renderer.estimatedBytes(size)), memoryLabel(ImageMemoryPolicy.forDevice(this).workingBytes.toDouble())) + if (renderer.fits(size)) ui(R.string.ui_fits_the_current_budget) else ui(R.string.ui_choose_a_smaller_size)
312:             dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.isEnabled = size != null && renderer.fits(size)
313:         }
314:         sizing.changed = { refresh() }

315:         dialog.setOnShowListener { refresh(); dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
316:             refresh(); sizing.dimensions?.takeIf { renderer.fits(it) }?.let { dialog.dismiss(); makeOutput(renderer,it,toPaint) }
317:         } }; dialog.show()

95:         root.addView(info,LinearLayout.LayoutParams(-1,if (compact()) dp(24) else -2))

203:             val file = pendingOutput; pendingOutput = null
204:             if (resultCode == RESULT_OK && data?.data != null && file != null) saveOutput(file,data.data!!) else file?.delete()
205:         }
206:     }
207:     private fun metadata(uri: Uri): Pair<String,Long?> {
208:         var name = uri.lastPathSegment ?: ui(R.string.ui_image); var timestamp: Long? = null
209:         try { contentResolver.query(uri,null,null,null,null)?.use { cursor -> if (cursor.moveToFirst()) {
210:             val n = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (n >= 0 && !cursor.isNull(n)) name = cursor.getString(n)
211:             val modified = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED)
212:             if (modified >= 0 && !cursor.isNull(modified)) timestamp = cursor.getLong(modified).takeIf { it > 0 }
213:             else { val m = cursor.getColumnIndex("date_modified"); if (m >= 0 && !cursor.isNull(m)) timestamp = cursor.getLong(m).takeIf { it > 0 && it <= Long.MAX_VALUE/1000 }?.times(1000) }
214:         } } } catch (_: Exception) { /* Metadata is optional; never invent a file timestamp. */ }

238:                 runOnUiThread {if(!abandoned.get() && !isDestroyed && !isFinishing) {importSelection=null;errors.add("${uri.lastPathSegment}: ${error.message}");next(index+1)}}
239:             }
240:             worker.execute {
241:                 try {
242:                     val (name,time)=metadata(uri)
243:                     contentResolver.openInputStream(uri)?.use {ImportFiles.copy(it,file)} ?: throw IOException(ui(R.string.ui_no_readable_image_data))
244:                     runOnUiThread {
245:                         if(abandoned.get() || isDestroyed || isFinishing) file.delete()
246:                         else {
247:                             val selection=ImportSelection(this,worker,{residentPixels()},selected={source ->
248:                                 importSelection=null
249:                                 worker.execute {

124:         if (isDestroyed || !::tray.isInitialized) return
125:         if (assembly.images.none { it.id == selected }) selected = null
126:         renderTray()

202:         } else if (requestCode == SAVE_ASSEMBLY) {

127:         val ids = assembly.images.map { it.id }.toSet()
128:         previews.keys.filter { it !in ids }.forEach { previews.remove(it)?.recycle() }
