15:     fun manifest(snapshot: RasterHistory.Snapshot): JSONObject {
16:         val credits=(snapshot.undo+snapshot.redo).flatMap {it.imageCredits}.distinct()
17:         val creditIndex=credits.withIndex().associate {it.value to it.index}
18:         return JSONObject().put("version",1).put("image_credit_catalog",ImageCredit.write(credits)).apply {
19:             for((name,stack) in listOf("undo" to snapshot.undo,"redo" to snapshot.redo)) {
20:                 require(stack.size<=32768) { ui(org.catrobat.paintroid.R.string.ui_invalid_autosave_metadata) }
21:                 put(name,JSONArray().apply {stack.forEach {entry ->
22:                     put(JSONObject().put("width",entry.width).put("height",entry.height).put("sha256","0".repeat(64))
23:                         .put("image_credits",JSONArray(entry.imageCredits.map {creditIndex.getValue(it)})))
24:                 }})
25:             }
26:         }

28:     fun validate(snapshot: RasterHistory.Snapshot) = validateManifest(manifest(snapshot))
29:     fun validateManifest(manifest: JSONObject) {
30:         require(manifest.getInt("version")==1)
31:         require(manifest.getJSONArray("undo").length()<=32768 && manifest.getJSONArray("redo").length()<=32768)
32:         require(manifest.toString().toByteArray(Charsets.UTF_8).size<=MAX_INDEX_BYTES) {
33:             ui(org.catrobat.paintroid.R.string.ui_invalid_autosave_metadata)
34:         }
35:     }
36:     private fun hex(bytes: ByteArray)=bytes.joinToString("") {"%02x".format(it.toInt() and 255)}
37:     fun write(zip: ZipOutputStream,snapshot: RasterHistory.Snapshot) {
38:         validate(snapshot)
39:         val manifest=manifest(snapshot)
