66: 
67: private fun placementDialog(activity: Activity, title: String, body: View): AlertDialog = EditorDialogBuilder(activity)
68:     .setTitle(title)
69:     .setView(ScrollView(activity).apply { isFillViewport = true; addView(body) })
70:     .setNegativeButton(ui(R.string.ui_cancel), null)
71:     .setPositiveButton(ui(R.string.ui_apply), null)
72:     .create()

65:     ?.takeIf { it.isFinite() && it >= 0 && it <= Int.MAX_VALUE && it == kotlin.math.floor(it) }?.toInt()

33:                     val targetX = placementPixels(x) ?: throw IllegalArgumentException(ui(R.string.ui_assembly_position_nonnegative))
34:                     val targetY = placementPixels(y) ?: throw IllegalArgumentException(ui(R.string.ui_assembly_position_nonnegative))
35:                     assembly.position(imageId, targetX, targetY)
36:                     dialog.dismiss()
37:                 } catch (problem: Exception) {
38:                     error.text = problem.message ?: ui(R.string.ui_could_not_complete_the_operation)
39:                 }
40:             }
41:         }
42:         dialog.show()
43:         return dialog
44:     }
