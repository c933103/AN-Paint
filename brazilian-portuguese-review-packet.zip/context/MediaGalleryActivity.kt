57:                 CreditEditSession.create(filesDir,credits,CreditEditContext.ledgerOnly(credits))
58:             }
59:         } catch(_: Exception) {
60:             // Keep the explanation visible until dismissed. Finishing immediately would
61:             // detach the app-window Nôm notice before the user could read it.
62:             creditSessionError=EditorDialogBuilder(this).setMessage(ui(R.string.gallery_credit_could_not_save))
63:                 .setPositiveButton(ui(R.string.ui_done)) {_,_->finish()}
64:                 .setOnCancelListener {finish()}.show()
65:             return // Keep the original file/intent unchanged for explicit recovery.
66:         }
67:         unrestoredSessionToken=null
68:         documentCredits=creditSession.credits

238:             creditSession.edit(source,text) {ImageCreditArchive.retainAccepted(this,it)}
239:             documentCredits=creditSession.credits
240:             creditsEdited=true;returnEditedCredits()
241:         },onDismiss={
242:             try {creditSession.saveDraft(null)} catch(_: Exception) {
243:                 LocaleTypography.showMessage(this,ui(R.string.gallery_credit_could_not_save),Toast.LENGTH_LONG)
244:             }
245:         })
246:     }
247:     private fun returnEditedCredits() {
248:         setResult(RESULT_OK,creditSession.result())
249:     }

410:         if(!::creditSession.isInitialized)return
411:         try {
412:             val draft=creditEditor?.takeIf {it.dialog.isShowing}?.snapshot?.invoke() ?: return
413:             creditSession.saveDraft(draft)
414:         } catch(_: Exception) {
415:             LocaleTypography.showMessage(this,ui(R.string.gallery_credit_could_not_save),Toast.LENGTH_LONG,
416:                 creditEditor?.dialog?.window?.decorView)
417:         }
418:     }
419:     override fun onSaveInstanceState(outState: Bundle) {
420:         preserveCreditDraft()
421:         if(::creditSession.isInitialized) creditSession.saveState(outState)

381:                 if(resultFile===file) temporary=null else rendered=null
382:             } catch(error: Exception) {
383:                 runOnUiThread {if(!isFinishing && !isDestroyed) {
384:                     val reason=if(error is SvgOriginalSize.SizeException) ui(when(error.reason) {
385:                         SvgOriginalSize.Reason.UNUSABLE_ORIGINAL_SIZE -> R.string.commons_svg_original_size_unavailable
386:                         SvgOriginalSize.Reason.EXCEEDS_BITMAP_DIMENSIONS -> R.string.commons_svg_original_size_too_large
387:                     }) else commonsMetadataReason(error)
388:                     showStatus(ui(R.string.ui_could_not_load_gallery_image,reason))
389:                 }}
390:             }
391:               catch(error: OutOfMemoryError) {failure(ui(R.string.ui_not_enough_memory_to_inspect_the_gallery_image))}
392:               catch(error: LinkageError) {failure(ui(R.string.ui_could_not_load_gallery_image,ui(R.string.gallery_image_component_unavailable)))}

380:                 // The callback owns only the returned file. Always remove a downloaded SVG after rendering.

102:             row.addView(galleryButton(this,label,tagName,12f,run=run))
103:         }
104:         fun actionRow(actions: GalleryActions): View=if(VerticalText.uiVertical(this@MediaGalleryActivity)) ColumnScrollView(this).apply {
105:             addView(actions)
106:         } else actions
107:         action(ui(R.string.ui_copy_all),"gallery_copy_credits") {
108:             val credits=ImageCredit.text(documentCredits)
109:             if(credits.isBlank()) LocaleTypography.showMessage(this,ui(R.string.ui_no_gallery_images_have_been_inserted),Toast.LENGTH_SHORT)
110:             else GalleryCredits.copy(this,credits)
111:         }
112:         action(ui(R.string.gallery_edit_credits),"gallery_edit_credits") {showCreditEditor()}
113:         action(ui(R.string.ui_credits_terms),"gallery_terms") {openExternal(Uri.parse(provider.terms))}

69:         creditsEdited=creditSession.accepted || state?.getBoolean("document_image_credits_edited")==true

114:         action(ui(R.string.ui_done),"gallery_done") {finish()};controls.addView(actionRow(row))
115:         if(ImageCreditArchive.hasRecords(this)) {
116:             val legacy=GalleryActions(this).apply {
117:                 addView(galleryButton(this@MediaGalleryActivity,ui(R.string.legacy_credits_title),"gallery_legacy_credits") {
118:                     startActivityForResult(Intent(this@MediaGalleryActivity,LegacyImageCreditsActivity::class.java),LEGACY_CREDITS)
119:                 })
120:             }
