110:                 out.toByteArray()
111:             }
112:         fun read(file: File): PlatformImageColour {
113:             try { LegacyColourMetadata.check(file) }
114:             catch (error: LegacyColourMetadata.UnsupportedColour) {
115:                 throw IOException(ui(R.string.save20_unsupported_image_colour),error)
116:             } catch (error: IOException) {
117:                 throw IOException(ui(R.string.colour_invalid_metadata),error)
118:             }
119:             var profile: ByteArray?=null;var cicp: ByteArray?=null;var highDepth=false
120:             var pngGamma: Double?=null;var pngChromaticities: DoubleArray?=null;var pngSrgb=false
121:             val removed=mutableListOf<LongRange>();var format=""

53:             else -> input
54:         } } catch (error: LinkageError) {
55:             // A damaged/unsupported native installation must become the normal
56:             // visible import error, rather than escaping the worker and leaving
57:             // the editor permanently busy. Never substitute unconverted pixels.
58:             throw IOException(ui(R.string.colour_converter_unavailable),error)
59:         }
60:     }
61: 
62:     fun <T> withDecodeFile(source: File, action: (File) -> T): T {
63:         if (!explicitConversion) return action(source)
64:         val temporary = File.createTempFile("colour-input-", ".img", source.parentFile)

93:         } finally { temporary.delete() }
94:     }
95: 
96:     companion object {
97:         private const val MAX_PROFILE = 4 * 1024 * 1024
98:         private fun error(): Nothing = throw IOException(ui(R.string.colour_invalid_metadata))
99:         private fun readLittle(input: RandomAccessFile): Long = (0..3).fold(0L) { result,shift ->
100:             val value=input.read();if(value<0)error();result or (value.toLong() shl (shift*8))
101:         }
102:         private fun bytes(input: RandomAccessFile, length: Long): ByteArray {
103:             if(length !in 0..MAX_PROFILE.toLong()) error()
104:             return ByteArray(length.toInt()).also { input.readFully(it) }

122:             RandomAccessFile(file,"r").use { input ->
123:                 if(input.length()<8) return PlatformImageColour("",emptyList(),null,null,null,null,false)

67:                 RandomAccessFile(temporary,"rw").use { output ->
68:                     val buffer = ByteArray(64 * 1024)
69:                     fun copyUntil(end: Long) {
70:                         while (input.filePointer < end) {
71:                             val count = input.read(buffer,0,minOf(buffer.size.toLong(),end-input.filePointer).toInt())
72:                             if (count < 0) throw IOException(ui(R.string.colour_truncated_metadata))
73:                             output.write(buffer,0,count)
74:                         }
75:                     }
76:                     omitted.sortedBy { it.first }.forEach { range -> copyUntil(range.first); input.seek(range.last+1) }
77:                     copyUntil(input.length())
78:                     if (format == "WEBP") {

209:                 if((it[2].toInt() and 255)!=0 || (it[3].toInt() and 255)!=1)error()
210:             }
211:             profile?.let {
212:                 if(it.size<128 || String(it,36,4,Charsets.US_ASCII)!="acsp")error()
213:                 if(String(it,16,4,Charsets.US_ASCII) !in setOf("RGB ","GRAY"))
214:                     throw IOException(ui(R.string.colour_unsupported_icc_model))
215:             }
216:             return PlatformImageColour(format,removed,if(cicp==null)profile else null,cicp,
217:                 if(usePngMetadata)pngGamma?.toFloat() else null,
218:                 if(usePngMetadata)pngChromaticities?.map { it.toFloat() }?.toFloatArray() else null,highDepth)
219:         }
220:     }
