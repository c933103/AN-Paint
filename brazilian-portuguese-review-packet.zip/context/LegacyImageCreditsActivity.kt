88:         body.addView(picker)
89:         updatePage()
90:         body.addView(creditScroll,LinearLayout.LayoutParams(-1,0,1f));body.addView(navigation)
91:         status=TextView(this).apply {
92:             tag="legacy_credit_status";setTextColor(EditorColours.onSurface)
93:             if(archive.unreadableSnapshots>0)text=ui(R.string.legacy_credits_unreadable)
94:         }
95:         body.addView(status)
96:         fun action(label: String, tagName: String, run: ()->Unit) {
97:             body.addView(Button(this).apply {
98:                 text=label;tag=tagName;isAllCaps=false;setOnClickListener {run()}
99:                 isEnabled=records.isNotEmpty() || tagName=="legacy_credit_done"

115:                     },EXPORT_TEXT)
116:                 } catch(error: Exception) {
117:                     pendingExportToken=null
118:                     status.text=when(error) {
119:                         is ActivityNotFoundException -> ui(R.string.ui_android_could_not_find_a_file_picker_enable)
120:                         is SecurityException -> ui(R.string.ui_android_blocked_the_file_picker,
121:                             error.message ?: ui(R.string.ui_could_not_complete_the_operation))
122:                         else -> ui(R.string.ui_could_not_complete_the_operation)
123:                     }
124:                 }
125:             }
126:         }

114:                         putExtra(Intent.EXTRA_TITLE,"AN-Paint-legacy-credit.txt")

127:         action(ui(R.string.ui_done),"legacy_credit_done") {finish()}

128:         setContentView(body);LocaleTypography.install(body)

138:         // returned file: URI truncate this app's private draft/archive files.
139:         // Our own FileProvider is for sharing cache/images, not SAF destinations;
140:         // strip Android's optional user-id prefix before rejecting that authority.
141:         if(uri.scheme!="content" || uri.authority.isNullOrEmpty() ||
142:             uri.authority?.substringAfterLast('@')=="$packageName.fileprovider") {
143:             status.text=ui(R.string.ui_could_not_complete_the_operation);return
144:         }
145:         val credit=records.singleOrNull {it.token==token}?.credit ?: ImageCreditArchive.find(this,token)
146:         if(credit==null) {status.text=ui(R.string.ui_could_not_complete_the_operation);return}
147:         status.text=ui(R.string.ui_working)
148:         worker.execute {
149:             val failure=try {

150:                 val stream=contentResolver.openOutputStream(uri,"wt") ?: throw IOException("No output stream")
151:                 stream.writer(Charsets.UTF_8).use {it.write(credit.text)}
152:                 null

153:             } catch(error: Exception) {error}
154:             runOnUiThread {if(!isDestroyed) status.text=ui(if(failure==null)
155:                 R.string.gallery_credit_saved else R.string.ui_could_not_complete_the_operation)}
156:         }
157:     }
158: 
159:     override fun onSaveInstanceState(state: Bundle) {
160:         state.putString("selected_token",records.getOrNull(selected)?.token);state.putInt("page",page)
161:         state.putString("export_token",pendingExportToken)

129:     }
130: 
131:     public override fun onActivityResult(requestCode: Int,resultCode: Int,data: Intent?) {
132:         super.onActivityResult(requestCode,resultCode,data)
133:         if(requestCode!=EXPORT_TEXT)return
