10:         val output=ByteArrayOutputStream()
11:         val buffer=ByteArray(8192)
12:         while(true) {
13:             val count=input.read(buffer)
14:             if(count<0) break
15:             require(count<=limit-output.size()) { ui(org.catrobat.paintroid.R.string.ui_invalid_autosave_metadata) }
16:             output.write(buffer,0,count)
17:         }
18:         return output.toString(Charsets.UTF_8.name())
19:     }
20: }
