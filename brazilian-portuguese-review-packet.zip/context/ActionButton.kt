7: import android.content.Context
8: import android.graphics.*
9: import android.view.View
10: import org.catrobat.paintroid.R
11: 
12: enum class EditIcon(private val labelId: Int) { SAVE(R.string.ui_save), FIT(R.string.ui_fit_entire_canvas_in_view), UNDO(R.string.ui_undo), REDO(R.string.ui_redo), CUT(R.string.ui_cut), COPY(R.string.ui_copy), PASTE(R.string.ui_paste), MINUS(R.string.ui_zoom_out), PLUS(R.string.ui_zoom_in), SELECT_ALL(R.string.ui_select_all), SIDEBAR(R.string.ui_toggle_toolbox);
13:     val label: String get() = ui(labelId)
14: }
15: 
16: class ActionButton(context: Context, val icon: EditIcon) : View(context) {
17:     var sideLayout=false
18:     private val glyph = CopyleftIcon(context, when (icon) {
