31:         addView(colours,LayoutParams(-1,-1).apply { rightMargin=0 })
32:     }
33:     fun refresh() {
34:         foregroundTarget.contentDescription=ui(R.string.ui_foreground_edit_colour,hex(foreground))
35:         backgroundTarget.contentDescription=ui(R.string.ui_background_edit_colour,hex(backgroundColour))
36:         contentDescription=ui(R.string.ui_foreground_colour)+" / "+ui(R.string.ui_background_colour)
37:         invalidate()
38:     }
39:     private fun hex(c: Int)=String.format(Locale.ROOT,"#%06X",c and 0xffffff)
40:     override fun onDraw(c: Canvas) {
41:         super.onDraw(c)
42:         val d=resources.displayMetrics.density

30:         // Separate targets keep foreground/background editing accessible.

43:         val p=Paint(Paint.ANTI_ALIAS_FLAG)
44:         if(VerticalText.uiVertical(context)) {
45:             listOf(foreground to ui(R.string.ui_fg),backgroundColour to ui(R.string.ui_bg)).forEachIndexed {i,(colour,name) ->
46:                 val left=i*width/2f
47:                 p.color=colour;c.drawRect(left+2*d,2*d,left+width/2f-2*d,height-2*d,p)
48:                 val luminance=androidx.core.graphics.ColorUtils.calculateLuminance(colour)
49:                 p.color=if(luminance>.179) Color.BLACK else Color.WHITE;p.textSize=11*resources.displayMetrics.scaledDensity
50:                 p.typeface=VerticalText.uiTypeface(context) ?: Typeface.DEFAULT_BOLD
51:                 val caption=name+"\n"+hex(colour)

54:                 VerticalText.draw(c,caption,p,VerticalText.uiDirection(context),GlyphOrientation.MIXED);c.restore()
55:             }
56:             return
57:         }
58:         val colourRight=width.toFloat()
59:         listOf(foreground to ui(R.string.ui_fg),backgroundColour to ui(R.string.ui_bg)).forEachIndexed { i,(colour,name) ->
60:             val top=i*height/2f
61:             p.color=colour;c.drawRect(3*d,top+2*d,colourRight,top+height/2f-2*d,p)
62:             fun linear(value: Int): Double { val s=value/255.0;return if (s<=.04045) s/12.92 else Math.pow((s+.055)/1.055,2.4) }
63:             val luminance=.2126*linear(Color.red(colour))+.7152*linear(Color.green(colour))+.0722*linear(Color.blue(colour))
64:             p.color=if (luminance>.179) Color.BLACK else Color.WHITE
65:             p.textSize=11*d;p.typeface=Typeface.create(VerticalText.uiTypeface(context) ?: Typeface.DEFAULT,Typeface.BOLD)

29:         colours.addView(backgroundTarget,LinearLayout.LayoutParams(if(VerticalText.uiVertical(context)) 0 else -1,if(VerticalText.uiVertical(context)) -1 else 0,1f))
