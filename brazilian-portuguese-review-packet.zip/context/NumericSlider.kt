66:             val input=EditText(context).apply {
67:                 tag="numeric_input";LocaleNumberInput.configure(this)
68:                 setText((slider.progress+minimum).toString());selectAll();gravity=Gravity.CENTER
69:             }
70:             val dialog=EditorDialogBuilder(context).setTitle(name).setMessage(ui(R.string.ui_enter_a_whole_number_from_to, minimum, maximum))
71:                 .setView(input).setPositiveButton(ui(R.string.ui_apply),null).setNegativeButton(ui(R.string.ui_cancel),null).create()
72:             dialog.setOnShowListener { dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
73:                 val n=input.text.toString().toIntOrNull()
74:                 if(n==null || n !in minimum..maximum) input.error=ui(R.string.ui_enter_a_number_from_to, minimum, maximum)
75:                 else { slider.progress=n-minimum;dialog.dismiss() }
76:             } };dialog.show()
77:         }

78:     }
79: }

65:         number.setOnClickListener {

53:         orientation=if(VerticalText.uiVertical(context)) HORIZONTAL else VERTICAL;isBaselineAligned=false
54:         number.isAllCaps=false;number.textSize=11f;number.setPadding(0,0,0,0);number.minWidth=0;number.minimumWidth=0
55:         addView(number,LayoutParams(if(VerticalText.uiVertical(context)) -2 else -1,if(VerticalText.uiVertical(context)) -2 else dp(44)))
56:         slider.max=maximum-minimum;slider.progress=value.coerceIn(minimum,maximum)-minimum
57:         slider.contentDescription=name;addView(slider,LayoutParams(if(VerticalText.uiVertical(context)) dp(100) else -1,dp(44)))
58:         fun display(n: Int) { number.text=ui(R.string.ui_numeric_slider_value,name,n);number.contentDescription=ui(R.string.ui_tap_to_type_a_number, name, n) }
59:         display(slider.progress+minimum)
60:         slider.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
61:             override fun onProgressChanged(bar: SeekBar?,n: Int,user: Boolean) { display(n+minimum);changed(n+minimum) }
62:             override fun onStartTrackingTouch(bar: SeekBar?)=Unit
63:             override fun onStopTrackingTouch(bar: SeekBar?)=Unit
64:         })
