74: 
75:     fun showEditor(activity: Activity, credits: List<ImageCredit>, draft: EditorDraft?,
76:         onEdit: (String,String)->Unit, onDismiss: ()->Unit): EditorSession? = try {
77:         CreditSessionJson.withResources {buildEditor(activity,credits,draft,onEdit,onDismiss)}
78:     } catch(_: java.io.IOException) {
79:         LocaleTypography.showMessage(activity,ui(R.string.gallery_credit_could_not_save),Toast.LENGTH_LONG)
80:         null
81:     }
82: 
83:     private fun buildEditor(activity: Activity, credits: List<ImageCredit>, draft: EditorDraft?,
84:         onEdit: (String,String)->Unit, onDismiss: ()->Unit): EditorSession? {
85:         val entries=credits.associateBy {it.source}.toMutableMap()

108:                 CreditSessionJson.withResources {onEdit(source,text)}
109:             }
110:             catch(_: IllegalArgumentException) {
111:                 LocaleTypography.showMessage(activity,ui(R.string.gallery_credit_too_large),Toast.LENGTH_LONG,field);return false
112:             } catch(_: java.io.IOException) {
113:                 LocaleTypography.showMessage(activity,ui(R.string.gallery_credit_could_not_save),Toast.LENGTH_LONG,field);return false
114:             }
115:             entries[source]=ImageCredit(source,text)
116:             return true
117:         }
118:         val initialText=if(restoredIndex>=0) draft!!.text else entries.getValue(sources[selected]).text
119:         CreditSessionJson.checkText(initialText)

106:                 require(CreditSessionJson.fitsInline(field.text,AutosaveStore.MAX_METADATA_BYTES))
107:                 text=CreditSessionJson.snapshot(source,field.text).text

129:             }
130:         }
131:         val dialog=EditorDialogBuilder(activity).setTitle(ui(R.string.ui_image_credits))
132:             .setView(ScrollView(activity).apply {addView(body)})
133:             .setNegativeButton(ui(R.string.gallery_copy_credit),null)
134:             .setNeutralButton(ui(R.string.ui_save),null)
135:             .setPositiveButton(ui(R.string.ui_done),null).create()
136:         dialog.setOnShowListener {
137:             fun action(which: Int,tagName: String,run: ()->Unit) {
138:                 dialog.getButton(which).apply {tag=tagName;setOnClickListener {run()}}
139:             }
140:             action(AlertDialog.BUTTON_NEGATIVE,"gallery_credit_copy") {if(save()) copy(activity,entries.getValue(sources[selected]).text,field)}

49:     }
50:     fun copy(context: Context, text: String, anchor: android.view.View? = null): Boolean {
51:         try {publishClipboard(context,ClipData.newPlainText(ui(R.string.ui_image_credits),text))}
52:         catch(_: Exception) {
53:             // Binder/provider rejection must not roll back an accepted Save or claim Copied.
54:             LocaleTypography.showMessage(context,ui(R.string.ui_could_not_complete_the_operation),Toast.LENGTH_LONG,anchor)
55:             return false
56:         }
57:         LocaleTypography.showMessage(context,ui(R.string.gallery_credit_copied),Toast.LENGTH_SHORT,anchor)
58:         return true
59:     }
60: 

141:             action(AlertDialog.BUTTON_NEUTRAL,"gallery_credit_save") {if(save()) LocaleTypography.showMessage(activity,ui(R.string.gallery_credit_saved),Toast.LENGTH_SHORT,field)}
