19:     PICKER(R.string.ui_eyedropper, R.string.ui_tap_the_image_to_sample_the_foreground_colour),
20:     ZOOM(R.string.ui_navigate, R.string.ui_drag_to_pan_without_drawing_pinch_with_two),
21:     PENCIL(R.string.ui_pencil, R.string.ui_draw_a_crisp_one_pixel_line),
22:     BRUSH(R.string.ui_brush, R.string.ui_draw_with_the_selected_brush_tip_and_size),
23:     WATERCOLOR(R.string.ui_watercolor, R.string.ui_draw_soft_watercolor_strokes_strength_controls_how_strongly),
24:     SPRAY(R.string.ui_airbrush, R.string.ui_hold_or_drag_to_spray_colour),
25:     TEXT(R.string.ui_text, R.string.ui_tap_the_canvas_to_place_text_and_choose),
26:     LINE(R.string.ui_line, R.string.ui_drag_from_the_start_to_the_end_of),
27:     CURVE(R.string.ui_curve, R.string.ui_drag_a_line_then_drag_twice_to_set),
28:     RECTANGLE(R.string.ui_rectangle, R.string.ui_drag_between_opposite_corners_choose_outline_or_fill),
29:     POLYGON(R.string.ui_polygon, R.string.ui_tap_vertices_then_double_tap_the_last_vertex),
30:     ELLIPSE(R.string.ui_ellipse, R.string.ui_drag_across_the_ellipse_s_bounding_box),

17:     ERASER(R.string.ui_eraser, R.string.ui_drag_to_erase_with_the_background_colour),
18:     FILL(R.string.ui_bucket_fill, R.string.ui_tap_an_enclosed_area_adjust_tolerance_for_similar),

13: 
14: enum class PaintTool(private val labelId: Int, private val hintId: Int) {
15:     LASSO(R.string.ui_free_form_select, R.string.ui_draw_around_an_area_drag_inside_to_move),
16:     SELECT(R.string.ui_rectangle_select, R.string.ui_drag_a_selection_drag_inside_to_move_square),

186:         (Build.VERSION.SDK_INT < 26 || image.colorSpace?.isSrgb == true)
187: 
188:     private fun copyToCanvasFormat(image: Bitmap, checkMemory: Boolean = true): Bitmap {
189:         if (checkMemory) allocationGuard(image.width,image.height)
190:         if (canonicalPixels(image)) return image.copy(Bitmap.Config.ARGB_8888,true)
191:             ?: throw OutOfMemoryError(ui(R.string.ui_could_not_prepare_the_image))
192:         val copy=Bitmap.createBitmap(image.width,image.height,Bitmap.Config.ARGB_8888)
193:         try { Canvas(copy).drawBitmap(image,0f,0f,null); return copy }
194:         catch (error: Throwable) { copy.recycle(); throw error }
195:     }
196: 
197:     fun replace(image: Bitmap, asEdit: Boolean = false, retainCredits: Boolean = asEdit) {

430:         else canvas.drawBitmap(bitmap, 0f, 0f, copyPaint)
431:         replace(next, true)
432:     }
433: 
434:     fun cropCanvas(rect: Rect) {
435:         require(rect.left >= 0 && rect.top >= 0 && rect.right <= bitmap.width && rect.bottom <= bitmap.height && rect.width() > 0 && rect.height() > 0) { ui(R.string.ui_crop_must_stay_inside_the_canvas) }
436:         changeCanvasBounds(rect)
437:     }
438: 
439:     fun changeCanvasBounds(rect: Rect) {
440:         val width = rect.right.toLong()-rect.left; val height = rect.bottom.toLong()-rect.top
441:         require(width in 1..Int.MAX_VALUE.toLong() && height in 1..Int.MAX_VALUE.toLong()) { ui(R.string.ui_enter_positive_canvas_dimensions_within_android_s_coordinate) }

31:     ROUND_RECT(R.string.ui_rounded_rectangle, R.string.ui_set_radius_px_then_drag_between_opposite_corners),
32:     HEART(R.string.ui_heart, R.string.ui_drag_between_opposite_corners_to_draw_a_heart),
33:     STAR(R.string.ui_star, R.string.ui_drag_between_opposite_corners_to_draw_a_five),
34:     ARROW(R.string.ui_arrow, R.string.ui_drag_from_the_tail_towards_the_arrowhead_choose);
35:     val label: String get() = ui(labelId)
36:     val hint: String get() = ui(hintId)

442:         if (rect == Rect(0,0,bitmap.width,bitmap.height)) return
443:         allocationGuard(rect.width(),rect.height()); finishSelection()
444:         val next = Bitmap.createBitmap(rect.width(),rect.height(),Bitmap.Config.ARGB_8888)
445:         try {
446:             next.eraseColor(background)
447:             val copy = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC) }

150:     val residentPixels: Long get() = bitmap.width.toLong() * bitmap.height +
151:         (selection?.image?.let { it.width.toLong() * it.height } ?: 0) +
152:         (clipboard?.let { it.width.toLong() * it.height } ?: 0)
153: 
154:     private fun blank(w: Int, h: Int, color: Int): Bitmap {
155:         require(w > 0 && h > 0) { ui(R.string.ui_enter_positive_image_dimensions) }
156:         allocationGuard(w, h)
157:         return Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).apply { eraseColor(color or Color.BLACK);setHasAlpha(false) }
158:     }
159: 
160:     fun checkpoint(clearRedo: Boolean = true) {
161:         val snapshot = history.capture(bitmap,committedCredits.values.toList())

419:         s.rect.set(cx-s.image.width/2f,cy-s.image.height/2f,cx+s.image.width/2f,cy+s.image.height/2f)
420:         edited();return true
421:     }
422: 
423:     fun resize(w: Int, h: Int, stretch: Boolean) {
424:         require(w > 0 && h > 0) { ui(R.string.ui_enter_positive_image_dimensions) }
425:         finishSelection()
426:         val next = blank(w, h, background)
427:         val canvas = Canvas(next)
428:         val copyPaint = Paint(if (stretch) Paint.FILTER_BITMAP_FLAG else 0).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC) }
429:         if (stretch) canvas.drawBitmap(bitmap, null, Rect(0, 0, w, h), copyPaint)

12: import java.io.File

10: import android.os.Build
11: import java.util.ArrayDeque

349:     private fun transformedSelectionImage(): Bitmap? {
350:         val s = selection ?: return null
351:         val bounds = s.geometry.bounds()
352:         val w = kotlin.math.ceil(bounds.width().toDouble()).toLong()
353:         val h = kotlin.math.ceil(bounds.height().toDouble()).toLong()
354:         require(w in 1..Int.MAX_VALUE.toLong() && h in 1..Int.MAX_VALUE.toLong()) { ui(R.string.ui_selection_dimensions_are_too_large) }
355:         allocationGuard(w.toInt(),h.toInt())
356:         val output = Bitmap.createBitmap(w.toInt(),h.toInt(),Bitmap.Config.ARGB_8888)
357:         var rendered: Bitmap? = null
358:         try {
359:             rendered = selectionImage()!!
360:             val canvas = Canvas(output);canvas.translate(-bounds.left,-bounds.top)
