20: /** Estimates are doubles only for byte display/comparison; exact pixel counts use Long. */
21: fun memoryLabel(bytes: Double): String {
22:     val units = arrayOf("B", "KiB", "MiB", "GiB", "TiB", "PiB", "EiB")
23:     var amount = bytes.coerceAtLeast(0.0); var unit = 0
24:     while (amount >= 1024 && unit < units.lastIndex) { amount /= 1024; unit++ }
25:     return String.format(Locale.ROOT, ui(R.string.ui_1f_s), amount, units[unit])
26: }
27: 
28: data class ImportPlan(val target: ImageDimensions, val sample: Int, val decodedPixels: Long) {
29:     fun estimatedBytes(residentPixels: Long) = max(target.pixels * 12.0, decodedPixels * 4.0 + target.pixels * 8.0) + residentPixels * 4.0
30:     companion object {
31:         fun create(source: ImageDimensions, target: ImageDimensions): ImportPlan {

158:         var decoded: Bitmap? = null
159:         var output: Bitmap? = null
160:         try {
161:             val colour = checkNotNull(platformColour)
162:             val raw = withPlatformFile { platformFile -> colour.withDecodeFile(platformFile) { BitmapFactory.decodeFile(it.path,colour.options(plan.sample)) } }
163:                 ?: throw IOException(ui(R.string.ui_android_could_not_decode_this_image))
164:             decoded = raw
165:             val input = colour.convert(raw)
166:             if (input !== raw) { raw.recycle(); decoded = input }
167:             input.density = Bitmap.DENSITY_NONE
168:             val rotation = orientation?.rotationDegrees ?: 0; val flip = orientation?.isFlipped == true
169:             if (rotation == 0 && !flip && input.width == plan.target.width && input.height == plan.target.height && input.isMutable && input.config == Bitmap.Config.ARGB_8888) {

32:             require(target.width <= source.width && target.height <= source.height) { ui(R.string.ui_choose_dimensions_no_larger_than_the_original) }
33:             fun ceilDivide(n: Int, d: Int) = (n.toLong() + d - 1) / d
34:             var sample = 1
35:             // Keep at least the requested detail. Decode a bounded power-of-two sample,
36:             // then scale once to the exact requested dimensions while applying EXIF.
37:             while (sample < (1 shl 30) && sample * 2 <= max(source.width, source.height) &&
38:                 ceilDivide(source.width, sample * 2) >= target.width && ceilDivide(source.height, sample * 2) >= target.height) sample *= 2

11: import kotlin.math.*
12: 
13: data class ImageDimensions(val width: Int, val height: Int) {
14:     init { require(width > 0 && height > 0) { ui(R.string.ui_enter_positive_image_dimensions) } }
15:     val pixels: Long get() = width.toLong() * height
16:     fun describe() = String.format(Locale.ROOT, ui(R.string.ui_d_d_px_d_pixels_2f_mp), width, height, pixels, pixels / 1_000_000.0)
17:     fun scaled(scale: Double) = ImageDimensions(max(1, floor(width * scale).toInt()), max(1, floor(height * scale).toInt()))
18: }
19: 

9: import java.io.IOException
10: import java.util.Locale

44: fun ImageMemoryPolicy.accepts(plan: ImportPlan, residentPixels: Long): Boolean =
45:     plan.target.pixels <= maxPixels(residentPixels) && plan.decodedPixels <= ImageMemoryPolicy.MAX_BITMAP_PIXELS && plan.estimatedBytes(residentPixels) <= workingBytes.toDouble()
46: 
47: fun ImageMemoryPolicy.checkImport(plan: ImportPlan, residentPixels: Long) {
48:     check(plan.target.width, plan.target.height, residentPixels)
49:     if (!accepts(plan, residentPixels)) throw ImageSizeException(ui(R.string.ui_the_decoder_and_editing_buffers_need_about_the, memoryLabel(plan.estimatedBytes(residentPixels)), memoryLabel(workingBytes.toDouble())))
50: }
51: 
52: fun ImageMemoryPolicy.suggestResize(source: ImageDimensions, residentPixels: Long, maxScale: Double = 1.0): ImageDimensions? {
53:     if (!accepts(ImportPlan.create(source, ImageDimensions(1,1)), residentPixels)) return null
54:     var low = 0.0; var high = maxScale.coerceIn(0.0,1.0)
55:     // Leave 10% of the computed working budget free for changes while the dialog is open.

84:             plan.decodedPixels <= (Int.MAX_VALUE.toLong()-8) / minOf(decodedBytesPerPixel,8) &&
85:             estimatedBytes(plan,residentPixels) <= policy.workingBytes.toDouble()
86: 
87:     fun checkImport(policy: ImageMemoryPolicy, plan: ImportPlan, residentPixels: Long) {
88:         policy.check(plan.target.width,plan.target.height,residentPixels)
89:         if(!accepts(policy,plan,residentPixels)) throw ImageSizeException(ui(R.string.ui_the_decoder_and_editing_buffers_need_about_the,
90:             memoryLabel(estimatedBytes(plan,residentPixels)),memoryLabel(policy.workingBytes.toDouble())))
91:     }
92: 
93:     fun suggestResize(source: ImageDimensions, policy: ImageMemoryPolicy, residentPixels: Long, maxScale: Double = 1.0): ImageDimensions? {
94:         if(!accepts(policy,ImportPlan.create(source,ImageDimensions(1,1)),residentPixels)) return null
95:         var low=0.0;var high=maxScale.coerceIn(0.0,1.0)

145:     fun accepts(policy: ImageMemoryPolicy,plan: ImportPlan,residentPixels: Long)=memoryRequirements.accepts(policy,plan,residentPixels)
146:     fun checkImport(policy: ImageMemoryPolicy,plan: ImportPlan,residentPixels: Long)=memoryRequirements.checkImport(policy,plan,residentPixels)
147:     fun suggestResize(policy: ImageMemoryPolicy,residentPixels: Long,maxScale: Double=1.0)=memoryRequirements.suggestResize(dimensions,policy,residentPixels,maxScale)
148: 
149:     fun decode(plan: ImportPlan,workingBytes: Long=ImageMemoryPolicy.forRuntime().workingBytes,residentPixels: Long=0): Bitmap {
150:         if (estimatedBytes(plan,residentPixels)>workingBytes) throw ImageSizeException(ui(R.string.ui_the_decoder_and_editing_buffers_need_about_the,
151:             memoryLabel(estimatedBytes(plan,residentPixels)),memoryLabel(workingBytes.toDouble())))
152:         val decoderBudget=memoryRequirements.decoderBudget(workingBytes,plan.target,residentPixels)
153:         if(jxl) return JxlCodec.decode(file,plan.target,decoderBudget)
154:         if(heif) return HeifCodec.decode(file,plan.target,decoderBudget)
155:         if(tiff) return TiffCodec.decode(file,plan.target,decoderBudget,pageIndex=pageIndex)
156:         if(pdf) return PdfCodec.decode(file,plan.target,decoderBudget,pageIndex=pageIndex)

129:         else if(heif) {val size=HeifCodec.dimensions(file);bounds.outWidth=size.width;bounds.outHeight=size.height}
130:         else if(tiff) {val size=TiffCodec.dimensions(file,pageIndex);bounds.outWidth=size.width;bounds.outHeight=size.height}
131:         else if(pdf) {val size=PdfCodec.dimensions(file,pageIndex);bounds.outWidth=size.width;bounds.outHeight=size.height}
132:         else if(ico) {val size=IcoCodec.dimensions(file);bounds.outWidth=size.width;bounds.outHeight=size.height}
133:         else withPlatformFile {BitmapFactory.decodeFile(it.path, bounds)}
134:         if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IOException(ui(R.string.ui_this_file_is_not_a_supported_image_use))
135:         orientation = if(jxl || heif || tiff || dib || pdf || ico) null else try { ExifInterface(file.path) } catch (_: IOException) { null }
136:         dimensions = if (orientation?.rotationDegrees in listOf(90,270)) ImageDimensions(bounds.outHeight,bounds.outWidth) else ImageDimensions(bounds.outWidth,bounds.outHeight)
137:         // Inspect the native source/tile footprint once, not on every slider tick.
138:         // Ordinary formats never initialize a JNI library here.
139:         memoryRequirements=ImportMemoryRequirements(
140:             when {heif -> HeifCodec.decodeWorkingBytes(file,ImageDimensions(1,1));tiff -> TiffCodec.decodeWorkingBytes(file,ImageDimensions(1,1),pageIndex);
