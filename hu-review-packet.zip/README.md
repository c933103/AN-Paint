# Hungarian P0 + P1 linguistic review

Source: AN Paint develop `4355869e2e198b5616419291cba225b018444fab`, tree `b9b148d5d8ef7c7b088500a9c177f9f59304b800`.

All 341 priority keys were reviewed as one batch: 92 P0 and 249 P1. This is a linguistic and current static-context review, not a technical-format check presented as linguistic acceptance.

## Result

- 292 current values accepted within static consumer context.
- 30 current values accepted for wording only, with no exact direct production consumer found. Their source-only limits remain.
- 1 exact prior sampled-memory pair retained with its original bounded semantic limits.
- 18 current values require proposed correction: 8 P0 and 10 P1. No proposed text has been integrated or independently accepted.
- Zero priority keys left unreviewed. No native-speaker, whole-language, device, layout, visual or accessibility-behavior acceptance is claimed.

The main corrections address the inaccurate translation-completeness claim, crop-edge grammatical composition, malformed tap/hold instructions, top-left canvas anchoring, returning from navigation to drawing, decoder memory-floor wording, save/recovery phrasing, format-list case structure and consistent dithering terminology.

All 21 historical complete-value Hungarian pairs still bind exactly to the supplied source and target; only the sampled-memory pair overlaps these 341 keys. Including the other 20 retained pairs, the priority-only reconciliation is 343 current / 18 held / 356 present unknown / 0 missing, out of 717 entries.

Two explicit adjacent P2 findings were found while checking actual crop consumers: `ui_top` has the same edge-label composition problem, and both `ui_crop_preview_images` forms turn “may move attached images” into definite movement of attachments. They are recorded separately and are not changed by this patch or counted as priority/P2 acceptance. If the tracker records these known findings as holds, the catalogue partition is 343 current / 20 held / 354 present unknown / 0 missing. Do not silently count them as accepted or leave the findings unrecorded.

## Files

- `hungarian-p0-p1-341-review.json`: full 341-key ledger, exact values/hashes, resolved alias, individual linguistic rationales, source references, context snippets, confidence and limits.
- `current-bindings.json`: compact current source/target bindings.
- `prior-exact-current-bindings.json`: all 21 historical pairs rebound, retaining original receipts.
- `correction-proposals.json`: 18 proposed replacements and reasons, with before/after hashes.
- `hungarian-priority-candidate.patch`: proposal-only patch against `Paintroid/src/main/res/values-hu/strings.xml`.
- `candidate/Paintroid/src/main/res/values-hu/strings.xml`: standalone candidate copy, never written to shared source.
- `adjacent-p2-findings.json`: two additional crop-context findings with separate proposed wording; no P2 completion claim.
- `hungarian-p0-p1-review.csv`: readable per-key summary.
- `validation.json`: lightweight parse, exact-key, placeholder, source-unchanged and patch-scope checks.

## Verification limits

The candidate XML parses, keeps all 717 entries, changes exactly 18 priority strings, preserves positional format tokens and leaves resource attributes intact. Hungarian `50–300%-ot` is literal text under `formatted="false"`, not a format placeholder. Those structural checks support the artifact only; the review decisions come from the separate per-key linguistic rationales.

No builds, Gradle, APK generation, CI, emulator/device operation, version changes or release actions were performed. No screenshots were created and no raster/layout result is claimed. The shared source catalogue was not modified. The existing source message about unsupported colour conversion is reused by some export codecs despite its import-focused advice; that source-side issue is disclosed in the affected entry and is not repaired by a Hungarian-only proposal.
