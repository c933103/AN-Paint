"""Execute exact display helper bodies on a JVM with a documented Resources formatter stand-in.
This supplements, and does not replace, Android/Robolectric execution.
"""
from pathlib import Path
import subprocess,json,hashlib,xml.etree.ElementTree as ET
O=Path(__file__).resolve().parent;W=O.parent/'worktree';B=Path('/workspace/shared/anpaint-commons-errors-20261017/compile-check/deps')
java='/usr/lib/jvm/java-21-openjdk-amd64/bin/java';deps=':'.join(str(p)for p in sorted(B.glob('*.jar')))
source=(W/'Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageImport.kt').read_text()
body=source[source.index('data class ImageDimensions'):source.index('data class ImportPlan')]
rootbody='fun describe() = String.format(Locale.ROOT, ui(R.string.ui_d_d_px_d_pixels_2f_mp), width, height, pixels, pixels / 1_000_000.0)'
fixedbody='fun describe() = ui(R.string.ui_d_d_px_d_pixels_2f_mp, width, height, pixels, pixels / 1_000_000.0)'
fixedmemory='return ui(R.string.ui_1f_s, amount, units[unit])'
rootmemory='return String.format(Locale.ROOT, ui(R.string.ui_1f_s), amount, units[unit])'
if fixedbody not in body or fixedmemory not in body:raise ValueError('Unexpected current consumer')
res=W/'Paintroid/src/main/res'
def strings(folder):return {n.get('name'):''.join(n.itertext())for n in ET.parse(res/folder/'strings.xml').getroot()if n.tag=='string'}
en=strings('values')
def kt(s):return json.dumps(s,ensure_ascii=False).replace('$','\\$')
key='ui_d_d_px_d_pixels_2f_mp';mk='ui_1f_s';templates={tag:{k:strings(folder).get(k,en[k])for k in [key,mk]}for tag,folder in [('pt-BR','values-pt-rBR'),('de','values-de'),('en-US','values'),('ar-EG','values-ar'),('ro','values-ro')]}
head='''package probe
import java.util.Locale
import kotlin.math.*
object R { object string { const val ui_enter_positive_image_dimensions=0; const val ui_d_d_px_d_pixels_2f_mp=1; const val ui_1f_s=2 } }
var selected=Locale.US
var current="en-US"
'''
head+='val templates=mapOf('+',\n'.join(kt(t)+' to listOf("positive dimensions",'+','.join(kt(v[k])for k in[key,mk])+')'for t,v in templates.items())+')\n'
head+='''// Android Resources.getString(id,args) performs this resource-configuration formatting.
fun ui(id:Int,vararg values:Any?):String { val text=templates.getValue(current)[id]; return if(values.isEmpty()) text else String.format(selected,text,*values) }
'''
tail='''
fun equal(expected:Any,actual:Any) { check(expected==actual) { "Expected [$expected], actual [$actual]" } }
fun main() {
 val cases=listOf(
  Triple("pt-BR","en-US","1500 × 1500 px · Quantidade de pixels: 2.250.000 (2,25 MP)"),
  Triple("de","en-US","1500 × 1500 px · 2.250.000 Pixel (2,25 MP)"),
  Triple("en-US","pt-BR","1500 × 1500 px · Pixel count: 2,250,000 (2.25 MP)"),
  Triple("ar-EG","en-US","١٥٠٠ × ١٥٠٠ px · ٢٬٢٥٠٬٠٠٠ بكسل (٢٫٢٥ ميغابكسل)"),
  Triple("ro","en-US","1500 × 1500 px · Pixel count: 2.250.000 (2,25 MP)"))
 for((tag,process,expected)in cases) {current=tag;selected=Locale.forLanguageTag(tag);Locale.setDefault(Locale.forLanguageTag(process));equal(expected,ImageDimensions(1500,1500).describe())}
 for((tag,process,decimal)in listOf(Triple("pt-BR","en-US",','),Triple("en-US","pt-BR",'.'))) {
  current=tag;selected=Locale.forLanguageTag(tag);Locale.setDefault(Locale.forLanguageTag(process))
  for((bytes,expected)in listOf(-1536.0 to "0${decimal}0 B",0.0 to "0${decimal}0 B",1023.0 to "1023${decimal}0 B",1024.0 to "1${decimal}0 KiB",1536.0 to "1${decimal}5 KiB",1572864.0 to "1${decimal}5 MiB",1610612736.0 to "1${decimal}5 GiB")) equal(expected,memoryLabel(bytes))
  val huge=ImageDimensions(Int.MAX_VALUE,Int.MAX_VALUE);equal(4_611_686_014_132_420_609L,huge.pixels)
  check(huge.describe().contains(if(tag=="pt-BR") "4.611.686.014.132.420.609" else "4,611,686,014,132,420,609"))
 }
 println("PASS: 5 complete summaries, 14 memory boundary values, 2 exact Long counts and 2 grouped Long displays")
}
'''
variants={'repaired':body,'old_root_dimensions':body.replace(fixedbody,rootbody),'old_root_memory':body.replace(fixedmemory,rootmemory),'process_default_dimensions':body.replace(fixedbody,rootbody.replace('Locale.ROOT','Locale.getDefault()'))}
results=[]
for name,b in variants.items():
 d=O/'isolated-consumers'/name;d.mkdir(parents=True,exist_ok=True);p=d/'Probe.kt';p.write_text(head+b+tail)
 args=[java,'-cp',deps,'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-jvm-target','17','-classpath',deps,'-d',str(d/'classes'),str(p)]
 c=subprocess.run(args,text=True,capture_output=True);(d/'compile.log').write_text(c.stdout+c.stderr)
 if c.returncode:raise ValueError(c.stderr)
 r=subprocess.run([java,'-cp',str(d/'classes')+':'+str(B/'kotlin-stdlib-1.9.24.jar'),'probe.ProbeKt'],text=True,capture_output=True);(d/'run.log').write_text(r.stdout+r.stderr)
 if (r.returncode==0)!=(name=='repaired'):raise ValueError('Unexpected control outcome '+name+' '+r.stdout+r.stderr)
 results.append({'variant':name,'compile_exit':c.returncode,'run_exit':r.returncode,'result':'pass'if name=='repaired'else 'rejected as expected','source_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
report={'source_file_sha256':hashlib.sha256(source.encode()).hexdigest(),'scope':'Exact ImageDimensions/memoryLabel bodies executed on Java21/Kotlin1.9.24 using source XML templates and a resource-locale String.format stand-in. Not Android or Robolectric execution.','cases':results}
(O/'isolated-consumers.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
