from pathlib import Path
import json,hashlib,re,zipfile
O=Path(__file__).resolve().parent;W=O.parent/'worktree';HEAD='30413454eaa1c1599c15a0a42a4110d8d1976514'
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def write(name,v):(O/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
summary={}
for name in ['host-normal','host-optimized','focused-ptbr-normal','focused-ptbr-optimized','focused-ru-normal']:
 b=(O/(name+'.log')).read_bytes();m=re.search(r'(?m)^Ran (\d+) tests in ([0-9.]+)s\s+OK\s*',b.decode())
 if not m:raise ValueError('Incomplete or failed suite '+name)
 summary[name]={'tests':int(m[1]),'seconds':float(m[2]),'exit_code':0,'log':name+'.log','sha256':sha(b)}
for r in json.loads((O/'repair-delta.json').read_text()):
 p=W/r['path'];b=p.read_bytes()
 if sha(b)!=r['sha256']or blob(b)!=r['git_blob_sha']:raise ValueError('Source drift: '+r['path'])
 cp=O/'application-candidate'/r['path'];cp.parent.mkdir(parents=True,exist_ok=True);cp.write_bytes(b)
prior=json.loads((O.parent/'application-delta.json').read_text())
res=W/'Paintroid/src/main/res/values-pt-rBR/strings.xml'
if blob(res.read_bytes())!='86e7b543d000d3515cc5d0c7e43e193fa3871d50':raise ValueError('Eight wording values drifted')
write('test-summary.json',{'candidate_commit':HEAD,'candidate_tree':'3ac7a0abe119504abbde70537bd6d4a2fcc46d3d','checks':summary,'direct_kotlin_compile':json.loads((O/'kotlin-compile.json').read_text()),'isolated_jvm':json.loads((O/'isolated-consumers.json').read_text()),'earlier_normal_run':'Passed 878 tests but a negative-byte clamp test case was added while it ran. Preserved separately; final normal aggregate repeated after all source edits.','android_gradle_robolectric_lint_device':'Not run locally. Direct compilation and isolated helper execution do not replace exact-head hosted gates.','hosted_run':'https://github.com/c933103/AN-Paint/actions/runs/39046719952','older_run_not_new_head_coverage':'https://github.com/c933103/AN-Paint/actions/runs/39045262426'})
write('repair-summary.json',{'parent_commit':'76807df744b990159fa62c2a68cfe7f4558b967b','candidate_commit':HEAD,'candidate_tree':'3ac7a0abe119504abbde70537bd6d4a2fcc46d3d','source_pr':'https://github.com/c933103/AN-Paint/pull/117','finding':'https://github.com/c933103/AN-Paint/pull/117#discussion_r4303256624','change':'ImageDimensions.describe and memoryLabel delegate typed formatting to currentResources through ui(id,args).','delta_files':6,'overall_pr_files':8,'remote_tree_files_verified':1184,'all_retained_content_and_modes_match':True,'eight_linguistic_values_unchanged':True,'three_open_holds_unchanged':True,'prior_evidence':'https://github.com/c933103/AN-Paint/tree/fb0c77cb5964df034989c692d39f952d76a73e01','prior_status_correction':'The prior consumer test and review treated ROOT numeric punctuation as expected; this was wrong for selected locale display. Those numeric expectations are superseded; baseline linguistic judgments are preserved.','follow_up_record':'remaining-root-display-consumers.json','limits':['No whole-language/native-speaker/layout acceptance.','Other display-only ROOT uses are not fixed by this patch.','Editable numeric serialization, parsing and arithmetic remain unchanged.']})
files={'README.md','six-file-repair.patch','repair-delta.json','candidate-full-tree.json','independent-review.json','format-contract-check.json','repair-summary.json','test-summary.json','remaining-root-display-consumers.json','isolated-consumers.json','kotlin-compile.json','kotlin-compile.log','run_isolated_consumers.py','demonstrate_remaining_consumers.py','RemainingDisplays.kt','remaining-display-compile.log','remaining-display-run.log','compile_changed.py','finalize_repair_evidence.py','host-normal.log','host-optimized.log','host-normal-before-final-clamp-case.log','focused-ptbr-normal.log','focused-ptbr-optimized.log','focused-ru-normal.log','ImageImport-before.kt','BrazilianPortuguesePriorityWordingTest-before.kt'}
files.update(str(p.relative_to(O))for p in (O/'isolated-consumers').rglob('*')if p.is_file()and p.suffix in {'.kt','.log'})
files.update(str(p.relative_to(O))for p in (O/'application-candidate').rglob('*')if p.is_file())
rows=[{'path':p,'size_bytes':(O/p).stat().st_size,'sha256':sha((O/p).read_bytes()),'git_blob_sha':blob((O/p).read_bytes())}for p in sorted(files)]
write('artifact-manifest.json',{'candidate_commit':HEAD,'files':rows})
with zipfile.ZipFile(O/'numeric-locale-repair-evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(files|{'artifact-manifest.json'}):
  i=zipfile.ZipInfo(p,date_time=(2026,10,17,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=(0o100644<<16);z.writestr(i,(O/p).read_bytes())
with zipfile.ZipFile(O/'numeric-locale-repair-evidence.zip')as z:
 if z.testzip()is not None:raise ValueError('ZIP CRC')
 for r in rows:
  if sha(z.read(r['path']))!=r['sha256']:raise ValueError('ZIP member mismatch')
b=(O/'numeric-locale-repair-evidence.zip').read_bytes();write('packet-receipt.json',{'candidate_commit':HEAD,'archive':'numeric-locale-repair-evidence.zip','size_bytes':len(b),'sha256':sha(b),'git_blob_sha':blob(b),'files':len(rows)+1,'all_member_hashes_verified':True})
print(json.dumps(summary,indent=2));print((O/'packet-receipt.json').read_text())
