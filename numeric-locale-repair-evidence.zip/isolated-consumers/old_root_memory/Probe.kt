package probe
import java.util.Locale
import kotlin.math.*
object R { object string { const val ui_enter_positive_image_dimensions=0; const val ui_d_d_px_d_pixels_2f_mp=1; const val ui_1f_s=2 } }
var selected=Locale.US
var current="en-US"
val templates=mapOf("pt-BR" to listOf("positive dimensions","%1\$d × %2\$d px · Quantidade de pixels: %3\$,d (%4\$.2f MP)","%1\$.1f %2\$s"),
"de" to listOf("positive dimensions","%1\$d × %2\$d px · %3\$,d Pixel (%4\$.2f MP)","%1\$.1f %2\$s"),
"en-US" to listOf("positive dimensions","%1\$d × %2\$d px · Pixel count: %3\$,d (%4\$.2f MP)","%1\$.1f %2\$s"),
"ar-EG" to listOf("positive dimensions","%1\$d × %2\$d px · %3\$,d بكسل (%4\$.2f ميغابكسل)","%1\$.1f %2\$s"),
"ro" to listOf("positive dimensions","%1\$d × %2\$d px · Pixel count: %3\$,d (%4\$.2f MP)","%1\$.1f %2\$s"))
// Android Resources.getString(id,args) performs this resource-configuration formatting.
fun ui(id:Int,vararg values:Any?):String { val text=templates.getValue(current)[id]; return if(values.isEmpty()) text else String.format(selected,text,*values) }
data class ImageDimensions(val width: Int, val height: Int) {
    init { require(width > 0 && height > 0) { ui(R.string.ui_enter_positive_image_dimensions) } }
    val pixels: Long get() = width.toLong() * height
    fun describe() = ui(R.string.ui_d_d_px_d_pixels_2f_mp, width, height, pixels, pixels / 1_000_000.0)
    fun scaled(scale: Double) = ImageDimensions(max(1, floor(width * scale).toInt()), max(1, floor(height * scale).toInt()))
}

/** Estimates are doubles only for byte display/comparison; exact pixel counts use Long. */
fun memoryLabel(bytes: Double): String {
    val units = arrayOf("B", "KiB", "MiB", "GiB", "TiB", "PiB", "EiB")
    var amount = bytes.coerceAtLeast(0.0); var unit = 0
    while (amount >= 1024 && unit < units.lastIndex) { amount /= 1024; unit++ }
    return String.format(Locale.ROOT, ui(R.string.ui_1f_s), amount, units[unit])
}


fun equal(expected:Any,actual:Any) { check(expected==actual) { "Expected [$expected], actual [$actual]" } }
fun main() {
 val cases=listOf(
  Triple("pt-BR","en-US","1500 × 1500 px · Quantidade de pixels: 2.250.000 (2,25 MP)"),
  Triple("de","en-US","1500 × 1500 px · 2.250.000 Pixel (2,25 MP)"),
  Triple("en-US","pt-BR","1500 × 1500 px · Pixel count: 2,250,000 (2.25 MP)"),
  Triple("ar-EG","en-US","١٥٠٠ × ١٥٠٠ px · ٢٬٢٥٠٬٠٠٠ بكسل (٢٫٢٥ ميغابكسل)"),
  Triple("ro","en-US","1500 × 1500 px · Pixel count: 2.250.000 (2,25 MP)"))
 for((tag,process,expected)in cases) {current=tag;selected=Locale.forLanguageTag(tag);Locale.setDefault(Locale.forLanguageTag(process));equal(expected,ImageDimensions(1500,1500).describe())}
 for((tag,process,decimal)in listOf(Triple("pt-BR","en-US",','),Triple("en-US","pt-BR",'.'))) {
  current=tag;selected=Locale.forLanguageTag(tag);Locale.setDefault(Locale.forLanguageTag(process))
  for((bytes,expected)in listOf(-1536.0 to "0${decimal}0 B",0.0 to "0${decimal}0 B",1023.0 to "1023${decimal}0 B",1024.0 to "1${decimal}0 KiB",1536.0 to "1${decimal}5 KiB",1572864.0 to "1${decimal}5 MiB",1610612736.0 to "1${decimal}5 GiB")) equal(expected,memoryLabel(bytes))
  val huge=ImageDimensions(Int.MAX_VALUE,Int.MAX_VALUE);equal(4_611_686_014_132_420_609L,huge.pixels)
  check(huge.describe().contains(if(tag=="pt-BR") "4.611.686.014.132.420.609" else "4,611,686,014,132,420,609"))
 }
 println("PASS: 5 complete summaries, 14 memory boundary values, 2 exact Long counts and 2 grouped Long displays")
}
