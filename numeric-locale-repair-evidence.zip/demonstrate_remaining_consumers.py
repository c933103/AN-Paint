from pathlib import Path
import json,subprocess,xml.etree.ElementTree as ET,base64,hashlib
O=Path(__file__).resolve().parent;W=O.parent/'worktree';B=Path('/workspace/shared/anpaint-commons-errors-20261017/compile-check/deps');java='/usr/lib/jvm/java-21-openjdk-amd64/bin/java';deps=':'.join(str(p)for p in sorted(B.glob('*.jar')))
classic='Paintroid/src/main/java/org/catrobat/paintroid/classic/'
def strings(folder):return {n.get('name'):''.join(n.itertext()).replace('\\n','\n')for n in ET.parse(W/'Paintroid/src/main/res'/folder/'strings.xml').getroot()if n.tag=='string'}
pt=strings('values-pt-rBR');ar=strings('values-ar')
records=[
 {'path':classic+'ImageResizeDialog.kt','line':43,'locale':'pt-BR','key':'ui_current_safe_editing_budget_s_up_to_2f','template':pt['ui_current_safe_editing_budget_s_up_to_2f'],'args':'"1,5 MiB", 2.25','impact':'Resize budget line combines localized memory text with ROOT decimal-dot megapixels.'},
 {'path':classic+'ImageMemoryPolicy.kt','line':47,'locale':'pt-BR','key':'ui_d_d_pixels_2f_mp_exceeds_the_current','template':pt['ui_d_d_pixels_2f_mp_exceeds_the_current'],'args':'1500, 1500, 2.25, 1.5','impact':'Oversize rejection warning retains decimal-dot requested and allowed MP values in a Brazilian Portuguese sentence; admission math is unaffected.'},
 {'path':classic+'ClassicPaintActivity.kt','line':1008,'locale':'pt-BR','key':'ui_current_safe_budget_2f_mp','template':pt['ui_current_safe_budget_2f_mp'],'args':'2.25','impact':'New/resize/canvas-size dialog budget caption retains decimal-dot MP values.'},
 {'path':classic+'ClassicPaintActivity.kt','line':705,'locale':'pt-BR','key':'ui_0f_0f_px_1f','template':pt['ui_0f_0f_px_1f'],'args':'1500.0, 1000.0, 12.5','impact':'Selection dimensions caption retains decimal-dot rotation angle; other locales also retain ROOT digits.'},
 {'path':classic+'ClassicPaintActivity.kt','line':1425,'locale':'ar-EG','key':'ui_recent_colour_d_06x_tap_foreground_hold_background','template':ar['ui_recent_colour_d_06x_tap_foreground_hold_background'],'args':'3, 0xabcdef','impact':'Populated recent-colour accessibility caption uses ROOT index digits while empty-cell caption uses localized ui formatting. Hex identifier must remain unchanged.'},
 {'path':classic+'PaintCanvas.kt','line':217,'locale':'pt-BR','key':None,'template':'%.2f%%','args':'2.5','impact':'Low-zoom label and its consumers retain decimal-dot percentage. The >=10% integer branch also uses unlocalized string interpolation.'}]
def kt(s):return json.dumps(s,ensure_ascii=False).replace('$','\\$')
source='import java.util.*\nfun main(){\n'
for i,r in enumerate(records):
 source+='run { val t='+kt(r['template'])+'; val before=String.format(Locale.ROOT,t,'+r['args']+');val after=String.format(Locale.forLanguageTag('+kt(r['locale'])+'),t,'+r['args']+');check(before!=after);println("'+str(i)+'\\t"+Base64.getEncoder().encodeToString(before.toByteArray())+"\\t"+Base64.getEncoder().encodeToString(after.toByteArray())) }\n'
source+='}\n';p=O/'RemainingDisplays.kt';p.write_text(source);out=O/'remaining-display-classes'
c=subprocess.run([java,'-cp',deps,'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-jvm-target','17','-classpath',deps,'-d',str(out),str(p)],text=True,capture_output=True);(O/'remaining-display-compile.log').write_text(c.stdout+c.stderr)
if c.returncode:raise ValueError(c.stderr)
r=subprocess.run([java,'-cp',str(out)+':'+str(B/'kotlin-stdlib-1.9.24.jar'),'RemainingDisplaysKt'],text=True,capture_output=True);(O/'remaining-display-run.log').write_text(r.stdout+r.stderr)
if r.returncode:raise ValueError(r.stderr)
for l in r.stdout.splitlines():
 i,a,b=l.split('\t');e=records[int(i)];e['root_formatted_example']=base64.b64decode(a).decode();e['selected_locale_example']=base64.b64decode(b).decode();e.pop('args');e.pop('template')
 for k in ['path']: pass
 e['url']='https://github.com/c933103/AN-Paint/blob/75d56c8c9597f135799d2a3aac84c1e8aa3ee2a4/'+e['path']+'#L'+str(e['line'])
 content=(W/e['path']).read_bytes();e['source_sha256']=hashlib.sha256(content).hexdigest();e['source_line']=content.decode().splitlines()[e['line']-1]
result={'scope':'Follow-up only. No changes to these consumers in PR117 numeric repair. Actual Java Formatter examples using exact source XML templates and representative arguments; no installed UI claim.','records':records,'intentional_invariants':['DimensionControls.kt:59, ImageCropDialog.kt:82 and NormalizeImagesDialog.kt:35 serialize editable numeric fields with decimal dots accepted by existing parsers; keep separate from display labels.','Colour hex values use ASCII hexadecimal syntax; they must not be localized as decimal digits.','Identifiers, sort keys and text codec syntax using Locale.ROOT are machine semantics, not locale display defects.']}
(O/'remaining-root-display-consumers.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print('Verified six remaining formatter mismatches; edit-field and hex syntax explicitly distinguished.')
