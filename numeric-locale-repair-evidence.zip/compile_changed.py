from pathlib import Path
import subprocess,json,hashlib
O=Path(__file__).resolve().parent;W=O.parent/'worktree'; B=Path('/workspace/shared/anpaint-commons-errors-20261017/compile-check')
deps=':'.join(str(p)for p in sorted((B/'deps').glob('*.jar')))
sdk='/workspace/shared/passengercount-restart-race-20261017/investigation/sdk-platform/android-35/android.jar'
cp=':'.join([deps,str(B/'classes17'),str(B/'test-classes17'),sdk])
main=W/'Paintroid/src/main/java/org/catrobat/paintroid/classic';test=W/'Paintroid/src/test/java/org/catrobat/paintroid/local'
files=[main/'ImageImport.kt',test/'ImageDisplayLocaleTest.kt',test/'BrazilianPortuguesePriorityWordingTest.kt',test/'SizingAndTrimTest.kt',test/'EditorStartupTestSupport.kt',test/'EditorTestNavigation.kt']
args=['/usr/lib/jvm/java-21-openjdk-amd64/bin/java','-cp',deps,'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-jvm-target','17','-Xstring-concat=inline','-Xfriend-paths='+str(B/'classes17')+','+str(B/'test-classes17'),'-classpath',cp,'-d',str(O/'compiled-check'),*map(str,files)]
r=subprocess.run(args,text=True,capture_output=True);(O/'kotlin-compile.log').write_text(r.stdout+r.stderr);(O/'kotlin-compile.json').write_text(json.dumps({'command':args,'exit_code':r.returncode,'changed_source_sha256':{str(p.relative_to(W)):hashlib.sha256(p.read_bytes()).hexdigest()for p in files},'scope':'Supplementary direct Kotlin 1.9.24/API35 changed-file compile against previously built dependency classes; not full Gradle build or Robolectric execution.'},indent=2)+'\n');print(r.stdout+r.stderr);raise SystemExit(r.returncode)
