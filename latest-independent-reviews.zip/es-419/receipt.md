# Independent es-419 candidate review

Result: accept all 13 exact proposals unchanged; 0 revise, 0 hold. Classification remains 4 contextual grammar/meaning corrections, 8 clarity/idiom/context improvements, and 1 optional cosmetic change. Twelve have independently inspected static consumer context; one is wording-only.

Inspected tree: b9b148d5d8ef7c7b088500a9c177f9f59304b800

All proposed wording is acceptable broad Latin American Spanish. Existing simple-past forms, familiar-singular imperative and terms such as reemplazar are retained. Shared wording with Spain is not itself evidence of error or of a need for regional replacement. No country-specific or native-speaker certification is claimed.

## Exact decisions

### string/save20_destination_error — ACCEPT (recommended_clarity)

English: The completed image could not replace its destination.

Current: La imagen terminada no pudo sustituir su destino.

Accepted proposed value: No se pudo reemplazar el archivo de destino con la imagen terminada.

Accept. The four independently inspected consumers report failure to rename a completed temporary file into a destination file. Naming the archivo de destino makes the object clear. Reemplazar is natural in Latin American Spanish; the candidate neither announces success nor guarantees that an earlier file survives.

Source: Paintroid/src/main/java/org/catrobat/paintroid/classic/BitmapFileCodec.kt:19; Paintroid/src/main/java/org/catrobat/paintroid/classic/DibCodec.kt:34; Paintroid/src/main/java/org/catrobat/paintroid/classic/IcoCodec.kt:100; Paintroid/src/main/java/org/catrobat/paintroid/classic/TextImageCodec.kt:62

### string/ui_d_d_pixels_2f_mp_exceeds_the_current — ACCEPT (recommended_clarity)

English: %1$d × %2$d pixels (%3$.2f MP) exceeds the current safe editing budget of %4$.2f MP. AN Paint keeps the complete image in memory and reserves space for transforms and selections. Available memory determines this budget. The operation was stopped before allocating the oversized bitmap. No automatic resizing was applied.

Current: %1$d × %2$d píxeles (%3$.2f MP) supera el límite seguro de edición actual de %4$.2f MP. AN Paint mantiene la imagen completa en memoria y reserva espacio para transformaciones y selecciones. La memoria disponible determina este límite. La operación se detuvo antes de asignar el mapa de bits sobredimensionado. No se aplicó ningún cambio de tamaño automático.

Accepted proposed value: Una imagen de %1$d × %2$d píxeles (%3$.2f MP) supera el límite seguro de edición actual de %4$.2f MP. AN Paint mantiene la imagen completa en memoria y reserva espacio para transformaciones y selecciones. La memoria disponible determina este límite. La operación se detuvo antes de asignar el mapa de bits sobredimensionado. No se aplicó ningún cambio de tamaño automático.

Accept. Una imagen de supplies an unambiguous singular subject for supera. A dimensions expression can be understood as an implicit singular image size, so keep this classified as clarity rather than upgrading it to a definite grammatical bug. All memory-limit, stopped-allocation and no-resizing statements and numeric arguments are retained.

Source: Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageMemoryPolicy.kt:46

### string/ui_export_explanation23 — ACCEPT (recommended_idiom)

English: Export an icon, Base64 text or ASCII art. Exporting keeps the current image and its Save destination unchanged.

Current: Exporta un icono, texto Base64 o arte ASCII. Exportar no cambia la imagen actual ni su destino de Guardar.

Accepted proposed value: Exporta un icono, texto Base64 o arte ASCII. La exportación no modifica la imagen actual ni su destino de guardado.

Accept. Destino de guardado is a natural noun phrase where destino de Guardar reads as an awkward literal reference to the command. The proposed second sentence preserves the current-image/current-save-destination distinction; Exporta retains the existing familiar singular imperative, compatible with broad Latin American UI usage.

Source: Paintroid/src/main/java/org/catrobat/paintroid/classic/SaveOptionsDialog.kt:52; Paintroid/src/main/java/org/catrobat/paintroid/classic/SaveOptionsDialog.kt:183

### string/ui_higher_quality_usually_makes_a_larger_file_lossless — ACCEPT (recommended_idiom)

English: Higher quality usually makes a larger file. Lossless keeps every colour value.

Current: Una calidad mayor suele producir un archivo más grande. Sin pérdida conserva todos los valores de color.

Accepted proposed value: Una calidad mayor suele producir un archivo más grande. La compresión sin pérdidas conserva todos los valores de color.

Accept. La compresión sin pérdidas supplies the missing explicit conceptual subject and reads naturally. The nearby checkbox is %1$s sin pérdida; singular pérdida is also valid, so this is improved explanatory prose, not proof that the checkbox terminology is incorrect. No promise beyond the English preservation of color values is added.

Source: Paintroid/src/main/java/org/catrobat/paintroid/classic/SaveOptionsDialog.kt:103

### string/ui_the_image_was_saved_but_android_could_not — ACCEPT (recommended_idiom)

English: The image was saved, but Android could not open sharing: %1$s

Current: La imagen se guardó, pero Android no pudo abrir el sistema de compartir: %1$s

Accepted proposed value: La imagen se guardó, pero Android no pudo abrir las opciones para compartir: %1$s

Accept. Opciones para compartir is an idiomatic description of the Android chooser opened here. The simple-past successful save remains separate from the later sharing failure, and the diagnostic placeholder is unchanged. No present-perfect Spain-oriented replacement is introduced.

Source: Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:1380

### string/colour_truncated_metadata — ACCEPT (recommended_clarity)

English: The image ends inside its colour metadata.

Current: La imagen termina dentro de sus metadatos de color.

Accepted proposed value: El archivo de imagen está truncado en sus metadatos de color.

Accept. Archivo de imagen and truncado accurately communicate incomplete file data rather than implying a spatial endpoint of the picture. The consumer throws on end-of-input while copying a segment in color-metadata handling. This is linguistic acceptance of the source diagnosis, not a certification that every possible underlying file failure is diagnosed correctly.

Source: Paintroid/src/main/java/org/catrobat/paintroid/classic/PlatformImageColour.kt:72

### string/ui_all — ACCEPT (recommended_context_consistency)

English: All

Current: Todo

Accepted proposed value: Todas

Accept. The actual heading is Aplicar a estas imágenes and the action selects every image checkbox. Todas supplies the feminine plural referent and pairs naturally with Ninguna. Todo can refer generically to everything, so this remains contextual precision rather than a reversed-action or definite grammar defect.

Source: Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt:135

### string/ui_collapse_tool_category — ACCEPT (contextual_grammar_correction)

English: %1$s: %2$s selected. Collapse tools and options

Current: %1$s: %2$s seleccionado. Contraer herramientas y opciones

Accepted proposed value: %1$s. Herramienta seleccionada: %2$s. Contraer herramientas y opciones

Accept. The explicit noun Herramienta governs seleccionada, preventing gender disagreement for Acuarela, Selección rectangular, Línea, Curva, Elipse, Estrella and Flecha while also working with masculine tool names. The category remains separate, both substitutions remain ordered, and Contraer preserves the action. All 16 actual category/tool pairs were composed independently.

Source: Paintroid/src/main/java/org/catrobat/paintroid/classic/ToolCategoryButton.kt:27

### string/ui_drawing_canvas_pinch_and_move_two_fingers_to — ACCEPT (meaning_correction)

English: Drawing canvas. Pinch and move two fingers to zoom and pan. Navigate mode also pans with one finger.

Current: Lienzo de dibujo. Pellizca y mueve dos dedos para ampliar y desplazar. El modo Navegar también permite desplazar con un dedo.

Accepted proposed value: Lienzo de dibujo. Pellizca y mueve dos dedos para hacer zoom y desplazar. El modo Navegar también permite desplazar con un dedo.

Accept. Hacer zoom covers both enlargement and reduction, unlike ampliar alone. The source touch handler scales by the ratio of finger spans and independently pans with the moving midpoint, which supports the two operations. Navegar and one-finger panning are retained. The existing pellizca instruction was not newly introduced by the proposal; this pass does not claim screen-reader or gesture usability testing.

Source: Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:271; Paintroid/src/main/java/org/catrobat/paintroid/classic/PaintCanvas.kt:148

### string/ui_expand_tool_category — ACCEPT (contextual_grammar_correction)

English: %1$s: %2$s selected. Expand tools and options

Current: %1$s: %2$s seleccionado. Expandir herramientas y opciones

Accepted proposed value: %1$s. Herramienta seleccionada: %2$s. Expandir herramientas y opciones

Accept. As in the collapse template, Herramienta seleccionada avoids attaching masculine seleccionado directly to feminine tool names. Expandir retains the distinct expansion action. All 16 actual category/tool pairs were composed independently.

Source: Paintroid/src/main/java/org/catrobat/paintroid/classic/ToolCategoryButton.kt:27

### string/ui_none — ACCEPT (contextual_grammar_correction)

English: None

Current: Ninguno

Accepted proposed value: Ninguna

Accept. Ninguna correctly means no image in the image-selection group: the singular feminine pronoun refers to ninguna imagen. The only directly located production consumer is the same group as Todas. Recheck agreement if the generic resource is reused for a different referent.

Source: Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt:135

### string/ui_percent — ACCEPT (optional_cosmetic)

English: Percent

Current: porcentaje

Accepted proposed value: Porcentaje

Accept, optional. Porcentaje is consistent with neighboring Píxeles in all three standalone radio-unit selectors. Lowercase porcentaje is understandable and not a meaning error; this remains cosmetic. The different embedded resource ui_percent_fd8671 must stay lowercase and is unchanged.

Source: Paintroid/src/main/java/org/catrobat/paintroid/classic/DimensionControls.kt:31; Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt:96; Paintroid/src/main/java/org/catrobat/paintroid/classic/NormalizeImagesDialog.kt:50

### string/ui_trim_expand_canvas_by_touch — ACCEPT (recommended_idiom)

English: Trim / expand canvas by touch…

Current: Recortar / ampliar lienzo con el tacto…

Accepted proposed value: Recortar / ampliar lienzo con gestos táctiles…

Accept on wording only. Con gestos táctiles naturally describes touch interaction and avoids con el tacto, which evokes the sense of touch. The terse menu-label form can omit the article before lienzo. No direct production reference was found, so this does not certify a reachable menu, a particular gesture or implemented behavior.

Source: No direct production consumer found; wording-only.

## Scope

- Static linguistic review only.
- The touch-label proposal is wording-only, with no direct production consumer found.
- No full-language acceptance, device/layout, TalkBack, locale-routing or runtime certification.
- No builds, Gradle, APK, CI, source-resource edits, publication or release performed.

The JSON companion contains source hashes, all 32 independent actual tool/category compositions, and six additional context compositions. Both files are review receipts only.
