# Independent Filipino candidate review

Result: accept all seven exact core proposals; accept the five separate refinements as optional only; retain the three correct direction labels with their two-template composition condition; keep the palette composition on hold. No mandatory wording revision was identified.

Reviewed source tree: `b9b148d5d8ef7c7b088500a9c177f9f59304b800`. Local HEAD: `ddffe57016c689b2a7868c31e415dcb625f5c6b5`. Source worktree was clean before and after.

This is a bounded model-based linguistic and static-consumer review, not native-human, runtime, layout, TalkBack, whole-language or full-341-key certification. All candidates remain unapplied.

## Important distinctions

- An accepted clarification is not automatically a confirmed semantic bug in the current translation. The five optional suggestions contribute zero confirmed failures.
- The three priority edge labels are correct alone. Their complete hints depend on both shared crop templates. The fourth actual argument, Itaas, was inspected only as dependency context.
- The Save alias is already accurate. Adding the source ellipsis is optional punctuation alignment, not proof that a dialog always follows: existing save targets are written directly.
- Technical loans such as canvas, pixel, crop, file, memory, working buffers, credit, color metadata, I-save and I-drag are not rejected merely for being loans.

## Per-key decisions

### string/gallery_credit_too_large — ACCEPT (core)

English: These image credits would make the drawing too large to restore. Your previous drawing and credits have been kept.

Current: Gagawing masyadong malaki ng mga credit na ito ang guhit upang maibalik ito. Pinanatili ang dati mong guhit at mga credit.

Proposed: Magiging masyadong malaki ang guhit para maibalik kung idaragdag ang mga credit na ito. Pinanatili ang dati mong guhit at mga credit.

Accept the exact proposal. The masyadong malaki ... para maibalik construction expresses a size that prevents restoration, and kung idaragdag ties that condition to the supplied credits. The preserved-previous-drawing assurance is unchanged. The current upang phrase invites an unintended purpose reading; this supports a clarity correction, not a claim that every reader misunderstands the current value.

Sources: `Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:1209`, `Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:1444`, `Paintroid/src/main/java/org/catrobat/paintroid/classic/GalleryCredits.kt:111`.

### string/ui_keeps_pixels_at_the_top_left_smaller_canvas — ACCEPT (core)

English: Keeps pixels at the top left. Smaller canvas dimensions discard pixels beyond the right/bottom edge; Undo restores them.

Current: Pinananatili ang pixels sa kaliwang itaas. Itinatapon ng mas maliit na canvas ang pixels sa labas ng kanan/ibaba; ibinabalik sila ng Ibalik.

Proposed: Pinananatili ang mga pixel sa kaliwang itaas. Kapag pinaliit ang mga sukat ng canvas, inaalis ang mga pixel na lampas sa kanan o ibabang gilid; maibabalik ang mga ito gamit ang Ibalik.

Accept the exact proposal. It preserves top-left anchoring, the loss beyond the right or bottom boundary when canvas dimensions shrink, and recovery through the actual Ibalik command. Mga ito supplies an unambiguous inanimate reference. The original still conveys the intended operation; pronoun choice and expanded edge wording alone are not proof of a semantic bug.

Sources: `Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:1007`.

### string/colour_truncated_metadata — ACCEPT (core)

English: The image ends inside its colour metadata.

Current: Nagtatapos ang larawan sa loob ng color metadata nito.

Proposed: Naputol ang file ng larawan sa loob ng color metadata nito.

Accept the exact proposal. Naputol ang file names an incomplete file rather than suggesting that the visible picture spatially ends within metadata. The direct consumer throws on a premature read EOF. Color metadata is an acceptable technical phrase here; no cause of corruption or promise of recovery is added. The original is close to the equally terse English, so this is diagnostic clarification rather than proven wrong factual content.

Sources: `Paintroid/src/main/java/org/catrobat/paintroid/classic/PlatformImageColour.kt:72`.

### string/ui_crop_preview_drag_an_edge_or_corner_drag — ACCEPT (core)

English: Crop preview. Drag an edge or corner; drag inside to move the crop.

Current: Preview ng crop. I-drag ang gilid o sulok; i-drag ang loob para ilipat ang crop.

Proposed: Preview ng crop. I-drag ang gilid o sulok; i-drag sa loob nito para ilipat ang crop.

Accept the exact proposal. Sa loob nito specifies the location of the drag gesture, whereas ang loob makes the interior its grammatical object. The opening preview, edge/corner action, and move-crop purpose are retained. This is the CropPreview content description, not a claim that the rendered control or spoken announcement was exercised.

Sources: `Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt:23`.

### string/ui_edit_transform33 — ACCEPT (core)

English: Flip / Rotate

Current: Baligtarin / Ikutin

Proposed: Baligtarin / Paikutin

Accept the exact proposal. Paikutin clearly asks for rotation of the edited object and matches the inspected Rotate, 90-degree, and 180-degree commands. Baligtarin preserves Flip. Ikutin is understandable in the UI, so the improvement is action-verb precision and consistency, not evidence of a wrong command being executed.

Sources: `Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:77`.

### string/ui_trim_in_pixels — ACCEPT (core)

English: %1$s trim in pixels

Current: %1$s na bawas sa pixels

Proposed: Bawas sa %1$s (pixels)

Accept the exact proposal as part of the two-template group. The consumer supplies a bare edge name, not a numeric amount: Kaliwa, Itaas, Kanan, or Ibaba. Bawas sa + edge gives an amount removed at that boundary; (pixels) identifies the input unit. No linker inflection must be guessed from the argument. The awkward current edge + na bawas sequence is avoided without rewriting the correct edge labels.

Actual composed candidates: Bawas sa Kaliwa (pixels); Bawas sa Itaas (pixels); Bawas sa Kanan (pixels); Bawas sa Ibaba (pixels).

Sources: `Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt:104`, `Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt:116`.

### string/ui_trim_in_percent — ACCEPT (core)

English: %1$s trim in percent

Current: %1$s na bawas sa porsiyento

Proposed: Bawas sa %1$s (porsiyento)

Accept the exact proposal as part of the two-template group. The same four actual edge arguments produce meaningful Bawas sa + edge labels, and (porsiyento) correctly identifies the percentage mode. Keep it coordinated with the pixel-mode replacement. The formatter still receives one numbered string argument; the change does not itself verify speech rendering.

Actual composed candidates: Bawas sa Kaliwa (porsiyento); Bawas sa Itaas (porsiyento); Bawas sa Kanan (porsiyento); Bawas sa Ibaba (porsiyento).

Sources: `Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt:104`.

### string/ui_save_a5d0d9 — ACCEPT (optional)

English: Save…

Current: @string/ui_save

Proposed: I-save…

Accept as optional source-alignment only. The current alias resolves to I-save and is already an accurate Save action. I-save… matches the source punctuation. Crucially, requestSave(false) opens options only when no saved target exists; otherwise it writes to the existing target. Therefore do not justify the ellipsis as proof that another dialog always follows, and do not classify its current absence as a confirmed translation failure.

Sources: `Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:1069`.

### string/commons_svg_original_size_unavailable — ACCEPT (optional)

English: The SVG does not declare a usable original size. No canvas-based size was substituted.

Current: Walang nakasaad na magagamit na orihinal na laki sa SVG. Walang ipinalit na laki na batay sa lona.

Proposed: Walang nakasaad na magagamit na orihinal na laki sa SVG. Walang ipinalit na laki na batay sa canvas.

Accept as optional terminology consistency. Both versions retain the unusable original SVG size and the explicit assurance that a canvas-based size was not substituted. Canvas aligns with the nearby digital-canvas commands. Lona is not intrinsically incorrect, and the complete current sentence already preserves the English facts.

Sources: `Paintroid/src/main/java/org/catrobat/paintroid/classic/MediaGalleryActivity.kt:385`.

### string/ui_d_d_px_d_pixels_2f_mp — ACCEPT (optional)

English: %1$d × %2$d px · Pixel count: %3$,d (%4$.2f MP)

Current: %1$d × %2$d px · %3$,d pixels (%4$.2f MP)

Proposed: %1$d × %2$d px · Bilang ng pixel: %3$,d (%4$.2f MP)

Accept as optional label clarity. Bilang ng pixel makes the count explicit and all four exact format tokens remain intact. Width, height, total pixel count, and megapixels retain their distinct roles. The current numeric total followed by pixels already conveys a count, so the missing literal label is not a missing fact. Technical pixel/px/MP terminology does not require a native replacement.

Sources: `Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageImport.kt:15`.

### string/ui_edit_canvas33 — ACCEPT (optional)

English: Canvas

Current: Lona

Proposed: Canvas

Accept as optional terminology consistency. Canvas names the group containing the inspected canvas-related commands and aligns with Laki ng canvas and other existing labels. Lona is a defensible translation of canvas; harmonizing terminology must not be reported as repairing a proven mistranslation.

Sources: `Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt:76`.

### string/ui_the_full_image_and_working_buffers_exceed_the — ACCEPT (optional)

English: The full image and working buffers exceed the current safe budget, or Android could not allocate them. Resize a copy to edit it. Your original file will stay unchanged.

Current: Lumampas ang buong larawan at working buffers sa kasalukuyang ligtas na limitasyon, o hindi sila ma-allocate ng Android. Baguhin ang laki ng isang kopya para ma-edit ito. Hindi magbabago ang orihinal mong file.

Proposed: Lumampas ang buong larawan at working buffers sa kasalukuyang ligtas na limitasyon, o hindi makapaglaan ng memory ang Android para sa mga ito. Baguhin ang laki ng isang kopya para ma-edit ito. Hindi magbabago ang orihinal mong file.

Accept as optional idiomatic clarification. The proposed memory-allocation clause is natural technical Filipino and retains the alternative memory-failure conditions, resize-a-copy advice, and unchanged-original assurance. The current sila/ma-allocate phrasing is understandable and should not be inflated into a semantic failure. Working buffers, memory, and file are retained technical terms, not defects merely because they are loans.

Sources: `Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageResizeDialog.kt:27`.

### string/ui_left — ACCEPT (dependent_priority_label)

English: Left

Current: Kaliwa

Proposed: (none; unchanged label or unresolved hold)

Kaliwa correctly names the left edge. No label edit is necessary. The complete pixel and percentage hints are acceptable with the two proposed shared templates; the awkward relation belongs to the current templates, not to this direction word.

Sources: `Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt:72`.

### string/ui_right — ACCEPT (dependent_priority_label)

English: Right

Current: Kanan

Proposed: (none; unchanged label or unresolved hold)

Kanan correctly names the right edge. No label edit is necessary. The complete pixel and percentage hints are acceptable with the two proposed shared templates; the awkward relation belongs to the current templates, not to this direction word.

Sources: `Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt:72`.

### string/ui_bottom — ACCEPT (dependent_priority_label)

English: Bottom

Current: Ibaba

Proposed: (none; unchanged label or unresolved hold)

Ibaba correctly names the bottom edge. No label edit is necessary. The complete pixel and percentage hints are acceptable with the two proposed shared templates; the awkward relation belongs to the current templates, not to this direction word.

Sources: `Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt:72`.

### string/ui_foreground_background_colour_palette — HOLD (unknown_composition)

English: Foreground %1$s, background %2$s. %3$s colour palette.

Current: Harap %1$s, likod %2$s. %3$s paleta ng kulay.

Proposed: (none; unchanged label or unresolved hold)

The foreground/background labels and three numbered placeholders are present. Whether the third argument can directly precede paleta ng kulay depends on its actual wording: a bare adjective may require a linker, while a supplied phrase may already carry one. No direct production reference or actual argument domain was found in the bounded source scan. Keep this as unknown composed idiom, not a demonstrated malformed runtime string. Do not invent a value or mark the whole language failed.

## Evidence and limits

The JSON receipt contains complete values, independently checked value/source hashes, exact consumer lines and context, crop substitutions, optional wrapper composition, and the scan boundary. Value hashes follow the upstream compact-JSON-string convention; raw UTF-8 hashes are also recorded for candidate pairs. File hashes cover raw bytes.

The full input package hash manifest was checked. The English/current values match the bound source; all seven candidate values match the supplied candidate catalogue. No original catalogue was edited. No build, Gradle, APK, CI, runtime, Android formatter, UI, TalkBack, publication or release action was performed.
