# Spain Spanish P0+P1 linguistic review

## Result

One complete **341-key batch** was reviewed: **92 P0 + 249 P1**. This is a fresh AI linguistic and static source-context review, not reconstructed credit from the unavailable original Spanish priority review.

- P0: **88 current values accepted**, **4 corrections proposed**.
- P1: **248 current values accepted**, **1 correction proposed**.
- Total: **336 current values accepted**, **5 complete replacement values recommended**. The candidate contains all five replacements, so its 341 reviewed values have a linguistic decision; it has not been integrated or independently signed off.
- No new linguistic decisions are unresolved within this batch. This does not clear dormant-consumer, visual, native-speaker or TalkBack limitations.
- All **30 existing bounded accepted receipts** match both current English and current Spanish exactly. Nine overlap this batch; 21 are outside it. Their bounded scope remains unchanged.
- The separate assembly-help hold remains outside this batch. Its current English differs from the old union snapshot, while Spanish is identical; this review does not infer that the full source-reference/consumer-scope hold has been resolved.

## Source binding

Requested develop revision: `4355869e2e198b5616419291cba225b018444fab`, supplied by the coordinating task. The materialized checkout is commit `ddffe57016c689b2a7868c31e415dcb625f5c6b5`, whose tree was independently checked as `b9b148d5d8ef7c7b088500a9c177f9f59304b800`, the supplied current-develop tree. The requested develop commit object is not present in this local clone, so this report does not claim to have independently read its commit-to-tree relation locally.

The priority manifest and complete current English/es-ES values are included by identity in `priority-input.json` and `per-key-review.json`; full-value SHA-256 fingerprints bind every decision. `consumer-index.json` records the literal production references inspected in Kotlin/Java/XML. No test-only references are used to imply a live consumer.

## Proposed changes

1. **P0 / save20_destination_error / semantic clarity, medium severity**
   - Current: La imagen terminada no pudo sustituir su destino.
   - Proposed: No se ha podido sustituir el archivo de destino por la imagen terminada.
   - `BitmapFileCodec`, `DibCodec`, `IcoCodec` and `TextImageCodec` report failed replacement of a destination file after encoding. The image is not replacing an abstract location. The proposed wording names the file and does not claim it was modified.

2. **P0 / ui_export_explanation23 / idiom and state clarity, low severity**
   - Proposed: Exporta un icono, texto Base64 o arte ASCII. La exportación no modifica la imagen actual ni su destino de guardado.
   - Replaces the unnatural “destino de Guardar”, retaining the crucial distinction between export and save, all three export types, unchanged current image and unchanged save destination.

3. **P0 / ui_higher_quality_usually_makes_a_larger_file_lossless / grammar and terminology, low severity**
   - Proposed: Una calidad mayor suele producir un archivo más grande. La compresión sin pérdidas conserva todos los valores de color.
   - Gives the lossless-mode sentence an explicit subject rather than the bare “Sin pérdida”, preserving “usually” and every colour value.

4. **P0 / ui_the_image_was_saved_but_android_could_not / idiom and state clarity, low severity**
   - Proposed: La imagen se ha guardado, pero Android no ha podido abrir las opciones para compartir: %1$s
   - The consumer starts the Android share chooser after a completed save. Natural wording replaces “el sistema de compartir”; successful save, failed sharing launch and the error argument remain explicit.

5. **P1 / ui_percent / label consistency, low severity**
   - Current: porcentaje
   - Proposed: Porcentaje
   - This is the standalone radio-button label beside Píxeles. The separate lowercase `ui_percent_fd8671` used inside accessibility phrases stays unchanged. This is cosmetic consistency, not a warning-semantics defect.

Priority tiers are catalogue importance, not the severity of these findings.

## Meaning and locale checks

The review covered every complete P0/P1 source/target pair, including save/export/discard state, draft/recovery retention, animation loss, original-file preservation, memory limits, exact dimension/range constraints, crop bounds, gesture instructions, tool/menu terms, number formats and accessibility descriptions.

- Spain usage is retained where meaningful: Añadir, Pulsa/Mantén pulsado, Ajustes, Goma de borrar. Shared Spanish is not automatically treated as Latin-American leakage. Configuración, for example, is also valid in Spain.
- The existing **Todas/Ninguna** are correct for selected images in the crop dialog; the es-419 alternatives are not imported.
- **Hacer zoom** already covers enlargement and reduction. The current canvas description is not treated as the earlier “ampliar only” omission.
- **Archivo > Cargar imagen** matches the actual current Spanish resource route in recovery instructions; no unrelated “Abrir” label is introduced.
- The **Guardar** alias is a valid concise save button; it is not a translation failure merely because English has an ellipsis.
- The compact **FG/BG** badges are retained as existing UI conventions alongside fully localized accessibility descriptions. This does not establish that every Spanish user recognizes these abbreviations or that small-label rendering is satisfactory.
- There are **no plural entries in P0/P1**. The outside-batch `plurals/ui_crop_preview_images` receipt, including its one/other map, is carried by exact binding only, not newly credited as a priority plural review.

## Separate verification limits

**311** reviewed keys have at least one literal production source reference. **30** do not and receive source-only wording decisions. Absence of a static reference is not proof of runtime unreachability. For the dormant `ui_foreground_background_colour_palette`, an eventual consumer must establish the third argument’s agreement and spoken context before UI acceptance.

No new screenshot, rendered layout, Android routing, glyph-fit, native-speaker or TalkBack execution was performed. No new build is needed to establish these text-level findings. Existing source and prior receipts were reused; no suitable current full-priority Spanish screenshot set was supplied or claimed.

The separate assembly-help hold, all inherited receipt limitations and whole-language non-acceptance remain intact. PR56 remains a tracking draft and must not be merged as a result of this review.

## Lightweight validation

- 341 unique priority decisions, exactly 92 P0 and 249 P1.
- All 341 complete current and candidate placeholder sequences match English.
- Android literal-newline counts preserved.
- XML parses successfully.
- Resource names, types, aliases and attributes preserved.
- Exactly five targeted resource values changed; every other es-ES resource is unchanged.
- Generic Spanish and es-419 are untouched.
- All 30 prior accepted English/Spanish receipt pairs still hash-match.
- No build, Gradle, APK, CI, emulator, release or version action. No shared production edit, branch or PR action.

## Coverage accounting

At the current unmodified source, the 717-entry catalogue partitions as:

- 357 accepted current linguistic or previously bounded values: 336 from this batch plus 21 prior accepted values outside it.
- 5 proposed corrections, not current-value acceptance.
- 1 retained outside-batch hold.
- 354 outside-batch entries without mapped acceptance.

Only after integration and exact rebinding of the five candidates would the accepted count become 362, with the same 1 hold and 354 unknown. This is not whole-language acceptance.

## Deliverables

- `per-key-review.json`: all 341 complete decisions, values, rationales, fingerprints, consumer references and limits.
- `per-key-review.csv`: tabular counterpart.
- `findings.json`: five complete proposed replacements with context.
- `es-ES-priority-candidate.patch`: minimal source-preserving patch.
- `candidate/Paintroid/src/main/res/values-b+es+ES/strings.xml`: complete candidate resource.
- `prior-receipt-audit.json`: exact 30 accepted receipt bindings plus the unchanged separate hold.
- `consumer-index.json`: static production reference map.
- `summary.json`: machine-readable counts, scope and validation.
