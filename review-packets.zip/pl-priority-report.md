# Polish P0 + P1: current-source linguistic reconciliation

Date: 21 October 2026. Requested source: `4355869e2e198b5616419291cba225b018444fab`.
Verified tree: `b9b148d5d8ef7c7b088500a9c177f9f59304b800`.

## Result

The whole assigned batch is accounted for. **All 341 P0/P1 entries are present and match the complete English/Polish pairs in the original independent review.** There is no priority translation gap to fill and no additional wording correction justified by this pass.

| Priority | Present | Retained bounded review | Holds |
|---|---:|---:|---:|
| P0 | 92 | 86 | 6 |
| P1 | 249 | 224 | 25 |
| Total | 341 | 310 | 31 |

The 31 holds comprise **30 dormant/no-identified-consumer cases and one compact Fit layout concern**. None is closed here. There are zero newly accepted entries and zero newly translated entries. This is not “341 new reviews.”

Across the full catalogue, Polish remains 398/717 exact entries. All 319 missing entries, plus the previously tracked 45 present-but-review-unknown entries, are outside P0/P1. The missing P2 crop-preview plural is not part of this assignment. Full-dialog, full-locale and plural completeness must not be inferred.

## Linguistic work and retained provenance

The accepted review is preserved rather than repeated. Every one of the 341 rows records the complete current pair, hashes, original per-string linguistic decision, original hold or acceptance limits, and current direct consumers. The original record independently read 341 complete pairs, accepted 304 unchanged/drafted values and six exact corrections, and held 31. Those six replacements are already present and unchanged. The withdrawn pre-reset localization claims are not reused.

Eight direct consumer changes were inspected for their effect on language:

- `ui_d_d_pixels_2f_mp_exceeds_the_current`: the complete safety warning and four typed numeric arguments retain their meaning under localized display formatting.
- `ui_0f_0f_px_1f`: pixel dimensions, newline and degree precision remain intact.
- `ui_1f_s`: the localized decimal amount still precedes an invariant memory-unit abbreviation.
- `ui_d_d_px_d_pixels_2f_mp`: the noun-label construction “Liczba pikseli” remains grammatical with any pixel count and does not need a new Polish plural form.
- `language20_device_default`: “Użyj języka systemu” still means the device/system-language choice.
- `ui_the_draft_is_saving_try_again_shortly`: the specific draft-saving wording now belongs to the autosaving branch, not every busy operation.
- `ui_please_wait_for_the_current_operation`: the general waiting instruction correctly covers the added non-autosaving busy branch.
- `ui_done`: the added feedback-dismiss consumer remains compatible with the existing completion label; this does not establish Polish vertical-mode or layout acceptance.

The changed zoom-value dependency was also checked in `ui_canvas_zoom_771f84` and `ui_px`. Localized numeric punctuation does not introduce noun/adjective agreement requirements. Current `UiText`, `LocaleText`, language-selection and horizontal `FlowButton` behavior were read as context, not certified through execution.

All remaining relevant consumer-file changes were inspected as a single source diff. They do not change the linguistic role of the other accepted pairs. Exact accepted wording, typed placeholders, recovery filenames, format names, menu-route terminology, and the established dynamic-tool and dimension-unit constructions are retained. No alternative terminology is imposed merely for stylistic preference.

## Holds kept separate from linguistic acceptance

The 30 former no-consumer holds still have no direct production reference in the scanned main Kotlin/Java and non-values XML. Their full wording remains available for review, but absent references do not prove unreachability or resolve implicit nouns, discarded objects, dynamic arguments, or future usage. In particular, the referent of “Główne,” the object of generic “Discard,” the palette-state placeholder, and foreground/background action scope remain limited by the original context findings.

`ui_fit` remains “Cały obraz w oknie.” Its meaning is understandable. The current horizontal `zoom_fit_view` still places it in a 44 × 44 dp control with 8 dp horizontal padding and 13 sp text; horizontal measurement delegates to native Button. The vertical icon path and other full-width Fit buttons do not prove this Polish horizontal caption fits. This pass neither measures clipping nor closes that hold. No linguistic shortening is proposed merely to conceal a presentation concern.

## Evidence and identity

- [Current tracker, intentionally unmerged PR56](https://github.com/c933103/AN-Paint/pull/56).
- [Original independent priority-review packet](https://github.com/c933103/AN-Paint/blob/399d7ab1ec6fd197c9824518b470a6d8a0086df9/priority-review-packets.zip), member `pl/independent-final-receipt.json`.
- Original archive SHA-256: `ade1e4eca35692f70dae7691ea14cebc17da0e353fa9fb9a0b4eee17eea45c7a`.
- [Deduplicated prior reconciliation](https://github.com/c933103/AN-Paint/tree/2fff195596e7a792185b3b29eb756b7df9081a92/review-reconciliation-20261020).
- [Current priority policy](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/translations/STRING_IMPORTANCE.md).

The clean local checkout HEAD is `ddffe57016c689b2a7868c31e415dcb625f5c6b5`, a same-tree reviewed snapshot. Its Git tree exactly matches the requested merge tree recorded in the existing postmerge merge-identity receipt. This distinction is explicit in the machine-readable binding; the local commit is not falsely described as the requested merge commit.

## Deliverables

- `polish-p0-p1-current-review.json`: full 341-entry rebound decisions and provenance, exact values and limits.
- `per-string-decisions.tsv`: concise individual linguistic dispositions, preserving original reasons and adding current-context notes.
- `proposed-changes.json`: explicit empty change list.
- `candidate/strings.xml`: byte-identical current Polish catalogue, a no-op candidate rather than a production edit.
- `candidate.diff`: empty, confirming no proposed source difference.
- `static-checks.json`: read-only XML/JSON/hash/reference checks.
- `direct-consumer-deltas.json` and `consumer-changes.diff`: reviewed source deltas.
- `prior-evidence/pl/`: exact downloaded published receipt members and their retained summary.
- `finalize_review.py`: reproducible lightweight reconciliation/check script; it does not build or run the app.

## Limits and next action

No builds, Gradle, APK compilation, CI dispatch, emulator runs, release/version actions, production-branch edits or remote publication were performed. No new native-speaker, installed UI, TalkBack, rendering, full-dialog, whole-language or release acceptance is claimed.

The appropriate outcome is to retain 310 bounded accepted pairs, preserve all 31 holds, and record the exact current binding. There is no translation patch or new build justified solely by this batch. Any further dormant-consumer or compact-Fit work remains a separate contextual/presentation task, not unfinished Polish missing-string work.
