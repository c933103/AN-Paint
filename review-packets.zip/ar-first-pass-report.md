# Arabic P0 + P1 linguistic review — 21 October 2026

## Outcome

The entire current Arabic priority batch has been read as one linguistic review: **341 typed keys, 92 P0 and 249 P1**. Every key is directly present. There are **no missing translations** in this batch, although two visible role abbreviations remain English and have proposed Arabic replacements.

- **1 existing exact-pair bounded review carried**, not newly counted.
- **332 newly reviewed current values retained**: 302 have direct static production consumers; 30 have wording-only acceptance because no direct production consumer was found.
- **8 proposed corrections**: 2 P0 and 6 P1. These remain unapplied proposals, not accepted production corrections.
- This is **Modern Standard Arabic (`ar`)**, not Moroccan Arabic/Darija (`ary`) or a review of every Arabic-script language.

No production file was edited. No other locale was edited. No Work task, Gradle run, AAPT2 run, APK, CI, emulator, release, version change or runtime execution was performed.

## Exact source and evidence binding

Requested develop commit: `4355869e2e198b5616419291cba225b018444fab`.

Reviewed checkout tree, independently verified: `b9b148d5d8ef7c7b088500a9c177f9f59304b800`. The checkout's local snapshot HEAD is `ddffe57016c689b2a7868c31e415dcb625f5c6b5`; the requested develop commit object is not present locally. The parent supplied and owns the develop-to-tree identity verification. This report does not confuse local HEAD with the published develop commit.

Scope comes from `translations/string-importance.json`, schema 2, with the current `STRING_IMPORTANCE.md` definitions. The review read current `AGENTS.md`, `TRANSLATING.md`, canonical English/Arabic XML, and relevant production consumers. The September withdrawal of broad historical localization acceptance remains in force.

The prior exact-key map was the 20 October reconciliation at [2fff1955](https://github.com/c933103/AN-Paint/tree/2fff195596e7a792185b3b29eb756b7df9081a92/review-reconciliation-20261020), supplemented by its original [entry receipts](https://github.com/c933103/AN-Paint/blob/tracking/language-translation-progress-20261012/verification/translation-entry-review-2026-10-13/entry-review-receipts.json). Of its 22 Arabic keys, only `string/ui_sampled_resize_memory_explanation` belongs to this batch. Its complete English/Arabic JSON-value hashes match the original SAMPLED-MEMORY-20261015 receipt. The sampled-decoding explanation still has the same `ImageResizeDialog` role. `carried-receipt.json` retains the original bounded scope/confidence and exact rebinding. The other 21 mapped keys are not silently counted as P0/P1 work.

The older SVG translation proposal records were inspected as provenance, not promoted to acceptance simply because values are present. The two current P1 SVG error messages are included in the new source-context review. Historic blanket Arabic review/completion claims are not revived.

## Eight correction proposals

1. P0 `formats22_animation_message`: change the count phrase to **عدد الإطارات في ملف %1$s هذا: %2$s.** The current invariant `إطارًا` is not grammatical after all actual counts. `ImportSelection.showAnimation` supplies exact counts and lower-bound phrases. The proposed count-label construction works without changing the two string placeholders or the no-animation warning.
2. P0 `save20_gif_description`: replace vague `التمويه المتعمد` with the existing setting term **تمويه الألوان بالنقط**. This names GIF dithering rather than suggesting intentional image blur. The 256-colour and first-frame limitations are unchanged.
3. P1 `ui_d_d_px_d_pixels_2f_mp`: restore **عدد البكسلات:** before the total, matching the current English Pixel count distinction and avoiding a fixed counted-noun form. Width, height, grouped total and megapixel formatting remain identical.
4. P1 `ui_hex_rrggbb`: use **سداسي عشري #RRGGBB**, naming hexadecimal explicitly rather than only sixfold/hex shorthand.
5. P1 `ui_fg`: replace English `FG` with **مقدمة** in the visible foreground swatch.
6. P1 `ui_bg`: replace English `BG` with **خلفية** in the visible background swatch.
7. P1 `ui_invalid_selection_outline`: use **محيط التحديد غير صالح.** for the actual serialized selection contour. This is a terminology clarification over `مخطط`, not a claim that the original reverses the operation.
8. P1 `ui_trim_amounts_must_fit_inside_each_image_use`: use **يجب ألا تتجاوز مقادير القص أبعاد كل صورة؛ استخدم أعدادًا صحيحة من البكسلات أو نسبًا مئوية.** This repairs awkward syntax and makes whole-number pixel input explicit. It does not imply that all individually valid margins leave a nonempty crop; the consumer separately checks that.

The hexadecimal term is supported by [Microsoft's Arabic colour-field documentation](https://support.microsoft.com/ar-sa/office/%D8%AA%D8%BA%D9%8A%D9%8A%D8%B1-%D9%86%D8%B3%D9%82-%D8%A7%D9%84%D9%86%D9%85%D9%88%D8%B0%D8%AC-895ca902-833b-4f56-9488-f36480d837ef). [Unicode CLDR's Arabic categories](https://unicode.org/cldr/charts/49/supplemental/language_plural_rules.html#ar) corroborate that arbitrary counts cannot be assumed to share one form. Neither reference certifies these complete AN Paint sentences; the decisions depend on the actual source pairs and consumers.

## Context and RTL distinctions

- Save, Save as, derivative export, save-and-share, autosave and recovery remain semantically distinct. Preserved originals/recovery copies are not described as overwritten or lost.
- Physical top-left origin, right/bottom cropping, explicit left/right text alignment, horizontal/vertical flips and clockwise rotation are not mirrored merely because Arabic reads right-to-left.
- File-format identifiers, filenames such as `canvas.png`, unit tokens, hex syntax and positional placeholders are retained. Menu navigation sequences keep the correct command destinations. This does not certify the on-screen bidi placement of mixed Arabic/Latin text.
- Seven English-identical numerical/unit/format templates are intentional. `FG`/`BG` are different: they are visible English role abbreviations, not unit or format identifiers.
- The `ui_save_a5d0d9` alias was resolved to the current Arabic `ui_save` value. Both alias and exact target are recorded; alias presence was not used to credit an unchecked target.
- Accessible labels were reviewed as text in their actual static contexts, including tap versus long press and foreground versus background. No spoken TalkBack order or output was executed or accepted.
- There are **zero plural resources in P0+P1**. Count grammar inside ordinary strings was still reviewed. The separate six-form P2 `plurals/ui_crop_preview_images` retains its existing bounded receipt and is not newly counted here.
- Thirty keys have no direct production reference in the scanned `Paintroid/src/main` Kotlin/Java/layout resources. Their wording is reviewed, but no live behavior, future argument composition or current visibility is asserted.

## Lightweight validation and limits

`validation.json` records XML parsing, exact-key uniqueness, complete placeholder-token parity for all 341 current pairs and all eight proposals, unchanged nonedited Arabic entries in the candidate, and source/candidate hashes. These checks support resource integrity only; they do not establish language quality themselves.

The patch is generated only from the eight proposed values into a separate candidate file. It has not been applied to shared production source, independently approved, published or merged. A parent/reviewer can inspect each correction without reopening unchanged prior review work.

This is a model-assisted linguistic/static-source review, **not native-speaker certification, whole-Arabic-catalogue acceptance, screenshot acceptance, glyph shaping/bidi/layout acceptance, physical-device acceptance or TalkBack verification**. No screenshot was reclassified as acceptance for newly proposed text. The compact swatch replacements especially have no new visual-fit claim.

## Deliverables

- `review-decisions.json`: all 341 complete English/current-Arabic pairs, exact hashes, per-key decision, rationale, formatter tokens, consumer references and limits.
- `corrections.json`: eight full current/proposed pairs, reasons, confidence and source consumers.
- `carried-receipt.json`: original sampled-memory receipt and exact current rebinding.
- `proposed-arabic.patch`: minimal proposal-only XML patch.
- `candidate/strings.xml`: proposal-only full Arabic catalogue; never copied over production.
- `summary.json`, `validation.json`: exact scope/disposition counts and lightweight validation.
- `composition-examples.json`: static substitution examples for the count and pixel-total proposals, not Android formatting/rendering output.
- `source-manifest.json`: relevant source-file hashes, current tree identity, reference URLs and restrictions.

Parent integration/durable publication remains separate. The priority batch is fully reviewed, but its eight corrections are still proposals.
