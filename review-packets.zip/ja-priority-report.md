# Japanese P0 + P1: current-source linguistic reconciliation

Source: AN Paint develop `4355869e2e198b5616419291cba225b018444fab`, tree `b9b148d5d8ef7c7b088500a9c177f9f59304b800`.

## Result

All **341** current Japanese priority identities are present and already have complete-message linguistic evidence: **92 P0 + 249 P1**. There are **zero missing entries, zero newly unreviewed linguistic pairs, and zero proposed wording corrections**.

- **340** exact unchanged source/target pairs carry their accepted bounded review.
- **1** exact unchanged pair receives a **static source-context rebound**, not a new translation or new linguistic-review credit: `string/ui_the_draft_is_saving_try_again_shortly`.
- Preserve **30** identities' prior wording-only/no-direct-production-callsite limits. The current bounded reference scan finds direct production references for the other **311** identities.
- There is one preserved resource alias (`ui_save_a5d0d9` → `ui_save`) and no plural resource in P0/P1. The catalogue's plural is outside this batch.

Do not describe this as 341 new reviews or new translations. The important result is that current priority work is already linguistically covered, and the old tracker hold can be represented accurately without more rebuilding.

## The one source-context rebound

Japanese: 下書きを保存中です。少し待ってからもう一度お試しください。

The complete Japanese message naturally and accurately describes an active draft save followed by a short retry. Earlier review already accepted its wording but held a generic-busy caller because an unrelated operation could potentially be described as draft saving. Actual non-autosave visibility was not demonstrated.

Current source resolves that distinction:

- [ClassicPaintActivity.kt:915–917](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt#L915-L917) selects it only when `autosaving`.
- [ClassicPaintActivity.kt:1432–1436](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ClassicPaintActivity.kt#L1432-L1436) now selects it only for autosaving and otherwise uses the neutral `ui_please_wait_for_the_current_operation`. This is the source correction associated with [PR146](https://github.com/c933103/AN-Paint/pull/146).

The artifact retains the original hold and complete historical receipt. It records the generic-busy misuse as statically addressed, without claiming a new runtime/reachability, installed-device, rendering, TalkBack, or native-human result.

## Percent accessibility correction preserved

The newly merged P2 crop description remains exactly `%1$sの切り詰め量（%%）`. [Its actual consumer](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt#L104) supplies the localized edge. `%%` is necessary in this formatted template to emit the actual percent symbol, for example 左の切り詰め量（%）. This review proposes no replacement with the word パーセント and no formatter workaround.

## Evidence and validation

The reconciliation joins the [immutable all-language review union](https://github.com/c933103/AN-Paint/tree/2fff195596e7a792185b3b29eb756b7df9081a92/review-reconciliation-20261020), [later merged-review delta](https://github.com/c933103/AN-Paint/blob/854d1402a7a268d9156a159ff3bbe9ca1a6fb95d/merged-review-delta.json.gz), original per-entry receipts and [independent open-item review packet](https://github.com/c933103/AN-Paint/tree/2b22c4f9efc2174854a247901f5c191a299d69df). All 341 current English/Japanese value hashes match their applicable bound evidence. Original confidence, wording-only, alias and dormant restrictions remain attached per identity.

Lightweight XML/JSON parsing verified exact tier totals, unique typed identities, placeholder contracts and escaped-newline counts. English, Japanese, priority manifest and the affected consumer file have local Git blob hashes matching the exact remote source commit. Source and resource files were not edited.

No Gradle, APK, emulator, CI, release, version or new device/render/TalkBack work was run. Existing tests were read only as context. This is not whole-language or P2/P3 acceptance.

## Deliverables

- `japanese-p0-p1-reconciliation.json`: all 341 identities, complete current values, attributes, hashes, source line links, consumer references, historical receipts and scope limits.
- `proposed-corrections.json`: empty array, deliberately.
- `reconcile.py`: lightweight repeatable reconciliation and assertions.
- `input-pairs.json`, `input-pairs.txt`, `call-sites.json`, `call-sites.txt`: bounded inputs and source-reference inventory.

The dedicated [translation tracker PR56](https://github.com/c933103/AN-Paint/pull/56) remains an intentional draft. This review does not change it or authorize merging it.
