from pathlib import Path
import json,hashlib,subprocess,sys,xml.etree.ElementTree as E
O=Path(__file__).resolve().parent;S=O/'source';sys.path.insert(0,str(S/'tools'));from current_localization_contracts import require_string
report=json.load(open(O/'esperanto-p0-p1-review.json'));pairs=report['entries'];tree=json.load(open(O/'base-tree.json'));rows=json.load(open(O/'corrections.json'));fixture=json.load(open(S/'tools/fixtures/current_localization/esperanto_priority_current_wording.json'))
def check(ok,msg):
 if not ok:raise ValueError(msg)
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def scalar(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
priority=json.load(open(S/'translations/string-importance.json'));keys=[k for t in priority['tiers'] if t['id'] in ('P0','P1') for k in t['keys']];check(len(pairs)==len(keys)==341 and [r['key'] for r in pairs]==keys,'review coverage differs');check(len(set(r['key'] for r in pairs))==341,'duplicate review')
for r in pairs:
 check(bool(r['rationale']) and r['confidence'] in ('H','M','L'),'missing judgement')
 for side in ('english','esperanto'):check(scalar(r[side]['value'])==r[side]['sha256'],'value hash drift')
 if 'proposed' in r:check(scalar(r['proposed']['value'])==r['proposed']['sha256'],'proposed value drift')
old=subprocess.check_output(['git','show','HEAD:Paintroid/src/main/res/values-b+eo/strings.xml'],cwd=S).decode();current=(S/'Paintroid/src/main/res/values-b+eo/strings.xml').read_text();en=(S/'Paintroid/src/main/res/values/strings.xml').read_text()
def nodes(xml):return {e.tag+'/'+e.get('name'):(dict(e.attrib),''.join(e.itertext())) for e in E.fromstring(xml)}
a,b,c=nodes(old),nodes(current),nodes(en)
check(set(a)==set(b),'catalogue identity drift');changed={k for k in a if a[k]!=b[k]};check(changed=={r['key'] for r in rows} and len(changed)==16,'unexpected resource changes')
for r in pairs:
 check(a[r['key']]==(r['esperanto']['attrs'],r['esperanto']['value']),'baseline target drift')
 check(c[r['key']]==(r['english']['attrs'],r['english']['value']),'baseline source drift')
for r in rows:
 k=r['key'].split('/')[1];check(a[r['key']][0]==b[r['key']][0],'attribute drift');require_string(current,k,r['proposed']['value'],fixture['constraints'][k]['eo'])
 try:require_string(old,k,r['proposed']['value'],fixture['constraints'][k]['eo'])
 except ValueError:pass
 else:raise ValueError('old value survived')
changed_paths={'Paintroid/src/main/res/values-b+eo/strings.xml','Paintroid/src/test/java/org/catrobat/paintroid/local/EsperantoPriorityWordingTest.kt','tools/fixtures/current_localization/esperanto_priority_current_wording.json','tools/test_esperanto_priority_wording.py'}
base={r['path']:r for r in tree['tree'] if r['type']=='blob'}
for path,r in base.items():
 content=subprocess.check_output(['git','show','HEAD:'+path],cwd=S);check(blob(content)==r['sha'],'base content drift '+path)
 if path not in changed_paths:check(blob((S/path).read_bytes())==r['sha'],'unrelated content drift '+path)
 check(('100755' if (S/path).stat().st_mode&0o111 else '100644')==r['mode'],'mode drift '+path)
actual=set(subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=S,text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=S,text=True).splitlines())
check(actual==changed_paths,'four-file delta differs: '+str(actual));check(len([r for r in pairs if r['decision']=='hold'])==9,'hold drift');check(len([r for r in pairs if r['decision']=='wording_only'])==27,'wording-only drift')
print(json.dumps({'review_entries':341,'corrections':16,'holds':9,'wording_only':27,'verified_baseline_leaves':len(base),'changed_paths':sorted(changed_paths),'old_values_rejected':16,'result':'passed'},indent=2))
