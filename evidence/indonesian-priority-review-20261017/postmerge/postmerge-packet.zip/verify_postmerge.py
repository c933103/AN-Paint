"""Recheck preserved hosted outcomes against the exact reviewed source; does not rerun Android."""
from pathlib import Path
import hashlib,json,re,sys,xml.etree.ElementTree as ET
ROOT=Path(__file__).parent
SOURCE=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT.parent/'source'
def require(v,m):
 if not v:raise ValueError(m)
def read(n):return json.loads((ROOT/n).read_text())
s=read('jvm-summary.json');run=read('final-run.json');merge=read('merged-commit.json');jobs=read('final-jobs.json')['jobs']
require(run['status']=='completed' and run['conclusion']=='success','Incomplete final run')
require(run['head_sha']==s['source_head'] and run['id']==s['run'],'Wrong head/run')
require(merge['sha']==s['hosted_checkout'] and merge['tree']['sha']==s['source_tree']==s['hosted_tree'],'Source tree mismatch')
require(len(jobs)==6 and all(j['status']=='completed' and j['conclusion']=='success' for j in jobs),'Incomplete jobs')
source_test=SOURCE/'Paintroid/src/test/java/org/catrobat/paintroid/local/IndonesianPriorityWordingTest.kt'
expected=set(re.findall(r'@Test fun (\w+)\(',source_test.read_text()));xmls=list((ROOT/'junit').glob('*.xml'));totals={k:0 for k in ('tests','errors','failures','skipped')};found=False
for p in xmls:
 r=ET.parse(p).getroot();cases=r.findall('testcase');require(len(cases)==int(r.get('tests')),'Missing JVM cases')
 require(all(not any(c.find(k)is not None for k in ('error','failure','skipped'))for c in cases),'Nonpassing JVM case')
 for k in totals:totals[k]+=int(r.get(k,0))
 if r.get('name')==s['consumer_test_class']:
  found=True;require(set(c.get('name')for c in cases)==expected and len(cases)==len(expected)==2,'Consumer identities mismatch')
require(found and totals==s['jvm_totals'] and len(xmls)==s['jvm_suite_count'],'JVM summary mismatch')
require(all(totals[k]==0 for k in ('errors','failures','skipped')),'JVM failure/skip')
require(not ET.parse(ROOT/'lint-results-debug.xml').getroot().findall('issue'),'Lint issues')
host=(ROOT/'ci-phases/python.log').read_text();require(re.search(r'^Ran 911 tests in ',host,re.M) and re.search(r'^OK \(skipped=2\)$',host,re.M),'Hosted Python outcome mismatch')
sys.path.insert(0,str(SOURCE/'tools'))
from run_android_instrumentation import declared_tests,source_tests_sha256
coverage=read('emulator-summary/app/coverage.json');identity=read('emulator-summary/composed-device-identity.json');source=SOURCE/'app/src/androidTest';eligible=declared_tests(source,sdk_level=35)
require(coverage['success'] and coverage['execution_status']=='passed','Emulator coverage incomplete')
require(identity['commit']==s['hosted_checkout'] and identity['run_id']==str(run['id']),'Wrong device identity')
require(identity['source_tests_sha256']==source_tests_sha256(source),'Wrong instrumentation source')
require(set(map(tuple,coverage['completed']))==eligible and len(coverage['completed'])==len(eligible),'Missing/duplicate app methods')
require(identity['group_run_attempts']=={'core':1,'position':1} and identity['composed_in_run_attempt']==1,'Unexpected attempt composition')
native=read('emulator-summary/Paintroid/androidTest-results/summary.json');native_expected=declared_tests(SOURCE/'Paintroid/src/androidTest',sdk_level=35)
require(native['success'] and native['completed_tests']==native['expected_tests']==len(native_expected),'Native inventory incomplete')
require(not any(native[k]for k in ('missing','unexpected','errors')) and all(c['status']=='passed' for c in native['cases']),'Native failure')
require(set((c['classname'],c['name'])for c in native['cases'])==native_expected,'Wrong native cases')
exact=read('exact-script/summary.json');require(exact['success'] and exact['commit']==s['hosted_checkout'] and exact['tree']==s['source_tree'],'Wrong exact-script evidence')
print(json.dumps({'success':True,'jvm':totals,'consumer_cases':sorted(expected),'api35_app_methods':len(eligible),'api35_native_methods':len(native_expected),'source_tree':s['source_tree'],'attempts':identity['group_run_attempts']},indent=2))
