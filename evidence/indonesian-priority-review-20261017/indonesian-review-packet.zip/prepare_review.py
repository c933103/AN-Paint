from pathlib import Path
import json,re,hashlib,sys,collections,xml.etree.ElementTree as E
O=Path(__file__).resolve().parent;S=O/'source';sys.path.insert(0,str(S/'tools'));import translation_catalogues as c
pairs=json.loads((O/'pairs.json').read_text());notes={int(x.split('\t',1)[0]):x.split('\t',1)[1] for x in (O/'decisions.tsv').read_text().splitlines()};prior=json.loads((O/'prior-receipts.json').read_text());byprior={x['key']:x for x in prior['receipts']}
changes={'ui_the_encoder_did_not_finish':'Enkoder tidak menyelesaikan pengodean.','ui_pixels_6ec9c2':'piksel'}
p=S/'Paintroid/src/main/res/values-in/strings.xml';raw=p.read_text();baseline=O/'baseline-indonesian.xml';
if not baseline.exists():baseline.write_text(raw)
raw=baseline.read_text();cor=[]
for key,new in changes.items():
 pat=rf'(<string name="{key}">)(.*?)(</string>)';m=re.search(pat,raw,re.S);old=m[2];raw=raw[:m.start(2)]+new+raw[m.end(2):];r=next(x for x in pairs if x['key']=='string/'+key);cor.append({'key':key,'english':r['english']['value'],'before':old,'after':new,'reason':notes[r['n']],'consumers':r['refs']})
p.write_text(raw)
fx={'schema_version':1,'note':'Two bounded Indonesian P0/P1 corrections after a complete-value review; no whole-language or native-speaker certification. All existing processing-label holds remain unchanged.','values':{},'constraints':{}}
for r in cor:
 key=r['key'];fx['values'][key]={'default':r['english'],'id':r['after']};fx['constraints'][key]={'attributes':{'name':key},'formatted':True,'placeholders':dict(c.placeholders(r['english']))}
(S/'tools/fixtures/current_localization/indonesian_priority_current_wording.json').write_text(json.dumps(fx,ensure_ascii=False,indent=2)+'\n');(O/'corrections.json').write_text(json.dumps(cor,ensure_ascii=False,indent=2)+'\n')
def hs(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
entries=[]
for r in pairs:
 key=r['key'].split('/')[1];status='accepted_static_context' if r['refs'] else 'accepted_wording_only'
 if r['n'] in (101,103,241):status='accepted_wording_only'
 if r['n'] in (78,124,199,208):status='held_uncertain'
 if key in changes:status='corrected_independently_accepted'
 en=r['english']['value'];old=r['indonesian']['value'];new=changes.get(key,old)
 entries.append({**r,'candidate':new,'decision':status,'reason':notes[r['n']],'confidence':'high_semantic_moderate_idiomatic' if status!='held_uncertain' else 'open','source_revision':'9bff0abd8f7bc04facbb556908b3a6f578c7346f','english_sha256':hs(en),'before_sha256':hs(old),'candidate_sha256':hs(new),'prior_receipt':byprior.get(r['key']),'new_tracker_credit':False,'limit':'Model-based complete-value linguistic and static-consumer review only; no native-speaker, installed-layout, TalkBack or whole-language certification.'})
summary=dict(collections.Counter(r['decision'] for r in entries));review={'schema_version':1,'locale':'id','resource_qualifier':'in','source_revision':'9bff0abd8f7bc04facbb556908b3a6f578c7346f','entry_count':len(entries),'tiers':dict(collections.Counter(r['tier'] for r in entries)),'summary':summary,'prior_records_preserved':len(prior['receipts']),'prior_selected_records':sum(r['prior_receipt'] is not None for r in entries),'tracker_written':False,'scope':'Full P0/P1 values only; the other 376 canonical entries are not fully reviewed. All prior receipts retained as historical input without duplicate credit.','entries':entries}

for e in entries:
 name=e['key'].split('/')[1]
 for field,rel in [('english','Paintroid/src/main/res/values/strings.xml'),('indonesian','Paintroid/src/main/res/values-in/strings.xml')]:
  line=next(i+1 for i,l in enumerate((S/rel).read_text().splitlines()) if 'name=\"'+name+'\"' in l)
  e[field+'_source_url']=f"https://github.com/c933103/AN-Paint/blob/{review['source_revision']}/{rel}#L{line}"
 for ref in e['refs']:ref['url']=f"https://github.com/c933103/AN-Paint/blob/{review['source_revision']}/{ref['path']}#L{ref['line']}"
review['prior_receipts_ref']='cc1d2718b88b9f08e25b3013ccdbc10770e7f332'
review['prior_receipts_path']='verification/translation-entry-review-2026-10-13/entry-review-receipts.json'
(O/'indonesian-p0-p1-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in review.items() if k!='entries'},indent=2))
