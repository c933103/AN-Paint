from pathlib import Path
import subprocess,json,hashlib
O=Path(__file__).resolve().parent;W=O/'source';B=Path('/workspace/shared/anpaint-commons-errors-20261017/compile-check');A='/workspace/shared/passengercount-restart-race-20261017/investigation/sdk-tools/android-15/aapt2';sdk='/workspace/shared/passengercount-restart-race-20261017/investigation/sdk-platform/android-35/android.jar';T=O/'resource-check';T.mkdir(exist_ok=True)
manifest=(W/'Paintroid/src/main/AndroidManifest.xml').read_text().replace('<manifest xmlns:android="http://schemas.android.com/apk/res/android">','<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="org.catrobat.paintroid">').replace('${applicationId}','org.catrobat.paintroid');(T/'AndroidManifest.xml').write_text(manifest)
import shutil
mirrors=T/'mirrors';mirrors.mkdir(exist_ok=True)
for source,target in [('values-b+ko+Kore+KR','values-b+ko+Kore+KR+anpaint'),('values-b+qaa+Zsye+XV','values-b+en+Zsye+XV+anpaint')]:
 shutil.copytree(W/'Paintroid/src/main/res'/source,mirrors/target,dirs_exist_ok=True)
steps=[]
for label,command in [('compile',[A,'compile','--dir',str(W/'Paintroid/src/main/res'),'-o',str(T/'compiled.zip')]),('compile-mirrors',[A,'compile','--dir',str(mirrors),'-o',str(T/'mirrors.zip')]),('link',[A,'link','-o',str(T/'resources.apk'),'--manifest',str(T/'AndroidManifest.xml'),'-I',sdk,'--java',str(T/'symbols'),str(T/'compiled.zip'),str(T/'mirrors.zip')])]:
 r=subprocess.run(command,text=True,capture_output=True);(T/(label+'.log')).write_text(r.stdout+r.stderr);steps.append({'step':label,'command':command,'exit':r.returncode});print(label,r.returncode,r.stderr[:2000]);
 if r.returncode:raise SystemExit(r.returncode)
(T/'commands.json').write_text(json.dumps(steps,indent=2)+'\n')
deps=':'.join(str(p)for p in sorted((B/'deps').glob('*.jar')));cp=':'.join([deps,str(B/'classes17'),str(B/'test-classes17'),sdk]);main=W/'Paintroid/src/main/java/org/catrobat/paintroid/classic';test=W/'Paintroid/src/test/java/org/catrobat/paintroid/local';files=[test/'IndonesianPriorityWordingTest.kt']+list((T/'symbols').rglob('*.java'))
args=['java','-cp',deps,'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-jvm-target','17','-Xstring-concat=inline','-Xfriend-paths='+str(B/'classes17')+','+str(B/'test-classes17'),'-classpath',cp,'-d',str(O/'compiled-check'),*map(str,files)];r=subprocess.run(args,text=True,capture_output=True);(O/'kotlin-compile.log').write_text(r.stdout+r.stderr);(O/'kotlin-compile.json').write_text(json.dumps({'command':args,'exit_code':r.returncode,'source_sha256':{str(f.relative_to(W)):hashlib.sha256(f.read_bytes()).hexdigest()for f in files if W in f.parents},'scope':'Supplementary Kotlin 1.9.24/API35 changed-source compilation with freshly compiled resource symbols and previously compiled dependency classes; not full Gradle build or Robolectric execution.'},indent=2)+'\n');print(r.stdout+r.stderr);raise SystemExit(r.returncode)
