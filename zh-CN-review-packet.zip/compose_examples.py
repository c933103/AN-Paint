from pathlib import Path
import json,xml.etree.ElementTree as E
O=Path(__file__).parent;R=Path('/workspace/scratch/bbca2890f602/translation-current-integration-20261021/source')
z={e.get('name'):''.join(e.itertext()) for e in E.parse(R/'Paintroid/src/main/res/values-zh-rCN/strings.xml').getroot() if e.tag=='string'}
ledger=json.loads((O/'per-key-review.json').read_text());p={r['key'].split('/')[1]:r['proposed_value'] for r in ledger}
def value(k,new):return p.get(k,z[k]) if new else z[k]
def sub(k,args,new):
 s=value(k,new)
 for a,b in args.items():s=s.replace(a,b)
 return s.replace('\\n','\n')
examples=[]
def add(name,keys,context,before,after,note):
 examples.append({'name':name,'keys':keys,'consumer_context':context,'current_illustration':before,'proposed_illustration':after,'review_note':note})
for count in ['3','至少 3']:
 add('Animation count '+count,['formats22_animation_message','formats22_animation_still'],'ImportSelection.kt:90–96; second argument is exact count or localized at-least count.',sub('formats22_animation_message',{'%1$s':'GIF','%2$s':count},False)+'\n\n'+z['formats22_animation_still'],sub('formats22_animation_message',{'%1$s':'GIF','%2$s':count},True)+'\n\n'+p['formats22_animation_still'],'Both exact and at-least counts compose with 帧. Still-only opening and saving remain explicit. These are illustrative values, not actual imported files.')
add('Separate PNG default image',['formats22_animation_message','formats22_animation_poster'],'ImportSelection.kt:90–96, pngDefaultImageSeparate branch.',sub('formats22_animation_message',{'%1$s':'PNG','%2$s':'4'},False)+'\n\n'+z['formats22_animation_poster'],sub('formats22_animation_message',{'%1$s':'PNG','%2$s':'4'},True)+'\n\n'+p['formats22_animation_poster'],'Independent default image is distinguished from a preset, and import takes it instead of animation frames.')
for key in ['ui_a_separate_recovery_copy_has_been_kept_use','ui_autosave_is_paused_to_protect_that_draft_use']:
 add('Recovery notice '+key,[key,'ui_the_previous_draft_could_not_be_restored'],'EditorDraftRecovery.kt:35–45; reason inserted before recovery branch.',sub(key,{'%1$s':z['ui_the_previous_draft_could_not_be_restored']},False),sub(key,{'%1$s':z['ui_the_previous_draft_could_not_be_restored']},True),'The complete reason and recovery instructions compose. Separate copy retained versus autosave paused to protect the original remain different branches.')
for unit in ['ui_trim_in_pixels','ui_trim_in_percent']:
 add('Bottom edge '+unit,['ui_bottom',unit],'ImageCropDialog.kt:72,104,115; edge label passed to localized trim template.',sub(unit,{'%1$s':z['ui_bottom']},False),sub(unit,{'%1$s':p['ui_bottom']},True),'底层 is a layer-order label; 下 refers to the bottom edge. Top remains a separate unapplied P2 finding.')
for key in ['ui_background_edit_colour','ui_foreground_edit_colour']:
 add('Colour target '+key,[key],'ColourStatusButton.kt:34–36; hexadecimal colour argument.',sub(key,{'%1$s':'#336699'},False),sub(key,{'%1$s':'#336699'},True),'Explicit foreground/background colour role, followed by edit action. No TalkBack pronunciation or Android rendering was tested.')
for key in ['ui_expand_tool_category','ui_collapse_tool_category']:
 add('Tool category '+key,[key,'ui_drawing23','ui_brush'],'ToolCategoryButton.kt:27; category then selected tool.',sub(key,{'%1$s':z['ui_drawing23'],'%2$s':z['ui_brush']},False),sub(key,{'%1$s':p['ui_drawing23'],'%2$s':p['ui_brush']},True),'Chinese grammar works with both substitutions; no gender inflection needed.')
add('Memory refusal',['ui_d_d_pixels_2f_mp_exceeds_the_current'],'ImageMemoryPolicy.kt:46; width, height, MP, MP limit.',sub('ui_d_d_pixels_2f_mp_exceeds_the_current',{'%1$d':'6000','%2$d':'4000','%3$.2f':'24.00','%4$.2f':'16.00'},False),sub('ui_d_d_pixels_2f_mp_exceeds_the_current',{'%1$d':'6000','%2$d':'4000','%3$.2f':'24.00','%4$.2f':'16.00'},True),'All four arguments and no-auto-resize consequence remain. Values are chosen examples, not a measured memory budget.')
add('Save/export instructions',['ui_save','save20_title','ui_export_explanation23','ui_export_did_not_save23'],'SaveOptionsDialog.kt:52,183; ClassicPaintActivity.kt:1361–1364.',z['ui_export_explanation23']+'\n'+z['ui_export_did_not_save23'],p['ui_export_explanation23']+'\n'+p['ui_export_did_not_save23'],'Export does not update the current save destination and does not satisfy pending current-image save. 保存/另存为 menu names match. The generic saved-file toast is not changed in this translation-only candidate.')
add('Language note',['language20_translation_note'],'AppLanguage.kt:149–156, custom title.',sub('language20_translation_note',{},False),sub('language20_translation_note',{},True),'Restores complete source message, English fallback and intended heading/paragraph separation; not a rendered-layout check.')
(O/'static-composition-examples.json').write_text(json.dumps({'scope':'Illustrative string substitution using actual consumer argument roles; not Android formatting, execution, rendering or device tests.','examples':examples},ensure_ascii=False,indent=2)+'\n')
print(len(examples),'illustrations')
