# Human-authored linguistic decisions after reading all 341 pairs and their production references.
# Numbers bind to the frozen priority manifest in pairs-consumers.json, not a sortable presentation.
fixes = {
1: ('此 %1$s 包含 %2$s 帧。AN Paint 编辑静态图片，不会保留动画。', 'zh-CN terminology', 'medium', 'Use 帧 for animation frames rather than the Taiwan-oriented 画格. The second argument can be 至少 N, so %2$s 帧 composes correctly without a second classifier. The still-only/no-animation consequence remains explicit.'),
2: ('此 PNG 有一张独立的默认图片。系统会导入该图片，而不是动画帧。保存后会生成静态图片。', 'default-image semantics and zh-CN terminology', 'medium', '预设 can suggest a user preset rather than PNG’s separate default image. Use 默认图片 and Mainland software terms 导入/帧. Preserve import precedence and still-image saving.'),
3: ('只会导入第一帧。保存后会生成静态图片。', 'zh-CN terminology', 'medium', 'Replace 汇入/画格 with 导入/帧. Retain first-frame-only import and still-image output.'),
5: ('此 %1$s 结构过于复杂，无法确认是否包含多帧。AN Paint 只会打开静态图片，不会保留动画。', 'zh-CN terminology', 'medium', 'Use 帧 in the uncertain-animation branch; keep uncertainty distinct from a claim that the file is animated, and retain unconditional still-only import.'),
6: ('使用明暗不同的字符生成纯文本。请使用等宽字体查看。这只是视觉呈现，不能作为原始图片重新打开。', 'zh-CN terminology and idiom', 'medium', '等阔字体/检视 are not natural Mainland technical UI wording; 等宽字体/查看 identifies the needed display correctly. Plain text and irreversibility remain explicit.'),
9: ('PDF 页面会以 144 dpi 渲染。文字和矢量对象会转换为像素。', 'zh-CN graphics terminology', 'medium', 'Use 矢量对象, not converted Taiwan terminology 向量物件, for vector objects. 渲染 naturally describes PDF rasterization; preserve 144 dpi and conversion of both text and vectors to pixels.'),
13: ('无法用已生成的图片替换目标文件。', 'destination and completion clarity', 'medium', 'The codecs fail when renaming an encoded temporary file to its destination. 目的地文件 is an unnatural literal place-name; 目标文件 identifies the actual replacement target without claiming replacement succeeded.'),
17: ('静态图片，最多 256 色。抖动处理可使颜色渐变更平滑。动画 GIF 只会打开第一帧。', 'zh-CN graphics terminology', 'medium', 'Replace 抖色/画格 with explicit 抖动处理/帧. Preserve still output, maximum palette size, gradient benefit and first-frame-only opening.'),
19: ('较高质量可保留更多细节，通常也会产生较大的文件。', 'control terminology consistency', 'low', 'Use 质量 to match the actual quality control label ui_quality (质量（%）). Retain detail preservation and usually, rather than guaranteeing a file size.'),
21: ('此图片使用 AN Paint 尚无法转换的颜色配置文件。请先在支持色彩管理的编辑器中将其转换为 sRGB PNG，再导入。', 'zh-CN colour-management terminology', 'medium', 'Use 颜色配置文件 for colour profile rather than the inherited 色彩描述档. The separate PR86 receipt endorsed only the bounded remedy and did not globally endorse that term. Keep not-yet-supported conversion, colour-managed editor, exact sRGB PNG and conversion-before-import order.'),
22: ('%1$s 已保留另一份恢复副本。请使用「文件」>「导出恢复副本」将其保存为 ZIP。如需使用常规的大小调整功能，请从 ZIP 中解压 canvas.png，再打开该图片。', 'recovery instruction grammar', 'medium', 'Repair the awkward 如有需要使用… construction while preserving the prefixed reason, separate recovery copy, exact export menu, ZIP and canvas.png extraction before ordinary image resizing.'),
23: ('图片拼接缺少一张源图片。', 'missing-versus-lost semantics', 'medium', 'The consumer checks that the source path is inside its directory and is a file; it does not establish that a file was lost. 缺少 states missing without the stronger 遗失 claim; 源图片 is normal technical usage.'),
25: ('即使输出尺寸很小，解码一张源图片所需的内存仍超过当前可用内存。缩小拼接尺寸无法解决此问题。请关闭其他文档，或先准备较小的源图片再试。拼接内容未改变。', 'memory failure grammar and consequence clarity', 'medium', 'The source image does not itself output a tiny result. Recast the concessive clause around output dimensions and decoder memory. Preserve the irreducible memory floor, both remedies, and the unchanged-assembly guarantee.'),
33: ('自动保存的选区编码失败。', 'selection terminology consistency', 'low', 'Use 选区, already present in 裁剪到选区/删除选区/矩形选区, for the floating selection bitmap encoded by AutosaveStore.'),
34: ('无法创建撤销缓存。请腾出一些设备存储空间，然后再试。', 'storage terminology', 'medium', '设备保存空间 is unnatural and can blur storage with a Save operation. 存储空间 is the relevant device-storage remedy; this is not a request to free RAM.'),
42: ('%1$d × %2$d 像素（%3$.2f MP）超出当前 %4$.2f MP 的安全编辑上限。AN Paint 会将完整图片保留在内存中，并为变换和选区操作预留空间。此上限由可用内存决定。系统已在为过大的位图分配内存前停止操作，并未自动调整大小。', 'allocation semantics and zh-CN graphics terminology', 'medium', '配置 means configure, not allocate; say 分配内存 for the stopped bitmap allocation. Use 位图 and 选区 rather than 点阵图/选择范围. Preserve all dimensions/budgets, full resident image, reservations, budget basis and no-auto-resize guarantee.'),
49: ('导出图标、Base64 文本或 ASCII 艺术。导出不会改变当前图片及其保存位置。', 'save destination idiom', 'low', '保存目的地 is an unnatural location calque. 保存位置 clearly denotes the current save destination, distinct from the exported copy; the three derived export types and unchanged image remain.'),
52: ('较高质量通常会产生较大的文件。无损压缩会保留每个颜色值。', 'compression terminology and grammar', 'low', 'Use 质量 to match the quality control and make the nominal compression mode explicit as 无损压缩 rather than the isolated adjective 无损. Preserve usually and every colour value.'),
62: ('已导出恢复副本。请从 ZIP 中解压 canvas.png，并使用「文件」>「打开图片」打开它。ZIP 也包含草稿设置及任何浮动选区。', 'selection terminology and recovery grammar', 'low', 'Use 浮动选区 consistently with selection controls and make the image object of 打开 explicit. Preserve the actual localized File > Load image route, ZIP contents and exact filename.'),
64: ('估算包括当前画布和剪贴板、采样解码及编辑缓冲区。实际内存用量会有所不同。较小的副本会损失细节。原始文件不会改变。', 'zh-CN clipboard and decoding terminology', 'low', 'The old complete-value receipt remains exact-bound but is not a global terminology endorsement. Use Mainland 剪贴板/采样 instead of 剪贴簿/取样, preserving all estimate components, variability, detail loss and unchanged original file.'),
89: ('内存不足，无法以原始分辨率完成此操作。系统并未自动调整大小。', 'zh-CN resolution terminology', 'medium', '分辨率 is the normal Mainland image-resolution term; 解析度 is imported Taiwan terminology. Preserve original-resolution scope and absence of automatic resizing.'),
93: ('无法启动图片色彩转换器。图片并未导入。', 'zh-CN import terminology', 'medium', 'Use 导入 rather than 汇入, matching the independently reviewed gallery component failure and the actual image-import action. Preserve converter-start failure and explicit non-import.'),
97: ('SVG 的原始大小超出 Android 位图的尺寸上限。并未调整大小。', 'zh-CN bitmap terminology', 'low', 'Use 位图 for Android bitmap, preserving the dimension-limit failure and no-resize result.'),
99: ('此文件超出 512 MiB 导入上限。请选择较小的文件。', 'zh-CN import terminology', 'low', 'Use 导入 rather than 汇入. Preserve the exact binary-unit limit and smaller-file remedy, not an instruction merely to choose fewer pixels.'),
104: ('应用语言\\n\\n翻译内容在 AN Paint 的语言资源中维护。新增或尚未翻译的文字会以英语显示。', 'unsupported completeness claim and omitted fallback', 'high', 'The current value claims all translatable interface text is included, contradicting the current English and withdrawn completeness status. Restore the heading, resource-maintenance statement and English fallback for new/untranslated text, with the two literal Android paragraph escapes.'),
114: ('Android 阻止打开文件选择器：%1$s', 'idiomatic failure description', 'low', '封锁 sounds like a broad blockade. The consumer catches SecurityException while launching the picker; describe that blocked opening and keep the full diagnostic argument.'),
116: ('Android 找不到文件选择器。请在 Android 设置中启用「文件」（Files）或「文档」（Documents）应用，然后再试。', 'app-name distinction and grammar', 'medium', 'The source offers Files or Documents, but the current Files/文件 pair can name the same option twice and omit Documents. Localize both alternatives distinctly and supply the missing locative 中; no particular OEM label is guaranteed.'),
122: ('背景色 %1$s。编辑颜色。', 'accessibility referent clarity', 'low', 'The substituted value is a hexadecimal colour, not background content. Name 背景色 to match the dialog and the paired foreground description.'),
126: ('下', 'wrong geometric meaning', 'high', '底层 denotes a bottom layer, but ImageCropDialog uses this resource for the bottom crop edge, beside 左/顶层/右. Use 下, parallel to 左/右. The paired top-edge defect is outside this batch and is reported separately.'),
139: ('请选择较小的输出副本。源图片及裁剪设置会保持原有分辨率。', 'zh-CN resolution terminology', 'medium', 'Use 源图片/分辨率 for original source images and resolution. Preserve that only the output copy shrinks while source data and crop settings remain at original resolution.'),
140: ('请选择较小的尺寸。', 'unidiomatic dimension instruction', 'low', '较小的大小 is awkward repetition. 尺寸 names the output width/height controlled by the actual dialog.'),
149: ('调色板。点按设为前景色；长按设为背景色。滚动可查看更多颜色。', 'zh-CN scrolling terminology', 'low', '滚动 is normal Mainland interface wording; 卷动 is converted regional terminology. Preserve tap versus hold and foreground/background assignments.'),
152: ('确认选区', 'selection terminology consistency', 'low', 'This button commits the pending selection, not a choice among settings. Use 选区 consistently with the selection tools and deletion/crop actions.'),
163: ('裁剪预览。拖动边缘或角点调整大小；拖动内部以移动裁剪范围。', 'zh-CN geometric terminology', 'low', '角位 is a Hong Kong-style expression. 角点 identifies the crop corner naturally in Mainland Chinese while preserving resize versus move gestures.'),
173: ('绘图画布。用双指捏合或张开可缩放，双指拖动可平移。「移动与缩放」模式也可用单指平移。', 'gesture instruction clarity', 'medium', 'The current wording repeats 缩放…以缩放 and never names the pinch gesture clearly. Explain pinch/open for both zoom directions and dragging for pan, retaining the exact localized Navigate mode and one-finger exception.'),
187: ('请输入 Android 坐标范围内且大于 0 的画布尺寸。', 'zh-CN orthography', 'low', 'Use Mainland 坐标 rather than 座标; preserve Android coordinate-range and positive-dimension constraints.'),
210: ('前景色 %1$s。编辑颜色。', 'accessibility referent clarity', 'low', 'The substituted value is a hexadecimal colour. Name 前景色 to match the dialog and paired background description rather than generic foreground content.'),
223: ('选区轮廓无效。', 'selection terminology consistency', 'low', 'Use 选区 for the actual selection outline object, matching the surrounding selection controls; retain invalidity rather than missingness.'),
249: ('即使输出尺寸最小，此图片的解码器工作缓冲区所需内存仍超过当前上限。请取消并使用较小的源图片。', 'memory-budget semantics and grammar', 'medium', 'A buffer cannot be placed into an upper limit (放入…上限). Say its memory requirement exceeds the limit, retaining the smallest-output impossibility and cancel/smaller-source remedy.'),
251: ('内存不足，无法完成此图片的加载', 'open-failure grammar', 'low', '无法完成开启此图片 is an ungrammatical verb stack. State that image loading could not complete, preserving the memory cause and avoiding a successful-open implication.'),
296: ('选区尺寸过大。', 'selection terminology consistency', 'low', 'Use 选区 for the selection bitmap dimensions, matching selection controls; do not imply the whole canvas is too large.'),
316: ('完整图片及工作缓冲区超出当前安全上限，或 Android 无法分配所需内存。请调整一份副本的大小后再编辑。原始文件不会改变。', 'memory allocation terminology', 'medium', '配置所需内存 means configure memory, not allocate it. Use 分配; preserve the alternative budget/allocation causes, explicit copy resizing and unchanged original file.'),
320: ('此文件不是支持的图片。请使用 PNG、JPEG、JPEG XL、WebP、HEIC、AVIF、BMP、GIF、DIB、TIFF、ICO、PDF 或 Base64 编码的图片文本。', 'encoded-text clarity', 'low', '图片文字 can mean text visible inside a picture. Specify Base64-encoded image text, as accepted by TextImageCodec, and retain every format in the supported list.'),
323: ('工具分类。滚动查看更多工具', 'zh-CN scrolling terminology', 'low', 'Use Mainland interface term 滚动 instead of 卷动. This resource has no literal production reference in the frozen tree, so the decision is wording-only.'),
}

# Every unchanged entry has an explicit reviewed reason; no accept-by-default fallback.
retain_notes = {}
def note(numbers, reason):
    for n in numbers:
        assert n not in retain_notes and n not in fixes
        retain_notes[n] = reason
note([4], '动画图片 is understandable and natural for the animation warning title; it does not promise animated editing.')
note([7], 'The complete sentence preserves exported output versus unsaved full drawing and saving a full copy before replacement. 变更/取代 are valid written Chinese, not errors merely because 更改/替换 are alternatives. Source-only: no literal consumer found.')
note([8], '开启静态图片 is understandable Chinese for opening a still image and preserves the dialog action; 开启 is not inherently wrong for zh-CN.')
note([10], 'Preserves save-or-restore failure, retention of existing saved image credits, and retry. 致谢信息 is the established local UI name for these records; this review does not certify legal adequacy or endorse it globally as a replacement for attribution.')
note([11], 'Preserves the conditional consequence of oversized credit data and explicit retention of the previous drawing and credits; no completed-data-loss claim.')
note([12], 'Preserves partial unreadability and retention of the stored copies, not successful restoration. 致谢信息 matches the existing credit UI naming.')
note([14], 'Correctly states that image plus encoding buffers exceed the export memory limit; 内存 is RAM, not device storage.')
note([15,16], 'The file-dialog field label is natural zh-CN and names the correct property without changing a format or destination.')
note([18], 'Preserves the prohibition on slashes and control characters in the filename. 文件名称 and 斜线 are valid Mainland terms; no blanket terminology replacement is needed.')
note([20], '另存为… is the standard Save as action and retains the continuation ellipsis; used both in the file menu and save dialog.')
note([24], '已保存拼合图片 correctly communicates completed assembly save. 拼合图片 is understandable in this context; stylistic consistency with 拼接 is not treated as a semantic defect.')
note([26], 'Preserves failed autosave and the explicit manual 保存 remedy; the action name matches ui_save.')
note([27], 'Correctly identifies failure encoding the autosaved image, distinct from selection encoding and metadata errors.')
note([28], 'Preserves the prefixed failure reason, protective autosave pause, recovery-copy export versus current-work save, exact menu labels, and PNG/JPEG choices.')
note([29], 'Correctly states missing autosave metadata rather than malformed or unreadable metadata.')
note([30], 'Preserves paused, not failed or completed, autosave and the manual 保存 remedy.')
note([31], 'Correctly identifies missing autosave pixel data.')
note([32], 'Correctly distinguishes unreadable autosave pixels from missing data.')
note([35], '全部清除 is a clear command for clearing all assembly items; the action is not presented as reversible or non-destructive.')
note([36], '清空图片 accurately describes clearing image contents rather than deleting a saved file.')
note([37,38,39], 'The error prefix correctly names the failed export/open/save action. The consumer appends a diagnostic separately; no success is implied.')
note([40], 'Preserves assembly-save failure and the full diagnostic after the colon.')
note([41], '无法保存图片拼接 communicates failure to store the assembly state; it does not claim source-file deletion. 保存 is acceptable for the storage operation here.')
note([43], '放弃更改 makes the discarded object explicit, appropriate to unsaved changes. No literal current consumer found, so retain wording only.')
note([44], '放弃更改 accurately labels the destructive replacement-confirmation branch, distinct from 继续编辑 and 保存.')
note([45], '草稿尚未保存 preserves not-yet-saved state and does not assert a save failure.')
note([46], '已还原草稿 correctly indicates successful draft restoration; 还原 is valid Mainland usage.')
note([47], '已保存草稿 correctly indicates completed draft saving, not a pending operation.')
note([48], 'Retains that an export was created but the current image still must be saved before continuing. The named 保存/另存为 actions match the actual menu.')
note([50,51], '导出恢复副本 identifies the separate recovery-export action/title; the menu variant retains its ellipsis and the title variant does not add one.')
note([53], 'Preserves successful canvas restoration, unreadable undo history and separately retained original recovery draft; no claim of restored history.')
note([54], 'Correct invalid-metadata diagnosis in all size/version/JSON-bound checks; not confused with absence.')
note([55], '继续编辑 is the natural non-destructive action to stay in the editor.')
note([56], 'Preserves top-left pixel anchoring, discard beyond right/bottom boundaries when shrinking the canvas, and explicit Undo restoration; the command name 撤销 matches.')
note([57], 'Preserves memory failure and the assurance that assembly source files are retained; it does not claim the operation succeeded.')
note([58], 'Preserves format-specific memory failure and PNG as an alternative, not a guaranteed successful remedy.')
note([59], 'Correct failed-PNG-encoding diagnosis; format token remains unchanged.')
note([60], '已保留上一份草稿供复原 distinguishes retention for later recovery from already-restored state. 复原 is understandable Mainland wording.')
note([61], '已复原图片 is a clear fallback filename/label for a recovered image, not a claim about unsaved current work.')
note([63], 'The question proposes resizing a large image rather than asserting that resizing already happened.')
note([65], '保存 is the standard Mainland save command, including colour edits and credit text saving.')
note([66], 'The resource alias resolves to 保存. That action is correct in confirmReplacement; the absent ellipsis does not alter save versus discard semantics. Alias is preserved unchanged.')
note([67,68], '保存并分享 correctly preserves both steps; the menu/title ellipsis distinction remains. 分享 is valid Mainland app terminology.')
note([69,70,71,72], '保存为 correctly names the output format, preserving format tokens/placeholders and ellipses. No literal current consumer found; source-only wording review.')
note([73], 'Preserves selection of image format/compression and reuse of filename, location, format and settings by 保存. 文件名称 is valid zh-CN.')
note([74], '保存 PNG clearly names the assembly output format and save action.')
note([75], '保存更改？ is the natural save-before-replacement confirmation question.')
note([76], '已保存 %1$s clearly reports completion and accepts the filename argument without Chinese inflection or agreement problems. Any English-consumer generic export toast scope is not fixed by translation.')
note([77], 'Preserves saving a copy first, then choosing a sharing app, while the current Save destination is unchanged.')
note([78], 'Correct in-progress draft-save status and deferred retry instruction; not confused with completed save or failure.')
note([79], 'Correct incomplete-encoder diagnosis, distinct from a particular format or file-picker error.')
note([80], 'Preserves successful image save, failed Android share launch and diagnostic argument; no risk of treating the saved image as lost.')
note([81], 'Preserves inability to move the previous draft into a recovery-copy destination, without falsely claiming that a separate copy exists.')
note([82], 'Correctly states failure to preserve the previous draft separately.')
note([83], 'Correct failure to restore the previous draft; does not imply deletion.')
note([84], 'Correct extra-memory requirement to reopen the previous draft; distinct from insufficient device storage.')
note([85], 'Preserves failed opening of the saved assembly and the appended diagnostic; 开启 remains understandable zh-CN.')
note([86,90], '无法写入 correctly describes a non-writable destination. 所选/此 preserve selected versus current location reference.')
note([87], 'Retains the conditional consequence that this trim amount would remove the entire image. 裁减量 is a valid description of edge reduction, not automatically an error because 裁剪 is also used.')
note([88], 'Correct damaged-undo-cache diagnosis; not equated with missing history.')
note([91], '含有未预期的数据 is understandable technical Chinese for unexpected trailing undo-cache data.')
note([92], 'Retains current image and unsaved changes. 目前/变更 are valid written Chinese and do not need mechanical regional substitution.')
note([94], 'Preserves invalid OR unsupported colour metadata, rather than collapsing these to corruption alone.')
note([95], 'Correctly explains that image data ends before its colour metadata is complete; all parts of the truncation meaning remain.')
note([96], 'Preserves unsupported ICC model, decoder conversion limitation, colour-managed application and RGB-copy-before-import remedy. 色彩管理 is standard Mainland terminology.')
note([98], 'Preserves unusable original SVG size and explicitly states no canvas-based substitute size was applied.')
note([100], '应用语言 naturally labels the app-specific language selector rather than a device-wide language change.')
note([101], '应用语言：%1$s correctly composes with the selected language name.')
note([102], '使用系统语言 naturally expresses following the device language; it does not claim to change system settings.')
note([103], '设置 is the natural Mainland settings label.')
note([105,108,166,253,272,273], 'The complete numeric/composed template preserves argument order, precision, units and separators. Chinese wording or punctuation fits the actual dimensions/status/value consumer; no grammatical agreement is required.')
note([106], '100% correctly names the actual-size zoom action; the percent sign is a literal, not a missing format argument.')
note([107], '1 px is a language-neutral one-pixel unit label; no literal current consumer found.')
note([109], '实际大小（100%） accurately names actual-size viewing; source-only because no literal current consumer was found.')
note([110], '添加颜色 naturally labels adding a colour in the palette/dialog and does not promise saving a whole image.')
note([111], '加入文字 is understandable natural Chinese for inserting text. 添加文字 is an alternative, not a required correction.')
note([112,127,128,181,193,198,211,230,261,270,275,276,288,310,337], 'The tool name is a natural or established Mainland drawing-software label for the exact PaintTool/action. Its meaning matches the production tool enumeration or drawing control; no mechanical synonym change is necessary.')
note([113], '全部 correctly selects all image checkboxes in batch crop; context makes the object explicit.')
note([115], 'Correct Android image-decoding failure, not a format-not-supported claim.')
note([117,118,119], '应用 correctly expresses applying settings/bounds/crop in the actual confirmation control; object-specific labels preserve their distinction.')
note([120], '正在自动保存草稿… correctly reports ongoing autosave, retaining the ellipsis.')
note([121,209], '背景色/前景色 are the standard Chinese colour-role terms and compose naturally as the combined content description.')
note([123], '基本颜色 accurately labels the basic palette.')
note([124,199], 'FG/BG are intentionally compact literal badges in the custom colour view, paired with fully localized foreground/background accessibility descriptions. Retain the convention, but unaided recognition and small-label legibility are not established by this linguistic review.')
note([125,225,329], 'The typography style label is standard Mainland Chinese and matches the bold/italic/underline toggle.')
note([129], '取消 is correct in all listed cancellation/dismissal branches; it does not imply reversing an already-completed operation.')
note([130,131,132], '画布边界/画布大小 correctly distinguish canvas bounds from image-resampling dimensions; menu continuation ellipses and dialog titles are preserved.')
note([133,134], '画布缩放 correctly names viewing zoom, not destructive image resizing; the composed label keeps its zoom argument.')
note([135], '笔刷 is an established drawing term. No literal current consumer was found for this older category label, so acceptance is wording-only.')
note([136,137], '插入/选择 are natural category labels and match their production tool groups.')
note([138,228,287], '居中/左对齐/右对齐 are standard text-alignment labels. 居中 also remains correct in the vertical-alignment choice array.')
note([141], 'Preserves a minimum of one selected image; no plural inflection is necessary in Chinese.')
note([142], 'Preserves the upper bound at the original image dimensions, without requiring smaller dimensions when equal size is allowed.')
note([143], '选择位置… is a natural destination-picker action and retains its continuation ellipsis.')
note([144], 'Preserves decoding the source image OR tiles before resizing and the possibility that smaller output still exceeds memory. 来源图片/来源图块 are understandable even though 源 is a shorter technical alternative.')
note([145,194], '收起/展开调色板 form a natural opposite pair; no literal current production reference found, so wording-only scope.')
note([146,195], 'The category and selected-tool substitutions compose naturally without gender agreement. 已选择 and 收起/展开 retain state and action separately.')
note([147,196], '收起/展开工具箱 correctly describe the actual toolbox toggle states.')
note([148,151], 'The hexadecimal colour argument remains in the correct position, and tap/hold instructions preserve foreground versus background assignment where present. No duplicate # is introduced.')
note([150], '颜色 is a natural name for the colour tab; singular/plural English differences do not require Chinese changes.')
note([153,165,259,277,292,330], 'The editing command is standard Mainland Chinese and maps to its actual copy/cut/paste/redo/select-all/undo action.')
note([154], '全部复制 clearly refers to copying all displayed text/credits in the actual consumers, not copying every drawing object.')
note([155], 'Correct failed application of the crop; does not claim the image was cropped.')
note([156], 'Correct edit-failure prefix followed by the full diagnostic or localized retry text; Chinese punctuation composes cleanly.')
note([157,158,159], 'The complete error correctly names failure to complete an operation/place an image/prepare an image. It does not invent causes or successful recovery.')
note([160], '裁剪%1$s composes with the image filename as a Chinese dialog title. A visual space before a Latin filename is optional typography, not a semantic defect.')
note([161,164,167], '裁剪图片/裁剪到选区/删除选区 accurately distinguish whole-image crop, crop to the selection and deletion of the selection.')
note([162,314], 'Preserves containment within the canvas/image respectively; the two geometric constraints are not confused.')
note([168], '完成 naturally dismisses completed information/credit/language panels and matches the source Done action.')
note([169], '草稿等待保存 correctly expands pending into the actual unsaved-waiting state; it does not claim completed saving.')
note([170,172], '绘图 is a natural drawing-category label and matches the menu/category use.')
note([171], '再次绘图 is understandable for returning from Navigate to the previous drawing tool, rather than undoing or replaying a drawing.')
note([174,175], '绘图设置 correctly labels the settings menu/dialog with the appropriate ellipsis distinction.')
note([176,179], 'Explicitly naming 背景色/前景色 removes ambiguity about editing background/foreground colours. Both values are source-only because no literal current consumer was found.')
note([177], '画布 is the natural label for the canvas editing group.')
note([178], '编辑颜色 naturally labels the colour-edit action/dialog.')
note([180], '翻转／旋转 accurately names both transform categories.')
note([182,185], 'The numeric-validation sentence preserves the two bounds in order; 整数 correctly distinguishes integer-only input from unrestricted numbers.')
note([183,188,189,190,191,334], 'The dimension validation preserves strict positivity, any original-size upper bound, and the at-least-one-pixel condition where specified. Numeric conditions are not softened or rounded away.')
note([184,186], 'The trim-validation instruction correctly requires a value for every edge/all four edges. 裁减量 remains a valid term for the amount removed from an edge.')
note([192], '请输入有效尺寸 is a natural invalid-dimension correction instruction.')
note([197], '导出为… clearly labels derived export, distinct from 另存为… for saving the current image.')
note([200], '适合窗口 expresses Fit to the viewing window, not resizing the underlying image. The reviewed consumers call paintCanvas.fit(); later Fit implementation changes are outside this frozen context binding.')
note([201], '显示整个画布 correctly communicates fitting the entire canvas into view. It does not imply canvas resampling; later consumer changes are not certified.')
note([202], '显示整张图片 accurately expresses fit-to-view for an image. No literal current consumer found; do not infer a new live UI action.')
note([203], '使图片适合画布 correctly names fitting the floating image to the canvas, distinct from view-only Fit. Does not claim original-size preservation.')
note([204,205], '水平翻转/垂直翻转 correctly distinguish the transform axes used by the scale matrix.')
note([206,207], '字体/字体系列 are standard Chinese typography terms for the font and font-family selector.')
note([208], 'The complete foreground/background/palette template is grammatically viable and preserves three arguments. No literal consumer establishes the third argument, so acceptance is source-template wording only; actual spoken composition remains unverified.')
note([212], '从设备选择… naturally describes the local-device image source and retains continuation.')
note([213], '已复制全文 correctly communicates completed full-text copying.')
note([214,215,338], '高度/宽度 with parenthesized localized units form natural dimension labels and accessibility descriptions; numerical unit choice is preserved.')
note([216], '高度 correctly renders the plural English dimension category without adding a Chinese plural marker; source-only.')
note([217], '十六进制 #RRGGBB correctly states the hexadecimal colour syntax and preserves all literal characters.')
note([218,300], '隐藏/显示编辑控件 form a clear opposite pair; no literal current production consumer found, so wording-only scope.')
note([219], '图片 is a natural fallback image name when the document provider supplies none.')
note([220,221], '插入/在画布中插入图片… preserve insertion action and canvas destination. These older labels have no literal current consumer.')
note([222], '颜色无效 correctly reports a rejected colour value in the editing fields.')
note([224], '反转颜色 accurately labels inversion of colours, not exchanging foreground and background.')
note([226], '语言 is a natural plural/category label for the language picker; Chinese does not require a plural suffix.')
note([227,286], '左/右 correctly identify the crop edges and compose with the trim-in-pixels/percent templates. The separate top/bottom layer mistranslations do not invalidate these correct directions.')
note([229], '左箭头：收起 correctly states direction and collapse action. No literal current consumer found.')
note([231], '行距（%） correctly names percentage line spacing; the percent symbol is literal.')
note([232], '打开图片… is a natural Mainland rendering of loading an image and is the exact label named in the recovery instructions.')
note([233,234], '锁定宽高比/锁定比例 correctly preserve the aspect lock actions. The shorter proportions label is adequate in the selection control.')
note([235], '放大倍率（%） accurately labels the magnifier’s 100–400% scale rather than pixel dimensions.')
note([236], '主要 is a viable generic Main/category translation, but no literal consumer supplies its omitted noun. Retain only contextless wording; a future live consumer may require a more specific label.')
note([237,238], '菜单/颜色 are natural source-only labels; no literal production reference was found for these older entries.')
note([239,240,241,243], '编辑/文件/帮助/查看 are natural menu labels and name the actual menu categories without unintended commands.')
note([242], '图像 is a valid Mainland synonym of 图片 and works as the fallback image title used here. Do not mechanically replace it for stylistic uniformity.')
note([244], '移动与缩放 usefully names the Navigate tool’s pan/zoom behaviour and matches the explicit mode name in the canvas gesture help.')
note([245,247], '新建…/新建图片 correctly distinguish the menu command and new-image dialog, including continuation.')
note([246], '新颜色 is a natural label for a new colour; source-only because no literal current consumer was found.')
note([248], 'Correct absence of readable image data; does not allege corrupted source files.')
note([250], '无 is understandable as the counterpart to 全部 in the batch-crop image-selection row. 取消全选 is a possible refinement, not necessary to preserve meaning.')
note([252], 'Correct memory failure while inspecting an image, distinct from loading completion.')
note([254], '确定 is the natural confirmation/dismissal label for these informational error dialogs.')
note([255], '原始大小 correctly labels resetting the floating image to original dimensions, distinct from fitting it to the canvas.')
note([256], '其他图片 correctly labels image-source insertion outside the current drawing.')
note([257,304], '轮廓/填充 correctly distinguish outline versus filled shape styles beside 填满＋线条. The shorter 填充 is sufficient in this context; no false solid-fill defect is introduced.')
note([258], '调色板 is the standard Mainland palette label.')
note([260], 'Preserves copying an area or using the actual 绘图 → 插入 → 其他图片 route. 范围 is understandable for an area and does not change the copy prerequisite.')
note([262,263,265,266], '百分比/像素 are the correct Chinese unit labels, including their composition inside width/height accessibility descriptions. English case differences need no Chinese distinction.')
note([264], '双指缩放及平移模式 communicates pinch/zoom and pan; no literal current consumer found, so no live gesture certification.')
note([267,328], '放置文字/输入文字 correctly distinguish placing text on the canvas from entering its content.')
note([268], '请再试一次 is a natural fallback retry instruction without an unsupported recovery promise.')
note([269], '请等待目前操作完成 correctly asks the user to wait for the active operation rather than retry it in parallel.')
note([271], '预览 is the standard Chinese preview label.')
note([274], '就绪 correctly names the initial ready state.')
note([278], '移除 correctly names removing the selected assembly item, distinct from unplacing it or deleting a saved source file.')
note([279,281], '黑／白 and 重设为黑／白 correctly describe resetting foreground/background to black/white; 重设 is understandable Mainland Chinese. The longer resource is source-only.')
note([280], '重设裁剪 correctly resets the crop to original image bounds. 重置 is an alternative, not a mandatory correction.')
note([282,285], '调整大小并加载/调整副本大小 preserve resizing-and-loading and resizing a copy; neither suggests modifying the original source file.')
note([283,284], '调整图像/图片大小 are both valid Mainland image-resize labels; preserve menu ellipsis versus dialog title and do not manufacture a 图像/图片 synonym defect.')
note([289,290], 'Preserves exact 180° and clockwise 90° rotations. Lack of an optional space before the number is not a meaning defect in Chinese.')
note([291], 'Preserves image scaling and unlocking the width/height ratio to stretch independently; no confusion with changing canvas bounds.')
note([293,294], '选择范围/请先选择范围 clearly asks for an area selection and preserves the prerequisite before crop/cut/copy/delete actions. A verb phrase need not use the noun 选区.')
note([295], '目前选择的颜色 accurately labels the selected-colour preview.')
note([297], '分享已保存图片 correctly names sharing an already-saved image in the Android chooser title.')
note([298], '显示全部 correctly fits the entire assembly into view without claiming to save or modify it.')
note([299], '显示控件 correctly exits the hidden-controls/fullscreen state.')
note([301], '显示放大绘图预览 accurately labels the magnified drawing-preview toggle.')
note([302,303], '大小（像素/px） correctly names font/brush/pencil size with the relevant pixel unit.')
note([305], '交换颜色 correctly swaps foreground and background in the production handler, distinct from colour inversion.')
note([306], '交换前景色/背景色 explicitly names both colour roles; source-only because no literal current consumer found.')
note([307], '请先点按一张图片 correctly states the selected-image prerequisite in assembly remove/unplace handlers.')
note([308], '点按画布\\n输入文字 preserves the two-line tap-then-type instruction; literal Android line break retained.')
note([309], 'The label/value/tap-to-enter-number accessibility sentence is grammatical Chinese and preserves both arguments in order.')
note([311,312], '文字对齐/文字方向 accurately distinguish alignment and writing direction. 文字 is valid Mainland usage beside the 文本 tool label.')
note([313], 'Preserves the minimum crop area of one pixel, not merely nonnegative dimensions.')
note([315], 'Preserves approximate decoder/editing-buffer memory, current safe limit and smaller-copy remedy, with both memory arguments in the original order.')
note([317,318,319], '没有传回 clearly states no returned file/files/image data. 传回 is understandable Mainland Chinese; 返回 is an alternative, not grounds for indiscriminate changes.')
note([321], '容差 is the standard image-editing tolerance term for the fill control.')
note([322], 'Preserves current budget excess and the two remedies: smaller dimensions OR cancel and free memory. It does not claim resizing is always sufficient.')
note([324], '裁减量必须为 0 或以上 correctly permits zero and rejects negative trim amounts.')
note([325], 'Preserves containment inside each image and integer-pixel versus percentage input; the unit requirements remain distinct.')
note([326], '以触控裁减／扩展画布… is understandable Chinese for touch-based canvas trimming/expansion. 裁减 legitimately describes edge reduction; no literal current consumer found.')
note([327], '请尝试其他文件或位置 preserves the alternative file-or-destination remedy when no diagnostic is available.')
note([331], '无标题 is the conventional fallback filename for a new/unnamed document.')
note([332,333], 'Preserves the exact inclusive 1–1024 pixel and 50–300% validation ranges, with natural Chinese instructions.')
note([335], '使用颜色 correctly applies the chosen colour rather than saving an image or changing palette membership.')
note([336], 'Preserves exact #RRGGBB input syntax; no translated characters or altered hash marker.')
note([339], '处理中… correctly signals an ongoing operation; distinct from 就绪 and completed save.')
note([340,341], '放大/缩小 correctly describe zoom-in/zoom-out viewing commands rather than destructive image-resize operations.')
assert len(fixes) + len(retain_notes) == 341, sorted(set(range(1,342))-set(fixes)-set(retain_notes))
