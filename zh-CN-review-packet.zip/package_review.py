from pathlib import Path
import json, hashlib, csv, re, difflib, xml.etree.ElementTree as ET, collections, subprocess, zipfile
from review_decisions import fixes,retain_notes
ROOT=Path('/workspace/scratch/bbca2890f602/translation-current-integration-20261021/source')
OUT=Path(__file__).parent
SOURCE='Paintroid/src/main/res/values/strings.xml'; TARGET='Paintroid/src/main/res/values-zh-rCN/strings.xml'; MANIFEST='translations/string-importance.json'
REV='4355869e2e198b5616419291cba225b018444fab'; TREE='b9b148d5d8ef7c7b088500a9c177f9f59304b800'
URL='https://github.com/c933103/AN-Paint/blob/'+REV+'/'
H=lambda x:hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
B=lambda x:hashlib.sha256(x).hexdigest()
def emit(name,x):
 (OUT/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def elements(p):return {e.tag+'/'+e.get('name'):e for e in ET.parse(p).getroot() if e.get('name')}
def val(e):return ''.join(e.itertext()) if e.tag=='string' else {c.get('quantity'):''.join(c.itertext()) for c in e}
enel=elements(ROOT/SOURCE);zhel=elements(ROOT/TARGET);en={k:val(v) for k,v in enel.items()};zh={k:val(v) for k,v in zhel.items()}
rows=json.loads((OUT/'pairs-consumers.json').read_text());manifest=json.loads((ROOT/MANIFEST).read_text())
assert [(r['tier'],r['key']) for r in rows]==[(t['id'],k) for t in manifest['tiers'] if t['id'] in ('P0','P1') for k in t['keys']]
assert all(r['en']==en[r['key']] and r['zh_CN']==zh[r['key']] for r in rows)
old=json.loads(Path('/tmp/an-all-language-reviews/all-language-review-union.json').read_text())
prior=[]
for p in old['receipts']:
 if p['tag']!='zh-CN':continue
 k=p['key']; prior.append({**p,'current_complete_english_value':en[k],'current_complete_localized_value':zh[k], 'recomputed_english_sha256':H(en[k]),'recomputed_localized_sha256':H(zh[k]),'exact_english_match':H(en[k])==p['current_english_sha256'],'exact_localized_match':H(zh[k])==p['current_localized_sha256'],'in_priority_batch':k in {x['key'] for x in rows},'original_scope_and_limits_retained':True})
assert len(prior)==22 and all(p['exact_english_match'] and p['exact_localized_match'] for p in prior)
original_receipts=json.loads(Path('/tmp/an-current-ledger-audit/original/entry-review-receipts.json').read_text())
p=next(p for p in original_receipts['partial_reviews'] if p['tag']=='zh-CN' and p['key']=='string/save20_unsupported_image_colour')
k=p['key'];narrow={**p,'source_url':'https://github.com/c933103/AN-Paint/pull/86#issuecomment-6183064757','cohort_definition':original_receipts['cohorts'][p['cohort']],'current_complete_english_value':en[k],'current_complete_localized_value':zh[k],'exact_english_match':H(en[k])==p['reviewed_english_sha256'],'exact_localized_match':H(zh[k])==p['reviewed_localized_sha256'],'current_localized_utf8_sha256':B(zh[k].encode()),'not_complete_value_credit':True}
assert narrow['exact_english_match'] and narrow['exact_localized_match'] and narrow['current_localized_utf8_sha256']=='a7d09f85f10d7dd1edb233fdc8c8a216a92ed18d8dc98ca7d2c3ac5d388dd2e0'
emit('prior-complete-pairs-rebound.json',prior);emit('prior-colour-delta-only-receipt.json',narrow)
PAT=re.compile(r'%(?:\d+\$)?[-#+ 0,(<]*\d*(?:\.\d+)?[a-zA-Z]')
ledger=[]
for r in rows:
 i=r['number'];key=r['key'];change=fixes.get(i);candidate=change[0] if change else r['zh_CN'];refs=r['consumer_references'];alias=r['zh_CN'].startswith('@string/')
 resolved=zh[r['zh_CN'][1:]] if alias else r['zh_CN']
 candidate_resolved=zh[candidate[1:]] if candidate.startswith('@string/') else candidate
 current_seq=PAT.findall(resolved);source_seq=PAT.findall(r['en']);cand_seq=PAT.findall(candidate_resolved)
 assert source_seq==current_seq==cand_seq,(i,key,source_seq,current_seq,cand_seq)
 for c in refs:c['source_url']=URL+c['path']+'#L'+str(c['line'])
 ledger.append({**r,'locale':'zh-CN','decision':'propose_correction_or_refinement' if change else 'retain_current_wording','proposed_value':candidate,'rationale':change[3] if change else retain_notes[i],'issue_category':change[1] if change else None,'linguistic_severity':change[2] if change else None,'source_sha256_canonical_json':H(r['en']),'current_sha256_canonical_json':H(r['zh_CN']),'proposed_sha256_canonical_json':H(candidate),'current_sha256_utf8':B(r['zh_CN'].encode()),'proposed_sha256_utf8':B(candidate.encode()),'prior_complete_pair_exact_bound':key in {p['key'] for p in prior},'prior_partial_delta_only_exact_bound':key==narrow['key'],'consumer_scope':'static_production_references' if refs else 'source_only_no_literal_production_reference','alias_resolution':resolved if alias else None,'structural_checks':{'placeholder_sequences_match':True,'placeholder_sequence':source_seq,'current_literal_newlines':r['zh_CN'].count('\\n'),'proposed_literal_newlines':candidate.count('\\n'),'newline_change_explained':i==104 if r['zh_CN'].count('\\n')!=candidate.count('\\n') else None,'resource_attributes':dict(zhel[key].attrib)},'limits':['Independent AI linguistic and static-source review; not native-speaker sign-off.','No rendered UI, TalkBack, Android resource routing, runtime/device or behavioural verification.']+(['No literal current production reference found; this is not proof that the resource is unreachable, and no live composition is certified.'] if not refs else [])+(['Compact badge recognition and layout remain unverified.'] if i in (124,199) else [])})
assert len(ledger)==341 and len(set(r['key'] for r in ledger))==341
original=(ROOT/TARGET).read_text();candidate=original
for r in ledger:
 if r['decision']=='retain_current_wording':continue
 name=r['key'].split('/')[1];pattern=re.compile(r'(<string\b[^>]*\bname="'+re.escape(name)+r'"[^>]*>)(.*?)(</string>)',re.S);matches=list(pattern.finditer(candidate));assert len(matches)==1
 replacement=r['proposed_value'].replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
 candidate=pattern.sub(lambda m:m[1]+replacement+m[3],candidate)
cp=OUT/'candidate'/TARGET;cp.parent.mkdir(parents=True,exist_ok=True);cp.write_text(candidate)
new=elements(cp);assert set(new)==set(zhel)
changed=[]
for key,e in zhel.items():
 assert e.attrib==new[key].attrib
 if ET.tostring(e)!=ET.tostring(new[key]):changed.append(key)
assert set(changed)=={r['key'] for r in ledger if r['decision']!='retain_current_wording'}
assert all(val(new[r['key']])==r['proposed_value'] for r in ledger)
(OUT/'zh-CN-priority-candidate.patch').write_text(''.join(difflib.unified_diff(original.splitlines(keepends=True),candidate.splitlines(keepends=True),fromfile='a/'+TARGET,tofile='b/'+TARGET)))
emit('per-key-review.json',ledger);emit('proposals.json',[r for r in ledger if r['decision']!='retain_current_wording'])
with (OUT/'per-key-review.csv').open('w') as f:
 fields=['number','tier','key','decision','linguistic_severity','en','zh_CN','proposed_value','rationale','consumer_scope','prior_complete_pair_exact_bound','prior_partial_delta_only_exact_bound'];w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows({k:r[k] for k in fields} for r in ledger)
outside={'key':'string/ui_top','priority_tier':'P2','included_in_341':False,'source_value':en['string/ui_top'],'current_value':zh['string/ui_top'],'suggested_value':'上','rationale':'The crop-edge label says 顶层 (top layer), paired with the P1 Bottom defect. ImageCropDialog binds it to the top edge, not stacking order. 上 matches 左/右 and proposed 下. This is a separately recorded finding, not additional P0+P1 credit and not included in the 44-change patch.','consumer':{'path':'Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt','line':72,'source_url':URL+'Paintroid/src/main/java/org/catrobat/paintroid/classic/ImageCropDialog.kt#L72'},'source_sha256_canonical_json':H(en['string/ui_top']),'current_sha256_canonical_json':H(zh['string/ui_top']),'suggested_sha256_canonical_json':H('上'),'status':'candidate_finding_not_applied'}
emit('outside-batch-top-edge-finding.json',outside)
# Hash all actually indexed production files and core inputs. No source edits or builds.
paths=sorted({SOURCE,TARGET,MANIFEST,'AGENTS.md'}|{c['path'] for r in rows for c in r['consumer_references']})
bind=[]
for p in paths:
 b=(ROOT/p).read_bytes();git=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
 bind.append({'path':p,'bytes':len(b),'file_sha256':B(b),'git_blob_sha1':git,'source_url':URL+p})
head=subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip();tree=subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD^{tree}'],text=True).strip();assert tree==TREE
source_diff=subprocess.check_output(['git','-C',str(ROOT),'diff','--',*paths],text=True);assert not source_diff
emit('source-file-binding.json',{'reviewed_commit':REV,'reviewed_tree':TREE,'observed_local_head':head,'observed_local_tree':tree,'published_tree_verification':'Parent supplied verification that published commit 4355869e has this exact tree.','later_develop_limit':'Parent reports later ef46e8aa changes Fit/status code and not resources; this pass binds consumers only to the frozen b9b148d5 tree, not all later code.','files':bind})
summary={'locale':'zh-CN','review_type':'Independent AI linguistic and static consumer-context review','source_commit':REV,'source_tree':TREE,'catalogue_entries_present':len(zh),'reviewed_priority_entries':341,'reviewed_tiers':{'P0':92,'P1':249},'unchanged_retained':297,'proposed_changes':44,'proposal_tiers':dict(collections.Counter(r['tier'] for r in ledger if r['decision']!='retain_current_wording')),'proposal_linguistic_severity':dict(collections.Counter(r['linguistic_severity'] for r in ledger if r['decision']!='retain_current_wording')),'static_production_reference_found':sum(bool(r['consumer_references']) for r in ledger),'source_only_no_literal_production_reference':sum(not r['consumer_references'] for r in ledger),'prior_complete_pairs_rebound':22,'prior_complete_pair_overlap_with_priority_batch':1,'prior_complete_pairs_outside_priority_batch':21,'prior_partial_delta_only_pair_overlap_with_priority_batch':1,'priority_pairs_without_mapped_prior_complete_or_delta_evidence':339,'full_review_of_pairs_beyond_previous_complete_value_coverage':340,'entirely_new_341_claim':False,'prior_crop_preview_plural_is_P2_and_not_new_credit':True,'outside_priority_p2_findings':1,'whole_language_acceptance':False,'candidate_applied':False,'builds_gradle_apk_ci_runtime_device_release':False,'scope_limits':['Original PR2/reset obligations remain; no accepted historical full-341 zh-CN batch was assumed or reconstructed.','All 22 prior complete pairs match current English and Chinese values, retaining original confidence, limited-language, wording-only and context bounds.','The separate PR86 colour receipt is partial subject/agreement delta evidence and is not counted as complete-value acceptance. Its inherited terminology was not globally endorsed.','Of this batch, 1 pair had full bounded evidence, 1 had only partial evidence, and 339 had neither mapped form. Do not call all 341 wholly new.','The P2 crop-preview plural is one of the old 22 and receives no new priority credit.','297 retained values and 44 candidate corrections/refinements are distinct dispositions. Severity is linguistic impact, not a security rating; not all wording refinements imply unsafe current behaviour.','30 entries lack literal production references and are source-only; absence of a reference is not proof of unreachability.','No independent native-speaker, rendered-layout, TalkBack, locale-routing, runtime, device or release certification.','Only temporary review artifacts and an unapplied candidate were written; no production source edits, repository publication, builds or tests were run.']}
emit('summary.json',summary)
validation={'valid_source_and_candidate_xml':True,'manifest_matches_exact_341_order':True,'unique_review_keys':341,'unique_catalogue_keys':717,'per_key_human_authored_decision_or_rationale':341,'all_44_proposals_serialized_exactly':True,'all_source_current_candidate_placeholder_sequences_match':True,'resource_attributes_and_identities_preserved':True,'non_target_entries_unchanged':True,'plural_maps_unchanged':True,'aliases_unchanged':True,'literal_newline_changes':[{'key':'string/language20_translation_note','before':0,'after':2,'source':2,'reason':'Restore omitted source heading and paragraph separator.'}],'source_files_match_frozen_git_tree':True,'candidate_patch_changed_count':len(changed),'candidate_patch_keys':changed,'candidate_applied':False,'checks_are_static_artifact_checks_not_app_tests':True,'no_build_test_ci_runtime_release_work':True}
emit('validation.json',validation)
print(json.dumps(summary,ensure_ascii=False,indent=2))
