# Simplified Chinese P0 + P1 review, 21 October 2026

## Result

All 341 typed priority identities were read in full: 92 P0 and 249 P1. The independent AI linguistic/source-context pass retains 297 current values and proposes 44 corrections or refinements: 21 P0 and 23 P1. The patch is **unapplied**. This is not whole-language acceptance or native-speaker certification.

The two clearest content defects are:

- `language20_translation_note` claims that all translatable UI is included. The current English instead explains where translations are maintained and that new/untranslated text falls back to English. The proposal restores the complete message and heading/paragraph separation.
- `ui_bottom` says `底层` (bottom layer), but the crop dialog uses it for the bottom edge. The proposal is `下`, parallel to the existing `左` and `右` labels. Its paired Top resource says `顶层`; that is a separately recorded P2 finding, not part of the 341 batch or 44-change patch.

Other proposals clarify allocation versus configuration of memory, storage versus saving, an ungrammatical decoder-memory limit, save destinations, first-frame import/default-image semantics, gesture instructions, and Mainland Chinese technical terms. Examples include `帧`, `导入`, `等宽字体`, `矢量对象`, `位图`, `分配内存`, `存储空间`, `分辨率`, `剪贴板`, `颜色配置文件` and consistent `选区` naming. The two quality explanations are aligned with the actual `质量（%）` control.

Severity describes linguistic impact, not a security or runtime rating: 2 high, 21 medium, 21 low. Not all 44 proposals represent unsafe current behaviour; low-severity proposals include clarity and consistency refinements. Valid shared Chinese alternatives such as `开启`, `还原`, `目前`, `变更`, `图像`, `笔刷`, `重设`, `传回` and `裁减量` were not indiscriminately replaced. The established credit-record name `致谢信息` is retained in the three priority messages, without certifying license compliance or globally endorsing that term for attribution.

## Exact source binding and scope

- Published source commit: `4355869e2e198b5616419291cba225b018444fab`.
- Reviewed tree: `b9b148d5d8ef7c7b088500a9c177f9f59304b800`.
- Materialized checkout HEAD: `ddffe57016c689b2a7868c31e415dcb625f5c6b5`, with that exact tree.
- Catalogue: `Paintroid/src/main/res/values-zh-rCN/strings.xml`, 717 typed entries present.
- Manifest: `translations/string-importance.json`, exact ordered P0/P1 selection.
- 311 priority entries have literal static production references; 30 are explicitly source-only. The absence of a literal reference does not establish runtime unreachability.
- Parent-reported later develop `ef46e8aa` changes Fit/status code and not resources. This review binds consumers to the frozen tree above and does not recertify later consumer code.

The source code around animation branching, save/export/share, preservation/restoration, memory-limit explanations, crop-edge controls, colour accessibility descriptions, and language-note rendering was inspected. Static composition examples are included, but they are **illustrations, not Android execution or rendering tests**. Every ledger row includes exact English/current/proposed complete values, hashes, rationale, references, disposition and limits.

## Prior evidence is not new work

All 22 old complete-value pairs in the prior union were rebound to the current complete English and Chinese values. Their metadata, confidence and scope limitations are copied unchanged, including the limits for wording-only, limited-language and context-specific receipts.

- One of those 22 overlaps this priority batch: `ui_sampled_resize_memory_explanation`. Its old value remains exact-bound; this pass proposes Mainland terminology refinement without treating the old receipt as a broad glossary endorsement.
- The other 21 are outside P0/P1. They include the already-reviewed complete `ui_crop_preview_images` plural map. That plural receives **no new priority credit**.
- The separate PR86 `save20_unsupported_image_colour` receipt is explicitly **partial subject/agreement-delta evidence**, not complete-value acceptance. Its current raw UTF-8 target SHA-256 is `a7d09f85f10d7dd1edb233fdc8c8a216a92ed18d8dc98ca7d2c3ac5d388dd2e0`; the complete-value JSON hash also matches. The inherited `色彩描述档` term was not globally endorsed.
- Consequently, the 341 reviewed rows comprise 1 prior complete-value pair, 1 prior delta-only pair and 339 with neither mapped form of prior evidence. This is 340 complete-value reviews beyond previous complete-value coverage, **not 341 wholly new reviews**.

The PR2/reset obligations remain. No accepted historical full-341 zh-CN batch was assumed or reconstructed. Presence of all 717 resources is not proof of full review or translation correctness.

## Files

- `per-key-review.json` and `.csv`: full 341-row ledger.
- `proposals.json`: exact source/current/proposed values for all 44 proposals, with reasons and contexts.
- `zh-CN-priority-candidate.patch`: bounded 44-entry candidate diff.
- `candidate/.../values-zh-rCN/strings.xml`: full candidate catalogue, for inspection only.
- `outside-batch-top-edge-finding.json`: separate P2 Top finding; no edit or new batch credit.
- `pairs-consumers.json` and `contexts-*.txt`: complete reviewed pairs and indexed production references.
- `static-composition-examples.json`: illustrative current/proposed compositions from real consumer argument roles.
- `prior-complete-pairs-rebound.json`: all 22 exact old pairs and original receipt scope.
- `prior-colour-delta-only-receipt.json`: exact narrow PR86 evidence and its explicit limits.
- `source-file-binding.json`: source file hashes and immutable source links.
- `summary.json`, `validation.json`, `SHA256SUMS.json`: counts, artifact checks and hashes.
- `extract.py`, `review_decisions.py`, `package_review.py`: reproducible extraction/packaging and all human-readable review decisions. These do not edit the production tree.

## Validation and remaining limits

Static artifact checks confirm valid candidate XML; exactly the intended 44 changed resources; unchanged identity/attribute inventory, aliases, plural maps and all other entries; source/current/candidate format-argument sequences match; candidate values equal the ledger; all 341 rows have explicit authored decisions; and inspected source files remain identical to the frozen Git tree. The language note deliberately gains two literal `\n` escapes to match the source paragraph separation.

No production source changes, builds, Gradle, APK, CI, test suite, runtime/device, publication or release actions were performed. No visual layout, TalkBack, locale routing, compact FG/BG badge recognition or legal adequacy is certified. Candidate integration, independent acceptance and any subsequent verification remain separate work.

## Source links

- [Frozen source](https://github.com/c933103/AN-Paint/tree/4355869e2e198b5616419291cba225b018444fab)
- [zh-CN catalogue](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/Paintroid/src/main/res/values-zh-rCN/strings.xml)
- [Priority manifest](https://github.com/c933103/AN-Paint/blob/4355869e2e198b5616419291cba225b018444fab/translations/string-importance.json)
- [Narrow PR86 handoff](https://github.com/c933103/AN-Paint/pull/86#issuecomment-6183064757)
