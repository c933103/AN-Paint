from pathlib import Path
import xml.etree.ElementTree as E,json,re,hashlib,subprocess
r=Path('/workspace/scratch/bbca2890f602/translation-current-integration-20261021/source');o=Path(__file__).parent

def vals(p):
 return {x.tag+'/'+x.get('name'): (''.join(x.itertext()) if x.tag=='string' else {y.get('quantity'):''.join(y.itertext()) for y in x}) for x in E.parse(p).getroot() if x.get('name')}
e=vals(r/'Paintroid/src/main/res/values/strings.xml');z=vals(r/'Paintroid/src/main/res/values-zh-rCN/strings.xml');m=json.load(open(r/'translations/string-importance.json'))
keys=[(t['id'],k) for t in m['tiers'] if t['id'] in ['P0','P1'] for k in t['keys']]
refs={k:[] for t,k in keys}
for f in sorted((r/'Paintroid/src/main').rglob('*')):
 if f.suffix not in ('.kt','.java','.xml') or '/res/values' in str(f):continue
 for n,l in enumerate(f.read_text().splitlines(),1):
  for a,b,c,d in re.findall(r'R\.(string|plurals)\.([A-Za-z0-9_]+)|@(string|plurals)/([A-Za-z0-9_]+)',l):
   key=(a or c)+'/'+(b or d)
   if key in refs:refs[key].append({'path':str(f.relative_to(r)),'line':n,'excerpt':l.strip()})
rows=[{'number':i+1,'tier':t,'key':k,'en':e[k],'zh_CN':z[k],'consumer_references':refs[k]} for i,(t,k) in enumerate(keys)]
(o/'pairs-consumers.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
for start,end in [(1,92),(93,170),(171,260),(261,341)]:
 out=[]
 for x in rows[start-1:end]:
  out += [f"{x['number']} [{x['tier']}] {x['key']}",'EN: '+str(x['en']),'ZH: '+str(x['zh_CN'])]+[f"  {c['path']}:{c['line']} {c['excerpt']}" for c in x['consumer_references']]+['']
 (o/f'contexts-{start}-{end}.txt').write_text('\n'.join(out)+'\n')
print('priority',len(rows),'catalogue',len(z),'consumers',sum(bool(x['consumer_references']) for x in rows))
