# Swahili P0 + P1 linguistic review

## Result and limits

All **341 typed identities (92 P0 + 249 P1)** received complete-value linguistic review and individual source-context dispositions. The ledger contains the full English/current Swahili/candidate values, source lines, exact hashes, consumer excerpts, rationale, confidence and limits for every entry. This is model-based linguistic review, **not native-human or runtime certification**.

- **323 current priority entries retained within bounded scope**: 294 static-context judgments, 27 wording-only judgments, one exact prior complete-value receipt, and one current full-value judgment with an older narrow-delta receipt.
- **14 priority wording corrections proposed**, unapplied. They include semantic errors, grammar repairs and explicitly identified clarity refinements, not fourteen equally severe proven runtime defects.
- **3 attribution-terminology holds**, plus **1 unknown-composition context hold**.
- **5 optional editorial refinements** are separate from the core candidate and do not inflate the correction count.

Applying the core candidate exactly would give **337 model-reviewed priority dispositions and four remaining holds**. That is not independent acceptance, whole-language completion or a lifted localization-reset gate.

## Core findings

1. `language20_translation_note` currently claims the edition contains all translatable interface text. It omits the source's maintenance explanation and English fallback. The candidate restores the actual source contract, including its heading and paragraph break.
2. `save20_destination_error` describes changing the storage location, while its four codec emitters fail when replacing the destination with the completed encoded file. The candidate says the completed image could not replace the target file.
3. `ui_cannot_create_the_undo_cache_free_some_device` says to erase/delete space. The candidate requests making space on device storage and retrying, without inventing files to delete.
4. `ui_too_large_for_the_current_budget_reduce_the` says to open memory. The candidate requests freeing space in memory, distinct from device storage.
5. `save20_gif_description` combines plural GIFs with singular possessive agreement. The candidate uses “each animated GIF” and its first frame.
6. `ui_collapse_tool_category` and `ui_expand_tool_category` fix `imechaguliwa` after tool names from different noun classes. Actual supplied labels include `Mstari` and `Maandishi`. Both candidates make `zana iliyochaguliwa` the explicit grammatical anchor and retain both slots and the appropriate action.
7. `colour_invalid_metadata` and `ui_this_file_is_not_a_supported_image_use` use “not in use/in use” wording for unsupported/supported. The candidate uses `-auniwa`, consistent with the existing bounded-reviewed unsupported-URL message and narrowly corroborated by an official Epson Swahili manual.
8. `ui_swap23` and the source-only `ui_swap_foreground_background` use a generic “change” verb. The candidate explicitly exchanges colour positions, matching the actual foreground/background swap implementation for the active button.
9. `formats22_derived_exported` has an ambiguous antecedent for “replace it.” Its source-only candidate names the full drawing explicitly. This is not a demonstrated live-flow failure.
10. `ui_keeps_pixels_at_the_top_left_smaller_canvas` clarifies top-left anchoring instead of suggesting that only top-left pixels are kept, while preserving right/bottom loss and the exact `Tengua` undo action.
11. `colour_truncated_metadata` clarifies that the image file is truncated inside colour metadata. The source consumer detects premature EOF; the candidate does not invent the cause.

All fourteen exact before/after values are in `proposed-corrections.json` and the core patch. Two proposals are source-only (`formats22_derived_exported`, `ui_swap_foreground_background`); the other twelve have inspected direct production consumers.

## Remaining holds

The three attribution-term holds are:

- `gallery_credit_could_not_save`
- `gallery_credit_too_large`
- `legacy_credits_unreadable`

Their save/read/retention facts were reviewed, but `sifa` can denote qualities or praise rather than image attribution text. A competent Swahili reviewer should settle the product's attribution terminology across the linked UI. These are **uncertainty holds, not confirmed failures**. The candidate does not silently replace a cross-catalogue term. The conditional/future phrasing in `gallery_credit_too_large` should be considered with that review.

`ui_foreground_background_colour_palette` retains all three slots. No direct production caller or actual third-slot domain was found, so the composed idiom of `Paleti ya rangi %3$s` remains unknown. No hypothetical runtime failure or replacement is invented.

Other technical terms, including buffers, dithering, tolerance and compact foreground/background abbreviations, retain explicit confidence limits. Retention is not a claim of native idiom.

## Context actually inspected

An independent scan confirmed **311 keys with exact direct production references and 30 without**. It matched the supplied context index, then tied every cited source file to this exact tree and file hash. No-direct-reference is not proof that indirect or dynamic use is impossible.

Inspected compositions and consequences include:

- Exact and lower-bound animation frame counts, first-frame versus separate PNG poster import, and loss of animation on save.
- Completed codec output versus destination replacement, save versus derived export, unchanged Save destinations, and save-success/sharing-failure separation.
- Recovery reason concatenation, retained copies versus failed preservation, paused autosave, exact menu paths, ZIP export and `canvas.png` extraction.
- Top-left non-stretch draw at `(0,0)`, right/bottom loss and undo wording.
- Selected-tool announcements with actual tool/category combinations, not invented placeholder domains.
- Colour hex strings whose `#` is supplied either by the caller or the template.
- Crop-edge labels with both unit templates; the Swahili `Ukataji wa ... kwa ...` compositions do not require the Filipino template changes.
- Numeric dimension/unit ordering, memory estimate suffixes, original-file preservation, and navigation labels used in paste/recovery instructions.

`static-composition-examples.json` contains illustrative literal substitutions, **not Java/Android formatter or UI tests**. Unchanged P2 dependencies were inspected only as immediate context for priority keys, not counted as a full P2 batch.

## Prior evidence reconciled without scope inflation

All **21 supplied prior bounded complete-value pairs** still match both current English and Swahili JSON-value hashes. One overlaps this batch: `ui_sampled_resize_memory_explanation`. The twenty others remain outside the priority tally. Original and later receipts and caveats are carried where available.

Separately, the exact [PR #86 narrow receipt](https://github.com/c933103/AN-Paint/pull/86#issuecomment-6183064757) was retrieved and its Swahili target matched to raw UTF-8 SHA-256 `83c6d7e46973860f4487bd1adca4b9637039b26f10bf654a94000d24a293c863`.

Its original high confidence concerns the format-neutral `Picha hii` delta and associated agreement/temporal constraints, **not inherited technical idiom, a complete Swahili batch or native review**. The present ledger separately records a full-current-value model review of this priority entry. Thus there are 22 unique prior-evidence identities, but not 22 prior whole-value acceptances and not 341 entirely new pairs.

The current 717-entry catalogue partition is:

- **343 bounded current dispositions**: 323 priority + 20 non-overlapping prior complete pairs.
- **18 known pending/hold entries**: 14 proposed corrections + four unresolved holds.
- **356 present outside mapped review coverage**.
- **0 missing**.

This reconciles the supplied evidence rather than asserting that no other historical review exists. PR #4's reset and repository-wide withdrawal of earlier completion claims are not lifted.

## Exact source binding

- Reviewed tree: `b9b148d5d8ef7c7b088500a9c177f9f59304b800`.
- Observed local HEAD: `ddffe57016c689b2a7868c31e415dcb625f5c6b5`; its tree matches exactly.
- English: `Paintroid/src/main/res/values/strings.xml`.
- Swahili: `Paintroid/src/main/res/values-sw/strings.xml`.
- Manifest: `translations/string-importance.json`.
- The source worktree was clean before and after review; no production file was modified.

The parent identifies this tree as published `4355869e` content and reports later `ef46e8aa` Fit/status-only changes without resource changes. Those remote commits were not independently fetched by this worker. The review is bound to the stated tree and hashes, not silently rebound to later consumers.

The ledger records both compact-JSON value hashes (the union-receipt convention) and raw UTF-8 value hashes (the PR #86 convention). Values are XML-decoded stored text; Android backslash escapes remain literal. No Unicode normalization or trailing newline is added to value hashes. Three non-translatable English constants are not falsely counted as missing Swahili entries.

## Optional refinements

Five separate suggestions cover ASCII light/dark glyph wording, the Save ellipsis, an explicit pixel-count label, and two write-to-location formulations. The current meanings remain understandable; these are optional clarity/idiom improvements, not additional confirmed errors or hold resolutions.

`swahili-optional-refinements.patch` targets the original source. If the core patch is already applied, use `swahili-optional-after-core.patch` instead. Do not apply both optional patches.

## Verification

Completed mechanical artifact checks:

- Exact manifest reconciliation: 341 unique priority keys, 92 P0 and 249 P1.
- All 341 complete values and individual rationales present.
- Independent production-reference scan: 311 direct, 30 source-only.
- 717 catalogue identities retained; all attributes and priority placeholder signatures preserved.
- XML parse and exactly fourteen core value changes.
- All 21 prior pair hashes and the separate PR #86 raw target hash matched.
- Core, optional and combined patch dry-runs and exact application in disposable artifact copies only.
- Original source catalogue/manifest hashes unchanged and source worktree clean.

Not run: builds, Gradle, compilation, APK generation, CI, runtime, device/emulator, installed UI, TalkBack, font/layout checks, native-human review, publication or release. The candidate has not been independently accepted. Mechanical checks establish artifact integrity, not language correctness.

## Files

- `swahili-p0-p1-review.json` / `.csv`: authoritative full ledger.
- `proposed-corrections.json` and `swahili-priority-candidate.patch`: fourteen exact proposals.
- `candidate/Paintroid/src/main/res/values-sw/strings.xml`: complete separate candidate catalogue.
- `prior-21-exact-pairs.json`: all prior bounded complete-value evidence with limits.
- `pr86-narrow-receipt.json`: recovered Swahili-only row, original scope and current binding.
- `optional-refinements.json` and the two alternative optional patches.
- `independent-consumer-scan.json`, `source-bindings.json`, `static-composition-examples.json` and `validation.json`.
- `review-notes.txt`: 341 individually authored rationales.
- `references.json`: narrow external-reference use and its limits. The [Mozilla Swahili guide](https://mozilla-l10n.github.io/styleguides/sw/) informed general concise/consistent UI principles; it is not approval of these translations.
