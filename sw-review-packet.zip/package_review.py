import collections,csv,difflib,hashlib,json,pathlib,re,shutil,subprocess,xml.etree.ElementTree as ET,zipfile
O=pathlib.Path(__file__).resolve().parent
R=O.parent/'translation-current-integration-20261021/source'
SRC='Paintroid/src/main/res/values/strings.xml';LOC='Paintroid/src/main/res/values-sw/strings.xml';MAN='translations/string-importance.json'
TREE='b9b148d5d8ef7c7b088500a9c177f9f59304b800'
HEAD=subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip()
assert subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD^{tree}'],text=True).strip()==TREE
assert subprocess.check_output(['git','-C',str(R),'status','--porcelain'],text=True)==''
def h(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def utfh(v):return hashlib.sha256(v.encode()).hexdigest()
def fh(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):(O/p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def vals(p):
 d={}
 for e in ET.parse(p).getroot():
  if e.attrib.get('translatable')=='false':continue
  if e.tag=='string':d['string/'+e.attrib['name']]=''.join(e.itertext())
  elif e.tag=='plurals':d['plurals/'+e.attrib['name']]={c.attrib['quantity']:''.join(c.itertext()) for c in e}
 return d
en=vals(R/SRC);sw=vals(R/LOC);source_hashes={p:fh(R/p) for p in [SRC,LOC,MAN]}
manifest=json.loads((R/MAN).read_text());tiers={k:t['id'] for t in manifest['tiers'] for k in t['keys']}
rows=json.loads((O/'pairs-consumers.json').read_text());priority={x['key'] for x in rows}
assert priority=={k for k,t in tiers.items() if t in ('P0','P1')} and len(priority)==341
notes={int(i):v for i,v in (line.split('|',1) for line in (O/'review-notes.txt').read_text().splitlines())};assert set(notes)==set(range(1,342))
changes={
 'string/formats22_derived_exported':'%1$s imehamishwa. Mchoro wako kamili bado una mabadiliko ambayo hayajahifadhiwa; hifadhi nakala ya picha kamili kabla ya kubadilisha mchoro huo.',
 'string/save20_destination_error':'Picha iliyokamilika haikuweza kuchukua nafasi ya faili lengwa.',
 'string/save20_gif_description':'Picha tuli, hadi rangi 256. Dithering hulainisha mipito ya rangi. Kila GIF iliyohuishwa hufunguliwa kama fremu yake ya kwanza.',
 'string/ui_cannot_create_the_undo_cache_free_some_device':'Imeshindikana kuunda akiba ya kutengua. Tengeneza nafasi kwenye hifadhi ya kifaa, kisha ujaribu tena.',
 'string/ui_keeps_pixels_at_the_top_left_smaller_canvas':'Huweka picha kwenye kona ya juu kushoto. Kupunguza vipimo vya turubai huondoa pikseli zilizo nje ya ukingo wa kulia au wa chini; Tengua huzirejesha.',
 'string/colour_invalid_metadata':'Picha ina metadata ya rangi isiyo halali au isiyoauniwa.',
 'string/colour_truncated_metadata':'Faili ya picha imekatika katikati ya metadata yake ya rangi.',
 'string/language20_translation_note':'Lugha ya programu\\n\\nTafsiri hutunzwa katika rasilimali za lugha za AN Paint. Maandishi mapya au ambayo hayajatafsiriwa huonekana kwa Kiingereza.',
 'string/ui_collapse_tool_category':'%1$s: zana iliyochaguliwa ni %2$s. Kunja zana na chaguo',
 'string/ui_expand_tool_category':'%1$s: zana iliyochaguliwa ni %2$s. Panua zana na chaguo',
 'string/ui_swap23':'Badilisha nafasi za rangi',
 'string/ui_swap_foreground_background':'Badilisha nafasi za rangi ya mbele na ya mandharinyuma',
 'string/ui_this_file_is_not_a_supported_image_use':'Faili hii si picha inayoauniwa. Tumia PNG, JPEG, JPEG XL, WebP, HEIC, AVIF, BMP, GIF, DIB, TIFF, ICO, PDF au maandishi ya picha ya Base64.',
 'string/ui_too_large_for_the_current_budget_reduce_the':'Kubwa mno kwa kikomo cha sasa. Punguza vipimo au ghairi na utengeneze nafasi kwenye kumbukumbu.'
}
assert len(changes)==14 and set(changes)<=priority
optional={
 'string/formats22_ascii_description':('Huandika maandishi ya kawaida kwa herufi zinazowakilisha sehemu zenye mwanga na zenye giza. Yaangalie kwa fonti ya upana sawa. Huu ni uwakilishi wa kuona; hauwezi kufunguliwa tena kama picha asili.','Clarity proposal for the current uneven light-weight/black pair; represents tonal areas through characters. Medium confidence in technical idiom; keep separate from confirmed semantic corrections.'),
 'string/ui_save_a5d0d9':('Hifadhi…','Restore the source ellipsis rather than resolving to the plain Save alias. Current action meaning is already correct.'),
 'string/ui_d_d_px_d_pixels_2f_mp':('%1$d × %2$d px · Idadi ya pikseli: %3$,d (%4$.2f MP)','Restore the explicit pixel-count label. Current dimensions, count and MP already survive; this is clarity, not a missing numeric fact.'),
 'string/ui_the_selected_location_is_not_writable':('Haiwezekani kuandika kwenye eneo lililochaguliwa.','Idiomatic write-to-location expression; the current passive is already understandable in the output-stream context.'),
 'string/ui_this_location_is_not_writable':('Haiwezekani kuandika kwenye eneo hili.','Use the same write-to-location expression for source and recovery export. The current diagnostic does not misidentify the failed operation.')
}
credit_holds={'string/gallery_credit_could_not_save','string/gallery_credit_too_large','string/legacy_credits_unreadable'}
context_holds={'string/ui_foreground_background_colour_palette'}
holds=credit_holds|context_holds
union=json.loads(pathlib.Path('/tmp/an-all-language-reviews/all-language-review-union.json').read_text())
prior={x['key']:x for x in union['receipts'] if x['tag']=='sw'};assert len(prior)==21
ap=pathlib.Path('/tmp/an-current-ledger-audit/audit.json')
audit=json.loads(ap.read_text()) if ap.exists() else {'receipts':[]};orig={x['key']:x for x in audit['receipts'] if x['tag']=='sw'}
later={};carried=[]
for k,v in prior.items():
 assert h(en[k])==v['current_english_sha256'] and h(sw[k])==v['current_localized_sha256'],k
 lr=[]
 for ref in v.get('later_evidence',[]):
  if ref['file'] not in later:later[ref['file']]=json.loads((pathlib.Path('/tmp/an-all-language-reviews')/ref['file']).read_text())['receipts']
  receipt=later[ref['file']][ref['index']];assert receipt['tag']=='sw' and receipt['key']==k;lr.append(receipt)
 carried.append({'tag':'sw','key':k,'in_priority_batch':k in priority,'english':en[k],'swahili':sw[k],'english_sha256':h(en[k]),'swahili_sha256':h(sw[k]),'exact_current_pair':True,'scope_policy':'Carry original bounded complete-value evidence with all confidence/context limits. Exact hashes do not recertify consumer changes, native idiom, UI or whole catalogue.','union_receipt':v,'original_receipt':orig.get(k),'later_receipts':lr})
write('prior-21-exact-pairs.json',carried)
receipt=json.loads((O/'pr86-narrow-receipt.json').read_text());nrow=receipt['row'];nk='string/save20_unsupported_image_colour'
assert sw[nk]==nrow['new_value'] and utfh(sw[nk])==nrow['new_utf8_sha256']=='83c6d7e46973860f4487bd1adca4b9637039b26f10bf654a94000d24a293c863'
header=receipt.get('scope_header',receipt.get('body','').split('<details>')[0])
receipt={'url':receipt['url'],'source_head':'1cdddec794d1a408af7fa97f134de4784837a14b','scope_header':header,'row':nrow,'current_pair':{'key':nk,'english':en[nk],'swahili':sw[nk],'current_english_json_sha256':h(en[nk]),'current_swahili_json_sha256':h(sw[nk]),'current_swahili_raw_utf8_sha256':utfh(sw[nk]),'exact_target_match':True},'scope_limit':'Original high confidence applies to changing the format-specific BMP/GIF subject to Picha hii and resulting agreement/temporal retention. Do not count as a prior full-341 batch or promote inherited technical idiom to native acceptance. The present worker separately reviewed the complete current value.'}
write('pr86-narrow-receipt.json',receipt)
# Independently reconstruct exact production references, not just trusting the prior language package.
scan=collections.defaultdict(list)
for p in sorted((R/'Paintroid/src/main').rglob('*')):
 if not p.is_file() or p.suffix not in ('.kt','.java','.xml') or '/res/values' in str(p):continue
 lines=p.read_text().splitlines()
 for n,line in enumerate(lines,1):
  for name in set(re.findall(r'\bR\.string\.([a-zA-Z_0-9]+)\b|@string/([a-zA-Z_0-9]+)\b',line)):
   k='string/'+next(x for x in name if x)
   if k in priority:
    a=max(1,n-3);b=min(len(lines),n+3)
    scan[k].append({'path':str(p.relative_to(R)),'line':n,'text':line.strip(),'context_start_line':a,'context_end_line':b,'context':'\n'.join(f'{i}: {lines[i-1]}' for i in range(a,b+1)),'source_tree':TREE,'source_file_sha256':fh(p)})
for r in rows:
 got={(x['path'],x['line']) for x in scan[r['key']]};supplied={(x['path'],x['line']) for x in r['consumers']};assert got==supplied,(r['key'],got^supplied)
assert sum(bool(scan[k]) for k in priority)==311
write('independent-consumer-scan.json',{'source_tree':TREE,'method':'Exact R.string and @string reference scan in production .kt/.java/.xml files, excluding translated values directories. No-direct-reference does not prove absence of indirect/dynamic use.','direct_keys':311,'no_direct_keys':30,'references':dict(scan)})
token=re.compile(r'%(?:\d+\$)?[-#+ 0,(<]*\d*(?:\.\d+)?[a-zA-Z%]')
def tok(v):return sorted(token.findall(v)) if isinstance(v,str) else {k:tok(x) for k,x in v.items()}
entries=[]
for row in rows:
 k=row['key'];assert en[k]==row['en'] and sw[k]==row['sw']
 if k in credit_holds:state='unresolved_credit_terminology_hold'
 elif k in context_holds:state='unresolved_composed_context_hold'
 elif k in changes:state='proposed_wording_correction'
 elif k in prior:state='carried_prior_exact_bounded'
 elif k==nk:state='reviewed_current_static_with_prior_narrow_delta'
 elif not scan[k]:state='reviewed_current_wording_only'
 else:state='reviewed_current_static'
 val=changes.get(k,sw[k]);entry={'index':row['index'],'tag':'sw','tier':row['tier'],'key':k,'english':en[k],'swahili':sw[k],'candidate':val,'english_json_sha256':h(en[k]),'swahili_json_sha256':h(sw[k]),'candidate_json_sha256':h(val),'english_raw_utf8_sha256':utfh(en[k]),'swahili_raw_utf8_sha256':utfh(sw[k]),'candidate_raw_utf8_sha256':utfh(val),'disposition':state,'candidate_disposition':'proposal_unapplied_model_reviewed_not_independently_accepted' if k in changes else state,'confidence':'medium' if k in changes or k in holds or len(en[k])>90 or row['index'] in [124,199,217,270,321] else 'medium-high','review_note':notes[row['index']],'context_scope':'static_direct_consumer' if scan[k] else 'wording_only_no_direct_consumer_found','consumers':scan[k],'placeholder_tokens_english':tok(en[k]),'placeholder_tokens_current':tok(sw[k]),'placeholder_tokens_candidate':tok(val),'prior_full_value_receipt_key':k if k in prior else None,'prior_narrow_delta_receipt':receipt['url'] if k==nk else None,'optional_refinement_available':k in optional,'native_human_reviewed':False,'runtime_verified':False}
 if sw[k].startswith('@string/'):
  target='string/'+sw[k][8:];entry['alias_resolution']={'target':target,'current_value':sw[target],'candidate_value':changes.get(target,sw[target]),'scope':'Static local alias resolution; Android resource system not executed.'}
 entry['english_source_line']=next(i for i,l in enumerate((R/SRC).read_text().splitlines(),1) if 'name=\"'+k.split('/')[1]+'\"' in l)
 entry['swahili_source_line']=next(i for i,l in enumerate((R/LOC).read_text().splitlines(),1) if 'name=\"'+k.split('/')[1]+'\"' in l)
 entries.append(entry)
bykey={x['key']:x for x in entries}
classification={7:'antecedent_clarity',13:'destination_replacement_semantics',17:'plural_agreement',34:'free_storage_semantics',56:'top_left_anchoring_clarity',94:'unsupported_not_unused',95:'truncated_file_diagnostic_clarity',104:'false_completeness_claim_and_missing_fallback',146:'dynamic_noun_class_agreement',195:'dynamic_noun_class_agreement',305:'swap_not_generic_change',306:'swap_not_generic_change',320:'supported_not_in_use',322:'free_memory_semantics'}
corrections=[]
for k,v in changes.items():
 x=bykey[k];corrections.append({'tag':'sw','key':k,'tier':tiers[k],'english':en[k],'before':sw[k],'after':v,'before_json_sha256':h(sw[k]),'after_json_sha256':h(v),'before_raw_utf8_sha256':utfh(sw[k]),'after_raw_utf8_sha256':utfh(v),'reason':x['review_note'],'classification':classification[x['index']],'context_scope':x['context_scope'],'consumers':x['consumers'],'status':'proposed_unapplied_not_independently_approved','native_fluency_claim':False})
write('proposed-corrections.json',corrections)
opt=[]
for k,(v,reason) in optional.items():
 opt.append({'tag':'sw','key':k,'tier':tiers[k],'english':en[k],'before':sw[k],'after':v,'before_json_sha256':h(sw[k]),'after_json_sha256':h(v),'reason':reason,'classification':'optional_editorial_not_confirmed_error','status':'not_in_core_candidate_patch','current_disposition_unchanged':True})
write('optional-refinements.json',opt)
raw=(R/LOC).read_text()
def replace(raw,edits):
 out=raw
 for k,v in edits.items():
  name=k.split('/')[1];pattern=re.compile(r'(<string\s+name="'+re.escape(name)+r'"[^>]*>)(.*?)(</string>)',re.S);assert len(pattern.findall(out))==1
  escaped=v.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
  out,n=pattern.subn(lambda m:m[1]+escaped+m[3],out);assert n==1
 return out
candidate=replace(raw,changes);cp=O/'candidate'/LOC;cp.parent.mkdir(parents=True,exist_ok=True);cp.write_text(candidate)
patch=''.join(difflib.unified_diff(raw.splitlines(keepends=True),candidate.splitlines(keepends=True),fromfile='a/'+LOC,tofile='b/'+LOC));(O/'swahili-priority-candidate.patch').write_text(patch)
optional_candidate=replace(raw,{k:v for k,(v,_) in optional.items()});(O/'swahili-optional-refinements.patch').write_text(''.join(difflib.unified_diff(raw.splitlines(keepends=True),optional_candidate.splitlines(keepends=True),fromfile='a/'+LOC,tofile='b/'+LOC)))
combined_candidate=replace(candidate,{k:v for k,(v,_) in optional.items()});(O/'swahili-optional-after-core.patch').write_text(''.join(difflib.unified_diff(candidate.splitlines(keepends=True),combined_candidate.splitlines(keepends=True),fromfile='a/'+LOC,tofile='b/'+LOC)))
cv=vals(cp);assert set(en)==set(sw)==set(cv) and len(sw)==717
assert {k for k in sw if sw[k]!=cv[k]}==set(changes)
for k in priority:assert tok(en[k])==tok(sw[k])==tok(cv[k]),k
for k,(v,_) in optional.items():assert tok(en[k])==tok(v),k
attributes=lambda p:{e.tag+'/'+e.attrib['name']:e.attrib for e in ET.parse(p).getroot() if e.tag in ['string','plurals']}
assert attributes(R/LOC)==attributes(cp)
assert all(fh(R/k)==v for k,v in source_hashes.items())
statecounts=dict(collections.Counter(x['disposition'] for x in entries));tiercounts=dict(collections.Counter(x['tier'] for x in entries))
retained=priority-set(changes)-holds;accepted=retained|set(prior);pending=set(changes)|holds;unknown=set(sw)-accepted-pending
summary={'priority_entries':341,'priority_tiers':tiercounts,'direct_consumer_keys':311,'no_direct_consumer_keys':30,'current_dispositions':statecounts,'current_priority_bounded_retained':len(retained),'priority_proposed_corrections':len(changes),'priority_terminology_holds':len(credit_holds),'priority_unknown_composition_holds':len(context_holds),'outside_priority_corrections':0,'core_candidate_xml_changes':14,'optional_refinements_not_counted_as_failures':len(optional),'prior_bounded_complete_pairs':21,'prior_complete_pairs_overlapping_priority':1,'prior_complete_pairs_outside_priority':20,'additional_prior_narrow_delta_receipts':1,'unique_prior_evidence_identities':22,'current_full_batch_not_entirely_new':True,'catalogue_current_partition':{'bounded_current':len(accepted),'known_pending_or_context_hold':len(pending),'present_review_unknown':len(unknown),'missing':len(set(en)-set(sw)),'total':len(sw)},'candidate_if_applied':{'priority_model_reviewed_dispositions':341-len(holds),'terminology_or_composition_holds':len(holds),'not_independent_acceptance_native_or_runtime_certification':True},'priority_keys_without_disposition':0}
assert len(accepted)+len(pending)+len(unknown)==717
identity={'exact_reviewed_tree':TREE,'observed_local_head':HEAD,'binding':'The local HEAD tree is the assigned b9b148d5 tree. Parent identifies it as published 4355869e content; that remote commit was not independently fetched by this worker.','parent_reported_later_develop':'ef46e8aa changes Fit/status only, not resources. Later consumers are not silently rebound to this review.','source_catalogue':SRC,'source_catalogue_sha256':source_hashes[SRC],'localized_catalogue':LOC,'localized_catalogue_sha256':source_hashes[LOC],'priority_manifest':MAN,'priority_manifest_sha256':source_hashes[MAN],'source_worktree_clean_before_and_after':True,'hash_conventions':{'json_sha256':'SHA-256 of UTF-8 compact JSON with ensure_ascii=False, sorted keys, no trailing newline. Same convention as union receipts.','raw_utf8_sha256':'SHA-256 of exact XML-decoded stored text UTF-8, without a trailing newline or Unicode normalization. Backslash-n Android escapes remain literal. PR86 uses this raw-text convention.'}}
limits=['Model-based full-value linguistic review plus static source inspection; not native-human, installed UI, TalkBack, font, layout or speech certification.','All 341 priority identities have dispositions. Retained is bounded linguistic judgment, not whole-language completion. Three attribution-term holds and one unknown composition hold remain.','No builds, Gradle, compilation, APK, CI, runtime/device runs, production edits, publication or release. Mechanical XML/hash/placeholder/patch checks concern artifact integrity only.','The 30 keys with no direct production consumer have source-only scope. Absence of an exact reference does not exclude indirect/dynamic use.','Fourteen corrections are proposed, not applied or independently accepted. Five optional refinements are separate and do not increase confirmed-defect counts.','The existing PR4/reset history is not lifted by this review. Prior exact pairs and the PR86 narrow delta keep their original scopes; all 341 are not claimed entirely new.','Technical idiom remains medium-confidence, notably attribution sifa, buffers vihifadhi, dithering, tolerance uvumilivu, and abbreviations M/NY. A competent Swahili reviewer is still desirable.']
write('swahili-p0-p1-review.json',{'schema_version':1,'language':'Swahili','tag':'sw','review_date_utc':'2026-10-21','review_kind':'full_341_key_model_linguistic_and_static_source_context_review','source_identity':identity,'summary':summary,'limitations':limits,'entries':entries,'unresolved_holds':[x for x in entries if x['key'] in holds],'prior_complete_pairs_file':'prior-21-exact-pairs.json','prior_narrow_delta_file':'pr86-narrow-receipt.json','optional_editorial_file':'optional-refinements.json'})
write('source-bindings.json',{'source_identity':identity,'entries':[{'key':x['key'],'tier':x['tier'],'english_json_sha256':x['english_json_sha256'],'swahili_json_sha256':x['swahili_json_sha256'],'candidate_json_sha256':x['candidate_json_sha256']} for x in entries]})
with (O/'swahili-p0-p1-review.csv').open('w') as f:
 keys=['index','tier','key','disposition','candidate_disposition','context_scope','english','swahili','candidate','review_note'];w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows({k:x[k] for k in keys} for x in entries)
# Illustrations only: not Java, Android, formatter, UI, or runtime tests.
examples=[]
def sub(template,args):
 for i,v in enumerate(args,1):template=template.replace('%'+str(i)+'$s',str(v)).replace('%'+str(i)+'$d',str(v))
 return template.replace('\\n','\n')
for edge in ['ui_left','ui_top','ui_right','ui_bottom']:
 for name in ['ui_trim_in_pixels','ui_trim_in_percent']:
  k='string/'+name;examples.append({'case':name+'_'+edge,'resource_dependencies':[k,'string/'+edge],'current':sub(sw[k],[sw['string/'+edge]]),'scope':'unchanged P2 template dependency inspected only to evaluate priority edge labels; not a full P2 review'})
for n in [2,10,21]:
 for exact in [True,False]:
  count=str(n) if exact else sub(sw['string/formats22_at_least_frames'],[n]);examples.append({'case':f'animation_{n}_{exact}','current':sub(sw['string/formats22_animation_message'],['GIF',count])+'\n\n'+sw['string/formats22_animation_still'],'scope':'exact/lower-bound count and still-image consequence illustration'})
for tool in ['ui_line','ui_text','ui_rectangle_select','ui_pencil']:
 for name in ['ui_collapse_tool_category','ui_expand_tool_category']:
  k='string/'+name;cat=sw['string/ui_category_selection'] if tool=='ui_rectangle_select' else sw['string/ui_drawing23'] if tool=='ui_pencil' else sw['string/ui_category_insert']
  examples.append({'case':name+'_'+tool,'args':[cat,sw['string/'+tool]],'current':sub(sw[k],[cat,sw['string/'+tool]]),'candidate':sub(changes[k],[cat,sw['string/'+tool]]),'source':'ToolCategoryButton.kt:14-27 actual listed tool/category combinations'})
for k in ['ui_a_separate_recovery_copy_has_been_kept_use','ui_autosave_is_paused_to_protect_that_draft_use']:
 examples.append({'case':k,'current':sub(sw['string/'+k],[sw['string/ui_the_previous_draft_needs_more_memory_to_reopen']]),'source':'EditorDraftRecovery.kt:36-45,84 reason concatenation'})
for k in ['ui_choose_a_smaller_size','ui_too_large_for_the_current_budget_reduce_the']:
 prefix=sub(sw['string/ui_estimated_memory_current_working_budget'],['120 MiB','100 MiB']) if k=='ui_choose_a_smaller_size' else sub(sw['string/ui_copy_decoded_image_at_this_size_estimated_loading'],['1000 × 1000 px','4 MiB','120 MiB'])
 examples.append({'case':k,'current':prefix+sw['string/'+k],'candidate':prefix+changes.get('string/'+k,sw['string/'+k]),'scope':'literal terminal-newline concatenation illustration, not runtime number-format validation'})
write('static-composition-examples.json',examples)
checks=[]
for label,patches,expected in [('core',['swahili-priority-candidate.patch'],candidate),('optional',['swahili-optional-refinements.patch'],optional_candidate),('combined',['swahili-priority-candidate.patch','swahili-optional-after-core.patch'],combined_candidate)]:
 td=O/('patch-'+label+'-check');dest=td/LOC;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(raw)
 for pf in patches:
  result=subprocess.run(['git','apply','--check',str(O/pf)],cwd=td,text=True,capture_output=True);assert result.returncode==0,(pf,result.stderr)
  result=subprocess.run(['git','apply',str(O/pf)],cwd=td,text=True,capture_output=True);assert result.returncode==0,(pf,result.stderr)
 assert dest.read_text()==expected,label
 checks.append({'kind':label,'dry_run_and_disposable_copy_apply':'passed','exact_content_match':True})
assert subprocess.check_output(['git','-C',str(R),'status','--porcelain'],text=True)==''
assert all(fh(R/k)==v for k,v in source_hashes.items())
write('validation.json',{'scope':'Mechanical artifact-integrity checks, not application tests or linguistic/native certification','manifest_exact_341':True,'tier_counts':tiercounts,'catalogue_identities':717,'candidate_changes':14,'xml_parse':'passed','resource_identities_and_attributes_preserved':True,'all_priority_placeholder_signatures_preserved':True,'independent_direct_reference_scan_matches_supplied_context':True,'direct_consumer_keys':311,'no_direct_consumer_keys':30,'prior_complete_pair_hash_matches':21,'pr86_raw_target_hash_matches':True,'patch_checks':checks,'source_unmodified':True,'not_run':['build','Gradle','compilation','APK','CI','runtime','device/emulator','TalkBack','native-human review','publication','release'],'hash_conventions':identity['hash_conventions']})
write('references.json',[{'title':'Mozilla Swahili localization style guide','url':'https://mozilla-l10n.github.io/styleguides/sw/','use':'General reference for concise, unambiguous contemporary UI phrasing, noun-class agreement and unchanged format acronyms. Does not validate this catalogue or its proposed strings.'},{'title':'Epson Swahili administrator guide','url':'https://download4.epson.biz/sec_pubs/l1455_series/admg/sw/manual.pdf?CNW=&EXE=SetupNavi&LGW=&OSV=&VER=&pageid=&tab=','use':'Primary vendor terminology example: isiyoauniwa for unsupported, found in IPsec troubleshooting. Narrow corroboration only; not graphics-UI or native-human approval.'},{'title':'PR86 scoped colour-profile translation handoff','url':receipt['url'],'use':'Exact recovered Swahili narrow-delta receipt, independently raw-hash-matched; scope limits retained.'}])
print(json.dumps(summary,ensure_ascii=False,indent=2))
