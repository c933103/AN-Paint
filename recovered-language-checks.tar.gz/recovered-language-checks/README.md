# Recovered terminal host checks, 20 October 2026

- Swedish PR142: source 42b8c1daffd1c731701a7a870b1bb8e6690ece04, tree edae62db26f5493f5dd9019aaf936858347668e2; normal/optimized 1,004 tests each, exit 0.
- Korean PR144: source 8b0faf2a598526621013b9f3fccfcf8102977442, tree 23e46f732abb4d1ccbca48e13c89eec19614a61b; normal/optimized 1,005 tests each, exit 0.
- Taiwan Chinese PR143: source 5773cf9271819bc605b24842771bab061617e2b1, tree ca17fda32079e0dccc6112c739680b65d59e1a8c; normal/optimized 1,008 tests each, exit 0.

Commands are CI.md's Python unittest discovery, normally with -v and separately with -O. Logs include deliberately failing instrumentation protocol fixtures; final unittest summaries and exit files classify the aggregate. No local JVM, Android lint, APK, installed-device or layout pass is claimed. Hosted exact-source results remain separate. Review artifacts are on the immutable evidence refs linked in the PR descriptions. No merge or release was performed by this recovery.
