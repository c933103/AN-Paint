"""Package an already authored linguistic rereview. No application files are edited or executed."""
import collections, csv, difflib, hashlib, json, pathlib, re, shutil, subprocess, xml.etree.ElementTree as ET
ROOT=pathlib.Path('/workspace/scratch/bbca2890f602/translation-current-integration-20261021/source')
OUT=pathlib.Path(__file__).resolve().parent
SRC='Paintroid/src/main/res/values/strings.xml'; LOC='Paintroid/src/main/res/values-b+ko+KR/strings.xml'
COMMIT='4355869e2e198b5616419291cba225b018444fab'; TREE='b9b148d5d8ef7c7b088500a9c177f9f59304b800'
PRIOR=pathlib.Path('/tmp/an-korean-priority-review/review.json'); UNION=pathlib.Path('/tmp/an-all-language-reviews')
INDEP=pathlib.Path('/tmp/an-independent-corrections/korean-independent-review.json')
def h(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def fh(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def values(p):
 d={}
 for e in ET.parse(p).getroot():
  if e.tag=='string':d['string/'+e.attrib['name']]=''.join(e.itertext())
  elif e.tag=='plurals':d['plurals/'+e.attrib['name']]={x.attrib['quantity']:''.join(x.itertext()) for x in e}
 return d
def resource_info(rel,key):
 p=ROOT/rel;name=key.split('/')[1]
 line=next(i for i,l in enumerate(p.read_text().splitlines(),1) if re.search(r'<(?:string|plurals)\s+name="'+re.escape(name)+'"',l))
 return {'path':rel,'line':line,'source_commit':COMMIT,'source_tree':TREE,'file_sha256':fh(p),'url':f'https://github.com/c933103/AN-Paint/blob/{COMMIT}/{rel}#L{line}'}
def source_info(rel):
 b=(ROOT/rel).read_bytes()
 return {'path':rel,'bytes':len(b),'file_sha256':hashlib.sha256(b).hexdigest(),'git_blob_sha1':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'source_commit':COMMIT,'url':f'https://github.com/c933103/AN-Paint/blob/{COMMIT}/{rel}'}
en=values(ROOT/SRC);ko=values(ROOT/LOC)
manifest=json.loads((ROOT/'translations/string-importance.json').read_text()); expected=[(t['id'],k) for t in manifest['tiers'] if t['id'] in ('P0','P1') for k in t['keys']]
rows=json.loads((OUT/'pairs-consumers.json').read_text()); assert [(r['tier'],r['key']) for r in rows]==expected
assert len(rows)==341 and len({r['key'] for r in rows})==341
assert collections.Counter(r['tier'] for r in rows)=={'P0':92,'P1':249}
notes={int(i):n for i,n in (l.split('\t',1) for l in (OUT/'current-rereview-notes.tsv').read_text().splitlines())};assert set(notes)==set(range(1,342))
old_report=json.loads(PRIOR.read_text());old={r['key']:r for r in old_report['entries']}
independent=json.loads(INDEP.read_text()); independent_by={r['key']:r for r in independent['receipts']}
fixture=json.loads((ROOT/'tools/fixtures/current_localization/korean_priority_current_wording.json').read_text())
for k,v in fixture['values'].items():assert en['string/'+k]==v['default'] and ko['string/'+k]==v['ko-KR']
holds={'string/'+k for k in fixture['retained_context_holds']};assert len(holds)==3
# No prior text is rewritten. Historical references are copied with their original status/limits.
shutil.copyfile(PRIOR,OUT/'historical-priority-review.json');shutil.copyfile(INDEP,OUT/'historical-independent-proposals.json')
# Independent direct-reference inventory, excluding translated catalogues and test sources.
refs=collections.defaultdict(list); names={r['key'].split('/')[1] for r in rows}
for p in (ROOT/'Paintroid/src/main').rglob('*'):
 if p.suffix not in ('.kt','.java','.xml') or p.parent.name.startswith('values'):continue
 lines=p.read_text().splitlines()
 for i,line in enumerate(lines,1):
  for name in set(re.findall(r'(?:R\.string\.|@string/)([A-Za-z0-9_]+)',line)):
   if name not in names:continue
   rel=str(p.relative_to(ROOT));refs[name].append({'path':rel,'line':i,'text':line.strip(),'snippet':'\n'.join(f'{j+1}: {lines[j]}' for j in range(max(0,i-5),min(len(lines),i+4))),'source_url':f'https://github.com/c933103/AN-Paint/blob/{COMMIT}/{rel}#L{i}'})
for r in rows:assert {(c['path'],c['line'],c['text']) for c in r['consumers']}=={(c['path'],c['line'],c['text']) for c in refs[r['key'].split('/')[1]]}
prior_union={r['key']:r for r in json.loads((UNION/'all-language-review-union.json').read_text())['receipts'] if r['tag']=='ko-KR'}
assert len(prior_union)==23
orig={r['key']:r for r in json.loads(pathlib.Path('/tmp/an-current-ledger-audit/audit.json').read_text())['receipts'] if r['tag']=='ko-KR'}
def historical_values(rel):
 text=subprocess.check_output(['git','show',old_report['summary']['source_revision']+':'+rel],cwd=ROOT,text=True)
 return {e.tag+'/'+e.attrib['name']:(''.join(e.itertext()) if e.tag=='string' else {c.attrib['quantity']:''.join(c.itertext()) for c in e}) for e in ET.fromstring(text) if e.tag in ('string','plurals')}
old_en=historical_values(SRC);old_ko=historical_values(LOC)
carried=[];cache={}
for k,r in prior_union.items():
 assert h(old_en[k])==r['current_english_sha256'] and h(old_ko[k])==r['current_localized_sha256'],k
 exact=h(en[k])==r['current_english_sha256'] and h(ko[k])==r['current_localized_sha256']
 later=[]
 for ptr in r['later_evidence']:
  if ptr['file'] not in cache:cache[ptr['file']]=json.loads((UNION/ptr['file']).read_text())['receipts']
  receipt=cache[ptr['file']][ptr['index']];assert receipt['tag']=='ko-KR' and receipt['key']==k;later.append(receipt)
 carried.append({'tag':'ko-KR','key':k,'in_priority_batch':k in old,'english':en[k],'korean':ko[k],'english_sha256':h(en[k]),'korean_sha256':h(ko[k]),'historically_bound_english':old_en[k],'historically_bound_korean':old_ko[k],'exact_current_pair':exact,'current_binding_state':'current_bound' if exact else 'stale_english_changed','current_credit':exact,'union_receipt':r,'original_receipt':orig.get(k),'later_receipts':later,'scope_policy':'Only the original exact-pair evidence, confidence and limits carry. No automatic changed-consumer, runtime, native-human or whole-language promotion.'})
dump(OUT/'prior-23-binding-reconciliation.json',carried)
assert sum(r['exact_current_pair'] for r in carried)==22
stale=[r for r in carried if not r['exact_current_pair']]
assert [r['key'] for r in stale]==['string/ui_add_up_to_20_images_with_android_s']
dump(OUT/'outside-priority-stale-help-finding.json',{'key':stale[0]['key'],'not_in_341_key_count':True,'tier':'outside_P0_P1','status':'stale_prior_source_pair_requires_rereview','current_english':en[stale[0]['key']],'current_korean':ko[stale[0]['key']],'reason':'English added a full Exact position paragraph allowing overlaps and scoped first-image origin and no-overlap wording to snapping. Korean retains the older unconditional overlap prohibition, omits the new Exact position paragraph and retains older unplacement language. The old bounded receipt no longer matches the complete current English/Korean pair.','full_new_translation_review_performed':False,'replacement_proposed':False,'source_binding':{'english':resource_info(SRC,stale[0]['key']),'korean':resource_info(LOC,stale[0]['key'])}})
placeholder=re.compile(r'%(?:\d+\$)?[-#+ 0,(<]*\d*(?:\.\d+)?[a-zA-Z%]')
optional={'string/ui_none':'모두 선택 해제'}
entries=[];reconciliation=[]
for row in rows:
 i=row['index'];k=row['key'];prior=old[k];assert row['en']==en[k] and row['ko']==ko[k] and prior['english']==en[k]
 proposed=prior['proposed_korean']; matched='prior_current_value' if ko[k]==prior['current_korean'] else 'prior_independently_accepted_proposal'
 if matched=='prior_independently_accepted_proposal':
  assert proposed==ko[k] and independent_by[k]['decision']=='accept_proposed' and independent_by[k]['accepted_wording']==ko[k]
  assert independent_by[k]['input_texts']['english']==en[k] and independent_by[k]['input_texts']['proposed']==ko[k]
  ip=prior['independent_proposal_review']; receipt_path=pathlib.Path(ip['receipt_path'])
  assert fh(receipt_path)==ip['receipt_file_sha256'] and json.loads(receipt_path.read_text())==independent_by[k]
 else:assert proposed is None or k in holds
 consumers=sorted(refs[k.split('/')[1]],key=lambda c:(c['path'],c['line']))
 disposition='context_hold' if k in holds else 'accepted_current_static' if consumers else 'accepted_current_wording_only'
 resolved=ko[k];alias=None
 if resolved.startswith('@string/'):
  alias='string/'+resolved[8:];resolved=ko[alias]
 assert collections.Counter(placeholder.findall(en[k]))==collections.Counter(placeholder.findall(resolved)),k
 candidate=optional.get(k,ko[k]);resolved_candidate=resolved if alias else candidate
 assert collections.Counter(placeholder.findall(en[k]))==collections.Counter(placeholder.findall(resolved_candidate)),k
 rec={'key':k,'prior_index':prior['index'],'prior_status':prior['status'],'english_exact':True,'current_korean_equals_prior_current':ko[k]==prior['current_korean'],'current_korean_equals_prior_proposal':proposed is not None and ko[k]==proposed,'matching_prior_text':matched,'original_context_scope':prior['context_scope'],'original_context_limit':prior['context_limit'],'original_independent_proposal_receipt':prior.get('independent_proposal_review'),'historical_receipt_file':'historical-priority-review.json','historical_receipt_index':prior['index'],'priority_current_disposition':disposition,'repeated_review_not_new_unique_credit':True}
 reconciliation.append(rec)
 item={'index':i,'locale':'ko-KR','tier':row['tier'],'key':k,'english':en[k],'korean':ko[k],'resolved_korean':resolved,'english_sha256':h(en[k]),'korean_sha256':h(ko[k]),'disposition':disposition,'current_wording_accepted':k not in holds,'confidence':'withheld_context' if k in holds else 'model_medium_high','rereview_note':notes[i],'prior_linguistic_rationale':prior['linguistic_rationale'],'prior_binding':rec,'consumers':consumers,'context_scope':'static_direct_consumer' if consumers else 'wording_only_no_direct_consumer_found','source_binding':{'english':resource_info(SRC,k),'korean':resource_info(LOC,k)},'placeholders':{'english':placeholder.findall(en[k]),'current_resolved':placeholder.findall(resolved),'candidate_resolved':placeholder.findall(resolved_candidate),'matching_types_and_positions':True},'escaped_newlines':{'english':en[k].count('\\n'),'korean':resolved.count('\\n')},'candidate':candidate,'candidate_status':'optional_single_reviewer_refinement_not_applied' if k in optional else 'unchanged','candidate_sha256':h(candidate),'runtime_verified':False,'native_human_reviewed':False,'whole_language_acceptance':False}
 if alias:item['alias_resolution']={'target_key':alias,'resolved_value':resolved,'limitation':'Static local XML alias resolution only; Android resource execution was not performed. Short Save button is retained, not expanded to match English ellipsis.'}
 entries.append(item)
dump(OUT/'prior-priority-reconciliation.json',{'historical_review_sha256':fh(PRIOR),'historical_independent_proposals_sha256':fh(INDEP),'historical_source_commit':old_report['summary']['source_revision'],'counts':dict(collections.Counter(r['matching_prior_text'] for r in reconciliation)),'entries':reconciliation})
# Full source-bound optional candidate, with production unchanged.
raw=(ROOT/LOC).read_text();candidate=raw
for k,v in optional.items():
 name=k.split('/')[1];pattern=re.compile(r'(<string\s+name="'+re.escape(name)+r'"[^>]*>)(.*?)(</string>)',re.S)
 candidate,n=pattern.subn(lambda m:m[1]+v+m[3],candidate);assert n==1
candpath=OUT/'candidate'/LOC;candpath.parent.mkdir(parents=True,exist_ok=True);candpath.write_text(candidate)
cv=values(candpath);assert set(cv)==set(ko) and {k for k in ko if cv[k]!=ko[k]}==set(optional)
patch=''.join(difflib.unified_diff(raw.splitlines(True),candidate.splitlines(True),fromfile='a/'+LOC,tofile='b/'+LOC))
(OUT/'korean-optional-action-label.patch').write_text(patch)
proposal={'key':'string/ui_none','tier':'P1','english':en['string/ui_none'],'current':ko['string/ui_none'],'proposed':optional['string/ui_none'],'kind':'optional_action_clarity_refinement','required_to_preserve_current_acceptance':False,'reason':'없음 is understandable beside 모두 and was previously accepted. The sole static consumer clears all crop-item checkboxes, so 모두 선택 해제 spells out the action and avoids reading the label as an empty-state report. This is not a confirmed mistranslation or data-loss defect.','consumer':next(e for e in entries if e['key']=='string/ui_none')['consumers'],'atomic_dependencies':[],'independent_review_of_new_proposal':False,'applied_to_production':False}
dump(OUT/'optional-refinement.json',proposal)
# Static compositions are illustrative substitutions, not Java/Android formatter execution.
examples=[]
def fmt(s,*args):
 def sub(m):
  token=m.group(0);idx=re.match(r'%(\d+)\$',token)
  if not idx:return token
  value=args[int(idx[1])-1]
  if token.endswith('s'):return str(value)
  if token.endswith('d'):return format(int(value),',d') if ',' in token else str(int(value))
  precision=re.search(r'\.(\d+)f$',token)
  return f'{float(value):.{precision[1]}f}' if precision else str(value)
 return placeholder.sub(sub,s).replace('\\n','\n')
def example(label,k,args,depends=(),note=''):
 examples.append({'label':label,'key':k,'arguments':list(args),'composed_korean':fmt(ko[k],*args),'context_dependencies':list(depends),'note':note,'method':'Illustrative static text substitution; not Android/JVM or speech execution.'})
for n in [2,10,21]:
 example(f'Exact animation count {n}','string/formats22_animation_message',['GIF',str(n)],['string/formats22_at_least_frames'])
 example(f'Lower-bound animation count {n}','string/formats22_animation_message',['PNG',fmt(ko['string/formats22_at_least_frames'],n)],['string/formats22_at_least_frames'])
for t in ['string/ui_width_in','string/ui_height_in']:
 for unit in ['string/ui_pixels_6ec9c2','string/ui_percent_fd8671']:example('Dimension unit',t,[ko[unit]],[unit])
for edge in ['ui_left','ui_right','ui_top','ui_bottom']:
 for template in ['ui_trim_in_pixels','ui_trim_in_percent']:example('Crop-edge hint','string/'+template,[ko['string/'+edge]],['string/'+edge])
for category,tool in [('ui_drawing23','ui_pencil'),('ui_category_selection','ui_rectangle_select'),('ui_category_insert','ui_line')]:
 for template in ['ui_expand_tool_category','ui_collapse_tool_category']:example('Tool category','string/'+template,[ko['string/'+category],ko['string/'+tool]],['string/'+category,'string/'+tool])
for template in ['ui_foreground_edit_colour','ui_background_edit_colour']:example('Colour value','string/'+template,['#12AB34'])
example('Colour swatch','string/ui_colour_tap_foreground_hold_background',['12AB34'])
example('Filename with consonant ending','string/ui_crop',['풍경.png'])
example('Filename without ending dependency','string/ui_saved',['산.png'])
example('Numeric field','string/ui_tap_to_type_a_number',[ko['string/ui_size_px'],24],['string/ui_size_px'])
example('Pixel dimensions','string/ui_d_d_px_d_pixels_2f_mp',[4000,3000,12000000,12.0])
example('Protected draft and recovery','string/ui_a_separate_recovery_copy_has_been_kept_use',[ko['string/ui_the_previous_draft_could_not_be_restored']],['string/ui_the_previous_draft_could_not_be_restored'])
example('Paused autosave and recovery','string/ui_autosave_is_paused_to_protect_that_draft_use',[ko['string/ui_the_previous_draft_needs_more_memory_to_reopen']],['string/ui_the_previous_draft_needs_more_memory_to_reopen'])
example('Memory constraint','string/ui_the_decoder_and_editing_buffers_need_about_the',['128.0 MiB','64.0 MiB'])
example('Generic edit detail','string/ui_could_not_complete_the_edit',[ko['string/ui_please_try_again']],['string/ui_please_try_again'])
example('Status composition','string/ui_px',[ko['string/ui_pencil'],'100%',4000,3000,ko['string/ui_draft_pending']],['string/ui_pencil','string/ui_draft_pending'])
depkeys={d for e in examples for d in e['context_dependencies']}|{'string/ui_width_in','string/ui_trim_in_pixels','string/ui_trim_in_percent','string/ui_estimated_memory_current_working_budget','string/ui_copy_decoded_image_at_this_size_estimated_loading','string/ui_fits_the_current_budget'}
dump(OUT/'static-composition-examples.json',{'scope':'Only composition evidence for the priority batch. Out-of-batch resource values are context, not added P2/P3 review coverage.','dependency_values':[{'key':k,'english':en[k],'korean':ko[k],'in_priority_batch':k in old} for k in sorted(depkeys)],'examples':examples})
source_paths=sorted({SRC,LOC,'translations/string-importance.json','tools/fixtures/current_localization/korean_priority_current_wording.json','tools/test_korean_priority_wording.py'}|{c['path'] for e in entries for c in e['consumers']})
source_files=[source_info(p) for p in source_paths]
changed_prior=[{'path':s['path'],'prior_sha256':s['file_sha256'],'current_sha256':fh(ROOT/s['path']),'same_bytes':s['file_sha256']==fh(ROOT/s['path'])} for s in old_report['source_files']]
consumer_delta_paths=[s['path'] for s in changed_prior if not s['same_bytes'] and s['path'].endswith(('.kt','.java'))]
diff=subprocess.run(['git','diff',old_report['summary']['source_revision'],'HEAD','--',*consumer_delta_paths],cwd=ROOT,text=True,capture_output=True,check=True).stdout
(OUT/'consumer-changes-since-prior.diff').write_text(diff)
dump(OUT/'source-file-binding.json',{'reviewed_commit':COMMIT,'reviewed_tree':TREE,'observed_local_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'observed_local_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=ROOT,text=True).strip(),'published_commit_tree_verification':'Parent verified GitHub commit 4355869e2e198b5616419291cba225b018444fab has exact tree b9b148d5d8ef7c7b088500a9c177f9f59304b800.','latest_develop_limit':'Parent reports later ef46e8aa/c96f9708 changes are six Fit/status code/test/doc paths and no resources. This review does not claim those later consumers were all reviewed.','files':source_files,'comparison_to_historical_review':changed_prior})
counts=dict(collections.Counter(e['disposition'] for e in entries));assert counts=={'accepted_current_static':311,'accepted_current_wording_only':27,'context_hold':3}
limits=['Model-based linguistic and static source-consumer rereview; not native-human certification.','No builds, Gradle, Android compilation, APKs, CI, runtime/device checks, installed UI, layout, font rendering or TalkBack were run.','No application source changes, publication, version changes, release, repository commits, branches, PRs or merges were performed.','All judgments bind to the complete English/Korean values and reviewed source tree; unchanged resources alone do not recertify later consumer changes.','Thirty keys have no direct source reference; twenty-seven receive only wording acceptance and three remain context holds. No indirect reachability impossibility is claimed.','The optional one-key candidate is not integrated and is not independently reviewed in this pass; it is not required to retain existing bounded acceptance.','No other Korean locale variant, P2/P3 catalogue, or whole language is certified.','Existing prior receipts keep their original confidence, context limitations and provenance. Unknown coverage is not a failed translation.','PR #56 is an intentional draft tracker and must not be merged.']
summary={'locale':'ko-KR','scope':'South Korean canonical catalogue only, excluding ko-Kore-KR mixed script, North Korean ko-KP and generic ko.','reviewed_commit':COMMIT,'reviewed_tree':TREE,'catalogue':LOC,'typed_priority_keys':341,'P0':92,'P1':249,'resource_types':{'string':341},'disposition_counts':counts,'priority_current_bounded_accepted':338,'required_corrections':0,'optional_refinement_proposals':1,'context_holds':sorted(holds),'direct_reference_count':sum(len(v) for v in refs.values()),'no_direct_consumer_keys':30,'prior_old_union_mapped_records':23,'prior_old_union_exact_pairs':22,'prior_old_union_stale_source_pairs':1,'prior_old_union_priority_overlap':1,'prior_old_union_outside_priority_mapped':22,'prior_old_union_outside_priority_exact':21,'historical_priority_status_counts':dict(collections.Counter(p['status'] for p in old.values())),'historical_priority_current_pairs_exact':331,'historical_independently_accepted_proposals_now_exact_in_source':10,'historical_accepted_pairs_retained':327,'historical_prior_current_pair_retained':1,'new_unique_review_claim':False,'old_union_plus_current_priority_unique_bounded_pairs':359,'additional_mapped_current_pairs_relative_to_old_union_exact_subset':337,'net_current_pair_increase_from_old_union_reported_23':336,'catalogue_typed_present':len(ko),'unmapped_outside_priority':354,'nonacceptance_context_holds_not_failures':3,'outside_priority_stale_pair_requires_rereview':1,'whole_language_acceptance':False,'native_human_reviewed':False,'runtime_verified':False,'limits':limits}
summary['dispositions_by_tier']={tier:dict(collections.Counter(e['disposition'] for e in entries if e['tier']==tier)) for tier in ('P0','P1')}
assert len(ko)==717 and 359+354+3+1==717
ledger={'schema':'an-paint-ko-KR-current-priority-rereview-v2','summary':summary,'value_hash_format':'SHA-256 of UTF-8 canonical JSON (ensure_ascii=false, sort_keys=true, compact separators); source Android escapes retained.','review_method':'Every complete current pair was read with its static consumers and per-key authored notes; historical evidence was then reconciled. Mechanical checks protect identity and transcription, not linguistic correctness.','historical_evidence_files':{'historical-priority-review.json':fh(OUT/'historical-priority-review.json'),'historical-independent-proposals.json':fh(OUT/'historical-independent-proposals.json')},'entries':entries}
dump(OUT/'korean-p0-p1-review.json',ledger);dump(OUT/'summary.json',summary)
with (OUT/'korean-p0-p1-review.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['index','tier','key','disposition','english','korean','candidate','candidate_status','rereview_note','context_scope']);w.writeheader();w.writerows({k:e[k] for k in w.fieldnames} for e in entries)
# Isolated patch check: never apply to production.
testroot=OUT/'patch-check'; target=testroot/LOC;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(raw)
check=subprocess.run(['git','apply','--check',str(OUT/'korean-optional-action-label.patch')],cwd=testroot,text=True,capture_output=True)
assert check.returncode==0,check.stderr
applied=subprocess.run(['git','apply',str(OUT/'korean-optional-action-label.patch')],cwd=testroot,text=True,capture_output=True)
assert applied.returncode==0 and target.read_text()==candidate
shutil.rmtree(testroot)
assert (ROOT/LOC).read_text()==raw
prod_status=subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True);assert not prod_status
validation={'manifest_exact':True,'341_unique_notes':True,'all_current_values_match_read_inventory':True,'independent_direct_reference_scan_matches_inventory':True,'unique_direct_references':475,'all_priority_placeholder_signatures_match':True,'exact_prior_union_pairs':22,'stale_prior_union_pairs':1,'exact_historical_current_pairs':331,'exact_historical_independent_proposals_integrated':10,'individual_historical_independent_receipt_hashes_verified':10,'context_holds_preserved':sorted(holds),'candidate_xml_parses':True,'candidate_resource_identity_preserved':True,'candidate_changed_keys':sorted(optional),'isolated_patch_check':{'exit_code':check.returncode,'stderr':check.stderr},'isolated_patch_apply_matches_candidate':True,'production_catalogue_unchanged':True,'production_git_status_clean':True,'static_composition_example_count':len(examples),'not_run':['Gradle','build','Android resource compilation','APK','CI','JVM/Android runtime','device','installed UI','TalkBack','native-human review','publication','release'],'caveat':'Only artifact/static integrity checks ran. Their success is not linguistic or runtime certification.'}
dump(OUT/'validation.json',validation)
print(json.dumps(summary,ensure_ascii=False,indent=2)); print('Static integrity verification complete. Application source unchanged.')
