# South Korean ko-KR P0/P1 linguistic rereview

## Result

All **341 typed priority keys** were read as complete current English/Korean pairs: **92 P0 + 249 P1**, all strings.

- **338 retain bounded current acceptance:** 311 with inspected direct static consumers and 27 with wording-only scope.
- **3 existing context holds remain:** `ui_discard`, `ui_save_as`, and `ui_main23`.
- **0 required P0/P1 wording corrections identified.**
- **1 optional action-label refinement** is supplied as an unapplied candidate: `ui_none`, `없음` → `모두 선택 해제`. The current text remains understandable and accepted in its All/None selection context. The proposal makes the clear-selection action explicit; it is not presented as a proven mistranslation, functional defect or required fix.

This is model-based linguistic and static-source review, not native-human certification, installed-UI acceptance, TalkBack testing or whole-language completion. The scope is the canonical South Korean `values-b+ko+KR` catalogue only, not generic Korean, mixed-script Korean or North Korean.

## Reconciliation matters

The old union's 23 mapped Korean receipts were not the whole available review history. A separate full priority review exists at source revision `0134e79c588a027bbd239f7685fff52b0771819f`. This package preserves that complete report and its ten independent proposal-review receipts.

- Its original dispositions were 327 accepted current pairs, 10 proposed corrections, 3 uncertainty holds and 1 prior-current receipt.
- All 341 English priority values still match that review.
- 331 Korean values still match the old current text, including the three holds.
- The other 10 Korean values now match the independently accepted proposals exactly. The current source fixture also records those ten full corrected messages and the three retained holds.
- The 327 old acceptances and the one prior receipt are retained with their limits, not claimed as new unique review coverage. The ten implemented corrections are rebound to their accepted proposals rather than crediting the old rejected wording.

The current full batch therefore supports **338 bounded priority acceptances**, not “341 newly accepted translations.” Original confidence, scope, provenance and uncertainty remain available in the copied historical reports and per-entry references.

### One stale old receipt outside P0/P1

Of the old union's 23 records, **22 still match the complete current English/Korean pair**. One does not: `ui_add_up_to_20_images_with_android_s`, the long assembly help text.

Its Korean text remains unchanged, but the English now adds Exact position/free-overlap guidance, scopes the origin and overlap rules to snapping, and revises unplacement behavior. The Korean still has the older unconditional overlap prohibition and no Exact position paragraph. The old receipt is retained as historical evidence but **does not receive current acceptance credit**. This is separately documented, not smuggled into the 341-key count or treated as a newly completed P2/P3 review. No replacement is proposed in this package.

After deduplicating the one priority overlap, the conservative combined current mapping is:

- **359 bounded accepted pairs:** 338 priority plus 21 exact prior pairs outside the batch.
- **3 priority context holds.**
- **1 stale out-of-batch source pair requiring rereview.**
- **354 other present entries without mapped current acceptance in these reconciled sources.**

These total the 717 present typed entries. Unmapped means unknown in this reconciliation, not “bad translation” or “never reviewed.” This is a lower-bound evidence mapping, not whole-language acceptance.

## Source binding

Reviewed published commit: `4355869e2e198b5616419291cba225b018444fab`.

Exact reviewed tree: `b9b148d5d8ef7c7b088500a9c177f9f59304b800`.

Observed local checkout HEAD: `ddffe57016c689b2a7868c31e415dcb625f5c6b5`; its tree is the same. The parent independently verified that the published commit has this exact tree. The different local commit is not represented as current develop.

The parent reports that later develop commits `ef46e8aa` / `c96f9708` change six Fit/status code, test and documentation paths without changing resources. **This review does not claim all of those later consumers were reviewed.** All source permalinks, hashes and static conclusions here bind to the published reviewed commit above.

The 341-key manifest was reconciled exactly. An independent direct-reference scan found 475 unique production references; 30 priority keys had none. The absence of a direct reference is not proof that indirect use is impossible. The prior review's five changed consumer files were inspected as a source diff; their changed bytes were not accepted merely because the resource values matched.

## Linguistic and composition checks

The review retained complete safety-critical meanings, including:

- save/export/share distinctions and unchanged Save destination;
- exact menu labels in recovery instructions and canvas navigation guidance;
- preserved drafts, credits, source files and original images;
- memory budgets, decoding floors, alternative remedies and no automatic resizing;
- first-frame/separate-default-image import and loss of animation;
- canvas anchoring, crop bounds, whole-pixel requirements and Undo restoration;
- placeholder roles, hexadecimal prefix ownership, dimensions, limits, arbitrary filenames and appended diagnostic text.

Static compositions cover exact and lower-bound frame counts, width/height units, every crop edge in pixel/percentage modes, selected tool announcements, colour values, filenames, numeric prompts, memory messages, recovery instructions and status text. Korean number-neutral nouns and independent noun labels do not inherit unrelated plural/gender issues from other languages. Out-of-batch resource values read for composition receive **context-only**, not extra P2/P3 coverage.

The `ui_save_a5d0d9` alias was resolved to `ui_save` (`저장`) in static XML. Its shorter button label is retained intentionally rather than treating the alias text as a translation or forcing an ellipsis. No Android resource resolution was executed.

## Remaining context holds

- `ui_discard`: the target adds “changes” to bare “Discard,” without a caller establishing that referent.
- `ui_save_as`: the target assumes `%1$s` is a format, without a caller establishing the token's meaning.
- `ui_main23`: `기본` means basic/default; the absent section context prevents confirming that this is the intended “Main.”

These are **unresolved context questions**, not newly asserted translation failures. No speculative replacements are supplied. A demonstrated consumer or explicit intended role is needed before lifting them.

## Deliverables

- `korean-p0-p1-review.json`: authoritative 341-entry ledger, exact full values, per-key rereview notes, original rationales, placeholders, aliases, consumers, source permalinks and current/candidate dispositions.
- `korean-p0-p1-review.csv`: flat companion ledger.
- `summary.json`: precise scope and reconciled counts.
- `prior-priority-reconciliation.json`: all 341 prior/current pair comparisons.
- `historical-priority-review.json`: unchanged original full priority report, with its original limitations.
- `historical-independent-proposals.json`: unchanged independent review of the ten now-integrated historical proposals.
- `prior-23-binding-reconciliation.json`: all 23 old mapped records, original/later receipts, historical/current full values, 22 exact bindings and one stale binding.
- `outside-priority-stale-help-finding.json`: the out-of-batch assembly-help source mismatch, separately scoped.
- `optional-refinement.json`: one optional clear-selection wording proposal and exact consumer.
- `korean-optional-action-label.patch`: source-bound one-value candidate patch, **not applied to production**.
- `candidate/Paintroid/src/main/res/values-b+ko+KR/strings.xml`: complete optional candidate catalogue.
- `static-composition-examples.json`: 36 illustrative substitutions and exact context dependencies, not runtime tests.
- `source-file-binding.json` and `consumer-changes-since-prior.diff`: exact source identities and the inspected source delta.
- `validation.json`: artifact/static integrity checks and explicitly unrun stages.
- `current-rereview-notes.tsv`: individually authored current-pass notes for all 341 identities.
- `package_review.py`: reproducible evidence packaging and static identity checks. It does not translate or assign judgments from a heuristic.

## Verification and non-actions

Completed: exact manifest/unique-key reconciliation; 341 individual notes; independent direct-reference scan; placeholder position/type signatures; static alias and composition inspection; all old receipt bindings; all ten integrated proposal matches; candidate XML and resource identity checks; exactly one optional changed value; isolated-copy patch check/application with exact candidate equality; unchanged production catalogue and clean checkout.

Not performed: builds, Gradle, Android compilation, APK creation, CI, JVM/Android runtime checks, emulators, devices, installed UI, screenshots, font/layout checks, TalkBack, native-human review, source integration, version changes, publication, releases, PRs or merges. Static integrity checks do not establish linguistic or runtime correctness by themselves.

**PR #56 remains an intentional draft tracker and must never be merged.** The parent owns any durable repository publication or later integration.
